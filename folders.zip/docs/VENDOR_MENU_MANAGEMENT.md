# Vendor Menu Management System

## Overview

The Vendor Menu Management System provides comprehensive tools for restaurant vendors to manage their menu items, categories, inventory, and pricing. This system includes features for individual item management, bulk CSV import/export, inventory tracking with auto-disable functionality, and image handling with GD library processing.

## Features

### ✅ **Core Menu Management**
- **CRUD Operations**: Create, read, update, and delete menu items
- **Category Management**: Organize items into customizable categories
- **Image Upload**: GD library integration for image processing and optimization
- **Inventory Tracking**: Real-time stock quantity management
- **Auto-disable**: Automatic item disabling when out of stock
- **Bulk Operations**: CSV import/export for efficient menu management

### ✅ **Advanced Features**
- **Dietary Options**: Vegetarian, vegan, and gluten-free indicators
- **Customization Options**: Flexible item customization with pricing
- **Nutritional Information**: Calories and ingredient tracking
- **Allergen Management**: Comprehensive allergen information
- **Stock Alerts**: Low stock notifications and management
- **Performance Analytics**: Menu item statistics and insights

## Architecture

### **MVC Structure**
```
src/
├── controllers/
│   └── VendorMenuController.php     # Main menu management controller
├── models/
│   ├── MenuItem.php                 # Menu item model with inventory
│   ├── MenuCategory.php             # Category management model
│   └── Restaurant.php               # Restaurant profile integration
└── views/
    └── vendor/
        └── menu/
            ├── dashboard.php        # Menu overview dashboard
            ├── index.php           # Menu items listing
            ├── create.php          # Create/edit item form
            └── import.php          # CSV import interface
```

### **Database Schema**
```sql
-- Menu Categories Table
menu_categories:
- id (Primary Key)
- restaurant_id (Foreign Key)
- name (VARCHAR 100)
- description (TEXT)
- sort_order (INT)
- is_active (TINYINT)
- parent_id (Foreign Key, nullable)
- created_at, updated_at

-- Enhanced Menu Items Table
menu_items:
- id (Primary Key)
- restaurant_id (Foreign Key)
- category_id (Foreign Key)
- name, description, price
- image_url
- stock_quantity, min_stock_level
- preparation_time, calories
- ingredients, allergens
- is_vegetarian, is_vegan, is_gluten_free
- customization_options (JSON)
- is_available, deleted_at
- created_at, updated_at
```

## Controller Methods

### **VendorMenuController**

#### **Dashboard & Listing**
- `dashboard()`: Menu overview with statistics and quick actions
- `index()`: Paginated menu items list with filters
- `getRestaurantItems()`: Filtered item retrieval with pagination

#### **CRUD Operations**
- `create()`: Show create form
- `store()`: Process new item creation with validation
- `edit($id)`: Show edit form for existing item
- `update($id)`: Process item updates
- `delete($id)`: Soft delete menu item

#### **Inventory Management**
- `updateStock($id)`: Update stock quantity with auto-disable
- `toggleAvailability($id)`: Enable/disable item availability

#### **Bulk Operations**
- `showImport()`: Display CSV import interface
- `importCsv()`: Process CSV file import
- `downloadTemplate()`: Generate CSV template file

#### **Helper Methods**
- `handleImageUpload()`: GD library image processing
- `validateMenuItemData()`: Comprehensive data validation
- `processCsvImport()`: CSV parsing and validation
- `findOrCreateCategory()`: Dynamic category management

## Models

### **MenuItem Model**

#### **Core Methods**
```php
// CRUD Operations
createItem(array $data): ?int
updateItem(int $id, array $data): bool
deleteItem(int $id): bool

// Retrieval Methods
getRestaurantItems(int $restaurantId, ...): array
getRestaurantStats(int $restaurantId): array
getRecentItems(int $restaurantId, int $limit): array
getLowStockItems(int $restaurantId): array

// Inventory Management
updateStock(int $itemId, int $quantity): bool
checkLowStock(int $restaurantId): array
```

### **MenuCategory Model**

#### **Category Management**
```php
// CRUD Operations
createCategory(array $data): ?int
updateCategory(int $id, array $data): bool
deleteCategory(int $id): bool

// Retrieval Methods
getByRestaurant(int $restaurantId): array
getCategoryWithItemCount(int $restaurantId): array
findByName(string $name, int $restaurantId): ?array

// Organization
updateSortOrder(int $id, int $sortOrder): bool
reorderCategories(int $restaurantId, array $categoryIds): bool
```

## Views

### **Dashboard (`dashboard.php`)**
- **Statistics Cards**: Total items, available, low stock, out of stock
- **Recent Items**: Latest menu additions with quick actions
- **Low Stock Alerts**: Items requiring attention
- **Category Overview**: Category list with item counts
- **Quick Actions**: Direct links to common operations

### **Menu Items List (`index.php`)**
- **Advanced Filters**: Search, category, status filtering
- **Grid Layout**: Responsive card-based item display
- **Inline Actions**: Edit, toggle availability, update stock, delete
- **Pagination**: Efficient large menu handling
- **Bulk Operations**: Multi-select actions

### **Create/Edit Form (`create.php`)**
- **Comprehensive Form**: All item properties in organized sections
- **Image Upload**: Drag-and-drop with preview
- **Validation**: Real-time client-side validation
- **Dietary Options**: Checkbox selections for dietary preferences
- **Customization**: Flexible customization options input

### **CSV Import (`import.php`)**
- **Template Download**: Pre-formatted CSV template
- **Import Instructions**: Step-by-step guidance
- **Field Reference**: Complete field format documentation
- **Results Display**: Import success/error reporting
- **Progress Tracking**: Real-time import progress

## Image Handling

### **GD Library Integration**
```php
private function handleImageUpload(array $file): ?string
{
    // Validation
    - File type validation (JPEG, PNG, WebP)
    - Size limit enforcement (5MB)
    - Security checks
    
    // Processing
    - Image resource creation
    - Automatic resizing (max 800x600)
    - Quality optimization
    - Format conversion support
    
    // Storage
    - Unique filename generation
    - Directory structure creation
    - File path return
}
```

### **Supported Formats**
- **JPEG**: Quality 85% compression
- **PNG**: Compression level 6 with transparency
- **WebP**: Quality 85% compression
- **Auto-resize**: Maximum 800x600 pixels
- **File size**: Maximum 5MB upload

## CSV Import/Export

### **Import Process**
1. **Template Download**: Standardized CSV format
2. **Data Validation**: Field format and requirement checks
3. **Category Handling**: Auto-creation of missing categories
4. **Batch Processing**: Efficient bulk item creation
5. **Error Reporting**: Detailed validation error messages

### **CSV Format**
```csv
name,description,price,category_name,stock_quantity,preparation_time,calories,ingredients,allergens,is_vegetarian,is_vegan,is_gluten_free,customization_options
"Jollof Rice","Delicious Nigerian jollof rice with chicken","2500","Main Dishes","50","20","450","Rice, Chicken, Tomatoes, Onions, Spices","None","no","no","yes","Extra chicken, Spicy level"
```

### **Field Specifications**
- **Required**: name, description, price, category_name
- **Optional**: All other fields with sensible defaults
- **Boolean**: Accepts 1/true/yes/y for true, anything else for false
- **JSON**: Customization options as comma-separated values

## Inventory Management

### **Stock Tracking**
- **Real-time Updates**: Immediate stock quantity changes
- **Low Stock Alerts**: Configurable minimum stock levels
- **Auto-disable**: Automatic unavailability when stock reaches zero
- **Bulk Updates**: Efficient multi-item stock management

### **Auto-disable Logic**
```php
// Triggered on stock update
if ($stockQuantity === 0) {
    $updateData['is_available'] = 0;  // Auto-disable
} elseif ($stockQuantity > 0 && !$item['is_available']) {
    $updateData['is_available'] = 1;  // Auto-enable
}
```

## Security Features

### **Authentication & Authorization**
- **Role-based Access**: Vendor role requirement
- **Restaurant Ownership**: Vendors can only manage their own items
- **CSRF Protection**: Token-based form security
- **Input Validation**: Comprehensive server-side validation

### **File Upload Security**
- **Type Validation**: Strict image format enforcement
- **Size Limits**: Maximum file size restrictions
- **Path Sanitization**: Secure file path generation
- **Content Validation**: Image content verification

## Performance Optimizations

### **Database Optimization**
- **Indexes**: Strategic indexing for common queries
- **Views**: Pre-computed statistics and joins
- **Triggers**: Automated stock management
- **Pagination**: Efficient large dataset handling

### **Caching Strategy**
- **Query Caching**: Frequently accessed data caching
- **Image Optimization**: Automatic image compression
- **Lazy Loading**: Progressive content loading
- **CDN Ready**: Optimized for content delivery networks

## API Endpoints

### **AJAX Operations**
```javascript
// Stock Management
POST /vendor/menu/stock/{id}
Body: { "stock_quantity": 25 }

// Availability Toggle
POST /vendor/menu/toggle/{id}

// Item Deletion
DELETE /vendor/menu/delete/{id}

// CSV Import
POST /vendor/menu/import
Body: FormData with csv_file
```

## Error Handling

### **Validation Errors**
- **Field-level**: Individual field validation messages
- **Form-level**: Overall form validation status
- **User-friendly**: Clear, actionable error messages
- **Internationalization**: Multi-language error support

### **File Upload Errors**
- **Size Exceeded**: Clear file size limit messages
- **Invalid Format**: Supported format specifications
- **Processing Errors**: Image processing failure handling
- **Storage Errors**: File system error management

## Testing

### **Unit Tests**
```bash
# Run menu management tests
php tests/VendorMenuControllerTest.php
php tests/MenuItemModelTest.php
php tests/MenuCategoryModelTest.php
```

### **Integration Tests**
- **CSV Import**: Complete import workflow testing
- **Image Upload**: File upload and processing testing
- **Inventory Management**: Stock update and auto-disable testing
- **Category Management**: Category CRUD operations testing

## Usage Examples

### **Creating a Menu Item**
```php
// Controller usage
$data = [
    'restaurant_id' => $restaurantId,
    'category_id' => $categoryId,
    'name' => 'Jollof Rice',
    'description' => 'Delicious Nigerian jollof rice',
    'price' => 2500,
    'stock_quantity' => 50,
    'preparation_time' => 20,
    'is_available' => 1
];

$itemId = $this->menuItemModel->createItem($data);
```

### **Bulk CSV Import**
```php
// Process CSV file
$results = $this->processCsvImport($_FILES['csv_file'], $restaurantId);
// Returns: ['total' => 10, 'imported' => 8, 'errors' => [...]]
```

### **Stock Management**
```php
// Update stock with auto-disable
$this->menuItemModel->updateItem($itemId, [
    'stock_quantity' => 0  // Will auto-disable item
]);
```

## Deployment

### **Requirements**
- **PHP 8.0+**: Modern PHP with type declarations
- **GD Extension**: Image processing capabilities
- **MySQL 8.0+**: Advanced database features
- **File Permissions**: Write access to upload directories

### **Configuration**
```php
// config/app.php
'upload' => [
    'max_size' => 5 * 1024 * 1024,  // 5MB
    'allowed_types' => ['image/jpeg', 'image/png', 'image/webp'],
    'upload_path' => PUBLIC_PATH . '/images/menu/'
]
```

## Maintenance

### **Regular Tasks**
- **Image Cleanup**: Remove orphaned image files
- **Stock Audits**: Verify inventory accuracy
- **Category Optimization**: Reorganize category structure
- **Performance Monitoring**: Track query performance

### **Monitoring**
- **Low Stock Alerts**: Automated notification system
- **Upload Failures**: File upload error tracking
- **Import Errors**: CSV import failure monitoring
- **Performance Metrics**: Response time and throughput tracking

This comprehensive vendor menu management system provides restaurant owners with powerful tools to efficiently manage their menu offerings, inventory, and customer experience while maintaining high performance and security standards.
