# Time2Eat Search, Reviews, and Cancellations System

## Overview

This document outlines the comprehensive search functionality, ratings/reviews system, and order cancellations/refunds implementation for the Time2Eat food delivery platform. These features enhance user experience by providing powerful search capabilities, transparent feedback systems, and flexible order management.

## Search System

### Global Search Functionality

**SearchController** (`src/controllers/SearchController.php`):
- ✅ **Multi-Entity Search**: Simultaneous search across restaurants, menu items, and categories
- ✅ **Advanced Filtering**: Category, cuisine, price range, rating, dietary restrictions
- ✅ **Smart Relevance Scoring**: Intelligent ranking based on name matching, ratings, and popularity
- ✅ **Real-time Suggestions**: Auto-complete with type-ahead search suggestions
- ✅ **Search Analytics**: Track popular searches and user behavior

### Search Features

**1. Search Interface** (`src/views/search/index.php`):
- Modern, responsive search interface with Tailwind CSS
- Advanced filter sidebar with multiple criteria
- Grid/list view toggle for results display
- Real-time search suggestions with debouncing
- Active filter badges with easy removal

**2. Search Capabilities**:
- **Text Search**: Full-text search across names, descriptions, ingredients
- **Category Filtering**: Filter by food categories and cuisine types
- **Price Range**: Flexible price range filtering with predefined ranges
- **Rating Filter**: Minimum rating requirements (2+, 3+, 4+ stars)
- **Dietary Options**: Vegetarian, vegan, gluten-free filtering
- **Location-based**: Search by delivery area and restaurant location

**3. Search Optimization**:
- Full-text indexes on key searchable fields
- Search keyword enhancement for better matching
- Priority scoring based on ratings and popularity
- Caching of popular search results
- Search analytics for continuous improvement

### Search API Endpoints

```php
// Main search page
GET /search?q=query&category=1&cuisine=italian&sort=rating

// Live search suggestions
GET /search/suggestions?q=pizza

// Real-time search results
GET /search/live?q=burger&filters[]=category:1

// API search endpoint
GET /api/v1/search?q=query&limit=20
```

## Reviews and Ratings System

### Comprehensive Review Management

**ReviewController** (`src/controllers/ReviewController.php`):
- ✅ **Multi-Entity Reviews**: Rate restaurants, menu items, and delivery riders
- ✅ **Verified Reviews**: Only customers who completed orders can review
- ✅ **Review Moderation**: Admin approval system with spam protection
- ✅ **Helpful Voting**: Users can mark reviews as helpful
- ✅ **Review Reporting**: Report inappropriate or fake reviews

**Review Model** (`src/models/Review.php`):
- ✅ **Comprehensive Analytics**: Rating distributions, trends, and statistics
- ✅ **Featured Reviews**: Highlight exceptional reviews for marketing
- ✅ **Review Aggregation**: Calculate average ratings and review counts
- ✅ **Review Filtering**: Filter by rating, date, verification status

### Review Features

**1. Review Creation** (`src/views/reviews/create.php`):
- Interactive star rating system with hover effects
- Separate ratings for restaurant, individual items, and delivery
- Rich text comments with character limits
- Auto-save draft functionality
- Mobile-optimized interface

**2. Review Display**:
- Star rating visualization with distribution charts
- Verified purchase badges for authentic reviews
- Helpful vote counts and user interactions
- Review filtering and sorting options
- Responsive design for all devices

**3. Review Management**:
- Admin moderation dashboard
- Bulk approval/rejection tools
- Spam detection and filtering
- Review analytics and reporting
- Featured review selection

### Review Workflow

1. **Order Completion**: Customer completes order successfully
2. **Review Invitation**: System sends review invitation email/SMS
3. **Review Creation**: Customer accesses review form from order history
4. **Multi-Entity Rating**: Rate restaurant, items, and delivery separately
5. **Moderation**: Admin reviews and approves/rejects submissions
6. **Publication**: Approved reviews appear on restaurant/item pages
7. **Interaction**: Other users can mark reviews as helpful or report issues

## Cancellations and Refunds System

### Intelligent Cancellation Management

**CancellationController** (`src/controllers/CancellationController.php`):
- ✅ **Smart Cancellation Rules**: Time-based and status-based cancellation policies
- ✅ **Automatic Approval**: Instant approval for eligible early-stage cancellations
- ✅ **Refund Processing**: Automated refund calculation and processing
- ✅ **Multi-Role Support**: Customer, vendor, and admin cancellation capabilities
- ✅ **Comprehensive Tracking**: Full audit trail of cancellation requests

**Cancellation Model** (`src/models/Cancellation.php`):
- ✅ **Advanced Analytics**: Cancellation rates, trends, and reason analysis
- ✅ **Performance Metrics**: Average review times and approval rates
- ✅ **Automated Processing**: Auto-approval for eligible cancellations
- ✅ **Reporting Tools**: Comprehensive cancellation reporting and insights

### Cancellation Features

**1. Cancellation Interface** (`src/views/cancellations/create.php`):
- Clear cancellation policy display
- Refund amount calculation and timeline
- Structured reason selection with custom details
- Confirmation workflow with policy acknowledgment
- Real-time status updates

**2. Cancellation Rules**:
- **Pending Orders**: 100% refund, instant approval
- **Confirmed Orders (≤5 min)**: 100% refund, instant approval
- **Confirmed Orders (≤15 min)**: 90% refund, requires approval
- **Preparing Orders**: 75% refund, requires approval
- **Ready Orders**: 50% refund, requires approval
- **Picked Up/Delivered**: No cancellation allowed

**3. Refund Processing**:
- Automatic refund percentage calculation
- Integration with payment gateways for refund processing
- Refund status tracking and notifications
- Multiple refund methods support
- Refund timeline communication

### Cancellation Workflow

1. **Cancellation Request**: Customer initiates cancellation from order page
2. **Eligibility Check**: System validates cancellation eligibility and refund amount
3. **Reason Collection**: Customer provides cancellation reason and details
4. **Automatic Processing**: Eligible cancellations are approved instantly
5. **Manual Review**: Complex cases require admin/vendor approval
6. **Refund Processing**: Approved cancellations trigger refund workflow
7. **Notification**: All parties receive status updates via email/SMS

## Database Schema

### New Tables

**review_helpful**: Track helpful votes on reviews
**review_reports**: Manage review reporting and moderation
**order_cancellations**: Complete cancellation request management
**search_analytics**: Track search behavior and popular terms
**user_search_preferences**: Store user search preferences
**review_drafts**: Save incomplete reviews for later completion

### Enhanced Tables

**restaurants**: Added search keywords and priority scoring
**menu_items**: Added search optimization fields
**orders**: Added review and cancellation tracking
**reviews**: Added approval and moderation fields

## API Integration

### Search API

```php
// Search with filters
GET /api/v1/search?q=pizza&category=1&min_rating=4&sort=rating

// Search suggestions
GET /search/suggestions?q=piz

// Live search results
GET /search/live?q=pizza&restaurant_id=5
```

### Reviews API

```php
// Get reviews for entity
GET /api/v1/reviews?type=restaurant&id=1&page=1&limit=10

// Submit review
POST /reviews/store
{
    "order_id": 123,
    "restaurant_rating": 5,
    "restaurant_comment": "Excellent food!",
    "item_reviews": {...}
}

// Mark review helpful
POST /reviews/123/helpful
```

### Cancellations API

```php
// Request cancellation
POST /cancellations/store
{
    "order_id": 123,
    "reason": "changed_mind",
    "details": "Found better option"
}

// Admin approve cancellation
POST /admin/cancellations/456/approve
{
    "notes": "Approved due to restaurant delay"
}
```

## User Experience Features

### Search Experience
- **Instant Results**: Real-time search with debounced input
- **Smart Suggestions**: Contextual auto-complete suggestions
- **Visual Filters**: Easy-to-use filter interface with visual feedback
- **Result Highlighting**: Search term highlighting in results
- **Mobile Optimization**: Touch-friendly interface for mobile users

### Review Experience
- **Interactive Rating**: Smooth star rating with visual feedback
- **Progress Saving**: Auto-save drafts to prevent data loss
- **Rich Feedback**: Support for detailed comments and ratings
- **Social Proof**: Display helpful votes and verification badges
- **Easy Navigation**: Seamless integration with order history

### Cancellation Experience
- **Clear Policies**: Transparent cancellation and refund policies
- **Real-time Calculation**: Instant refund amount calculation
- **Status Tracking**: Live updates on cancellation request status
- **FAQ Integration**: Built-in help and frequently asked questions
- **Multi-channel Notifications**: Email and SMS status updates

## Analytics and Reporting

### Search Analytics
- Popular search terms and trends
- Search success rates and click-through rates
- User search behavior patterns
- Filter usage statistics
- Performance optimization insights

### Review Analytics
- Rating distributions and trends
- Review volume and engagement metrics
- Sentiment analysis and feedback themes
- Moderation efficiency statistics
- Featured review performance

### Cancellation Analytics
- Cancellation rates by restaurant and time period
- Reason analysis and trend identification
- Refund processing metrics
- Customer satisfaction impact
- Operational efficiency measurements

## Security and Moderation

### Search Security
- Input sanitization and SQL injection prevention
- Rate limiting on search API endpoints
- Search query logging and monitoring
- Spam search detection and blocking

### Review Security
- Verified purchase requirements
- Duplicate review prevention
- Spam detection algorithms
- Content moderation tools
- User reporting mechanisms

### Cancellation Security
- Authorization checks for cancellation requests
- Fraud detection for excessive cancellations
- Secure refund processing
- Audit trails for all cancellation actions
- Role-based access controls

## Performance Optimization

### Search Performance
- Full-text search indexes
- Search result caching
- Query optimization
- Elasticsearch integration (future)
- CDN for search assets

### Review Performance
- Efficient rating aggregation
- Review pagination
- Image optimization
- Lazy loading implementation
- Database query optimization

### Cancellation Performance
- Automated processing workflows
- Background refund processing
- Efficient status tracking
- Optimized notification delivery
- Scalable approval workflows

This comprehensive search, reviews, and cancellations system provides Time2Eat with enterprise-grade functionality that enhances user experience, builds trust through transparency, and provides flexible order management capabilities while maintaining high performance and security standards.
