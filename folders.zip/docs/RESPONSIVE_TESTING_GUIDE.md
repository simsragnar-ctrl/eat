# Time2Eat Responsive Testing Guide

## 🧪 Comprehensive Testing Suite for Responsive Design & Cross-Browser Compatibility

This guide provides complete instructions for testing the Time2Eat application across different devices, browsers, and scenarios to ensure optimal user experience.

## 📋 Table of Contents

1. [Quick Start](#quick-start)
2. [Testing Tools](#testing-tools)
3. [Device Testing](#device-testing)
4. [Cross-Browser Testing](#cross-browser-testing)
5. [PWA Testing](#pwa-testing)
6. [Performance Testing](#performance-testing)
7. [Accessibility Testing](#accessibility-testing)
8. [Manual Testing Checklist](#manual-testing-checklist)
9. [Automated Testing](#automated-testing)
10. [Troubleshooting](#troubleshooting)

## 🚀 Quick Start

### Running All Tests

```bash
# Navigate to the tests directory
cd tests/responsive

# Run PHP-based tests
php test-runner.php

# Or run with specific format
php test-runner.php?format=html
php test-runner.php?format=text
```

### Browser-Based Testing

1. Open your Time2Eat application in a browser
2. Add `?pwa-test=1` to the URL to enable PWA testing
3. Open browser developer tools (F12)
4. Check console for test results

## 🛠️ Testing Tools

### 1. Device Emulator (`device-emulator.js`)

**Features:**
- Real-time device switching
- Touch simulation
- Viewport testing
- Screenshot capture
- Responsive breakpoint testing

**Usage:**
```javascript
// Initialize device emulator
const emulator = new DeviceEmulator();

// Switch to specific device
emulator.switchDevice('iphone_12');

// Run device-specific tests
emulator.runTests();
```

### 2. Cross-Browser Test Suite (`cross-browser-test.js`)

**Features:**
- Browser feature detection
- CSS compatibility testing
- JavaScript compatibility
- Automatic polyfill loading
- Performance recommendations

**Usage:**
```javascript
// Initialize cross-browser testing
const crossBrowserTest = new CrossBrowserTestSuite();

// Results available in console and UI
```

### 3. PWA Test Suite (`pwa-test.js`)

**Features:**
- Service Worker testing
- Manifest validation
- Offline capability testing
- Push notification testing
- Installation testing

**Usage:**
```javascript
// Initialize PWA testing
const pwaTest = new PWATestSuite();

// Run specific PWA tests
await pwaTest.testServiceWorker();
await pwaTest.testManifest();
```

### 4. PHP Test Runner (`test-runner.php`)

**Features:**
- Comprehensive test orchestration
- HTML and text report generation
- Test result archiving
- Recommendation engine

## 📱 Device Testing

### Supported Device Profiles

#### Mobile Devices (320px - 480px)
- **iPhone SE**: 375×667px, 2x pixel ratio
- **iPhone 12**: 390×844px, 3x pixel ratio
- **Samsung Galaxy S21**: 384×854px, 2.75x pixel ratio
- **Google Pixel 5**: 393×851px, 2.75x pixel ratio
- **Very Small Screen**: 320×568px (edge case)

#### Tablets (768px - 1024px)
- **iPad**: 768×1024px, 2x pixel ratio
- **iPad Pro**: 1024×1366px, 2x pixel ratio
- **Samsung Galaxy Tab S7**: 753×1037px, 2.4x pixel ratio

#### Desktop (1024px+)
- **Small Desktop**: 1024×768px
- **Medium Desktop**: 1366×768px
- **Large Desktop**: 1920×1080px
- **Ultra Wide**: 3440×1440px (edge case)

### Device Testing Checklist

#### Layout Testing
- [ ] Container responsiveness
- [ ] Grid system behavior
- [ ] Flexbox layouts
- [ ] Text wrapping
- [ ] Image scaling
- [ ] Navigation adaptation

#### Touch Testing (Mobile/Tablet)
- [ ] Touch target size (minimum 44px)
- [ ] Swipe gestures
- [ ] Pinch-to-zoom
- [ ] Touch feedback
- [ ] Scroll behavior

#### Typography Testing
- [ ] Font size readability
- [ ] Line height spacing
- [ ] Text contrast
- [ ] Font loading
- [ ] Text overflow handling

## 🌐 Cross-Browser Testing

### Supported Browsers

#### Modern Browsers
- **Chrome 90+**: Full feature support
- **Firefox 88+**: Full feature support
- **Safari 14+**: Limited PWA support
- **Edge 90+**: Full feature support

#### Legacy Browsers
- **Internet Explorer 11**: Limited support with polyfills
- **Safari 13**: Partial PWA support
- **Chrome 80-89**: Mostly supported

### Browser-Specific Issues

#### Safari
- Limited Service Worker support
- WebP image format not supported in older versions
- Push notifications require user interaction
- Backdrop-filter may need prefixes

#### Internet Explorer 11
- No CSS Grid support (use Flexbox fallback)
- No ES6 support (requires transpilation)
- No fetch API (requires polyfill)
- Limited CSS custom properties

#### Firefox
- Backdrop-filter requires flag in older versions
- Some CSS features may need prefixes

### Cross-Browser Testing Process

1. **Feature Detection**
   ```javascript
   // Check CSS Grid support
   if (CSS.supports('display', 'grid')) {
       // Use CSS Grid
   } else {
       // Use Flexbox fallback
   }
   ```

2. **Polyfill Loading**
   ```javascript
   // Automatic polyfill loading
   if (!window.fetch) {
       loadPolyfill('fetch-polyfill.js');
   }
   ```

3. **Progressive Enhancement**
   ```css
   /* Base styles for all browsers */
   .container {
       display: flex;
   }
   
   /* Enhanced styles for modern browsers */
   @supports (display: grid) {
       .container {
           display: grid;
           grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
       }
   }
   ```

## 🚀 PWA Testing

### Service Worker Testing

#### Registration Test
```javascript
// Check if Service Worker is registered
navigator.serviceWorker.getRegistration()
    .then(registration => {
        if (registration) {
            console.log('✅ Service Worker registered');
        } else {
            console.log('❌ Service Worker not registered');
        }
    });
```

#### Caching Test
```javascript
// Test cache functionality
caches.keys().then(cacheNames => {
    console.log('Available caches:', cacheNames);
    
    if (cacheNames.length > 0) {
        return caches.open(cacheNames[0]);
    }
}).then(cache => {
    if (cache) {
        return cache.keys();
    }
}).then(cachedRequests => {
    console.log('Cached resources:', cachedRequests.length);
});
```

### Manifest Testing

#### Validation Checklist
- [ ] Manifest file exists and is valid JSON
- [ ] Required fields present (name, short_name, start_url, display, icons)
- [ ] Icons include 192x192 and 512x512 sizes
- [ ] Theme color matches design
- [ ] Background color specified
- [ ] Display mode appropriate (standalone/fullscreen)

### Offline Testing

#### Manual Offline Test
1. Open application in browser
2. Open Developer Tools → Network tab
3. Check "Offline" checkbox
4. Refresh page
5. Verify offline page loads
6. Test core functionality

#### Programmatic Offline Test
```javascript
// Simulate offline condition
window.addEventListener('online', () => {
    console.log('✅ Back online');
});

window.addEventListener('offline', () => {
    console.log('📴 Gone offline');
});

// Test offline capability
if (!navigator.onLine) {
    // Test offline functionality
}
```

## ⚡ Performance Testing

### Core Web Vitals

#### Largest Contentful Paint (LCP)
- **Target**: < 2.5 seconds
- **Test**: Use Lighthouse or WebPageTest
- **Optimization**: Optimize images, reduce server response time

#### First Input Delay (FID)
- **Target**: < 100 milliseconds
- **Test**: Real user interaction testing
- **Optimization**: Reduce JavaScript execution time

#### Cumulative Layout Shift (CLS)
- **Target**: < 0.1
- **Test**: Visual stability testing
- **Optimization**: Set image dimensions, avoid dynamic content insertion

### Performance Testing Tools

#### Browser DevTools
```javascript
// Measure performance
performance.mark('start');
// ... code to measure
performance.mark('end');
performance.measure('operation', 'start', 'end');

const measures = performance.getEntriesByType('measure');
console.log('Performance:', measures);
```

#### Lighthouse Testing
```bash
# Install Lighthouse CLI
npm install -g lighthouse

# Run Lighthouse audit
lighthouse https://your-domain.com --output html --output-path ./lighthouse-report.html
```

## ♿ Accessibility Testing

### WCAG 2.1 Compliance

#### Level A Requirements
- [ ] Images have alt text
- [ ] Form inputs have labels
- [ ] Headings are properly structured
- [ ] Color is not the only means of conveying information

#### Level AA Requirements
- [ ] Color contrast ratio ≥ 4.5:1 for normal text
- [ ] Color contrast ratio ≥ 3:1 for large text
- [ ] Text can be resized up to 200% without loss of functionality
- [ ] All functionality available via keyboard

### Accessibility Testing Tools

#### Automated Testing
```javascript
// Check color contrast
function checkColorContrast(element) {
    const styles = window.getComputedStyle(element);
    const color = styles.color;
    const backgroundColor = styles.backgroundColor;
    
    // Calculate contrast ratio
    const ratio = calculateContrastRatio(color, backgroundColor);
    return ratio >= 4.5; // WCAG AA standard
}
```

#### Manual Testing
1. **Keyboard Navigation**
   - Tab through all interactive elements
   - Ensure focus indicators are visible
   - Test keyboard shortcuts

2. **Screen Reader Testing**
   - Use NVDA (Windows) or VoiceOver (Mac)
   - Verify content is read in logical order
   - Check ARIA labels and descriptions

## ✅ Manual Testing Checklist

### Mobile Testing (320px - 768px)

#### Layout
- [ ] Content fits within viewport
- [ ] No horizontal scrolling
- [ ] Touch targets ≥ 44px
- [ ] Text is readable without zooming
- [ ] Images scale appropriately

#### Navigation
- [ ] Mobile menu works correctly
- [ ] Hamburger menu accessible
- [ ] Navigation items are touch-friendly
- [ ] Back button functionality

#### Forms
- [ ] Input fields are appropriately sized
- [ ] Virtual keyboard doesn't obscure inputs
- [ ] Form validation works on mobile
- [ ] Submit buttons are accessible

#### Performance
- [ ] Page loads within 3 seconds on 3G
- [ ] Images load progressively
- [ ] Smooth scrolling and animations
- [ ] No layout shifts during loading

### Tablet Testing (768px - 1024px)

#### Layout
- [ ] Optimal use of screen real estate
- [ ] Content adapts to landscape/portrait
- [ ] Touch and mouse interactions work
- [ ] Appropriate font sizes

#### Navigation
- [ ] Navigation adapts to tablet layout
- [ ] Both touch and hover states work
- [ ] Swipe gestures function correctly

### Desktop Testing (1024px+)

#### Layout
- [ ] Content doesn't stretch too wide
- [ ] Proper use of whitespace
- [ ] Hover states work correctly
- [ ] Keyboard navigation functional

#### Performance
- [ ] Fast loading on broadband
- [ ] Smooth animations and transitions
- [ ] Efficient resource usage

## 🤖 Automated Testing

### Continuous Integration Setup

#### GitHub Actions Example
```yaml
name: Responsive Testing

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Setup PHP
      uses: shivammathur/setup-php@v2
      with:
        php-version: '8.1'
    
    - name: Run Responsive Tests
      run: php tests/responsive/test-runner.php
    
    - name: Upload Test Results
      uses: actions/upload-artifact@v2
      with:
        name: test-results
        path: tests/responsive/test-results-*.json
```

### Automated Browser Testing

#### Selenium WebDriver Example
```php
<?php
use Facebook\WebDriver\Remote\RemoteWebDriver;
use Facebook\WebDriver\WebDriverBy;

// Initialize WebDriver
$driver = RemoteWebDriver::create('http://localhost:4444/wd/hub', 
    DesiredCapabilities::chrome());

// Test different viewport sizes
$viewports = [
    ['width' => 375, 'height' => 667], // iPhone
    ['width' => 768, 'height' => 1024], // iPad
    ['width' => 1920, 'height' => 1080] // Desktop
];

foreach ($viewports as $viewport) {
    $driver->manage()->window()->setSize(
        new WebDriverDimension($viewport['width'], $viewport['height'])
    );
    
    $driver->get('https://your-domain.com');
    
    // Run tests for this viewport
    $this->runViewportTests($driver, $viewport);
}

$driver->quit();
?>
```

## 🔧 Troubleshooting

### Common Issues

#### Layout Issues
**Problem**: Content overflows on mobile
**Solution**: 
```css
.container {
    max-width: 100%;
    overflow-x: hidden;
    box-sizing: border-box;
}
```

**Problem**: Images don't scale properly
**Solution**:
```css
img {
    max-width: 100%;
    height: auto;
}
```

#### Touch Issues
**Problem**: Touch targets too small
**Solution**:
```css
.touch-target {
    min-width: 44px;
    min-height: 44px;
    padding: 12px;
}
```

#### Performance Issues
**Problem**: Slow loading on mobile
**Solution**:
- Optimize images (WebP format)
- Implement lazy loading
- Minimize JavaScript bundles
- Use CDN for static assets

#### PWA Issues
**Problem**: Service Worker not updating
**Solution**:
```javascript
// Force Service Worker update
navigator.serviceWorker.getRegistration().then(registration => {
    if (registration) {
        registration.update();
    }
});
```

### Debug Tools

#### Browser DevTools
- **Responsive Design Mode**: Test different screen sizes
- **Network Tab**: Monitor resource loading
- **Performance Tab**: Analyze runtime performance
- **Application Tab**: Inspect Service Workers and storage

#### Console Commands
```javascript
// Test responsive breakpoints
window.matchMedia('(max-width: 768px)').matches

// Check PWA installation status
window.matchMedia('(display-mode: standalone)').matches

// Test touch capability
'ontouchstart' in window

// Check Service Worker status
navigator.serviceWorker.controller
```

## 📊 Test Results Interpretation

### Status Indicators
- **✅ Pass**: Feature works correctly
- **❌ Fail**: Critical issue that needs fixing
- **⚠️ Warning**: Minor issue or enhancement opportunity

### Priority Levels
1. **Critical**: Breaks core functionality
2. **High**: Significantly impacts user experience
3. **Medium**: Minor usability issues
4. **Low**: Enhancement opportunities

### Action Items
Based on test results, prioritize fixes:
1. Fix all critical failures first
2. Address high-priority warnings
3. Implement recommended enhancements
4. Document known limitations

## 🎯 Best Practices

### Mobile-First Development
1. Start with mobile design (320px)
2. Progressively enhance for larger screens
3. Use relative units (rem, em, %)
4. Test on real devices when possible

### Performance Optimization
1. Optimize images for different screen densities
2. Implement lazy loading for below-fold content
3. Use efficient CSS selectors
4. Minimize JavaScript execution on main thread

### Accessibility
1. Ensure keyboard navigation works everywhere
2. Provide sufficient color contrast
3. Use semantic HTML elements
4. Test with screen readers

### Cross-Browser Compatibility
1. Use feature detection, not browser detection
2. Provide graceful fallbacks
3. Test in multiple browsers regularly
4. Use autoprefixer for CSS vendor prefixes

---

## 📞 Support

For questions or issues with the testing suite:

1. Check the troubleshooting section above
2. Review browser console for error messages
3. Verify all test files are properly included
4. Ensure PHP version compatibility (8.0+)

**Happy Testing! 🧪✨**
