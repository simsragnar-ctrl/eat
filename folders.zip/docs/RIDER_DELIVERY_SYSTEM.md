# Rider Delivery System Documentation

## Overview

The Rider Delivery System is a comprehensive solution for managing delivery operations in the Time2Eat food delivery platform. It provides riders with tools for accepting deliveries, real-time navigation, earnings tracking, and schedule management.

## Features

### 🚀 Core Features

1. **Delivery Acceptance & Management**
   - Real-time delivery requests
   - Accept/reject delivery functionality
   - Status updates (picked up, on the way, delivered)
   - Delivery history and tracking

2. **Real-time Navigation**
   - Turn-by-turn navigation
   - Route optimization
   - Distance and time estimation
   - Voice navigation support

3. **Location Tracking**
   - GPS-based real-time location updates
   - Battery level monitoring
   - Online/offline status management
   - Location accuracy tracking

4. **Earnings Management**
   - Real-time earnings calculation
   - Performance statistics
   - Earnings history and analytics
   - Commission tracking

5. **Schedule Management**
   - Weekly availability schedules
   - Working hours configuration
   - Maximum concurrent deliveries
   - Automatic availability detection

## Architecture

### Models

#### RiderSchedule Model
- Manages rider availability schedules
- Supports weekly schedule configuration
- Handles maximum concurrent deliveries
- Provides availability checking methods

#### RiderLocation Model
- Tracks real-time rider locations
- Stores GPS coordinates and metadata
- Manages online/offline status
- Provides nearby rider queries

#### Delivery Model (Enhanced)
- Extended with rider-specific functionality
- Earnings calculation
- Distance tracking
- Status management

### Controllers

#### RiderDeliveryController
- Handles delivery acceptance/rejection
- Manages status updates
- Provides navigation routes
- Tracks earnings and statistics

### Views

#### Delivery Dashboard
- Real-time delivery requests
- Active delivery management
- Earnings overview
- Performance statistics

#### Navigation Interface
- Interactive map with route display
- Turn-by-turn directions
- Status update controls
- Customer contact options

#### Earnings Dashboard
- Detailed earnings analytics
- Performance metrics
- Historical data visualization
- Period-based filtering

## API Endpoints

### Delivery Management

```http
GET /api/rider/available-deliveries
```
Get available deliveries nearby
- Parameters: `radius`, `limit`, `page`
- Returns: List of available deliveries with distance and earnings

```http
POST /api/rider/accept-delivery
```
Accept a delivery request
- Body: `{ "delivery_id": number }`
- Returns: Updated delivery details

```http
POST /api/rider/reject-delivery
```
Reject a delivery request
- Body: `{ "delivery_id": number, "reason": string }`
- Returns: Success confirmation

```http
POST /api/rider/update-delivery-status
```
Update delivery status
- Body: `{ "delivery_id": number, "status": string, "notes": string }`
- Returns: Updated delivery information

### Location Management

```http
POST /api/rider/update-location
```
Update rider's current location
- Body: `{ "latitude": number, "longitude": number, "accuracy": number }`
- Returns: Location update confirmation

### Navigation

```http
GET /api/rider/navigation-route
```
Get navigation route for delivery
- Parameters: `delivery_id`, `destination` (pickup/delivery)
- Returns: Route data with turn-by-turn directions

### Earnings

```http
GET /api/rider/earnings
```
Get rider earnings and statistics
- Parameters: `period` (today/week/month/all)
- Returns: Earnings data and performance metrics

## Database Schema

### rider_schedules Table
```sql
CREATE TABLE rider_schedules (
    id INT PRIMARY KEY AUTO_INCREMENT,
    rider_id INT NOT NULL,
    day_of_week TINYINT NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    is_available BOOLEAN DEFAULT TRUE,
    max_orders INT DEFAULT 5,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### rider_locations Table
```sql
CREATE TABLE rider_locations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    rider_id INT NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    accuracy FLOAT NULL,
    speed FLOAT NULL,
    heading FLOAT NULL,
    battery_level INT NULL,
    is_online BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## Configuration

### Map Providers
The system supports multiple map providers:

1. **Google Maps** (Primary)
   - Requires `GOOGLE_MAPS_API_KEY`
   - Provides detailed routing and geocoding

2. **OpenStreetMap** (Fallback)
   - Uses OSRM routing service
   - No API key required

### Environment Variables
```env
# Map Configuration
MAP_PROVIDER=google
GOOGLE_MAPS_API_KEY=your_api_key_here

# WebSocket Configuration
WEBSOCKET_HOST=localhost
WEBSOCKET_PORT=8080

# Delivery Configuration
DEFAULT_DELIVERY_RADIUS=10
MAX_CONCURRENT_DELIVERIES=5
RIDER_COMMISSION_RATE=0.7
DISTANCE_BONUS_RATE=50
```

## Real-time Features

### Location Updates
- Automatic GPS tracking every 5 seconds when online
- Battery level monitoring
- Accuracy and speed tracking
- WebSocket broadcasting to customers

### Push Notifications
- Delivery request notifications
- Status update confirmations
- Customer messages
- System alerts

### Live Tracking
- Real-time location sharing with customers
- ETA updates
- Route progress tracking
- Delivery confirmations

## Security Features

### Authentication & Authorization
- JWT-based authentication
- Role-based access control (rider role required)
- Session management
- CSRF protection

### Data Protection
- Location data encryption
- Secure API endpoints
- Rate limiting
- Input validation and sanitization

### Privacy Controls
- Location sharing permissions
- Data retention policies
- User consent management
- GDPR compliance

## Performance Optimizations

### Database Optimizations
- Spatial indexes for location queries
- Composite indexes for rider queries
- Query optimization for nearby searches
- Connection pooling

### Caching Strategy
- Redis caching for frequent queries
- Location data caching
- Route caching
- Session caching

### Mobile Optimizations
- Efficient GPS usage
- Battery optimization
- Offline capability
- Progressive loading

## Testing

### Unit Tests
- Model functionality testing
- Controller endpoint testing
- Service layer testing
- Utility function testing

### Integration Tests
- API endpoint testing
- Database integration testing
- External service integration
- Real-time feature testing

### Performance Tests
- Load testing for concurrent users
- Location update performance
- Database query performance
- Memory usage optimization

## Deployment

### Requirements
- PHP 8.0+
- MySQL 8.0+
- Redis (optional, for caching)
- WebSocket server (for real-time features)

### Installation Steps
1. Run database migrations
2. Configure environment variables
3. Set up WebSocket server
4. Configure map providers
5. Test API endpoints

### Monitoring
- Application performance monitoring
- Database query monitoring
- Real-time feature monitoring
- Error tracking and logging

## Troubleshooting

### Common Issues

1. **Location Not Updating**
   - Check GPS permissions
   - Verify network connectivity
   - Check battery optimization settings

2. **Navigation Not Working**
   - Verify map provider configuration
   - Check API key validity
   - Test network connectivity

3. **Push Notifications Not Received**
   - Check notification permissions
   - Verify push subscription
   - Test notification service

### Debug Tools
- Application logs
- Database query logs
- Network request monitoring
- Performance profiling

## Future Enhancements

### Planned Features
- Advanced route optimization
- Multi-stop delivery support
- Delivery time prediction
- Customer rating system
- Gamification features

### Technical Improvements
- Machine learning for route optimization
- Advanced analytics dashboard
- Mobile app development
- API versioning
- Microservices architecture

## Support

For technical support or questions about the Rider Delivery System:
- Documentation: `/docs/`
- API Reference: `/api/docs`
- Issue Tracking: GitHub Issues
- Contact: dev@time2eat.com
