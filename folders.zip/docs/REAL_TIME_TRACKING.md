# Real-Time Tracking System

This document describes the real-time order tracking system implemented in Time2Eat.

## Overview

The real-time tracking system provides live updates on order status and rider location using WebSocket connections and interactive maps. It supports both Google Maps and OpenStreetMap for maximum flexibility.

## Features

### 🚀 Core Features
- **Real-time Status Updates**: Live order status changes (pending → preparing → out for delivery → delivered)
- **Live Location Tracking**: Real-time rider location updates on interactive maps
- **WebSocket Integration**: Instant updates without page refresh
- **Fallback Polling**: Automatic fallback to HTTP polling if WebSocket fails
- **Multi-Map Support**: Google Maps or OpenStreetMap integration
- **Mobile-First Design**: Responsive design optimized for mobile devices

### 📱 User Experience
- **Public Tracking**: Track orders without login using tracking codes
- **Interactive Maps**: Pan, zoom, and view multiple locations
- **Progress Indicators**: Visual progress steps showing order journey
- **Rider Information**: Contact details and profile of assigned rider
- **Estimated Delivery Time**: Dynamic delivery time calculations
- **Connection Status**: Real-time connection status indicators

## Architecture

### Components

1. **TrackingController** (`src/controllers/TrackingController.php`)
   - Handles tracking requests and API endpoints
   - Manages authentication and authorization
   - Provides Server-Sent Events (SSE) for real-time updates

2. **Delivery Model** (`src/models/Delivery.php`)
   - Manages delivery records and tracking codes
   - Handles location updates and status changes
   - Calculates delivery statistics and earnings

3. **WebSocket Server** (`src/websocket/TrackingServer.php`)
   - Real-time WebSocket server using Ratchet
   - Handles client connections and message broadcasting
   - Manages delivery subscriptions and authentication

4. **Views**
   - `tracking/search.php`: Public tracking code search page
   - `tracking/live.php`: Live tracking with interactive map
   - `tracking/not-found.php`: Error page for invalid tracking codes

## Setup Instructions

### 1. Install Dependencies

```bash
composer require ratchet/pawl
composer require react/socket
```

### 2. Configure Environment Variables

Add to your `.env` file:

```env
# Map Provider (google or openstreetmap)
MAP_PROVIDER=openstreetmap

# Google Maps API Key (if using Google Maps)
GOOGLE_MAPS_API_KEY=your_google_maps_api_key_here

# WebSocket Server Settings
WEBSOCKET_HOST=localhost
WEBSOCKET_PORT=8080
```

### 3. Start WebSocket Server

```bash
# Start the WebSocket server
php scripts/websocket-server.php 8080

# Or run in background
nohup php scripts/websocket-server.php 8080 > websocket.log 2>&1 &
```

### 4. Configure Web Server

Ensure your web server can serve the tracking routes:

```apache
# Apache .htaccess
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php [QSA,L]
```

## API Endpoints

### Public Tracking
```
GET /track                          # Tracking search page
GET /track?code={tracking_code}     # Live tracking page
GET /api/tracking/code/{code}       # Get tracking data by code (JSON)
```

### Authenticated Tracking
```
POST /api/tracking/order            # Track by order ID
GET /api/tracking/order/{id}        # Get order tracking data
POST /api/tracking/location/update  # Update rider location (riders only)
POST /api/tracking/status/update    # Update delivery status (riders only)
GET /api/tracking/updates/{id}      # Server-Sent Events stream
```

## WebSocket Protocol

### Client Messages

#### Authentication
```json
{
  "type": "authenticate",
  "token": "base64_encoded_user_token"
}
```

#### Subscribe to Delivery Updates
```json
{
  "type": "subscribe_delivery",
  "delivery_id": 123
}
```

#### Update Rider Location (Riders Only)
```json
{
  "type": "location_update",
  "delivery_id": 123,
  "latitude": 5.9631,
  "longitude": 10.1591
}
```

#### Update Delivery Status (Riders Only)
```json
{
  "type": "status_update",
  "delivery_id": 123,
  "status": "out_for_delivery"
}
```

### Server Messages

#### Authentication Success
```json
{
  "type": "authenticated",
  "user_id": 123,
  "role": "customer"
}
```

#### Location Update
```json
{
  "type": "location_update",
  "delivery_id": 123,
  "latitude": 5.9631,
  "longitude": 10.1591,
  "timestamp": 1640995200
}
```

#### Status Update
```json
{
  "type": "status_update",
  "delivery_id": 123,
  "status": "delivered",
  "timestamp": 1640995200
}
```

## Map Integration

### Google Maps Setup

1. Get a Google Maps API key from [Google Cloud Console](https://console.cloud.google.com/)
2. Enable the following APIs:
   - Maps JavaScript API
   - Geocoding API
   - Places API (optional)
3. Set the API key in your `.env` file
4. Configure allowed domains in Google Cloud Console

### OpenStreetMap Setup

OpenStreetMap integration uses Leaflet.js and requires no API key:

1. Set `MAP_PROVIDER=openstreetmap` in `.env`
2. The system will automatically use OpenStreetMap tiles
3. Optionally configure custom tile servers in `config/maps.php`

## Deployment

### Production Considerations

1. **WebSocket Server**
   - Use a process manager like Supervisor to keep the WebSocket server running
   - Configure firewall to allow WebSocket port (default: 8080)
   - Use SSL/TLS for secure WebSocket connections (WSS)

2. **Performance**
   - Enable Redis for WebSocket message caching
   - Use a reverse proxy (nginx) for WebSocket connections
   - Implement connection limits and rate limiting

3. **Monitoring**
   - Monitor WebSocket server health and connections
   - Log tracking events for analytics
   - Set up alerts for server failures

### Supervisor Configuration

Create `/etc/supervisor/conf.d/time2eat-websocket.conf`:

```ini
[program:time2eat-websocket]
command=php /path/to/time2eat/scripts/websocket-server.php 8080
directory=/path/to/time2eat
user=www-data
autostart=true
autorestart=true
redirect_stderr=true
stdout_logfile=/var/log/time2eat-websocket.log
```

## Testing

### Manual Testing

1. Place a test order
2. Navigate to `/track` and enter the tracking code
3. Open browser developer tools to monitor WebSocket connections
4. Update order status from rider dashboard
5. Verify real-time updates appear on tracking page

### Automated Testing

```bash
# Test WebSocket server
php tests/websocket-test.php

# Test tracking API endpoints
php tests/tracking-api-test.php
```

## Troubleshooting

### Common Issues

1. **WebSocket Connection Failed**
   - Check if WebSocket server is running
   - Verify firewall settings
   - Check browser console for errors

2. **Map Not Loading**
   - Verify API key configuration
   - Check browser console for JavaScript errors
   - Ensure internet connection for map tiles

3. **Location Updates Not Working**
   - Check rider permissions and authentication
   - Verify GPS/location services are enabled
   - Check WebSocket connection status

### Debug Mode

Enable debug mode by setting:

```env
DEBUG_TRACKING=true
```

This will enable verbose logging and console output for troubleshooting.

## Security Considerations

1. **Authentication**: All sensitive operations require proper authentication
2. **Authorization**: Users can only track their own orders (except admins)
3. **Rate Limiting**: API endpoints have rate limiting to prevent abuse
4. **Input Validation**: All inputs are validated and sanitized
5. **HTTPS**: Use HTTPS in production for secure connections
6. **WebSocket Security**: Implement proper authentication for WebSocket connections

## Performance Optimization

1. **Caching**: Cache tracking data for frequently accessed orders
2. **Database Indexing**: Ensure proper indexes on tracking-related tables
3. **Connection Pooling**: Use connection pooling for database connections
4. **CDN**: Use CDN for map tiles and static assets
5. **Compression**: Enable gzip compression for API responses

## Future Enhancements

1. **Route Optimization**: Implement route optimization for multiple deliveries
2. **Predictive ETA**: Use machine learning for more accurate delivery time predictions
3. **Push Notifications**: Add mobile push notifications for status updates
4. **Geofencing**: Implement geofencing for automatic status updates
5. **Analytics Dashboard**: Add comprehensive tracking analytics for admins
