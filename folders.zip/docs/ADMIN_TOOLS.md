# Time2Eat Admin Tools Documentation

## Overview

The Time2Eat Admin Tools provide comprehensive system administration capabilities for the food delivery platform. These tools enable administrators to manage analytics, approvals, backups, notifications, and site settings through a professional web interface.

## Features

### 1. Advanced Analytics Dashboard (`/admin/tools/analytics`)

**Purpose**: Comprehensive platform insights and reporting with Chart.js integration and Excel export capabilities.

**Key Features**:
- **Overview Metrics**: Total users, revenue, orders, and average order value
- **Revenue Analytics**: Growth trends, revenue by source, commission earnings
- **User Analytics**: User growth, retention rates, top customers by role
- **Order Analytics**: Order trends, peak hours, completion rates
- **Geographic Analytics**: Orders by location, delivery heatmap, popular areas
- **Performance Metrics**: System health, API response times, error rates, uptime
- **Excel Export**: Complete analytics data export with PhpSpreadsheet integration

**Charts Available**:
- Revenue Growth (Line Chart)
- Order Trends (Bar Chart)
- User Growth by Role (Stacked Chart)
- Peak Hours Distribution (Bar Chart)

**Usage**:
```php
// Access analytics
GET /admin/tools/analytics?period=30days

// Export to Excel
GET /admin/tools/analytics?period=30days&export=excel
```

### 2. User and Restaurant Approvals (`/admin/tools/approvals`)

**Purpose**: Review and approve user registrations, restaurant applications, and role change requests.

**Key Features**:
- **User Registrations**: Approve/reject pending user accounts
- **Restaurant Applications**: Review restaurant registration details and approve/reject
- **Role Changes**: Manage user role change requests
- **Batch Operations**: Handle multiple approvals efficiently
- **Rejection Reasons**: Provide detailed feedback for rejections

**Approval Types**:
- New user registrations (pending status)
- Restaurant applications with owner details
- Role change requests (customer → vendor/rider)

**Usage**:
```php
// View approvals
GET /admin/tools/approvals?type=users

// Process approval
POST /admin/tools/approvals
{
    "action": "approve_user",
    "id": 123,
    "type": "user"
}

// Process rejection
POST /admin/tools/approvals
{
    "action": "reject_restaurant",
    "id": 456,
    "type": "restaurant",
    "reason": "Incomplete documentation"
}
```

### 3. Database Backup Management (`/admin/tools/backups`)

**Purpose**: Create, manage, and restore database backups with automated scheduling.

**Key Features**:
- **Manual Backup Creation**: On-demand database dumps
- **Backup Download**: Secure backup file downloads
- **Backup Restoration**: Database restore from backup files
- **Backup Deletion**: Cleanup old backup files
- **Automated Backups**: Configurable backup scheduling
- **Backup Settings**: Retention policies and frequency configuration

**Backup Operations**:
```php
// Create backup
POST /admin/tools/backups
{
    "action": "create_backup"
}

// Download backup
POST /admin/tools/backups
{
    "action": "download_backup",
    "filename": "time2eat_backup_2024-01-15_14-30-00.sql"
}

// Restore backup
POST /admin/tools/backups
{
    "action": "restore_backup",
    "filename": "time2eat_backup_2024-01-15_14-30-00.sql"
}
```

**Backup Settings**:
- Auto backup enabled/disabled
- Backup frequency (hourly, daily, weekly, monthly)
- Retention period (days to keep backups)
- Storage location configuration

### 4. Popup Notifications Management (`/admin/tools/notifications`)

**Purpose**: Create, schedule, and manage user notifications and system announcements.

**Key Features**:
- **Notification Creation**: Rich notification composer with targeting
- **Scheduling**: Schedule notifications for future delivery
- **Targeting**: Target specific user roles or all users
- **Priority Levels**: Low, normal, high, urgent priority settings
- **Notification Types**: Info, success, warning, error, promotion
- **Action URLs**: Add clickable actions to notifications
- **Expiration**: Set notification expiry dates
- **Analytics**: Track notification engagement and delivery

**Notification Types**:
- **Global**: Visible to all users
- **Role-based**: Target specific user roles (customer, vendor, rider)
- **Scheduled**: Future delivery notifications
- **Promotional**: Marketing and promotional messages

**Usage**:
```php
// Create notification
POST /admin/tools/notifications
{
    "action": "create_notification",
    "title": "System Maintenance",
    "message": "Scheduled maintenance tonight from 2-4 AM",
    "type": "warning",
    "target": "all",
    "priority": "high",
    "expires_at": "2024-01-16 06:00:00"
}

// Update notification
POST /admin/tools/notifications
{
    "action": "update_notification",
    "id": 123,
    "title": "Updated: System Maintenance"
}
```

### 5. Site Settings Management (`/admin/tools/settings`)

**Purpose**: Configure site-wide settings including contact information, business parameters, and system configuration.

**Settings Categories**:

**General Settings**:
- Site name, description, logo, favicon
- Default timezone and language
- Branding and visual elements

**Contact Information**:
- Contact email, phone, address
- Support email and WhatsApp number
- Business contact details

**Business Settings**:
- Delivery fees and commission rates
- Currency and minimum order amounts
- Maximum delivery distance and timeouts

**Email Configuration**:
- SMTP server settings
- Email templates and sender information
- Email notification preferences

**Social Media**:
- Facebook, Twitter, Instagram, LinkedIn URLs
- Social media integration settings

**System Settings**:
- Maintenance mode toggle
- User registration controls
- Backup and security settings

**Usage**:
```php
// Update settings
POST /admin/tools/settings
{
    "action": "update",
    "contact_email": "support@time2eat.cm",
    "delivery_fee": "750",
    "commission_rate": "0.18"
}
```

## Technical Implementation

### Architecture

**MVC Pattern**:
- **Controller**: `AdminToolsController` handles all admin tool requests
- **Models**: `Analytics`, `PopupNotification`, `SiteSetting` for data operations
- **Views**: Professional Tailwind CSS interfaces with Chart.js integration

**Security**:
- Admin role authentication required
- CSRF protection on all forms
- Input validation and sanitization
- Secure file handling for backups

**Database Integration**:
- Utilizes existing database schema
- Popup notifications table for user messaging
- Site settings table for configuration
- Analytics table for metrics storage

### Dependencies

**PHP Libraries**:
- PhpSpreadsheet for Excel export functionality
- MySQL for database operations
- GD library for image processing (if needed)

**Frontend Libraries**:
- Chart.js for data visualization
- Tailwind CSS for responsive design
- Feather Icons for UI icons
- Vanilla JavaScript for interactivity

### File Structure

```
src/
├── controllers/
│   └── AdminToolsController.php
├── models/
│   ├── Analytics.php
│   ├── PopupNotification.php
│   └── SiteSetting.php
└── views/
    └── admin/
        └── tools/
            ├── analytics.php
            ├── approvals.php
            ├── backups.php
            ├── notifications.php
            └── settings.php
```

### Routes

```php
// Admin Tools Routes
$router->get('/admin/tools/analytics', 'AdminToolsController@analytics');
$router->get('/admin/tools/approvals', 'AdminToolsController@approvals');
$router->post('/admin/tools/approvals', 'AdminToolsController@approvals');
$router->get('/admin/tools/backups', 'AdminToolsController@backups');
$router->post('/admin/tools/backups', 'AdminToolsController@backups');
$router->get('/admin/tools/notifications', 'AdminToolsController@notifications');
$router->post('/admin/tools/notifications', 'AdminToolsController@notifications');
$router->get('/admin/tools/settings', 'AdminToolsController@settings');
$router->post('/admin/tools/settings', 'AdminToolsController@settings');
```

## Usage Guidelines

### Best Practices

1. **Analytics**: Review analytics regularly to identify trends and optimize platform performance
2. **Approvals**: Process approvals promptly to maintain user satisfaction
3. **Backups**: Create backups before major system changes and maintain regular backup schedule
4. **Notifications**: Use appropriate priority levels and avoid notification spam
5. **Settings**: Test setting changes in development environment first

### Security Considerations

1. **Access Control**: Only admin users can access these tools
2. **Backup Security**: Store backups in secure locations with proper permissions
3. **Settings Validation**: All setting changes are validated before saving
4. **Audit Logging**: All admin actions are logged for security auditing

### Performance Optimization

1. **Analytics Caching**: Large analytics queries are optimized with proper indexing
2. **Backup Compression**: Backups can be compressed to save storage space
3. **Notification Batching**: Bulk notification operations for efficiency
4. **Settings Caching**: Frequently accessed settings are cached

## Troubleshooting

### Common Issues

1. **Analytics Not Loading**: Check database connections and query permissions
2. **Backup Failures**: Verify MySQL dump utility availability and permissions
3. **Notification Delivery**: Ensure proper database table structure and permissions
4. **Settings Not Saving**: Check form validation and database write permissions

### Error Handling

All admin tools include comprehensive error handling with:
- User-friendly error messages
- Detailed logging for debugging
- Graceful fallbacks for failed operations
- Transaction rollbacks for data integrity

## Future Enhancements

### Planned Features

1. **Advanced Analytics**: Machine learning insights and predictive analytics
2. **Automated Approvals**: Rule-based approval workflows
3. **Cloud Backups**: Integration with cloud storage providers
4. **Push Notifications**: Mobile push notification support
5. **A/B Testing**: Settings A/B testing framework

### Integration Opportunities

1. **External Analytics**: Google Analytics integration
2. **Monitoring Tools**: System monitoring and alerting
3. **Communication Platforms**: Slack/Discord integration for notifications
4. **Business Intelligence**: Advanced reporting and dashboards

This comprehensive admin tools system provides Time2Eat administrators with powerful capabilities to manage and monitor the food delivery platform effectively while maintaining security, performance, and user experience standards.
