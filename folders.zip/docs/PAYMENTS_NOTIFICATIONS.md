# Time2Eat Payment and Notification Integration

## Overview

The Time2Eat platform integrates comprehensive payment processing and notification systems to provide seamless transactions and real-time communication with users. This system supports multiple payment gateways including Cameroon-specific mobile money solutions and international payment processors.

## Payment Integration

### Supported Payment Methods

**1. Mobile Money (Cameroon)**
- **Tranzak Gateway**: Primary mobile money processor for MTN and Orange Money
- **Orange Money**: Direct Orange Money integration
- **MTN Mobile Money**: Direct MTN MoMo integration

**2. International Payment Gateways**
- **Stripe**: Credit/debit card processing with 3D Secure support
- **PayPal**: PayPal account and guest checkout

**3. Cash on Delivery**
- Traditional cash payment on delivery

### Payment Gateway Architecture

**PaymentGatewayService** (`src/services/PaymentGatewayService.php`):
- Unified interface for all payment gateways
- Automatic gateway selection based on payment method
- Fee calculation and currency conversion
- Webhook handling and payment verification

**Gateway Implementations**:
- `TranzakGateway`: Cameroon mobile money via Tranzak API
- `StripeGateway`: International card payments
- `PayPalGateway`: PayPal payments
- `OrangeMoneyGateway`: Direct Orange Money integration
- `MTNMoMoGateway`: Direct MTN MoMo integration

### Payment Flow

1. **Payment Initialization**:
   ```php
   POST /api/v1/payments/process
   {
       "order_id": 123,
       "payment_method": "mobile_money",
       "amount": 5000,
       "currency": "XAF",
       "phone_number": "+237670123456"
   }
   ```

2. **Payment Processing**:
   - Create payment record in database
   - Route to appropriate gateway
   - Handle gateway response
   - Update order and payment status

3. **Webhook Handling**:
   ```php
   POST /api/v1/payments/webhook/{provider}
   ```
   - Verify webhook signature
   - Update payment status
   - Send notifications
   - Update order status

4. **Payment Verification**:
   ```php
   GET /api/v1/payments/status?payment_id=123
   ```

### Payment Security

**Data Protection**:
- Payment method details encrypted using AES-256-CBC
- Sensitive data never stored in plain text
- PCI DSS compliance for card data

**Webhook Security**:
- Signature verification for all webhooks
- IP whitelisting for gateway callbacks
- Request rate limiting

**Transaction Security**:
- Unique transaction IDs and reference numbers
- Idempotency keys for duplicate prevention
- Comprehensive audit logging

### Fee Calculation

Each gateway implements fee calculation:
```php
$fees = $gateway->calculateFees($amount, $currency);
// Returns: ['fee' => 125.0, 'net_amount' => 4875.0, 'total_amount' => 5000.0]
```

**Tranzak Fees**: 2.5% (min 25 XAF, max 5000 XAF)
**Stripe Fees**: 2.9% + $0.30 USD
**PayPal Fees**: 2.9% + $0.30 USD
**Orange Money**: 1.5%
**MTN MoMo**: 1.5%

## Notification System

### Notification Channels

**1. Email Notifications** (`EmailService`):
- SMTP integration with PHPMailer
- HTML email templates
- Delivery tracking and error handling

**2. SMS Notifications** (`SMSService`):
- Twilio integration for SMS delivery
- Cameroon phone number formatting
- Delivery status tracking

**3. Push Notifications**:
- OneSignal integration (future enhancement)
- Real-time browser notifications

### Notification Types

**Payment Notifications**:
- Payment confirmation
- Payment success/failure
- Refund notifications
- Payment method expiry alerts

**Order Notifications**:
- Order confirmation
- Status updates (confirmed, preparing, ready, picked up, delivered)
- Order cancellation
- Delivery completion

**User Notifications**:
- Welcome messages
- Account verification
- Password reset
- Promotional messages

**Vendor Notifications**:
- New order alerts
- Payment confirmations
- Account updates

**Rider Notifications**:
- Delivery assignments
- Route updates
- Earnings notifications

### Notification Templates

Email templates located in `src/views/emails/`:
- `payment_confirmation.php`
- `payment_success.php`
- `order_confirmation.php`
- `order_status_update.php`
- `welcome.php`
- `password_reset.php`

SMS templates are dynamically generated with concise messaging optimized for mobile delivery.

### Notification Preferences

Users can configure notification preferences:
```php
$preferences = [
    'email_notifications' => true,
    'sms_notifications' => true,
    'order_updates' => true,
    'payment_notifications' => true,
    'promotional_emails' => true,
    'promotional_sms' => false
];
```

## Configuration

### Environment Variables

```env
# Email Configuration
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-app-password
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS=noreply@time2eat.cm
MAIL_FROM_NAME="Time2Eat"

# SMS Configuration
TWILIO_SID=your_twilio_sid
TWILIO_TOKEN=your_twilio_token
TWILIO_FROM=+1234567890

# Payment Gateways
STRIPE_PUBLIC_KEY=pk_test_...
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...

TRANZAK_API_KEY=your_tranzak_api_key
TRANZAK_API_SECRET=your_tranzak_api_secret
TRANZAK_SANDBOX=true

ORANGE_MONEY_MERCHANT_KEY=your_orange_money_key
MTN_MOMO_API_KEY=your_mtn_momo_key

# Security
ENCRYPTION_KEY=your_32_character_encryption_key_here
```

### Database Tables

**payments**: Complete payment transaction records
**payment_methods**: User saved payment methods (encrypted)
**notifications_log**: Notification delivery tracking

## API Endpoints

### Payment Endpoints

```php
// Process Payment
POST /api/v1/payments/process
{
    "order_id": 123,
    "payment_method": "mobile_money",
    "amount": 5000,
    "currency": "XAF",
    "phone_number": "+237670123456"
}

// Get Payment Status
GET /api/v1/payments/status?payment_id=123

// Process Refund (Admin/Vendor only)
POST /api/v1/payments/refund
{
    "payment_id": 123,
    "amount": 2500,
    "reason": "Customer request"
}

// Webhook Endpoint
POST /api/v1/payments/webhook/{provider}
```

### Response Format

```json
{
    "success": true,
    "payment_id": 123,
    "transaction_id": "TXN_ABC123_1234567890",
    "status": "pending",
    "redirect_url": "https://payment.gateway.com/pay/xyz",
    "message": "Payment initialized successfully"
}
```

## Error Handling

### Payment Errors

- **Invalid Amount**: Amount validation and currency checks
- **Gateway Errors**: API failures and timeout handling
- **Insufficient Funds**: Mobile money balance checks
- **Card Declined**: Card validation and 3D Secure handling

### Notification Errors

- **Email Delivery**: SMTP failures and bounce handling
- **SMS Delivery**: Twilio errors and invalid numbers
- **Template Errors**: Missing templates and rendering issues

### Error Logging

All errors are logged with context:
```php
$this->logError('Payment processing error', [
    'user_id' => $user['id'],
    'order_id' => $data['order_id'],
    'error' => $e->getMessage(),
    'trace' => $e->getTraceAsString()
]);
```

## Testing

### Payment Testing

**Tranzak Sandbox**:
- Test phone numbers: +237670000001 to +237670000010
- Test amounts: Any amount in XAF
- Webhook testing with ngrok

**Stripe Testing**:
- Test card: 4242424242424242
- Test webhooks with Stripe CLI

### Notification Testing

**Email Testing**:
- Use Mailtrap or similar for development
- Test all email templates

**SMS Testing**:
- Twilio test credentials
- Verify phone number formatting

## Security Considerations

### Payment Security

1. **PCI Compliance**: Never store card data
2. **Encryption**: All sensitive data encrypted at rest
3. **Webhook Verification**: All webhooks verified with signatures
4. **Rate Limiting**: API endpoints protected against abuse
5. **Input Validation**: All payment data validated and sanitized

### Notification Security

1. **Template Injection**: All user data escaped in templates
2. **Spam Prevention**: Rate limiting for notifications
3. **Unsubscribe**: Opt-out mechanisms for promotional messages
4. **Data Privacy**: Minimal personal data in notifications

## Monitoring and Analytics

### Payment Monitoring

- Transaction success/failure rates
- Gateway performance metrics
- Fee analysis and optimization
- Fraud detection patterns

### Notification Monitoring

- Delivery success rates
- Open and click-through rates
- Bounce and unsubscribe tracking
- Template performance analysis

## Future Enhancements

### Payment Features

1. **Recurring Payments**: Subscription support
2. **Split Payments**: Multi-vendor order splitting
3. **Cryptocurrency**: Bitcoin and stablecoin support
4. **Buy Now Pay Later**: Installment payment options

### Notification Features

1. **Rich Notifications**: HTML emails with dynamic content
2. **Push Notifications**: Real-time browser and mobile push
3. **WhatsApp Integration**: WhatsApp Business API
4. **Voice Notifications**: Automated voice calls for critical updates

This comprehensive payment and notification system provides Time2Eat with enterprise-grade transaction processing and communication capabilities, specifically optimized for the Cameroon market while supporting international expansion.
