# Time2Eat Installation Guide

## Overview

Time2Eat comes with a comprehensive web-based installer that works on any hosting environment. The installer automatically sets up the database, creates configuration files, and prepares your application for immediate use.

## System Requirements

### Minimum Requirements
- **PHP**: 8.0 or higher
- **MySQL**: 5.7 or higher (or MariaDB 10.2+)
- **Web Server**: Apache, Nginx, or IIS
- **Memory**: 128MB minimum (256MB recommended)
- **Storage**: 500MB free space

### Required PHP Extensions
- `pdo` - Database connectivity
- `pdo_mysql` - MySQL database driver
- `mbstring` - Multi-byte string handling
- `openssl` - Security and encryption
- `json` - JSON data handling
- `curl` - HTTP requests
- `gd` - Image processing

### Recommended Extensions
- `zip` - Archive handling
- `xml` - XML processing
- `fileinfo` - File type detection
- `intl` - Internationalization

## Installation Methods

### Method 1: Web-Based Installer (Recommended)

1. **Upload Files**
   - Upload all Time2Eat files to your web server
   - Ensure the `install.php` file is in the root directory

2. **Set Permissions**
   ```bash
   # For Linux/Unix hosting
   chmod 755 directories
   chmod 644 files
   chmod 777 public/uploads logs cache storage
   ```

3. **Run Installer**
   - Navigate to `http://your-domain.com/install.php`
   - Follow the step-by-step installation wizard

4. **Complete Setup**
   - The installer will guide you through 6 steps
   - Automatically creates database tables and configuration
   - Sets up admin account and basic settings

### Method 2: Manual Installation

If you prefer manual installation or the web installer doesn't work:

1. **Create Database**
   ```sql
   CREATE DATABASE time2eat CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```

2. **Import Schema**
   ```bash
   mysql -u username -p time2eat < database/data.sql
   mysql -u username -p time2eat < database/sample_data.sql
   ```

3. **Create Configuration**
   - Copy `.env.example` to `.env`
   - Update database credentials and other settings

4. **Set Permissions**
   - Ensure web server can write to required directories

## Installation Steps (Web Installer)

### Step 1: System Requirements Check
- Verifies PHP version and extensions
- Checks file permissions
- Validates server environment
- Must pass all checks to continue

### Step 2: Database Configuration
- Enter database connection details
- Tests database connectivity
- Creates database if it doesn't exist
- Validates user permissions

### Step 3: Database Setup
- Imports complete database schema
- Creates all necessary tables and indexes
- Optionally imports sample data
- Verifies successful installation

### Step 4: Admin Account Creation
- Creates the main administrator account
- Sets up login credentials
- Configures admin permissions
- Validates password strength

### Step 5: Final Configuration
- Sets application name and URL
- Generates security keys
- Creates environment configuration
- Sets up required directories

### Step 6: Installation Complete
- Displays success confirmation
- Provides next steps guidance
- Option to delete installer files
- Links to admin panel and homepage

## Hosting-Specific Instructions

### Shared Hosting (cPanel/Plesk)

1. **Database Setup**
   - Use hosting control panel to create database
   - Note the database name (may have prefix)
   - Create database user with full privileges

2. **File Upload**
   - Upload via File Manager or FTP
   - Extract ZIP file in public_html or www directory
   - Set correct file permissions

3. **Domain Configuration**
   - Point domain to installation directory
   - Ensure mod_rewrite is enabled
   - Configure SSL certificate if available

### VPS/Cloud Hosting

1. **Server Preparation**
   ```bash
   # Ubuntu/Debian
   sudo apt update
   sudo apt install apache2 mysql-server php8.0 php8.0-mysql php8.0-mbstring php8.0-xml php8.0-curl php8.0-gd
   
   # CentOS/RHEL
   sudo yum install httpd mysql-server php php-mysql php-mbstring php-xml php-curl php-gd
   ```

2. **Virtual Host Setup**
   ```apache
   <VirtualHost *:80>
       ServerName your-domain.com
       DocumentRoot /var/www/time2eat
       <Directory /var/www/time2eat>
           AllowOverride All
           Require all granted
       </Directory>
   </VirtualHost>
   ```

3. **SSL Configuration**
   ```bash
   # Using Let's Encrypt
   sudo certbot --apache -d your-domain.com
   ```

### Local Development

1. **XAMPP/WAMP Setup**
   - Install XAMPP or WAMP
   - Place files in htdocs/www directory
   - Start Apache and MySQL services
   - Access via http://localhost/time2eat

2. **Docker Setup**
   ```yaml
   version: '3.8'
   services:
     web:
       image: php:8.0-apache
       ports:
         - "80:80"
       volumes:
         - .:/var/www/html
     db:
       image: mysql:8.0
       environment:
         MYSQL_ROOT_PASSWORD: password
         MYSQL_DATABASE: time2eat
   ```

## Post-Installation Configuration

### Essential Settings

1. **Email Configuration**
   ```env
   MAIL_DRIVER=smtp
   MAIL_HOST=smtp.gmail.com
   MAIL_PORT=587
   MAIL_USERNAME=your-email@gmail.com
   MAIL_PASSWORD=your-app-password
   MAIL_ENCRYPTION=tls
   ```

2. **Payment Gateways**
   ```env
   # Stripe
   STRIPE_PUBLIC_KEY=pk_live_your_public_key
   STRIPE_SECRET_KEY=sk_live_your_secret_key
   
   # PayPal
   PAYPAL_CLIENT_ID=your_paypal_client_id
   PAYPAL_CLIENT_SECRET=your_paypal_secret
   
   # Tranzak (Mobile Money)
   TRANZAK_API_KEY=your_tranzak_api_key
   ```

3. **SMS Notifications**
   ```env
   TWILIO_SID=your_twilio_sid
   TWILIO_TOKEN=your_twilio_token
   TWILIO_FROM=+1234567890
   ```

4. **Google Maps**
   ```env
   MAP_API_KEY=your_google_maps_api_key
   MAP_PROVIDER=google
   ```

### Security Hardening

1. **File Permissions**
   ```bash
   # Secure file permissions
   find . -type f -exec chmod 644 {} \;
   find . -type d -exec chmod 755 {} \;
   chmod 600 .env
   chmod 777 public/uploads logs cache storage
   ```

2. **Apache Security**
   ```apache
   # .htaccess in root directory
   RewriteEngine On
   RewriteCond %{REQUEST_FILENAME} !-f
   RewriteCond %{REQUEST_FILENAME} !-d
   RewriteRule ^(.*)$ index.php [QSA,L]
   
   # Security headers
   Header always set X-Content-Type-Options nosniff
   Header always set X-Frame-Options DENY
   Header always set X-XSS-Protection "1; mode=block"
   ```

3. **Database Security**
   ```sql
   -- Create dedicated database user
   CREATE USER 'time2eat'@'localhost' IDENTIFIED BY 'strong_password';
   GRANT SELECT, INSERT, UPDATE, DELETE ON time2eat.* TO 'time2eat'@'localhost';
   FLUSH PRIVILEGES;
   ```

## Troubleshooting

### Common Issues

1. **Database Connection Failed**
   - Verify database credentials
   - Check if database server is running
   - Ensure user has proper permissions
   - Test connection manually

2. **File Permission Errors**
   ```bash
   # Fix common permission issues
   sudo chown -R www-data:www-data /var/www/time2eat
   sudo chmod -R 755 /var/www/time2eat
   sudo chmod -R 777 /var/www/time2eat/public/uploads
   ```

3. **PHP Extension Missing**
   ```bash
   # Ubuntu/Debian
   sudo apt install php8.0-extension-name
   sudo systemctl restart apache2
   
   # CentOS/RHEL
   sudo yum install php-extension-name
   sudo systemctl restart httpd
   ```

4. **Memory Limit Issues**
   ```ini
   ; php.ini
   memory_limit = 256M
   max_execution_time = 300
   max_input_vars = 3000
   ```

### Error Messages

- **"Headers already sent"**: Check for whitespace before `<?php` tags
- **"Class not found"**: Verify autoloader and file paths
- **"Access denied"**: Check database user permissions
- **"500 Internal Server Error"**: Check error logs and file permissions

### Log Files

Check these locations for error information:
- `/logs/error.log` - Application errors
- `/var/log/apache2/error.log` - Apache errors
- `/var/log/mysql/error.log` - MySQL errors
- PHP error log (location varies by system)

## Maintenance

### Regular Tasks

1. **Database Backups**
   ```bash
   # Daily backup script
   mysqldump -u username -p time2eat > backup_$(date +%Y%m%d).sql
   ```

2. **Log Rotation**
   ```bash
   # Clean old logs
   find logs/ -name "*.log" -mtime +30 -delete
   ```

3. **Cache Clearing**
   ```bash
   # Clear application cache
   rm -rf cache/*
   ```

### Updates

1. **Backup Before Updates**
   - Database backup
   - File system backup
   - Configuration backup

2. **Update Process**
   - Download new version
   - Replace files (keep .env and uploads)
   - Run any migration scripts
   - Clear cache

## Support

### Getting Help

- **Documentation**: Check `/docs/` directory
- **Logs**: Review error logs for specific issues
- **Community**: Join our community forums
- **Professional Support**: Contact our support team

### Reporting Issues

When reporting issues, include:
- PHP version and extensions
- MySQL version
- Server environment details
- Error messages and logs
- Steps to reproduce

## Security Considerations

### Production Checklist

- [ ] Delete installer files after installation
- [ ] Set strong database passwords
- [ ] Enable HTTPS/SSL
- [ ] Configure firewall rules
- [ ] Set proper file permissions
- [ ] Enable security headers
- [ ] Regular security updates
- [ ] Monitor access logs
- [ ] Backup strategy in place
- [ ] Error reporting disabled in production

### Best Practices

1. **Regular Updates**: Keep PHP, MySQL, and Time2Eat updated
2. **Strong Passwords**: Use complex passwords for all accounts
3. **Access Control**: Limit admin access to trusted users
4. **Monitoring**: Set up monitoring for unusual activity
5. **Backups**: Automated daily backups with offsite storage

This installation guide ensures a smooth setup process for Time2Eat on any hosting environment, from shared hosting to enterprise cloud platforms.
