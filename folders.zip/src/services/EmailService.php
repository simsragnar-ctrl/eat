<?php

namespace Time2Eat\Services;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

class EmailService
{
    private PHPMailer $mailer;
    private array $config;

    public function __construct()
    {
        $this->config = [
            'host' => $_ENV['MAIL_HOST'] ?? 'smtp.gmail.com',
            'port' => $_ENV['MAIL_PORT'] ?? 587,
            'username' => $_ENV['MAIL_USERNAME'] ?? '',
            'password' => $_ENV['MAIL_PASSWORD'] ?? '',
            'encryption' => $_ENV['MAIL_ENCRYPTION'] ?? 'tls',
            'from_address' => $_ENV['MAIL_FROM_ADDRESS'] ?? 'noreply@time2eat.cm',
            'from_name' => $_ENV['MAIL_FROM_NAME'] ?? 'Time2Eat'
        ];

        $this->initializeMailer();
    }

    /**
     * Send payment confirmation email
     */
    public function sendPaymentConfirmation(array $user, array $order, array $paymentResult): bool
    {
        $subject = "Payment Confirmation - Order #{$order['order_number']}";
        
        $body = $this->getEmailTemplate('payment_confirmation', [
            'user' => $user,
            'order' => $order,
            'payment_result' => $paymentResult
        ]);

        return $this->sendEmail($user['email'], $subject, $body);
    }

    /**
     * Send payment success email
     */
    public function sendPaymentSuccess(array $user, array $order): bool
    {
        $subject = "Payment Successful - Order #{$order['order_number']}";
        
        $body = $this->getEmailTemplate('payment_success', [
            'user' => $user,
            'order' => $order
        ]);

        return $this->sendEmail($user['email'], $subject, $body);
    }

    /**
     * Send payment failure email
     */
    public function sendPaymentFailure(array $user, array $order): bool
    {
        $subject = "Payment Failed - Order #{$order['order_number']}";
        
        $body = $this->getEmailTemplate('payment_failure', [
            'user' => $user,
            'order' => $order
        ]);

        return $this->sendEmail($user['email'], $subject, $body);
    }

    /**
     * Send refund notification email
     */
    public function sendRefundNotification(array $user, array $order, float $refundAmount): bool
    {
        $subject = "Refund Processed - Order #{$order['order_number']}";
        
        $body = $this->getEmailTemplate('refund_notification', [
            'user' => $user,
            'order' => $order,
            'refund_amount' => $refundAmount
        ]);

        return $this->sendEmail($user['email'], $subject, $body);
    }

    /**
     * Send order confirmation email
     */
    public function sendOrderConfirmation(array $user, array $order): bool
    {
        $subject = "Order Confirmation - #{$order['order_number']}";
        
        $body = $this->getEmailTemplate('order_confirmation', [
            'user' => $user,
            'order' => $order
        ]);

        return $this->sendEmail($user['email'], $subject, $body);
    }

    /**
     * Send order status update email
     */
    public function sendOrderStatusUpdate(array $user, array $order, string $oldStatus, string $newStatus): bool
    {
        $subject = "Order Update - #{$order['order_number']}";
        
        $body = $this->getEmailTemplate('order_status_update', [
            'user' => $user,
            'order' => $order,
            'old_status' => $oldStatus,
            'new_status' => $newStatus
        ]);

        return $this->sendEmail($user['email'], $subject, $body);
    }

    /**
     * Send order delivered email
     */
    public function sendOrderDelivered(array $user, array $order): bool
    {
        $subject = "Order Delivered - #{$order['order_number']}";
        
        $body = $this->getEmailTemplate('order_delivered', [
            'user' => $user,
            'order' => $order
        ]);

        return $this->sendEmail($user['email'], $subject, $body);
    }

    /**
     * Send order cancelled email
     */
    public function sendOrderCancelled(array $user, array $order, string $reason): bool
    {
        $subject = "Order Cancelled - #{$order['order_number']}";
        
        $body = $this->getEmailTemplate('order_cancelled', [
            'user' => $user,
            'order' => $order,
            'reason' => $reason
        ]);

        return $this->sendEmail($user['email'], $subject, $body);
    }

    /**
     * Send new order notification to vendor
     */
    public function sendNewOrderToVendor(array $vendor, array $order): bool
    {
        $subject = "New Order Received - #{$order['order_number']}";
        
        $body = $this->getEmailTemplate('new_order_vendor', [
            'vendor' => $vendor,
            'order' => $order
        ]);

        return $this->sendEmail($vendor['email'], $subject, $body);
    }

    /**
     * Send delivery assignment to rider
     */
    public function sendDeliveryAssignmentToRider(array $rider, array $order): bool
    {
        $subject = "New Delivery Assignment - #{$order['order_number']}";
        
        $body = $this->getEmailTemplate('delivery_assignment', [
            'rider' => $rider,
            'order' => $order
        ]);

        return $this->sendEmail($rider['email'], $subject, $body);
    }

    /**
     * Send welcome email
     */
    public function sendWelcomeEmail(array $user): bool
    {
        $subject = "Welcome to Time2Eat!";
        
        $body = $this->getEmailTemplate('welcome', [
            'user' => $user
        ]);

        return $this->sendEmail($user['email'], $subject, $body);
    }

    /**
     * Send password reset email
     */
    public function sendPasswordReset(array $user, string $resetToken): bool
    {
        $subject = "Password Reset Request - Time2Eat";
        
        $resetUrl = $_ENV['APP_URL'] . "/reset-password?token=" . $resetToken;
        
        $body = $this->getEmailTemplate('password_reset', [
            'user' => $user,
            'reset_url' => $resetUrl,
            'reset_token' => $resetToken
        ]);

        return $this->sendEmail($user['email'], $subject, $body);
    }

    /**
     * Send account verification email
     */
    public function sendAccountVerification(array $user, string $verificationToken): bool
    {
        $subject = "Verify Your Account - Time2Eat";
        
        $verificationUrl = $_ENV['APP_URL'] . "/verify-account?token=" . $verificationToken;
        
        $body = $this->getEmailTemplate('account_verification', [
            'user' => $user,
            'verification_url' => $verificationUrl,
            'verification_token' => $verificationToken
        ]);

        return $this->sendEmail($user['email'], $subject, $body);
    }

    /**
     * Send promotional email
     */
    public function sendPromotionalEmail(array $user, string $subject, string $message, array $options = []): bool
    {
        $body = $this->getEmailTemplate('promotional', [
            'user' => $user,
            'message' => $message,
            'options' => $options
        ]);

        return $this->sendEmail($user['email'], $subject, $body);
    }

    /**
     * Send bulk email
     */
    public function sendBulkEmail(array $user, string $subject, string $message, array $options = []): bool
    {
        $body = $this->getEmailTemplate('bulk_notification', [
            'user' => $user,
            'message' => $message,
            'options' => $options
        ]);

        return $this->sendEmail($user['email'], $subject, $body);
    }

    /**
     * Send maintenance notification email
     */
    public function sendMaintenanceNotification(array $user, string $message, \DateTime $scheduledTime): bool
    {
        $subject = "Scheduled Maintenance - Time2Eat";
        
        $body = $this->getEmailTemplate('maintenance_notification', [
            'user' => $user,
            'message' => $message,
            'scheduled_time' => $scheduledTime
        ]);

        return $this->sendEmail($user['email'], $subject, $body);
    }

    /**
     * Send email
     */
    private function sendEmail(string $to, string $subject, string $body, array $attachments = []): bool
    {
        try {
            $this->mailer->clearAddresses();
            $this->mailer->clearAttachments();

            $this->mailer->addAddress($to);
            $this->mailer->Subject = $subject;
            $this->mailer->Body = $body;

            // Add attachments if any
            foreach ($attachments as $attachment) {
                if (is_array($attachment)) {
                    $this->mailer->addAttachment($attachment['path'], $attachment['name'] ?? '');
                } else {
                    $this->mailer->addAttachment($attachment);
                }
            }

            return $this->mailer->send();

        } catch (Exception $e) {
            error_log("Email sending error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get email template
     */
    private function getEmailTemplate(string $template, array $data = []): string
    {
        $templatePath = __DIR__ . "/../views/emails/{$template}.php";
        
        if (file_exists($templatePath)) {
            ob_start();
            extract($data);
            include $templatePath;
            return ob_get_clean();
        }

        // Fallback to simple template
        return $this->getSimpleTemplate($template, $data);
    }

    /**
     * Get simple email template
     */
    private function getSimpleTemplate(string $template, array $data): string
    {
        $user = $data['user'] ?? [];
        $userName = $user['first_name'] ?? $user['username'] ?? 'Customer';

        $baseTemplate = "
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #e74c3c; color: white; padding: 20px; text-align: center; }
                .content { padding: 20px; background: #f9f9f9; }
                .footer { padding: 20px; text-align: center; font-size: 12px; color: #666; }
                .button { display: inline-block; padding: 10px 20px; background: #e74c3c; color: white; text-decoration: none; border-radius: 5px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>Time2Eat</h1>
                </div>
                <div class='content'>
                    <h2>Hello {$userName}!</h2>
                    {CONTENT}
                </div>
                <div class='footer'>
                    <p>© 2024 Time2Eat. All rights reserved.</p>
                    <p>Bamenda, Cameroon</p>
                </div>
            </div>
        </body>
        </html>";

        $content = $this->getTemplateContent($template, $data);
        return str_replace('{CONTENT}', $content, $baseTemplate);
    }

    /**
     * Get template content based on type
     */
    private function getTemplateContent(string $template, array $data): string
    {
        switch ($template) {
            case 'payment_confirmation':
                $order = $data['order'];
                return "<p>Your payment for order #{$order['order_number']} has been received and is being processed.</p>
                        <p>Order Total: {$order['total_amount']} XAF</p>
                        <p>We'll notify you once the payment is confirmed.</p>";

            case 'payment_success':
                $order = $data['order'];
                return "<p>Great news! Your payment for order #{$order['order_number']} has been successfully processed.</p>
                        <p>Your order is now being prepared.</p>";

            case 'order_confirmation':
                $order = $data['order'];
                return "<p>Thank you for your order! We've received your order #{$order['order_number']} and it's being processed.</p>
                        <p>Order Total: {$order['total_amount']} XAF</p>
                        <p>Estimated delivery time: {$order['estimated_delivery_time']}</p>";

            case 'welcome':
                return "<p>Welcome to Time2Eat, Bamenda's premier food delivery platform!</p>
                        <p>We're excited to have you join our community. Start exploring delicious local restaurants and get your favorite meals delivered right to your door.</p>
                        <a href='" . $_ENV['APP_URL'] . "/browse' class='button'>Start Ordering</a>";

            default:
                return "<p>Thank you for using Time2Eat!</p>";
        }
    }

    /**
     * Initialize PHPMailer
     */
    private function initializeMailer(): void
    {
        $this->mailer = new PHPMailer(true);

        try {
            // Server settings
            $this->mailer->isSMTP();
            $this->mailer->Host = $this->config['host'];
            $this->mailer->SMTPAuth = true;
            $this->mailer->Username = $this->config['username'];
            $this->mailer->Password = $this->config['password'];
            $this->mailer->SMTPSecure = $this->config['encryption'];
            $this->mailer->Port = $this->config['port'];

            // Recipients
            $this->mailer->setFrom($this->config['from_address'], $this->config['from_name']);

            // Content
            $this->mailer->isHTML(true);
            $this->mailer->CharSet = 'UTF-8';

        } catch (Exception $e) {
            error_log("PHPMailer initialization error: " . $e->getMessage());
        }
    }

    /**
     * Test email configuration
     */
    public function testConfiguration(): array
    {
        try {
            $this->mailer->smtpConnect();
            $this->mailer->smtpClose();
            
            return [
                'success' => true,
                'message' => 'Email configuration is working'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Email configuration error: ' . $e->getMessage()
            ];
        }
    }
}
