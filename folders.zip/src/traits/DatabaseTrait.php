<?php

declare(strict_types=1);

/**
 * Database Trait
 * Provides database connection and query methods
 */
trait DatabaseTrait
{
    protected ?\PDO $db = null;
    
    /**
     * Get database connection
     */
    protected function getDb(): \PDO
    {
        if ($this->db === null) {
            $this->db = $this->createConnection();
        }
        return $this->db;
    }
    
    /**
     * Create database connection
     */
    private function createConnection(): \PDO
    {
        $config = require __DIR__ . '/../../config/database.php';
        
        $dsn = "mysql:host={$config['host']};dbname={$config['database']};charset=utf8mb4";
        
        $options = [
            \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
            \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
            \PDO::ATTR_EMULATE_PREPARES => false,
            \PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
        ];
        
        try {
            return new \PDO($dsn, $config['username'], $config['password'], $options);
        } catch (\PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            throw new \Exception("Database connection failed");
        }
    }
    
    /**
     * Execute query with parameters
     */
    protected function query(string $sql, array $params = []): \PDOStatement
    {
        try {
            $stmt = $this->getDb()->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (\PDOException $e) {
            error_log("Query failed: {$sql} - " . $e->getMessage());
            throw new \Exception("Database query failed");
        }
    }
    
    /**
     * Fetch single row
     */
    protected function fetchOne(string $sql, array $params = []): ?array
    {
        $stmt = $this->query($sql, $params);
        $result = $stmt->fetch();
        return $result ?: null;
    }
    
    /**
     * Fetch all rows
     */
    protected function fetchAll(string $sql, array $params = []): array
    {
        $stmt = $this->query($sql, $params);
        return $stmt->fetchAll();
    }
    
    /**
     * Insert record and return ID
     */
    protected function insert(string $table, array $data): int
    {
        $columns = implode(', ', array_keys($data));
        $placeholders = ':' . implode(', :', array_keys($data));
        
        $sql = "INSERT INTO {$table} ({$columns}) VALUES ({$placeholders})";
        $this->query($sql, $data);
        
        return (int) $this->getDb()->lastInsertId();
    }
    
    /**
     * Update records
     */
    protected function update(string $table, array $data, array $where): int
    {
        $setParts = [];
        foreach (array_keys($data) as $column) {
            $setParts[] = "{$column} = :{$column}";
        }
        $setClause = implode(', ', $setParts);
        
        $whereParts = [];
        foreach (array_keys($where) as $column) {
            $whereParts[] = "{$column} = :where_{$column}";
        }
        $whereClause = implode(' AND ', $whereParts);
        
        $sql = "UPDATE {$table} SET {$setClause} WHERE {$whereClause}";
        
        // Prefix where parameters to avoid conflicts
        $params = $data;
        foreach ($where as $key => $value) {
            $params["where_{$key}"] = $value;
        }
        
        $stmt = $this->query($sql, $params);
        return $stmt->rowCount();
    }
    
    /**
     * Delete records
     */
    protected function delete(string $table, array $where): int
    {
        $whereParts = [];
        foreach (array_keys($where) as $column) {
            $whereParts[] = "{$column} = :{$column}";
        }
        $whereClause = implode(' AND ', $whereParts);
        
        $sql = "DELETE FROM {$table} WHERE {$whereClause}";
        $stmt = $this->query($sql, $where);
        
        return $stmt->rowCount();
    }
    
    /**
     * Begin transaction
     */
    protected function beginTransaction(): void
    {
        $this->getDb()->beginTransaction();
    }
    
    /**
     * Commit transaction
     */
    protected function commit(): void
    {
        $this->getDb()->commit();
    }
    
    /**
     * Rollback transaction
     */
    protected function rollback(): void
    {
        $this->getDb()->rollBack();
    }
    
    /**
     * Execute in transaction
     */
    protected function transaction(callable $callback): mixed
    {
        $this->beginTransaction();
        
        try {
            $result = $callback($this);
            $this->commit();
            return $result;
        } catch (\Exception $e) {
            $this->rollback();
            throw $e;
        }
    }
    
    /**
     * Build WHERE clause from array
     */
    protected function buildWhereClause(array $conditions): array
    {
        $whereParts = [];
        $params = [];
        
        foreach ($conditions as $column => $value) {
            if (is_array($value)) {
                // Handle IN clause
                $placeholders = [];
                foreach ($value as $i => $v) {
                    $placeholder = ":{$column}_{$i}";
                    $placeholders[] = $placeholder;
                    $params[$placeholder] = $v;
                }
                $whereParts[] = "{$column} IN (" . implode(', ', $placeholders) . ")";
            } elseif (is_null($value)) {
                $whereParts[] = "{$column} IS NULL";
            } else {
                $whereParts[] = "{$column} = :{$column}";
                $params[$column] = $value;
            }
        }
        
        return [
            'clause' => implode(' AND ', $whereParts),
            'params' => $params
        ];
    }
    
    /**
     * Paginate results
     */
    protected function paginate(string $sql, array $params, int $page = 1, int $perPage = 20): array
    {
        // Count total records
        $countSql = "SELECT COUNT(*) as total FROM ({$sql}) as count_query";
        $totalResult = $this->fetchOne($countSql, $params);
        $total = (int) $totalResult['total'];
        
        // Calculate pagination
        $offset = ($page - 1) * $perPage;
        $totalPages = (int) ceil($total / $perPage);
        
        // Get paginated results
        $paginatedSql = "{$sql} LIMIT {$perPage} OFFSET {$offset}";
        $data = $this->fetchAll($paginatedSql, $params);
        
        return [
            'data' => $data,
            'pagination' => [
                'current_page' => $page,
                'per_page' => $perPage,
                'total' => $total,
                'total_pages' => $totalPages,
                'has_next' => $page < $totalPages,
                'has_prev' => $page > 1
            ]
        ];
    }
    
    /**
     * Search with full-text search
     */
    protected function search(string $table, array $columns, string $query, array $where = []): array
    {
        $searchColumns = implode(', ', $columns);
        
        $sql = "SELECT *, MATCH({$searchColumns}) AGAINST(:query IN NATURAL LANGUAGE MODE) as relevance 
                FROM {$table} 
                WHERE MATCH({$searchColumns}) AGAINST(:query IN NATURAL LANGUAGE MODE)";
        
        $params = ['query' => $query];
        
        if (!empty($where)) {
            $whereClause = $this->buildWhereClause($where);
            $sql .= " AND " . $whereClause['clause'];
            $params = array_merge($params, $whereClause['params']);
        }
        
        $sql .= " ORDER BY relevance DESC";
        
        return $this->fetchAll($sql, $params);
    }
    
    /**
     * Get table schema
     */
    protected function getTableSchema(string $table): array
    {
        $sql = "DESCRIBE {$table}";
        return $this->fetchAll($sql);
    }
    
    /**
     * Check if table exists
     */
    protected function tableExists(string $table): bool
    {
        $sql = "SHOW TABLES LIKE :table";
        $result = $this->fetchOne($sql, ['table' => $table]);
        return $result !== null;
    }
    
    /**
     * Escape identifier (table/column names)
     */
    protected function escapeIdentifier(string $identifier): string
    {
        return '`' . str_replace('`', '``', $identifier) . '`';
    }
    
    /**
     * Get last insert ID
     */
    protected function getLastInsertId(): int
    {
        return (int) $this->getDb()->lastInsertId();
    }
    
    /**
     * Close database connection
     */
    protected function closeConnection(): void
    {
        $this->db = null;
    }
}
