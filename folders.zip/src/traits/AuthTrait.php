<?php

declare(strict_types=1);

require_once __DIR__ . '/../helpers/JWTHelper.php';

/**
 * Authentication Trait
 * Provides session and JWT-based authentication
 */
trait AuthTrait
{
    protected ?object $currentUser = null;
    protected ?string $authToken = null;
    
    /**
     * Start session if not already started
     */
    protected function startSession(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }
    
    /**
     * Load current user from session or JWT
     */
    protected function loadUser(): void
    {
        $this->startSession();
        
        // Try session first
        if (isset($_SESSION['user_id'])) {
            $this->currentUser = $this->getUserById($_SESSION['user_id']);
            return;
        }
        
        // Try JWT token
        $token = $this->getAuthToken();
        if ($token) {
            $payload = JWTHelper::decode($token);
            if ($payload && isset($payload['user_id'])) {
                $this->currentUser = $this->getUserById($payload['user_id']);
                $this->authToken = $token;
            }
        }
    }
    
    /**
     * Get auth token from header or cookie
     */
    private function getAuthToken(): ?string
    {
        // Check Authorization header
        $headers = getallheaders();
        if (isset($headers['Authorization'])) {
            $auth = $headers['Authorization'];
            if (preg_match('/Bearer\s+(.*)$/i', $auth, $matches)) {
                return $matches[1];
            }
        }
        
        // Check cookie
        return $_COOKIE['auth_token'] ?? null;
    }
    
    /**
     * Get user by ID
     */
    private function getUserById(int $userId): ?object
    {
        if (!method_exists($this, 'fetchOne')) {
            return null;
        }
        
        $userData = $this->fetchOne(
            "SELECT u.*, r.name as role_name, r.permissions 
             FROM users u 
             LEFT JOIN roles r ON u.role_id = r.id 
             WHERE u.id = ? AND u.status = 'active'",
            [$userId]
        );
        
        if (!$userData) {
            return null;
        }
        
        return (object) [
            'id' => (int)$userData['id'],
            'email' => $userData['email'],
            'username' => $userData['username'],
            'first_name' => $userData['first_name'],
            'last_name' => $userData['last_name'],
            'phone' => $userData['phone'],
            'role' => $userData['role_name'] ?? 'customer',
            'role_id' => (int)$userData['role_id'],
            'permissions' => $userData['permissions'] ? json_decode($userData['permissions'], true) : [],
            'created_at' => $userData['created_at'],
            'updated_at' => $userData['updated_at']
        ];
    }
    
    /**
     * Login user with credentials
     */
    protected function login(string $email, string $password, bool $remember = false): array
    {
        if (!method_exists($this, 'fetchOne')) {
            return ['success' => false, 'message' => 'Database not available'];
        }
        
        // Rate limiting
        $this->checkLoginRateLimit($email);
        
        $user = $this->fetchOne(
            "SELECT * FROM users WHERE email = ? AND status = 'active'",
            [$email]
        );
        
        if (!$user || !password_verify($password, $user['password'])) {
            $this->recordFailedLogin($email);
            return ['success' => false, 'message' => 'Invalid credentials'];
        }
        
        // Update last login
        $this->updateLastLogin($user['id']);
        
        // Create session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_role'] = $user['role'] ?? 'customer';
        
        // Create JWT token if requested or for API
        $token = null;
        if ($remember || $this->isApiRequest()) {
            $payload = [
                'user_id' => $user['id'],
                'email' => $user['email'],
                'role' => $user['role'] ?? 'customer',
                'exp' => time() + ($remember ? 30 * 24 * 3600 : 24 * 3600) // 30 days or 1 day
            ];
            $token = JWTHelper::encode($payload);
            
            if ($remember) {
                setcookie('auth_token', $token, time() + 30 * 24 * 3600, '/', '', true, true);
            }
        }
        
        $this->currentUser = $this->getUserById($user['id']);
        
        return [
            'success' => true,
            'user' => $this->currentUser,
            'token' => $token
        ];
    }
    
    /**
     * Register new user
     */
    protected function register(array $userData): array
    {
        if (!method_exists($this, 'fetchOne') || !method_exists($this, 'insert')) {
            return ['success' => false, 'message' => 'Database not available'];
        }
        
        // Check if email exists
        $existing = $this->fetchOne("SELECT id FROM users WHERE email = ?", [$userData['email']]);
        if ($existing) {
            return ['success' => false, 'message' => 'Email already registered'];
        }
        
        // Hash password
        $userData['password'] = password_hash($userData['password'], PASSWORD_DEFAULT);
        $userData['status'] = 'active';
        $userData['role'] = $userData['role'] ?? 'customer';
        $userData['created_at'] = date('Y-m-d H:i:s');
        $userData['updated_at'] = date('Y-m-d H:i:s');
        
        try {
            $userId = $this->insert('users', $userData);
            
            // Auto-login after registration
            $_SESSION['user_id'] = $userId;
            $_SESSION['user_role'] = $userData['role'];
            
            $this->currentUser = $this->getUserById($userId);
            
            return [
                'success' => true,
                'user' => $this->currentUser
            ];
        } catch (\Exception $e) {
            error_log("Registration failed: " . $e->getMessage());
            return ['success' => false, 'message' => 'Registration failed'];
        }
    }
    
    /**
     * Logout user
     */
    protected function logout(): void
    {
        $this->startSession();
        
        // Clear session
        session_unset();
        session_destroy();
        
        // Clear auth cookie
        if (isset($_COOKIE['auth_token'])) {
            setcookie('auth_token', '', time() - 3600, '/', '', true, true);
        }
        
        $this->currentUser = null;
        $this->authToken = null;
    }
    
    /**
     * Check if user is authenticated
     */
    protected function isAuthenticated(): bool
    {
        return $this->currentUser !== null;
    }
    
    /**
     * Check if user has specific role
     */
    protected function hasRole(string $role): bool
    {
        if (!$this->isAuthenticated()) {
            return false;
        }
        
        return $this->currentUser->role === $role;
    }
    
    /**
     * Check if user has any of the specified roles
     */
    protected function hasAnyRole(array $roles): bool
    {
        if (!$this->isAuthenticated()) {
            return false;
        }
        
        return in_array($this->currentUser->role, $roles);
    }
    
    /**
     * Check if user has specific permission
     */
    protected function hasPermission(string $permission): bool
    {
        if (!$this->isAuthenticated()) {
            return false;
        }
        
        return in_array($permission, $this->currentUser->permissions);
    }
    
    /**
     * Check if user can access resource
     */
    protected function canAccess(string $resource, string $action = 'read'): bool
    {
        if (!$this->isAuthenticated()) {
            return false;
        }
        
        $permission = "{$resource}.{$action}";
        return $this->hasPermission($permission) || $this->hasPermission("{$resource}.*");
    }
    
    /**
     * Generate CSRF token
     */
    protected function generateCsrfToken(): string
    {
        $this->startSession();
        
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        
        return $_SESSION['csrf_token'];
    }
    
    /**
     * Verify CSRF token
     */
    protected function verifyCsrfToken(): bool
    {
        $this->startSession();
        
        $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? null;
        $sessionToken = $_SESSION['csrf_token'] ?? null;
        
        if (!$token || !$sessionToken || !hash_equals($sessionToken, $token)) {
            if (!$this->isApiRequest()) {
                http_response_code(403);
                die('CSRF token mismatch');
            }
            return false;
        }
        
        return true;
    }
    
    /**
     * Check login rate limiting
     */
    private function checkLoginRateLimit(string $email): void
    {
        $key = "login_attempts:" . md5($email . $_SERVER['REMOTE_ADDR']);
        $attempts = $this->getCacheValue($key, 0);
        
        if ($attempts >= 5) {
            http_response_code(429);
            die('Too many login attempts. Please try again later.');
        }
    }
    
    /**
     * Record failed login attempt
     */
    private function recordFailedLogin(string $email): void
    {
        $key = "login_attempts:" . md5($email . $_SERVER['REMOTE_ADDR']);
        $attempts = $this->getCacheValue($key, 0);
        $this->setCacheValue($key, $attempts + 1, 900); // 15 minutes
    }
    
    /**
     * Update last login timestamp
     */
    private function updateLastLogin(int $userId): void
    {
        if (method_exists($this, 'update')) {
            $this->update('users', ['last_login' => date('Y-m-d H:i:s')], ['id' => $userId]);
        }
    }
    
    /**
     * Check if request is API request
     */
    private function isApiRequest(): bool
    {
        $path = $_SERVER['REQUEST_URI'] ?? '';
        return strpos($path, '/api/') === 0 || 
               (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false);
    }
    
    /**
     * Get current user
     */
    protected function getCurrentUser(): ?object
    {
        return $this->currentUser;
    }
    
    /**
     * Get user ID
     */
    protected function getUserId(): ?int
    {
        return $this->currentUser?->id;
    }
    
    /**
     * Get user role
     */
    protected function getUserRole(): ?string
    {
        return $this->currentUser?->role;
    }
    
    /**
     * Check if user owns resource
     */
    protected function ownsResource(int $resourceUserId): bool
    {
        return $this->isAuthenticated() && $this->currentUser->id === $resourceUserId;
    }
    
    /**
     * Require ownership or admin role
     */
    protected function requireOwnershipOrAdmin(int $resourceUserId): void
    {
        if (!$this->ownsResource($resourceUserId) && !$this->hasRole('admin')) {
            if ($this->isApiRequest()) {
                http_response_code(403);
                echo json_encode(['error' => 'Access denied']);
                exit;
            } else {
                $this->renderErrorPage(403, 'Access Denied');
            }
        }
    }
}
