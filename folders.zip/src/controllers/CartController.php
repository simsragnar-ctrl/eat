<?php

namespace Time2Eat\Controllers;

use Time2Eat\Core\BaseController;
use Time2Eat\Models\Cart;
use Time2Eat\Models\MenuItem;
use Time2Eat\Models\User;

class CartController extends BaseController
{
    private Cart $cartModel;
    private MenuItem $menuItemModel;
    private User $userModel;

    public function __construct()
    {
        parent::__construct();
        $this->cartModel = new Cart();
        $this->menuItemModel = new MenuItem();
        $this->userModel = new User();
    }

    public function index(): void
    {
        $this->requireAuth();
        
        $user = $this->getAuthenticatedUser();
        $cartItems = $this->cartModel->getCartByUser($user['id']);
        $cartTotals = $this->cartModel->getCartTotals($user['id']);
        
        // Get user's addresses for delivery
        $addresses = $this->userModel->getAddressesByUser($user['id']);
        
        // Get recent items for quick add
        $recentItems = $this->cartModel->getRecentCartItems($user['id']);

        $this->render('cart/index', [
            'title' => 'Shopping Cart - Time2Eat',
            'user' => $user,
            'cartItems' => $cartItems,
            'cartTotals' => $cartTotals,
            'addresses' => $addresses,
            'recentItems' => $recentItems
        ]);
    }

    public function add(): void
    {
        $this->requireAuth();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            return;
        }

        $validation = $this->validateRequest([
            'menu_item_id' => 'required|integer',
            'quantity' => 'required|integer|min:1|max:10',
            'customizations' => 'json',
            'special_instructions' => 'string|max:500'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $data = $validation['data'];
        
        // Get menu item details
        $menuItem = $this->menuItemModel->getMenuItemDetails($data['menu_item_id']);
        
        if (!$menuItem) {
            $this->jsonResponse(['success' => false, 'message' => 'Menu item not found'], 404);
            return;
        }

        if (!$menuItem['is_available'] || !$menuItem['is_open']) {
            $this->jsonResponse(['success' => false, 'message' => 'Item is currently unavailable'], 400);
            return;
        }

        // Validate and process customizations
        $customizations = [];
        $additionalCost = 0;
        
        if (!empty($data['customizations'])) {
            $customizationData = json_decode($data['customizations'], true);
            if ($customizationData) {
                $validation = $this->menuItemModel->validateCustomizations($data['menu_item_id'], $customizationData);
                
                if (!$validation['valid']) {
                    $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
                    return;
                }
                
                $customizations = $validation['customizations'];
                $additionalCost = $validation['additional_cost'];
            }
        }

        // Calculate final price
        $unitPrice = (float)$menuItem['price'] + $additionalCost;
        
        // Add to cart
        $cartData = [
            'user_id' => $user['id'],
            'menu_item_id' => $data['menu_item_id'],
            'quantity' => $data['quantity'],
            'unit_price' => $unitPrice,
            'customizations' => json_encode($customizations),
            'special_instructions' => $data['special_instructions'] ?? ''
        ];

        $cartItemId = $this->cartModel->addToCart($cartData);

        if ($cartItemId) {
            // Get updated cart totals
            $cartTotals = $this->cartModel->getCartTotals($user['id']);
            
            $this->jsonResponse([
                'success' => true,
                'message' => 'Item added to cart successfully',
                'cart_item_id' => $cartItemId,
                'cart_totals' => $cartTotals
            ]);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to add item to cart'], 500);
        }
    }

    public function update(): void
    {
        $this->requireAuth();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            return;
        }

        $validation = $this->validateRequest([
            'cart_item_id' => 'required|integer',
            'quantity' => 'required|integer|min:1|max:10'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $data = $validation['data'];

        // Verify cart item belongs to user
        $cartItem = $this->cartModel->getById($data['cart_item_id']);
        
        if (!$cartItem || $cartItem['user_id'] !== $user['id']) {
            $this->jsonResponse(['success' => false, 'message' => 'Cart item not found'], 404);
            return;
        }

        // Update quantity
        $updated = $this->cartModel->updateCartItem($data['cart_item_id'], [
            'quantity' => $data['quantity']
        ]);

        if ($updated) {
            // Get updated cart totals
            $cartTotals = $this->cartModel->getCartTotals($user['id']);
            
            $this->jsonResponse([
                'success' => true,
                'message' => 'Cart updated successfully',
                'cart_totals' => $cartTotals
            ]);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to update cart'], 500);
        }
    }

    public function remove(): void
    {
        $this->requireAuth();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            return;
        }

        $validation = $this->validateRequest([
            'cart_item_id' => 'required|integer'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $cartItemId = $data['cart_item_id'];

        $removed = $this->cartModel->removeFromCart($cartItemId, $user['id']);

        if ($removed) {
            // Get updated cart totals
            $cartTotals = $this->cartModel->getCartTotals($user['id']);
            
            $this->jsonResponse([
                'success' => true,
                'message' => 'Item removed from cart',
                'cart_totals' => $cartTotals
            ]);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to remove item from cart'], 500);
        }
    }

    public function clear(): void
    {
        $this->requireAuth();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $cleared = $this->cartModel->clearCart($user['id']);

        if ($cleared) {
            $this->jsonResponse([
                'success' => true,
                'message' => 'Cart cleared successfully',
                'cart_totals' => [
                    'subtotal' => 0,
                    'delivery_fee' => 0,
                    'total' => 0,
                    'item_count' => 0,
                    'restaurants' => []
                ]
            ]);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to clear cart'], 500);
        }
    }

    public function getCartCount(): void
    {
        $this->requireAuth();

        $user = $this->getAuthenticatedUser();
        $count = $this->cartModel->getCartItemCount($user['id']);

        $this->jsonResponse([
            'success' => true,
            'count' => $count
        ]);
    }

    public function getCartTotals(): void
    {
        $this->requireAuth();

        $user = $this->getAuthenticatedUser();
        $totals = $this->cartModel->getCartTotals($user['id']);

        $this->jsonResponse([
            'success' => true,
            'totals' => $totals
        ]);
    }

    public function applyPromoCode(): void
    {
        $this->requireAuth();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            return;
        }

        $validation = $this->validateRequest([
            'promo_code' => 'required|string|max:20'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $promoCode = strtoupper(trim($validation['data']['promo_code']));

        $result = $this->cartModel->applyPromoCode($user['id'], $promoCode);

        if ($result['valid']) {
            // Store promo code in session for checkout
            $_SESSION['applied_promo_code'] = $result['promo'];
            
            $cartTotals = $this->cartModel->getCartTotals($user['id']);
            $cartTotals['discount'] = $result['discount'];
            $cartTotals['final_total'] = $cartTotals['total'] - $result['discount'];
            
            $this->jsonResponse([
                'success' => true,
                'message' => $result['message'],
                'promo' => $result['promo'],
                'discount' => $result['discount'],
                'cart_totals' => $cartTotals
            ]);
        } else {
            $this->jsonResponse([
                'success' => false,
                'message' => $result['message']
            ], 400);
        }
    }

    public function removePromoCode(): void
    {
        $this->requireAuth();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            return;
        }

        unset($_SESSION['applied_promo_code']);
        
        $user = $this->getAuthenticatedUser();
        $cartTotals = $this->cartModel->getCartTotals($user['id']);

        $this->jsonResponse([
            'success' => true,
            'message' => 'Promo code removed',
            'cart_totals' => $cartTotals
        ]);
    }

    public function quickAdd(): void
    {
        $this->requireAuth();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            return;
        }

        $validation = $this->validateRequest([
            'menu_item_id' => 'required|integer'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $menuItemId = $validation['data']['menu_item_id'];

        // Get menu item details
        $menuItem = $this->menuItemModel->getMenuItemDetails($menuItemId);
        
        if (!$menuItem) {
            $this->jsonResponse(['success' => false, 'message' => 'Menu item not found'], 404);
            return;
        }

        if (!$menuItem['is_available'] || !$menuItem['is_open']) {
            $this->jsonResponse(['success' => false, 'message' => 'Item is currently unavailable'], 400);
            return;
        }

        // Add to cart with default settings (quantity: 1, no customizations)
        $cartData = [
            'user_id' => $user['id'],
            'menu_item_id' => $menuItemId,
            'quantity' => 1,
            'unit_price' => (float)$menuItem['price'],
            'customizations' => '{}',
            'special_instructions' => ''
        ];

        $cartItemId = $this->cartModel->addToCart($cartData);

        if ($cartItemId) {
            $cartTotals = $this->cartModel->getCartTotals($user['id']);
            
            $this->jsonResponse([
                'success' => true,
                'message' => 'Item added to cart successfully',
                'cart_item_id' => $cartItemId,
                'cart_totals' => $cartTotals
            ]);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to add item to cart'], 500);
        }
    }
}
