<?php

namespace Time2Eat\Controllers;

use Time2Eat\Core\BaseController;
use Time2Eat\Models\Cart;
use Time2Eat\Models\Order;
use Time2Eat\Models\User;
use Time2Eat\Models\Restaurant;

class CheckoutController extends BaseController
{
    private Cart $cartModel;
    private Order $orderModel;
    private User $userModel;
    private Restaurant $restaurantModel;

    public function __construct()
    {
        parent::__construct();
        $this->cartModel = new Cart();
        $this->orderModel = new Order();
        $this->userModel = new User();
        $this->restaurantModel = new Restaurant();
    }

    public function index(): void
    {
        $this->requireAuth();
        
        $user = $this->getAuthenticatedUser();
        
        // Validate cart before checkout
        $cartValidation = $this->cartModel->validateCartForCheckout($user['id']);
        
        if (!$cartValidation['valid']) {
            $_SESSION['checkout_errors'] = $cartValidation['errors'];
            $this->redirect('/cart');
            return;
        }

        $cartItems = $this->cartModel->getCartByUser($user['id']);
        $cartTotals = $this->cartModel->getCartTotals($user['id']);
        
        // Get user's addresses and payment methods
        $addresses = $this->userModel->getAddressesByUser($user['id']);
        $paymentMethods = $this->userModel->getPaymentMethodsByUser($user['id']);
        
        // Get applied promo code from session
        $appliedPromo = $_SESSION['applied_promo_code'] ?? null;
        $discount = 0;
        
        if ($appliedPromo) {
            $promoResult = $this->cartModel->applyPromoCode($user['id'], $appliedPromo['code']);
            if ($promoResult['valid']) {
                $discount = $promoResult['discount'];
                $cartTotals['discount'] = $discount;
                $cartTotals['final_total'] = $cartTotals['total'] - $discount;
            } else {
                unset($_SESSION['applied_promo_code']);
                $appliedPromo = null;
            }
        }

        $this->render('checkout/index', [
            'title' => 'Checkout - Time2Eat',
            'user' => $user,
            'cartItems' => $cartItems,
            'cartTotals' => $cartTotals,
            'addresses' => $addresses,
            'paymentMethods' => $paymentMethods,
            'appliedPromo' => $appliedPromo,
            'discount' => $discount
        ]);
    }

    public function placeOrder(): void
    {
        $this->requireAuth();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            return;
        }

        $validation = $this->validateRequest([
            'delivery_address_id' => 'required|integer',
            'payment_method_id' => 'required|integer',
            'delivery_instructions' => 'string|max:500',
            'affiliate_code' => 'string|max:20'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $data = $validation['data'];

        // Validate cart
        $cartValidation = $this->cartModel->validateCartForCheckout($user['id']);
        if (!$cartValidation['valid']) {
            $this->jsonResponse(['success' => false, 'errors' => $cartValidation['errors']], 400);
            return;
        }

        // Get cart items and totals
        $cartItems = $this->cartModel->getCartByUser($user['id']);
        $cartTotals = $this->cartModel->getCartTotals($user['id']);

        if (empty($cartItems)) {
            $this->jsonResponse(['success' => false, 'message' => 'Cart is empty'], 400);
            return;
        }

        // Verify delivery address belongs to user
        $address = $this->userModel->getAddressById($data['delivery_address_id']);
        if (!$address || $address['user_id'] !== $user['id']) {
            $this->jsonResponse(['success' => false, 'message' => 'Invalid delivery address'], 400);
            return;
        }

        // Verify payment method belongs to user
        $paymentMethod = $this->userModel->getPaymentMethodById($data['payment_method_id']);
        if (!$paymentMethod || $paymentMethod['user_id'] !== $user['id']) {
            $this->jsonResponse(['success' => false, 'message' => 'Invalid payment method'], 400);
            return;
        }

        try {
            $this->db->beginTransaction();

            // Process each restaurant's order separately
            $orderIds = [];
            $restaurantGroups = $cartValidation['restaurant_groups'];

            foreach ($restaurantGroups as $restaurantId => $restaurantData) {
                $restaurantItems = array_filter($cartItems, function($item) use ($restaurantId) {
                    return $item['restaurant_id'] == $restaurantId;
                });

                if (empty($restaurantItems)) {
                    continue;
                }

                // Calculate totals for this restaurant
                $subtotal = array_sum(array_column($restaurantItems, 'total_price'));
                $deliveryFee = $restaurantData['subtotal'] >= $restaurantData['minimum_order'] ? 
                              $restaurantItems[0]['delivery_fee'] : 0;

                // Apply promo code discount proportionally
                $discount = 0;
                $appliedPromo = $_SESSION['applied_promo_code'] ?? null;
                if ($appliedPromo && $cartTotals['subtotal'] > 0) {
                    $promoResult = $this->cartModel->applyPromoCode($user['id'], $appliedPromo['code']);
                    if ($promoResult['valid']) {
                        $discount = ($subtotal / $cartTotals['subtotal']) * $promoResult['discount'];
                    }
                }

                // Validate and process affiliate code
                $affiliateCommission = 0;
                $affiliateCode = '';
                if (!empty($data['affiliate_code'])) {
                    $affiliate = $this->userModel->findByAffiliateCode($data['affiliate_code']);
                    if ($affiliate && $affiliate['id'] !== $user['id']) {
                        $affiliateCode = $data['affiliate_code'];
                        $affiliateCommission = $this->orderModel->calculateAffiliateCommission(
                            $subtotal, $affiliate['affiliate_rate']
                        );
                    }
                }

                $totalAmount = $subtotal + $deliveryFee - $discount;

                // Create order
                $orderData = [
                    'customer_id' => $user['id'],
                    'restaurant_id' => $restaurantId,
                    'status' => 'pending',
                    'subtotal' => $subtotal,
                    'delivery_fee' => $deliveryFee,
                    'discount_amount' => $discount,
                    'total_amount' => $totalAmount,
                    'payment_method' => $paymentMethod['type'],
                    'payment_status' => 'pending',
                    'promo_code' => $appliedPromo['code'] ?? '',
                    'affiliate_code' => $affiliateCode,
                    'affiliate_commission' => $affiliateCommission,
                    'delivery_address' => json_encode([
                        'label' => $address['label'],
                        'address_line_1' => $address['address_line_1'],
                        'address_line_2' => $address['address_line_2'],
                        'city' => $address['city'],
                        'state' => $address['state'],
                        'postal_code' => $address['postal_code'],
                        'country' => $address['country'],
                        'latitude' => $address['latitude'],
                        'longitude' => $address['longitude']
                    ]),
                    'delivery_instructions' => $data['delivery_instructions'] ?? ''
                ];

                $orderId = $this->orderModel->createOrder($orderData);
                
                if (!$orderId) {
                    throw new \Exception('Failed to create order');
                }

                $orderIds[] = $orderId;

                // Move cart items to order items for this restaurant
                foreach ($restaurantItems as $item) {
                    $orderItemData = [
                        'order_id' => $orderId,
                        'menu_item_id' => $item['menu_item_id'],
                        'quantity' => $item['quantity'],
                        'unit_price' => $item['unit_price'],
                        'total_price' => $item['total_price'],
                        'customizations' => $item['customizations'],
                        'special_instructions' => $item['special_instructions'],
                        'created_at' => date('Y-m-d H:i:s'),
                        'updated_at' => date('Y-m-d H:i:s')
                    ];

                    $sql = "
                        INSERT INTO order_items 
                        (order_id, menu_item_id, quantity, unit_price, total_price, customizations, special_instructions, created_at, updated_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ";

                    $this->db->execute($sql, [
                        $orderItemData['order_id'],
                        $orderItemData['menu_item_id'],
                        $orderItemData['quantity'],
                        $orderItemData['unit_price'],
                        $orderItemData['total_price'],
                        $orderItemData['customizations'],
                        $orderItemData['special_instructions'],
                        $orderItemData['created_at'],
                        $orderItemData['updated_at']
                    ]);
                }
            }

            // Clear cart
            $this->cartModel->clearCart($user['id']);

            // Clear applied promo code
            unset($_SESSION['applied_promo_code']);

            // Update promo code usage if applicable
            if ($appliedPromo) {
                $this->db->execute(
                    "UPDATE promo_codes SET usage_count = usage_count + 1 WHERE id = ?",
                    [$appliedPromo['id']]
                );
            }

            $this->db->commit();

            // Send order confirmation notifications
            foreach ($orderIds as $orderId) {
                $this->sendOrderNotifications($orderId);
            }

            $this->jsonResponse([
                'success' => true,
                'message' => 'Order placed successfully',
                'order_ids' => $orderIds,
                'redirect' => '/orders'
            ]);

        } catch (\Exception $e) {
            $this->db->rollback();
            $this->logError('Order placement failed', [
                'user_id' => $user['id'],
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            $this->jsonResponse([
                'success' => false,
                'message' => 'Failed to place order. Please try again.'
            ], 500);
        }
    }

    public function validateAffiliateCode(): void
    {
        $this->requireAuth();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            return;
        }

        $validation = $this->validateRequest([
            'affiliate_code' => 'required|string|max:20'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $affiliateCode = strtoupper(trim($validation['data']['affiliate_code']));

        // Check if user is trying to use their own affiliate code
        if ($user['affiliate_code'] === $affiliateCode) {
            $this->jsonResponse([
                'success' => false,
                'message' => 'You cannot use your own affiliate code'
            ], 400);
            return;
        }

        $affiliate = $this->userModel->findByAffiliateCode($affiliateCode);

        if ($affiliate) {
            $cartTotals = $this->cartModel->getCartTotals($user['id']);
            $commission = $this->orderModel->calculateAffiliateCommission(
                $cartTotals['subtotal'], $affiliate['affiliate_rate']
            );

            $this->jsonResponse([
                'success' => true,
                'message' => 'Valid affiliate code',
                'affiliate' => [
                    'code' => $affiliateCode,
                    'name' => $affiliate['first_name'] . ' ' . $affiliate['last_name'],
                    'commission_rate' => $affiliate['affiliate_rate'],
                    'estimated_commission' => $commission
                ]
            ]);
        } else {
            $this->jsonResponse([
                'success' => false,
                'message' => 'Invalid affiliate code'
            ], 400);
        }
    }

    private function sendOrderNotifications(int $orderId): void
    {
        $order = $this->orderModel->getOrderDetails($orderId);
        
        if (!$order) {
            return;
        }

        // Send notification to customer
        $this->sendCustomerOrderNotification($order);
        
        // Send notification to restaurant
        $this->sendRestaurantOrderNotification($order);
        
        // Process affiliate commission if applicable
        if ($order['affiliate_code']) {
            $this->orderModel->processAffiliateCommission($orderId);
        }
    }

    private function sendCustomerOrderNotification(array $order): void
    {
        // Implementation for customer notification
        // This could be email, SMS, push notification, etc.
        
        $message = "Your order #{$order['order_number']} has been placed successfully. " .
                  "Total: {$order['total_amount']} XAF. " .
                  "We'll notify you when it's confirmed.";
        
        // Send notification logic here
        // Example: $this->notificationService->send($order['customer_id'], $message);
    }

    private function sendRestaurantOrderNotification(array $order): void
    {
        // Implementation for restaurant notification
        // This could be email, SMS, dashboard notification, etc.
        
        $message = "New order #{$order['order_number']} received. " .
                  "Total: {$order['total_amount']} XAF. " .
                  "Please confirm the order.";
        
        // Send notification logic here
        // Example: $this->notificationService->sendToRestaurant($order['restaurant_id'], $message);
    }
}
