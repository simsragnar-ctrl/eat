<?php

declare(strict_types=1);

require_once __DIR__ . '/../core/BaseController.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../helpers/JWTHelper.php';

use core\BaseController;
use models\User;

/**
 * Authentication Controller for Time2Eat
 * Handles user authentication, registration, and password management with comprehensive security
 */
class AuthController extends BaseController
{
    private User $userModel;

    public function __construct()
    {
        parent::__construct();
        $this->userModel = new User();
    }

    /**
     * Show login form
     */
    public function showLogin(): void
    {
        // Redirect if already logged in
        if ($this->isAuthenticated()) {
            $user = $this->getCurrentUser();
            $this->redirect($this->getRedirectUrl($user['role']));
            return;
        }

        // Generate CAPTCHA
        require_once __DIR__ . '/../security/SecurityManager.php';
        $security = SecurityManager::getInstance();
        $captcha = $security->generateCaptcha();

        $this->render('auth/login', [
            'title' => 'Login - Time2Eat',
            'page' => 'login',
            'captcha' => $captcha
        ]);
    }
    
    /**
     * Process login
     */
    public function login(): void
    {
        // Initialize security services
        require_once __DIR__ . '/../security/SecurityManager.php';
        require_once __DIR__ . '/../services/ErrorReportingService.php';

        $security = SecurityManager::getInstance();
        $errorReporting = ErrorReportingService::getInstance();

        // Redirect if already logged in
        if ($this->isAuthenticated()) {
            $user = $this->getCurrentUser();
            $this->redirect($this->getRedirectUrl($user['role']));
            return;
        }

        // Check rate limiting
        if (!$security->checkRateLimit('login_attempts')) {
            $this->render('auth/login', [
                'title' => 'Login - Time2Eat',
                'page' => 'login',
                'error' => 'Too many login attempts. Please try again later.',
                'captcha' => $security->generateCaptcha()
            ]);
            return;
        }

        // Validate CAPTCHA first
        if (!$security->validateCaptcha($_POST['captcha'] ?? '', $_POST['captcha_token'] ?? '')) {
            $security->logSecurityEvent('captcha_validation_failed', [
                'ip' => $this->getClientIp(),
                'email' => $_POST['email'] ?? ''
            ]);

            $this->render('auth/login', [
                'title' => 'Login - Time2Eat',
                'page' => 'login',
                'error' => 'Invalid CAPTCHA. Please try again.',
                'old' => $_POST,
                'captcha' => $security->generateCaptcha()
            ]);
            return;
        }

        // Sanitize and validate request
        $email = $security->sanitizeInput($_POST['email'] ?? '', 'email');
        $password = $_POST['password'] ?? '';
        $remember = !empty($_POST['remember']);

        if (empty($email) || empty($password)) {
            $this->render('auth/login', [
                'title' => 'Login - Time2Eat',
                'page' => 'login',
                'error' => 'Email and password are required.',
                'old' => $_POST,
                'captcha' => $security->generateCaptcha()
            ]);
            return;
        }

        if (!empty($this->errors)) {
            $this->render('auth/login', [
                'title' => 'Login - Time2Eat',
                'page' => 'login',
                'errors' => $this->errors,
                'old' => $data
            ]);
            return;
        }

        // Rate limiting with IP and email
        $ipKey = 'login_ip:' . $this->getClientIp();
        $emailKey = 'login_email:' . $data['email'];

        try {
            $this->checkRateLimit($ipKey, 5, 900); // 5 attempts per 15 minutes per IP
            $this->checkRateLimit($emailKey, 3, 1800); // 3 attempts per 30 minutes per email
        } catch (Exception $e) {
            $this->logSecurityEvent('login_rate_limit_exceeded', [
                'ip' => $this->getClientIp(),
                'email' => $data['email'],
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
            ]);

            $this->render('auth/login', [
                'title' => 'Login - Time2Eat',
                'page' => 'login',
                'error' => 'Too many login attempts. Please try again later.',
                'old' => $data
            ]);
            return;
        }

        // Sanitize input
        $email = $this->sanitizeEmail($data['email']);
        $password = $data['password'];
        $remember = !empty($data['remember']);

        // Find user
        $user = $this->userModel->findByEmail($email);

        if (!$user || !$this->userModel->verifyPassword($password, $user['password'])) {
            // Increment rate limit counters on failed login
            $this->incrementRateLimit($ipKey, 900);
            $this->incrementRateLimit($emailKey, 1800);

            $this->logSecurityEvent('login_failed', [
                'email' => $email,
                'ip' => $this->getClientIp(),
                'reason' => 'Invalid credentials',
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
            ]);

            $this->render('auth/login', [
                'title' => 'Login - Time2Eat',
                'page' => 'login',
                'error' => 'Invalid email or password.',
                'old' => $data
            ]);
            return;
        }

        // Check if user account is active
        if ($user['status'] !== 'active') {
            $message = match($user['status']) {
                'suspended' => 'Your account has been suspended. Please contact support.',
                'pending' => 'Your account is pending approval.',
                default => 'Your account is not active. Please contact support.'
            };

            $this->render('auth/login', [
                'title' => 'Login - Time2Eat',
                'page' => 'login',
                'error' => $message,
                'old' => $data
            ]);
            return;
        }

        // Successful login - clear rate limits
        $this->clearRateLimit($ipKey);
        $this->clearRateLimit($emailKey);

        // Log successful login
        $this->logSecurityEvent('login_success', [
            'user_id' => $user['id'],
            'email' => $email,
            'ip' => $this->getClientIp(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
        ]);

        // Login user
        $this->loginUser($user, $remember);

        // Update last login
        $this->userModel->updateLastLogin($user['id'], $this->getClientIp());

        // Set success message
        $this->flash('success', 'Welcome back, ' . $user['first_name'] . '!');

        // Redirect to intended URL or role-specific dashboard
        $redirectUrl = $_SESSION['intended_url'] ?? $this->getRedirectUrl($user['role']);
        unset($_SESSION['intended_url']);

        $this->redirect($redirectUrl);
    }

    /**
     * Show registration form
     */
    public function showRegister(): void
    {
        // Redirect if already logged in
        if ($this->isAuthenticated()) {
            $user = $this->getCurrentUser();
            $this->redirect($this->getRedirectUrl($user['role']));
            return;
        }

        $this->render('auth/register', [
            'title' => 'Sign Up - Time2Eat',
            'page' => 'register'
        ]);
    }
    
    /**
     * Process registration
     */
    public function register(): void
    {
        // Redirect if already logged in
        if ($this->isAuthenticated()) {
            $user = $this->getCurrentUser();
            $this->redirect($this->getRedirectUrl($user['role']));
            return;
        }

        // Validate CAPTCHA first
        if (!$this->validateCaptcha($_POST['captcha'] ?? '', $_POST['captcha_token'] ?? '')) {
            $this->render('auth/register', [
                'title' => 'Register - Time2Eat',
                'page' => 'register',
                'error' => 'Invalid CAPTCHA. Please try again.',
                'old' => $_POST
            ]);
            return;
        }

        // Validate request with comprehensive rules
        $data = $this->validateRequest([
            'first_name' => 'required|alpha|minlength:2|maxlength:50',
            'last_name' => 'required|alpha|minlength:2|maxlength:50',
            'email' => 'required|email|unique:users,email',
            'phone' => 'required|phone',
            'password' => 'required|minlength:8|password_strength',
            'confirm_password' => 'required|confirmed:password',
            'role' => 'required|in:customer,vendor,rider',
            'terms' => 'required|accepted',
            'captcha' => 'required',
            'captcha_token' => 'required'
        ]);

        if (!empty($this->errors)) {
            $this->render('auth/register', [
                'title' => 'Register - Time2Eat',
                'page' => 'register',
                'errors' => $this->errors,
                'old' => $data
            ]);
            return;
        }

        // Rate limiting with multiple checks
        $ipKey = 'register_ip:' . $this->getClientIp();
        $emailKey = 'register_email:' . $data['email'];

        try {
            $this->checkRateLimit($ipKey, 3, 3600); // 3 registrations per hour per IP
            $this->checkRateLimit($emailKey, 1, 86400); // 1 registration per day per email
        } catch (Exception $e) {
            $this->logSecurityEvent('registration_rate_limit_exceeded', [
                'ip' => $this->getClientIp(),
                'email' => $data['email'],
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
            ]);

            $this->render('auth/register', [
                'title' => 'Register - Time2Eat',
                'page' => 'register',
                'error' => 'Registration limit exceeded. Please try again later.',
                'old' => $data
            ]);
            return;
        }
        
        try {
            // Hash password
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            
            // Generate verification token
            $verificationToken = bin2hex(random_bytes(32));
            
            // Create user
            $stmt = $this->db->prepare("
                INSERT INTO users (username, email, password, phone, role, email_verification_token, created_at, updated_at) 
                VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())
            ");
            
            $stmt->execute([
                $username,
                $email,
                $hashedPassword,
                $phone,
                $role,
                $verificationToken
            ]);
            
            $userId = $this->db->lastInsertId();
            
            // Send verification email (implement email service)
            $this->sendVerificationEmail($email, $verificationToken);
            
            // Create user profile based on role
            $this->createUserProfile($userId, $role);
            
            $this->setFlash('success', 'Account created successfully! Please check your email to verify your account.');
            $this->redirect('/login');
            
        } catch (\Exception $e) {
            error_log("Registration error: " . $e->getMessage());
            $this->setFlash('error', 'An error occurred during registration. Please try again.');
            $this->view('auth/register', [
                'title' => 'Sign Up - Time2Eat',
                'username' => $username,
                'email' => $email,
                'phone' => $phone,
                'role' => $role
            ]);
        }
    }
    
    public function logout() {
        // Clear remember token if exists
        if (isset($_COOKIE['remember_token'])) {
            $token = $_COOKIE['remember_token'];
            
            try {
                $stmt = $this->db->prepare("DELETE FROM remember_tokens WHERE token = ?");
                $stmt->execute([hash('sha256', $token)]);
            } catch (\Exception $e) {
                error_log("Error clearing remember token: " . $e->getMessage());
            }
            
            // Clear cookie
            setcookie('remember_token', '', time() - 3600, '/', '', false, true);
        }
        
        // Destroy session
        session_destroy();
        
        $this->setFlash('success', 'You have been logged out successfully.');
        $this->redirect('/');
    }
    
    public function verifyEmail($token) {
        try {
            $stmt = $this->db->prepare("SELECT * FROM users WHERE email_verification_token = ? AND deleted_at IS NULL");
            $stmt->execute([$token]);
            $user = $stmt->fetch();
            
            if (!$user) {
                $this->setFlash('error', 'Invalid verification token.');
                $this->redirect('/login');
                return;
            }
            
            // Update user as verified
            $stmt = $this->db->prepare("UPDATE users SET email_verified_at = NOW(), email_verification_token = NULL, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$user['id']]);
            
            $this->setFlash('success', 'Email verified successfully! You can now log in.');
            $this->redirect('/login');
            
        } catch (\Exception $e) {
            error_log("Email verification error: " . $e->getMessage());
            $this->setFlash('error', 'An error occurred during verification.');
            $this->redirect('/login');
        }
    }
    
    private function isRateLimited($email) {
        if (!RATE_LIMIT_ENABLED) {
            return false;
        }
        
        try {
            $stmt = $this->db->prepare("
                SELECT COUNT(*) as attempts 
                FROM failed_logins 
                WHERE email = ? AND created_at > DATE_SUB(NOW(), INTERVAL ? SECOND)
            ");
            $stmt->execute([$email, RATE_LIMIT_WINDOW]);
            $result = $stmt->fetch();
            
            return $result['attempts'] >= MAX_LOGIN_ATTEMPTS;
        } catch (\Exception $e) {
            error_log("Rate limit check error: " . $e->getMessage());
            return false;
        }
    }
    
    private function recordFailedLogin($email) {
        try {
            $stmt = $this->db->prepare("INSERT INTO failed_logins (email, ip_address, created_at) VALUES (?, ?, NOW())");
            $stmt->execute([$email, $_SERVER['REMOTE_ADDR'] ?? '']);
        } catch (\Exception $e) {
            error_log("Failed login record error: " . $e->getMessage());
        }
    }
    
    private function clearFailedLogins($email) {
        try {
            $stmt = $this->db->prepare("DELETE FROM failed_logins WHERE email = ?");
            $stmt->execute([$email]);
        } catch (\Exception $e) {
            error_log("Clear failed logins error: " . $e->getMessage());
        }
    }
    
    private function getRedirectUrl($role) {
        switch ($role) {
            case 'admin':
                return '/admin/dashboard';
            case 'vendor':
                return '/vendor/dashboard';
            case 'rider':
                return '/rider/dashboard';
            default:
                return '/customer/dashboard';
        }
    }
    
    /**
     * Validate CAPTCHA
     */
    private function validateCaptcha(string $captcha, string $token): bool
    {
        if (empty($captcha) || empty($token)) {
            return false;
        }

        $expectedCaptcha = base64_decode($token);
        return strtoupper($captcha) === strtoupper($expectedCaptcha);
    }

    /**
     * Get client IP address
     */
    private function getClientIp(): string
    {
        $ipKeys = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR'];

        foreach ($ipKeys as $key) {
            if (!empty($_SERVER[$key])) {
                $ips = explode(',', $_SERVER[$key]);
                $ip = trim($ips[0]);

                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }

        return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    }

    /**
     * Log security events
     */
    private function logSecurityEvent(string $event, array $data): void
    {
        $logData = [
            'event' => $event,
            'timestamp' => date('Y-m-d H:i:s'),
            'ip' => $this->getClientIp(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'data' => $data
        ];

        // Log to security log
        error_log("SECURITY: " . json_encode($logData));

        // Store in database
        $this->insert('logs', [
            'level' => 'warning',
            'message' => "Security event: {$event}",
            'context' => json_encode($logData),
            'channel' => 'security',
            'user_id' => $data['user_id'] ?? null,
            'ip_address' => $this->getClientIp(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'url' => $_SERVER['REQUEST_URI'] ?? '',
            'method' => $_SERVER['REQUEST_METHOD'] ?? ''
        ]);
    }

    /**
     * Sanitize email address
     */
    private function sanitizeEmail(string $email): string
    {
        return strtolower(trim(filter_var($email, FILTER_SANITIZE_EMAIL)));
    }

    /**
     * Sanitize string input
     */
    private function sanitizeString(string $input): string
    {
        return trim(htmlspecialchars($input, ENT_QUOTES, 'UTF-8'));
    }

    /**
     * Sanitize phone number
     */
    private function sanitizePhone(string $phone): string
    {
        // Remove all non-numeric characters except +
        $phone = preg_replace('/[^\d+]/', '', $phone);

        // Add Cameroon country code if not present
        if (!str_starts_with($phone, '+')) {
            if (str_starts_with($phone, '237')) {
                $phone = '+' . $phone;
            } elseif (str_starts_with($phone, '6')) {
                $phone = '+237' . $phone;
            }
        }

        return $phone;
    }

    /**
     * Generate unique username from email
     */
    private function generateUsername(string $email): string
    {
        $baseUsername = strtolower(explode('@', $email)[0]);
        $baseUsername = preg_replace('/[^a-z0-9]/', '', $baseUsername);

        $username = $baseUsername;
        $counter = 1;

        while ($this->userModel->usernameExists($username)) {
            $username = $baseUsername . $counter;
            $counter++;
        }

        return $username;
    }

    /**
     * Generate unique affiliate code
     */
    private function generateAffiliateCode(): string
    {
        do {
            $code = strtoupper(substr(md5(uniqid(rand(), true)), 0, 8));
        } while ($this->userModel->findByAffiliateCode($code));

        return $code;
    }

    /**
     * Send email verification
     */
    private function sendEmailVerification(object $user): void
    {
        require_once __DIR__ . '/../helpers/JWTHelper.php';
        $token = \JWTHelper::createEmailVerificationToken($user->id, $user->email);

        // Store verification token
        $this->userModel->updateUser($user->id, [
            'email_verification_token' => $token,
            'email_verification_expires' => date('Y-m-d H:i:s', time() + 86400) // 24 hours
        ]);

        // Send email (implementation would use email service)
        error_log("Email verification sent to: {$user->email} with token: {$token}");
    }

    /**
     * Send welcome email
     */
    private function sendWelcomeEmail(object $user): void
    {
        // Implementation would use email service
        error_log("Welcome email sent to: {$user->email}");
    }

    /**
     * Process referral
     */
    private function processReferral(int $referrerId, int $newUserId): void
    {
        // Create referral record
        $this->insert('affiliate_referrals', [
            'affiliate_id' => $referrerId,
            'referred_user_id' => $newUserId,
            'commission_rate' => 0.05, // 5% default
            'status' => 'pending'
        ]);

        // Update referrer stats
        $this->query("UPDATE users SET referral_count = referral_count + 1 WHERE id = ?", [$referrerId]);
        $this->query("UPDATE affiliates SET total_referrals = total_referrals + 1 WHERE user_id = ?", [$referrerId]);
    }

    /**
     * Login user with session and remember token
     */
    private function loginUser(array $user, bool $remember = false): void
    {
        // Start session if not already started
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Set session data
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['authenticated'] = true;
        $_SESSION['login_time'] = time();

        // Set remember me cookie if requested
        if ($remember) {
            $token = bin2hex(random_bytes(32));
            $expires = time() + (30 * 24 * 60 * 60); // 30 days

            // Store token in database
            $this->userModel->setRememberToken($user['id'], hash('sha256', $token));

            // Set cookie
            setcookie('remember_token', $token, $expires, '/', '', false, true);
        }
    }

    private function sendVerificationEmail($email, $token) {
        // TODO: Implement email service
        // For now, just log the verification link
        $verificationUrl = APP_URL . "/verify-email/{$token}";
        error_log("Verification email for {$email}: {$verificationUrl}");
    }

    private function createUserProfile($userId, $role) {
        try {
            switch ($role) {
                case 'vendor':
                    $stmt = $this->db->prepare("INSERT INTO vendor_profiles (user_id, created_at, updated_at) VALUES (?, NOW(), NOW())");
                    $stmt->execute([$userId]);
                    break;
                case 'rider':
                    $stmt = $this->db->prepare("INSERT INTO rider_profiles (user_id, created_at, updated_at) VALUES (?, NOW(), NOW())");
                    $stmt->execute([$userId]);
                    break;
                default:
                    $stmt = $this->db->prepare("INSERT INTO customer_profiles (user_id, created_at, updated_at) VALUES (?, NOW(), NOW())");
                    $stmt->execute([$userId]);
            }
        } catch (\Exception $e) {
            error_log("Error creating user profile: " . $e->getMessage());
        }
    }
}
