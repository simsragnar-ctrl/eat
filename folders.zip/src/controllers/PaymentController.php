<?php

namespace Time2Eat\Controllers;

use Time2Eat\Core\BaseController;
use Time2Eat\Models\Payment;
use Time2Eat\Models\Order;
use Time2Eat\Models\PaymentMethod;
use Time2Eat\Services\PaymentGatewayService;
use Time2Eat\Services\NotificationService;

class PaymentController extends BaseController
{
    private Payment $paymentModel;
    private Order $orderModel;
    private PaymentMethod $paymentMethodModel;
    private PaymentGatewayService $paymentGateway;
    private NotificationService $notificationService;

    public function __construct()
    {
        parent::__construct();
        $this->paymentModel = new Payment();
        $this->orderModel = new Order();
        $this->paymentMethodModel = new PaymentMethod();
        $this->paymentGateway = new PaymentGatewayService();
        $this->notificationService = new NotificationService();
    }

    /**
     * Process payment for an order
     */
    public function processPayment(): void
    {
        $this->requireAuth();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            return;
        }

        $validation = $this->validateRequest([
            'order_id' => 'required|integer',
            'payment_method' => 'required|string|in:cash,card,mobile_money,orange_money,mtn_momo,paypal,stripe',
            'payment_method_id' => 'integer',
            'amount' => 'required|numeric|min:0',
            'currency' => 'string|in:XAF,USD,EUR',
            'return_url' => 'string|url',
            'cancel_url' => 'string|url'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $data = $validation['data'];

        try {
            // Get order details
            $order = $this->orderModel->getById($data['order_id']);
            if (!$order || $order['customer_id'] != $user['id']) {
                $this->jsonResponse(['success' => false, 'message' => 'Order not found'], 404);
                return;
            }

            // Check if order is already paid
            if ($order['payment_status'] === 'paid') {
                $this->jsonResponse(['success' => false, 'message' => 'Order already paid'], 400);
                return;
            }

            // Validate amount matches order total
            if (abs($data['amount'] - $order['total_amount']) > 0.01) {
                $this->jsonResponse(['success' => false, 'message' => 'Amount mismatch'], 400);
                return;
            }

            // Create payment record
            $paymentData = [
                'order_id' => $order['id'],
                'user_id' => $user['id'],
                'payment_method_id' => $data['payment_method_id'] ?? null,
                'transaction_id' => $this->generateTransactionId(),
                'reference_number' => $this->generateReferenceNumber(),
                'type' => 'payment',
                'method' => $data['payment_method'],
                'amount' => $data['amount'],
                'currency' => $data['currency'] ?? 'XAF',
                'status' => 'pending'
            ];

            $paymentId = $this->paymentModel->create($paymentData);
            if (!$paymentId) {
                $this->jsonResponse(['success' => false, 'message' => 'Failed to create payment record'], 500);
                return;
            }

            // Process payment based on method
            $result = $this->processPaymentByMethod($paymentId, $data, $order);

            if ($result['success']) {
                // Update order payment status
                $this->orderModel->update($order['id'], [
                    'payment_status' => $result['status'] ?? 'processing',
                    'payment_method' => $data['payment_method']
                ]);

                // Send confirmation notification
                $this->notificationService->sendPaymentConfirmation($user, $order, $result);

                $this->jsonResponse([
                    'success' => true,
                    'payment_id' => $paymentId,
                    'transaction_id' => $paymentData['transaction_id'],
                    'status' => $result['status'],
                    'redirect_url' => $result['redirect_url'] ?? null,
                    'message' => $result['message'] ?? 'Payment processed successfully'
                ]);
            } else {
                // Update payment status to failed
                $this->paymentModel->update($paymentId, [
                    'status' => 'failed',
                    'failure_reason' => $result['message'] ?? 'Payment processing failed'
                ]);

                $this->jsonResponse([
                    'success' => false,
                    'message' => $result['message'] ?? 'Payment processing failed'
                ], 400);
            }

        } catch (\Exception $e) {
            $this->logError('Payment processing error', [
                'user_id' => $user['id'],
                'order_id' => $data['order_id'],
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            $this->jsonResponse([
                'success' => false,
                'message' => 'Payment processing failed. Please try again.'
            ], 500);
        }
    }

    /**
     * Handle payment webhook callbacks
     */
    public function webhook(): void
    {
        $provider = $_GET['provider'] ?? '';
        
        if (!in_array($provider, ['stripe', 'paypal', 'orange_money', 'mtn_momo', 'tranzak'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid provider']);
            return;
        }

        try {
            $payload = file_get_contents('php://input');
            $signature = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? $_SERVER['HTTP_X_PAYPAL_TRANSMISSION_SIG'] ?? '';

            $result = $this->paymentGateway->handleWebhook($provider, $payload, $signature);

            if ($result['success']) {
                // Update payment and order status
                $this->updatePaymentFromWebhook($result['data']);
                http_response_code(200);
                echo json_encode(['status' => 'success']);
            } else {
                http_response_code(400);
                echo json_encode(['error' => $result['message']]);
            }

        } catch (\Exception $e) {
            $this->logError('Webhook processing error', [
                'provider' => $provider,
                'error' => $e->getMessage(),
                'payload' => $payload ?? 'No payload'
            ]);

            http_response_code(500);
            echo json_encode(['error' => 'Webhook processing failed']);
        }
    }

    /**
     * Get payment status
     */
    public function getPaymentStatus(): void
    {
        $this->requireAuth();

        $paymentId = $_GET['payment_id'] ?? '';
        $transactionId = $_GET['transaction_id'] ?? '';

        if (!$paymentId && !$transactionId) {
            $this->jsonResponse(['success' => false, 'message' => 'Payment ID or Transaction ID required'], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();

        try {
            if ($paymentId) {
                $payment = $this->paymentModel->getById($paymentId);
            } else {
                $payment = $this->paymentModel->getByTransactionId($transactionId);
            }

            if (!$payment || $payment['user_id'] != $user['id']) {
                $this->jsonResponse(['success' => false, 'message' => 'Payment not found'], 404);
                return;
            }

            $this->jsonResponse([
                'success' => true,
                'payment' => [
                    'id' => $payment['id'],
                    'transaction_id' => $payment['transaction_id'],
                    'status' => $payment['status'],
                    'amount' => $payment['amount'],
                    'currency' => $payment['currency'],
                    'method' => $payment['method'],
                    'created_at' => $payment['created_at'],
                    'processed_at' => $payment['processed_at']
                ]
            ]);

        } catch (\Exception $e) {
            $this->logError('Get payment status error', [
                'user_id' => $user['id'],
                'payment_id' => $paymentId,
                'transaction_id' => $transactionId,
                'error' => $e->getMessage()
            ]);

            $this->jsonResponse([
                'success' => false,
                'message' => 'Failed to get payment status'
            ], 500);
        }
    }

    /**
     * Process refund
     */
    public function processRefund(): void
    {
        $this->requireAuth(['admin', 'vendor']);

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            return;
        }

        $validation = $this->validateRequest([
            'payment_id' => 'required|integer',
            'amount' => 'required|numeric|min:0',
            'reason' => 'required|string|max:500'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $data = $validation['data'];

        try {
            $payment = $this->paymentModel->getById($data['payment_id']);
            if (!$payment) {
                $this->jsonResponse(['success' => false, 'message' => 'Payment not found'], 404);
                return;
            }

            // Check if refund amount is valid
            if ($data['amount'] > $payment['amount']) {
                $this->jsonResponse(['success' => false, 'message' => 'Refund amount exceeds payment amount'], 400);
                return;
            }

            // Process refund through gateway
            $result = $this->paymentGateway->processRefund($payment, $data['amount'], $data['reason']);

            if ($result['success']) {
                // Create refund record
                $refundData = [
                    'order_id' => $payment['order_id'],
                    'user_id' => $payment['user_id'],
                    'transaction_id' => $result['refund_id'],
                    'reference_number' => $this->generateReferenceNumber(),
                    'type' => 'refund',
                    'method' => $payment['method'],
                    'amount' => $data['amount'],
                    'currency' => $payment['currency'],
                    'status' => 'completed',
                    'notes' => $data['reason'],
                    'processed_at' => date('Y-m-d H:i:s')
                ];

                $refundId = $this->paymentModel->create($refundData);

                // Update original payment
                $this->paymentModel->update($payment['id'], [
                    'status' => $data['amount'] >= $payment['amount'] ? 'refunded' : 'partially_refunded',
                    'refunded_at' => date('Y-m-d H:i:s')
                ]);

                // Update order
                $this->orderModel->update($payment['order_id'], [
                    'payment_status' => $data['amount'] >= $payment['amount'] ? 'refunded' : 'partially_refunded',
                    'refund_amount' => $data['amount'],
                    'refund_reason' => $data['reason']
                ]);

                // Send refund notification
                $order = $this->orderModel->getById($payment['order_id']);
                $customer = $this->userModel->getById($payment['user_id']);
                $this->notificationService->sendRefundNotification($customer, $order, $data['amount']);

                $this->jsonResponse([
                    'success' => true,
                    'refund_id' => $refundId,
                    'message' => 'Refund processed successfully'
                ]);
            } else {
                $this->jsonResponse([
                    'success' => false,
                    'message' => $result['message'] ?? 'Refund processing failed'
                ], 400);
            }

        } catch (\Exception $e) {
            $this->logError('Refund processing error', [
                'user_id' => $user['id'],
                'payment_id' => $data['payment_id'],
                'error' => $e->getMessage()
            ]);

            $this->jsonResponse([
                'success' => false,
                'message' => 'Refund processing failed'
            ], 500);
        }
    }

    /**
     * Process payment by method
     */
    private function processPaymentByMethod(int $paymentId, array $data, array $order): array
    {
        switch ($data['payment_method']) {
            case 'cash':
                return [
                    'success' => true,
                    'status' => 'pending',
                    'message' => 'Cash payment will be collected on delivery'
                ];

            case 'stripe':
            case 'paypal':
            case 'orange_money':
            case 'mtn_momo':
                return $this->paymentGateway->processPayment($data['payment_method'], [
                    'payment_id' => $paymentId,
                    'amount' => $data['amount'],
                    'currency' => $data['currency'] ?? 'XAF',
                    'order' => $order,
                    'return_url' => $data['return_url'] ?? null,
                    'cancel_url' => $data['cancel_url'] ?? null
                ]);

            default:
                return [
                    'success' => false,
                    'message' => 'Unsupported payment method'
                ];
        }
    }

    /**
     * Update payment from webhook
     */
    private function updatePaymentFromWebhook(array $webhookData): void
    {
        $payment = $this->paymentModel->getByTransactionId($webhookData['transaction_id']);
        if (!$payment) {
            return;
        }

        // Update payment status
        $this->paymentModel->update($payment['id'], [
            'status' => $webhookData['status'],
            'gateway_response' => json_encode($webhookData['gateway_response'] ?? []),
            'processed_at' => date('Y-m-d H:i:s'),
            'failure_reason' => $webhookData['failure_reason'] ?? null
        ]);

        // Update order status
        if ($payment['order_id']) {
            $orderStatus = $webhookData['status'] === 'completed' ? 'paid' : 'failed';
            $this->orderModel->update($payment['order_id'], [
                'payment_status' => $orderStatus
            ]);

            // Send notification
            $order = $this->orderModel->getById($payment['order_id']);
            $customer = $this->userModel->getById($payment['user_id']);
            
            if ($webhookData['status'] === 'completed') {
                $this->notificationService->sendPaymentSuccessNotification($customer, $order);
            } else {
                $this->notificationService->sendPaymentFailureNotification($customer, $order);
            }
        }
    }

    /**
     * Generate unique transaction ID
     */
    private function generateTransactionId(): string
    {
        return 'TXN_' . strtoupper(uniqid()) . '_' . time();
    }

    /**
     * Generate unique reference number
     */
    private function generateReferenceNumber(): string
    {
        return 'REF_' . date('Ymd') . '_' . strtoupper(substr(uniqid(), -8));
    }
}
