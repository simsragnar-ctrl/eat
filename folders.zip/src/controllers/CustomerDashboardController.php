<?php

namespace Time2Eat\Controllers;

use Time2Eat\Core\BaseController;
use Time2Eat\Models\User;
use Time2Eat\Models\Order;
use Time2Eat\Models\Restaurant;

class CustomerDashboardController extends BaseController
{
    private User $userModel;
    private Order $orderModel;
    private Restaurant $restaurantModel;

    public function __construct()
    {
        parent::__construct();
        $this->userModel = new User();
        $this->orderModel = new Order();
        $this->restaurantModel = new Restaurant();
    }

    public function index(): void
    {
        $this->requireAuth();
        $this->requireRole('customer');

        $user = $this->getAuthenticatedUser();
        
        // Get customer statistics
        $stats = $this->getCustomerStats($user['id']);
        
        // Get recent orders
        $recentOrders = $this->orderModel->getRecentOrdersByCustomer($user['id'], 5);
        
        // Get recommendations
        $recommendations = $this->getRecommendations($user['id']);
        
        // Get favorite restaurants
        $favoriteRestaurants = $this->restaurantModel->getFavoritesByCustomer($user['id']);

        $this->render('dashboard/customer', [
            'title' => 'Customer Dashboard - Time2Eat',
            'user' => $user,
            'stats' => $stats,
            'recentOrders' => $recentOrders,
            'recommendations' => $recommendations,
            'favoriteRestaurants' => $favoriteRestaurants
        ]);
    }

    public function orders(): void
    {
        $this->requireAuth();
        $this->requireRole('customer');

        $user = $this->getAuthenticatedUser();
        $page = (int)($_GET['page'] ?? 1);
        $limit = 10;
        $offset = ($page - 1) * $limit;

        // Get orders with pagination
        $orders = $this->orderModel->getOrdersByCustomer($user['id'], $limit, $offset);
        $totalOrders = $this->orderModel->countOrdersByCustomer($user['id']);
        $totalPages = ceil($totalOrders / $limit);

        $this->render('customer/orders', [
            'title' => 'My Orders - Time2Eat',
            'user' => $user,
            'orders' => $orders,
            'currentPage' => $page,
            'totalPages' => $totalPages,
            'totalOrders' => $totalOrders
        ]);
    }

    public function favorites(): void
    {
        $this->requireAuth();
        $this->requireRole('customer');

        $user = $this->getAuthenticatedUser();
        
        // Get favorite restaurants and menu items
        $favoriteRestaurants = $this->restaurantModel->getFavoritesByCustomer($user['id']);
        $favoriteItems = $this->orderModel->getFavoriteItemsByCustomer($user['id']);

        $this->render('customer/favorites', [
            'title' => 'My Favorites - Time2Eat',
            'user' => $user,
            'favoriteRestaurants' => $favoriteRestaurants,
            'favoriteItems' => $favoriteItems
        ]);
    }

    public function profile(): void
    {
        $this->requireAuth();
        $this->requireRole('customer');

        $user = $this->getAuthenticatedUser();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->updateProfile();
            return;
        }

        // Get user addresses and payment methods
        $addresses = $this->userModel->getAddressesByUser($user['id']);
        $paymentMethods = $this->userModel->getPaymentMethodsByUser($user['id']);

        $this->render('customer/profile', [
            'title' => 'My Profile - Time2Eat',
            'user' => $user,
            'addresses' => $addresses,
            'paymentMethods' => $paymentMethods
        ]);
    }

    public function affiliates(): void
    {
        $this->requireAuth();
        $this->requireRole('customer');

        $user = $this->getAuthenticatedUser();

        // Check if user is an affiliate
        if (empty($user['affiliate_code'])) {
            // Redirect to affiliate signup
            $this->redirect('/customer/affiliate/signup');
            return;
        }

        // Get affiliate statistics
        $affiliateStats = $this->getAffiliateStats($user['id']);
        
        // Get referral history
        $referrals = $this->userModel->getReferralsByAffiliate($user['id']);
        
        // Get earnings history
        $earnings = $this->userModel->getAffiliateEarnings($user['id']);

        $this->render('customer/affiliates', [
            'title' => 'Affiliate Dashboard - Time2Eat',
            'user' => $user,
            'affiliateStats' => $affiliateStats,
            'referrals' => $referrals,
            'earnings' => $earnings
        ]);
    }

    public function addresses(): void
    {
        $this->requireAuth();
        $this->requireRole('customer');

        $user = $this->getAuthenticatedUser();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->handleAddressAction();
            return;
        }

        $addresses = $this->userModel->getAddressesByUser($user['id']);

        $this->render('customer/addresses', [
            'title' => 'My Addresses - Time2Eat',
            'user' => $user,
            'addresses' => $addresses
        ]);
    }

    public function payments(): void
    {
        $this->requireAuth();
        $this->requireRole('customer');

        $user = $this->getAuthenticatedUser();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->handlePaymentMethodAction();
            return;
        }

        $paymentMethods = $this->userModel->getPaymentMethodsByUser($user['id']);
        $transactions = $this->userModel->getTransactionHistory($user['id'], 10);

        $this->render('customer/payments', [
            'title' => 'Payment Methods - Time2Eat',
            'user' => $user,
            'paymentMethods' => $paymentMethods,
            'transactions' => $transactions
        ]);
    }

    private function getCustomerStats(int $customerId): array
    {
        return [
            'totalOrders' => $this->orderModel->countOrdersByCustomer($customerId),
            'totalSpent' => $this->orderModel->getTotalSpentByCustomer($customerId),
            'favoriteRestaurants' => $this->restaurantModel->countFavoritesByCustomer($customerId),
            'monthlyOrders' => $this->orderModel->getMonthlyOrderCount($customerId),
            'monthlySpent' => $this->orderModel->getMonthlySpent($customerId)
        ];
    }

    private function getRecommendations(int $customerId): array
    {
        // Get recommendations based on order history and preferences
        return $this->restaurantModel->getRecommendationsForCustomer($customerId, 5);
    }

    private function getAffiliateStats(int $userId): array
    {
        return [
            'totalReferrals' => $this->userModel->countReferralsByAffiliate($userId),
            'totalEarnings' => $this->userModel->getTotalAffiliateEarnings($userId),
            'monthlyReferrals' => $this->userModel->getMonthlyReferrals($userId),
            'monthlyEarnings' => $this->userModel->getMonthlyAffiliateEarnings($userId),
            'conversionRate' => $this->userModel->getAffiliateConversionRate($userId)
        ];
    }

    private function updateProfile(): void
    {
        $validation = $this->validateRequest([
            'first_name' => 'required|string|max:50',
            'last_name' => 'required|string|max:50',
            'email' => 'required|email|max:100',
            'phone' => 'required|string|max:20',
            'date_of_birth' => 'date',
            'gender' => 'in:male,female,other'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $data = $validation['data'];

        // Check if email is already taken by another user
        if ($data['email'] !== $user['email']) {
            $existingUser = $this->userModel->findByEmail($data['email']);
            if ($existingUser && $existingUser['id'] !== $user['id']) {
                $this->jsonResponse(['success' => false, 'message' => 'Email already taken'], 400);
                return;
            }
        }

        $updated = $this->userModel->update($user['id'], $data);

        if ($updated) {
            $this->jsonResponse(['success' => true, 'message' => 'Profile updated successfully']);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to update profile'], 500);
        }
    }

    private function handleAddressAction(): void
    {
        $action = $_POST['action'] ?? '';

        switch ($action) {
            case 'add':
                $this->addAddress();
                break;
            case 'update':
                $this->updateAddress();
                break;
            case 'delete':
                $this->deleteAddress();
                break;
            case 'set_default':
                $this->setDefaultAddress();
                break;
            default:
                $this->jsonResponse(['success' => false, 'message' => 'Invalid action'], 400);
        }
    }

    private function addAddress(): void
    {
        $validation = $this->validateRequest([
            'label' => 'required|string|max:50',
            'address_line_1' => 'required|string|max:255',
            'address_line_2' => 'string|max:255',
            'city' => 'required|string|max:100',
            'state' => 'string|max:100',
            'postal_code' => 'string|max:20',
            'country' => 'required|string|max:100',
            'latitude' => 'numeric',
            'longitude' => 'numeric',
            'is_default' => 'boolean'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $data = $validation['data'];
        $data['user_id'] = $user['id'];

        $addressId = $this->userModel->addAddress($data);

        if ($addressId) {
            $this->jsonResponse(['success' => true, 'message' => 'Address added successfully', 'address_id' => $addressId]);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to add address'], 500);
        }
    }

    private function updateAddress(): void
    {
        $validation = $this->validateRequest([
            'address_id' => 'required|integer',
            'label' => 'required|string|max:50',
            'address_line_1' => 'required|string|max:255',
            'address_line_2' => 'string|max:255',
            'city' => 'required|string|max:100',
            'state' => 'string|max:100',
            'postal_code' => 'string|max:20',
            'country' => 'required|string|max:100',
            'latitude' => 'numeric',
            'longitude' => 'numeric'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $data = $validation['data'];
        $addressId = $data['address_id'];
        unset($data['address_id']);

        // Verify address belongs to user
        $address = $this->userModel->getAddressById($addressId);
        if (!$address || $address['user_id'] !== $user['id']) {
            $this->jsonResponse(['success' => false, 'message' => 'Address not found'], 404);
            return;
        }

        $updated = $this->userModel->updateAddress($addressId, $data);

        if ($updated) {
            $this->jsonResponse(['success' => true, 'message' => 'Address updated successfully']);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to update address'], 500);
        }
    }

    private function deleteAddress(): void
    {
        $addressId = (int)($_POST['address_id'] ?? 0);

        if (!$addressId) {
            $this->jsonResponse(['success' => false, 'message' => 'Address ID required'], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();

        // Verify address belongs to user
        $address = $this->userModel->getAddressById($addressId);
        if (!$address || $address['user_id'] !== $user['id']) {
            $this->jsonResponse(['success' => false, 'message' => 'Address not found'], 404);
            return;
        }

        $deleted = $this->userModel->deleteAddress($addressId);

        if ($deleted) {
            $this->jsonResponse(['success' => true, 'message' => 'Address deleted successfully']);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to delete address'], 500);
        }
    }

    private function setDefaultAddress(): void
    {
        $addressId = (int)($_POST['address_id'] ?? 0);

        if (!$addressId) {
            $this->jsonResponse(['success' => false, 'message' => 'Address ID required'], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();

        // Verify address belongs to user
        $address = $this->userModel->getAddressById($addressId);
        if (!$address || $address['user_id'] !== $user['id']) {
            $this->jsonResponse(['success' => false, 'message' => 'Address not found'], 404);
            return;
        }

        $updated = $this->userModel->setDefaultAddress($user['id'], $addressId);

        if ($updated) {
            $this->jsonResponse(['success' => true, 'message' => 'Default address updated successfully']);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to update default address'], 500);
        }
    }

    private function handlePaymentMethodAction(): void
    {
        $action = $_POST['action'] ?? '';

        switch ($action) {
            case 'add':
                $this->addPaymentMethod();
                break;
            case 'delete':
                $this->deletePaymentMethod();
                break;
            case 'set_default':
                $this->setDefaultPaymentMethod();
                break;
            default:
                $this->jsonResponse(['success' => false, 'message' => 'Invalid action'], 400);
        }
    }

    private function addPaymentMethod(): void
    {
        $validation = $this->validateRequest([
            'type' => 'required|in:card,mobile_money,bank_transfer',
            'provider' => 'required|string|max:50',
            'account_name' => 'required|string|max:100',
            'account_number' => 'required|string|max:50',
            'is_default' => 'boolean'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $data = $validation['data'];
        $data['user_id'] = $user['id'];

        // Encrypt sensitive data
        $data['account_number'] = $this->encrypt($data['account_number']);

        $paymentMethodId = $this->userModel->addPaymentMethod($data);

        if ($paymentMethodId) {
            $this->jsonResponse(['success' => true, 'message' => 'Payment method added successfully', 'payment_method_id' => $paymentMethodId]);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to add payment method'], 500);
        }
    }

    private function deletePaymentMethod(): void
    {
        $paymentMethodId = (int)($_POST['payment_method_id'] ?? 0);

        if (!$paymentMethodId) {
            $this->jsonResponse(['success' => false, 'message' => 'Payment method ID required'], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();

        // Verify payment method belongs to user
        $paymentMethod = $this->userModel->getPaymentMethodById($paymentMethodId);
        if (!$paymentMethod || $paymentMethod['user_id'] !== $user['id']) {
            $this->jsonResponse(['success' => false, 'message' => 'Payment method not found'], 404);
            return;
        }

        $deleted = $this->userModel->deletePaymentMethod($paymentMethodId);

        if ($deleted) {
            $this->jsonResponse(['success' => true, 'message' => 'Payment method deleted successfully']);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to delete payment method'], 500);
        }
    }

    private function setDefaultPaymentMethod(): void
    {
        $paymentMethodId = (int)($_POST['payment_method_id'] ?? 0);

        if (!$paymentMethodId) {
            $this->jsonResponse(['success' => false, 'message' => 'Payment method ID required'], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();

        // Verify payment method belongs to user
        $paymentMethod = $this->userModel->getPaymentMethodById($paymentMethodId);
        if (!$paymentMethod || $paymentMethod['user_id'] !== $user['id']) {
            $this->jsonResponse(['success' => false, 'message' => 'Payment method not found'], 404);
            return;
        }

        $updated = $this->userModel->setDefaultPaymentMethod($user['id'], $paymentMethodId);

        if ($updated) {
            $this->jsonResponse(['success' => true, 'message' => 'Default payment method updated successfully']);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to update default payment method'], 500);
        }
    }
}
