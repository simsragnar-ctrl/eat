<?php

declare(strict_types=1);

namespace controllers;

require_once __DIR__ . '/../core/BaseController.php';

use core\BaseController;

/**
 * Enhanced Authentication Controller for Time2Eat
 * Comprehensive authentication with validation, rate limiting, and security features
 */
class EnhancedAuthController extends BaseController 
{
    /**
     * Show login form
     */
    public function showLogin(): void 
    {
        // If user is already logged in, redirect to dashboard
        if ($this->isAuthenticated()) {
            $this->redirect($this->getRedirectUrl($this->getUserRole()));
        }
        
        $this->render('auth/login', [
            'title' => 'Login - Time2Eat',
            'page' => 'login'
        ]);
    }
    
    /**
     * Process login
     */
    public function login(): void
    {
        // Validate CAPTCHA first
        if (!$this->validateCaptcha($_POST['captcha'] ?? '', $_POST['captcha_token'] ?? '')) {
            $this->render('auth/login', [
                'title' => 'Login - Time2Eat',
                'page' => 'login',
                'error' => 'Invalid CAPTCHA. Please try again.',
                'old' => $_POST
            ]);
            return;
        }

        // Validate request
        $data = $this->validateRequest([
            'email' => 'required|email',
            'password' => 'required|minlength:6',
            'remember' => 'in:on,1,true',
            'captcha' => 'required',
            'captcha_token' => 'required'
        ]);

        if (!empty($this->errors)) {
            $this->render('auth/login', [
                'title' => 'Login - Time2Eat',
                'page' => 'login',
                'errors' => $this->errors,
                'old' => $data
            ]);
            return;
        }

        // Rate limiting with IP and email
        $ipKey = 'login_ip:' . $this->getClientIp();
        $emailKey = 'login_email:' . $data['email'];

        try {
            $this->checkRateLimit($ipKey, 5, 900); // 5 attempts per 15 minutes per IP
            $this->checkRateLimit($emailKey, 3, 1800); // 3 attempts per 30 minutes per email
        } catch (Exception $e) {
            $this->logSecurityEvent('login_rate_limit_exceeded', [
                'ip' => $this->getClientIp(),
                'email' => $data['email'],
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
            ]);

            $this->render('auth/login', [
                'title' => 'Login - Time2Eat',
                'page' => 'login',
                'error' => 'Too many login attempts. Please try again later.',
                'old' => $data
            ]);
            return;
        }

        // Sanitize input
        $email = $this->sanitizeEmail($data['email']);
        $password = $data['password'];
        $remember = !empty($data['remember']);

        // Attempt login
        $result = $this->attemptLogin($email, $password, $remember);

        if (!$result['success']) {
            // Increment rate limit counters on failed login
            $this->incrementRateLimit($ipKey, 900);
            $this->incrementRateLimit($emailKey, 1800);

            $this->logSecurityEvent('login_failed', [
                'email' => $email,
                'ip' => $this->getClientIp(),
                'reason' => $result['message'],
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
            ]);

            $this->render('auth/login', [
                'title' => 'Login - Time2Eat',
                'page' => 'login',
                'error' => $result['message'],
                'old' => $data
            ]);
            return;
        }

        // Successful login - clear rate limits
        $this->clearRateLimit($ipKey);
        $this->clearRateLimit($emailKey);

        // Log successful login
        $this->logSecurityEvent('login_success', [
            'user_id' => $result['user']->id,
            'email' => $email,
            'ip' => $this->getClientIp(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
        ]);

        // Update last login
        $this->updateLastLogin($result['user']->id);

        // Set success message
        $this->flash('success', 'Welcome back, ' . $result['user']->first_name . '!');

        // Redirect to intended URL or role-specific dashboard
        $redirectUrl = $_SESSION['intended_url'] ?? $this->getRedirectUrl($result['user']->role);
        unset($_SESSION['intended_url']);

        $this->redirect($redirectUrl);
    }
    
    /**
     * Show registration form
     */
    public function showRegister(): void 
    {
        // If user is already logged in, redirect to dashboard
        if ($this->isAuthenticated()) {
            $this->redirect($this->getRedirectUrl($this->getUserRole()));
        }
        
        $this->render('auth/register', [
            'title' => 'Register - Time2Eat',
            'page' => 'register'
        ]);
    }
    
    /**
     * Process registration
     */
    public function register(): void
    {
        // Validate CAPTCHA first
        if (!$this->validateCaptcha($_POST['captcha'] ?? '', $_POST['captcha_token'] ?? '')) {
            $this->render('auth/register', [
                'title' => 'Register - Time2Eat',
                'page' => 'register',
                'error' => 'Invalid CAPTCHA. Please try again.',
                'old' => $_POST
            ]);
            return;
        }

        // Validate request with comprehensive rules
        $data = $this->validateRequest([
            'first_name' => 'required|alpha|minlength:2|maxlength:50',
            'last_name' => 'required|alpha|minlength:2|maxlength:50',
            'email' => 'required|email|unique:users,email',
            'phone' => 'required|phone',
            'password' => 'required|minlength:8|password_strength',
            'confirm_password' => 'required|confirmed:password',
            'role' => 'required|in:customer,vendor,rider',
            'terms' => 'required|accepted',
            'captcha' => 'required',
            'captcha_token' => 'required'
        ]);

        if (!empty($this->errors)) {
            $this->render('auth/register', [
                'title' => 'Register - Time2Eat',
                'page' => 'register',
                'errors' => $this->errors,
                'old' => $data
            ]);
            return;
        }

        // Rate limiting with multiple checks
        $ipKey = 'register_ip:' . $this->getClientIp();
        $emailKey = 'register_email:' . $data['email'];

        try {
            $this->checkRateLimit($ipKey, 3, 3600); // 3 registrations per hour per IP
            $this->checkRateLimit($emailKey, 1, 86400); // 1 registration per day per email
        } catch (Exception $e) {
            $this->logSecurityEvent('registration_rate_limit_exceeded', [
                'ip' => $this->getClientIp(),
                'email' => $data['email'],
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
            ]);

            $this->render('auth/register', [
                'title' => 'Register - Time2Eat',
                'page' => 'register',
                'error' => 'Registration limit exceeded. Please try again later.',
                'old' => $data
            ]);
            return;
        }

        // Sanitize input data
        $sanitizedData = [
            'first_name' => $this->sanitizeString($data['first_name']),
            'last_name' => $this->sanitizeString($data['last_name']),
            'email' => $this->sanitizeEmail($data['email']),
            'phone' => $this->sanitizePhone($data['phone']),
            'password' => $data['password'], // Don't sanitize password
            'role' => $data['role']
        ];

        // Generate username from email
        $sanitizedData['username'] = $this->generateUsername($sanitizedData['email']);

        // Generate affiliate code for all users
        $sanitizedData['affiliate_code'] = $this->generateAffiliateCode();

        // Check for referral code
        if (!empty($_GET['ref'])) {
            $referralCode = $this->sanitizeString($_GET['ref']);
            $referrer = $this->fetchOne("SELECT id FROM users WHERE affiliate_code = ? AND status = 'active'", [$referralCode]);
            if ($referrer) {
                $sanitizedData['referred_by'] = $referrer['id'];
            }
        }

        // Attempt registration
        $result = $this->attemptRegistration($sanitizedData);

        if (!$result['success']) {
            // Increment rate limit on failed registration
            $this->incrementRateLimit($ipKey, 3600);

            $this->logSecurityEvent('registration_failed', [
                'email' => $sanitizedData['email'],
                'ip' => $this->getClientIp(),
                'reason' => $result['message'],
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
            ]);

            $this->render('auth/register', [
                'title' => 'Register - Time2Eat',
                'page' => 'register',
                'error' => $result['message'],
                'old' => $data
            ]);
            return;
        }

        // Successful registration
        $this->incrementRateLimit($ipKey, 3600); // Still count successful registration

        $this->logSecurityEvent('registration_success', [
            'user_id' => $result['user']->id,
            'email' => $sanitizedData['email'],
            'role' => $sanitizedData['role'],
            'ip' => $this->getClientIp(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
        ]);

        // Send verification email
        $this->sendEmailVerification($result['user']);

        // Send welcome email (async)
        $this->sendWelcomeEmail($result['user']);

        // Handle referral if exists
        if (!empty($sanitizedData['referred_by'])) {
            $this->processReferral($sanitizedData['referred_by'], $result['user']->id);
        }

        // Set success message
        $this->flash('success', 'Registration successful! Please check your email to verify your account.');

        // Redirect to email verification page or dashboard
        if (config('auth.email_verification_required', true)) {
            $this->redirect('/verify-email?email=' . urlencode($sanitizedData['email']));
        } else {
            $redirectUrl = $this->getRedirectUrl($result['user']->role);
            $this->redirect($redirectUrl);
        }
    }
    
    /**
     * Show forgot password form
     */
    public function showForgotPassword(): void 
    {
        $this->render('auth/forgot-password', [
            'title' => 'Forgot Password - Time2Eat',
            'page' => 'forgot-password'
        ]);
    }
    
    /**
     * Process forgot password
     */
    public function forgotPassword(): void 
    {
        // Validate request
        $data = $this->validateRequest([
            'email' => 'required|email'
        ]);
        
        if (!empty($this->errors)) {
            $this->render('auth/forgot-password', [
                'title' => 'Forgot Password - Time2Eat',
                'page' => 'forgot-password',
                'errors' => $this->errors,
                'old' => $data
            ]);
            return;
        }
        
        // Rate limiting
        $this->checkRateLimit('forgot-password:' . $_SERVER['REMOTE_ADDR'], 3, 3600);
        
        // Find user
        $user = $this->fetchOne("SELECT * FROM users WHERE email = ? AND status = 'active'", [$data['email']]);
        
        if ($user) {
            // Generate reset token
            require_once __DIR__ . '/../helpers/JWTHelper.php';
            $token = \JWTHelper::createPasswordResetToken($user['id'], $user['email']);
            
            // Store token in database
            $this->update('users', [
                'reset_token' => $token,
                'reset_token_expires' => date('Y-m-d H:i:s', time() + 3600) // 1 hour
            ], ['id' => $user['id']]);
            
            // Send reset email
            $this->sendPasswordResetEmail($user, $token);
        }
        
        // Always show success message for security
        $this->flash('success', 'If an account with that email exists, we\'ve sent password reset instructions.');
        $this->redirect('/forgot-password');
    }
    
    /**
     * Show reset password form
     */
    public function showResetPassword(string $token): void 
    {
        // Validate token
        require_once __DIR__ . '/../helpers/JWTHelper.php';
        
        if (!\JWTHelper::validateTokenType($token, 'password_reset')) {
            $this->flash('error', 'Invalid or expired reset token.');
            $this->redirect('/forgot-password');
        }
        
        $this->render('auth/reset-password', [
            'title' => 'Reset Password - Time2Eat',
            'page' => 'reset-password',
            'token' => $token
        ]);
    }
    
    /**
     * Process password reset
     */
    public function resetPassword(): void 
    {
        // Validate request
        $data = $this->validateRequest([
            'token' => 'required',
            'password' => 'required|minlength:8',
            'confirm_password' => 'required|confirmed:password'
        ]);
        
        if (!empty($this->errors)) {
            $this->render('auth/reset-password', [
                'title' => 'Reset Password - Time2Eat',
                'page' => 'reset-password',
                'errors' => $this->errors,
                'token' => $data['token'] ?? ''
            ]);
            return;
        }
        
        // Validate token
        require_once __DIR__ . '/../helpers/JWTHelper.php';
        $payload = \JWTHelper::decode($data['token']);
        
        if (!$payload || $payload['type'] !== 'password_reset') {
            $this->flash('error', 'Invalid or expired reset token.');
            $this->redirect('/forgot-password');
        }
        
        // Find user and verify token
        $user = $this->fetchOne(
            "SELECT * FROM users WHERE id = ? AND email = ? AND reset_token = ? AND reset_token_expires > NOW()",
            [$payload['user_id'], $payload['email'], $data['token']]
        );
        
        if (!$user) {
            $this->flash('error', 'Invalid or expired reset token.');
            $this->redirect('/forgot-password');
        }
        
        // Update password
        $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
        $this->update('users', [
            'password' => $hashedPassword,
            'reset_token' => null,
            'reset_token_expires' => null,
            'updated_at' => date('Y-m-d H:i:s')
        ], ['id' => $user['id']]);
        
        $this->flash('success', 'Password reset successful! You can now log in with your new password.');
        $this->redirect('/login');
    }
    
    /**
     * Logout user
     */
    public function logout(): void 
    {
        $this->logout();
        $this->flash('success', 'You have been logged out successfully.');
        $this->redirect('/');
    }
    
    /**
     * Attempt user login
     */
    private function attemptLogin(string $email, string $password, bool $remember = false): array 
    {
        return $this->login($email, $password, $remember);
    }
    
    /**
     * Attempt user registration
     */
    private function attemptRegistration(array $data): array 
    {
        return $this->register($data);
    }
    
    /**
     * Get redirect URL based on user role
     */
    private function getRedirectUrl(string $role): string 
    {
        return match($role) {
            'admin' => '/admin/dashboard',
            'vendor' => '/vendor/dashboard',
            'rider' => '/rider/dashboard',
            default => '/dashboard'
        };
    }
    
    /**
     * Send welcome email to new user
     */
    private function sendWelcomeEmail(object $user): void 
    {
        // Implementation would use email service
        // For now, just log the action
        error_log("Welcome email sent to: {$user->email}");
    }
    
    /**
     * Send password reset email
     */
    private function sendPasswordResetEmail(array $user, string $token): void
    {
        // Implementation would use email service
        // For now, just log the action
        error_log("Password reset email sent to: {$user['email']} with token: {$token}");
    }

    /**
     * Validate CAPTCHA
     */
    private function validateCaptcha(string $captcha, string $token): bool
    {
        if (empty($captcha) || empty($token)) {
            return false;
        }

        $expectedCaptcha = base64_decode($token);
        return strtoupper($captcha) === strtoupper($expectedCaptcha);
    }

    /**
     * Get client IP address
     */
    private function getClientIp(): string
    {
        $ipKeys = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR'];

        foreach ($ipKeys as $key) {
            if (!empty($_SERVER[$key])) {
                $ips = explode(',', $_SERVER[$key]);
                $ip = trim($ips[0]);

                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }

        return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    }

    /**
     * Log security events
     */
    private function logSecurityEvent(string $event, array $data): void
    {
        $logData = [
            'event' => $event,
            'timestamp' => date('Y-m-d H:i:s'),
            'ip' => $this->getClientIp(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'data' => $data
        ];

        // Log to security log
        error_log("SECURITY: " . json_encode($logData));

        // Store in database
        $this->insert('logs', [
            'level' => 'warning',
            'message' => "Security event: {$event}",
            'context' => json_encode($logData),
            'channel' => 'security',
            'user_id' => $data['user_id'] ?? null,
            'ip_address' => $this->getClientIp(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'url' => $_SERVER['REQUEST_URI'] ?? '',
            'method' => $_SERVER['REQUEST_METHOD'] ?? ''
        ]);
    }

    /**
     * Sanitize email address
     */
    private function sanitizeEmail(string $email): string
    {
        return strtolower(trim(filter_var($email, FILTER_SANITIZE_EMAIL)));
    }

    /**
     * Sanitize string input
     */
    private function sanitizeString(string $input): string
    {
        return trim(htmlspecialchars($input, ENT_QUOTES, 'UTF-8'));
    }

    /**
     * Sanitize phone number
     */
    private function sanitizePhone(string $phone): string
    {
        // Remove all non-numeric characters except +
        $phone = preg_replace('/[^\d+]/', '', $phone);

        // Add Cameroon country code if not present
        if (!str_starts_with($phone, '+')) {
            if (str_starts_with($phone, '237')) {
                $phone = '+' . $phone;
            } elseif (str_starts_with($phone, '6')) {
                $phone = '+237' . $phone;
            }
        }

        return $phone;
    }

    /**
     * Generate unique username from email
     */
    private function generateUsername(string $email): string
    {
        $baseUsername = strtolower(explode('@', $email)[0]);
        $baseUsername = preg_replace('/[^a-z0-9]/', '', $baseUsername);

        $username = $baseUsername;
        $counter = 1;

        while ($this->fetchOne("SELECT id FROM users WHERE username = ?", [$username])) {
            $username = $baseUsername . $counter;
            $counter++;
        }

        return $username;
    }

    /**
     * Generate unique affiliate code
     */
    private function generateAffiliateCode(): string
    {
        do {
            $code = strtoupper(substr(md5(uniqid(rand(), true)), 0, 8));
        } while ($this->fetchOne("SELECT id FROM users WHERE affiliate_code = ?", [$code]));

        return $code;
    }

    /**
     * Update last login timestamp
     */
    private function updateLastLogin(int $userId): void
    {
        $this->update('users', [
            'last_login_at' => date('Y-m-d H:i:s'),
            'last_login_ip' => $this->getClientIp()
        ], ['id' => $userId]);
    }

    /**
     * Send email verification
     */
    private function sendEmailVerification(object $user): void
    {
        require_once __DIR__ . '/../helpers/JWTHelper.php';
        $token = \JWTHelper::createEmailVerificationToken($user->id, $user->email);

        // Store verification token
        $this->update('users', [
            'email_verification_token' => $token,
            'email_verification_expires' => date('Y-m-d H:i:s', time() + 86400) // 24 hours
        ], ['id' => $user->id]);

        // Send email (implementation would use email service)
        error_log("Email verification sent to: {$user->email} with token: {$token}");
    }

    /**
     * Process referral
     */
    private function processReferral(int $referrerId, int $newUserId): void
    {
        // Create referral record
        $this->insert('affiliate_referrals', [
            'affiliate_id' => $referrerId,
            'referred_user_id' => $newUserId,
            'commission_rate' => 0.05, // 5% default
            'status' => 'pending'
        ]);

        // Update referrer stats
        $this->query("UPDATE users SET referral_count = referral_count + 1 WHERE id = ?", [$referrerId]);
        $this->query("UPDATE affiliates SET total_referrals = total_referrals + 1 WHERE user_id = ?", [$referrerId]);
    }
}
