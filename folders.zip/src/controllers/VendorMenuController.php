<?php

declare(strict_types=1);

namespace Time2Eat\Controllers;

use Time2Eat\Core\Controller;
use Time2Eat\Models\MenuItem;
use Time2Eat\Models\Restaurant;
use Time2Eat\Models\MenuCategory;
use Time2Eat\Models\User;

/**
 * Vendor Menu Management Controller
 * Handles menu item CRUD, bulk operations, and inventory management
 */
class VendorMenuController extends Controller
{
    private MenuItem $menuItemModel;
    private Restaurant $restaurantModel;
    private MenuCategory $categoryModel;
    private User $userModel;

    public function __construct()
    {
        parent::__construct();
        $this->menuItemModel = new MenuItem();
        $this->restaurantModel = new Restaurant();
        $this->categoryModel = new MenuCategory();
        $this->userModel = new User();
    }

    /**
     * Display vendor menu dashboard
     */
    public function dashboard(): void
    {
        if (!$this->isAuthenticated() || !$this->hasRole(['vendor'])) {
            $this->redirect('/login');
            return;
        }

        $user = $this->getAuthenticatedUser();
        $restaurant = $this->restaurantModel->getByVendorId($user['id']);

        if (!$restaurant) {
            $this->redirect('/vendor/profile/create');
            return;
        }

        // Get menu statistics
        $stats = $this->menuItemModel->getRestaurantStats($restaurant['id']);
        $recentItems = $this->menuItemModel->getRecentItems($restaurant['id'], 10);
        $lowStockItems = $this->menuItemModel->getLowStockItems($restaurant['id']);
        $categories = $this->categoryModel->getByRestaurant($restaurant['id']);

        $this->render('vendor/menu/dashboard', [
            'title' => 'Menu Management - Time2Eat',
            'restaurant' => $restaurant,
            'stats' => $stats,
            'recentItems' => $recentItems,
            'lowStockItems' => $lowStockItems,
            'categories' => $categories
        ]);
    }

    /**
     * Display menu items list
     */
    public function index(): void
    {
        if (!$this->isAuthenticated() || !$this->hasRole(['vendor'])) {
            $this->redirect('/login');
            return;
        }

        $user = $this->getAuthenticatedUser();
        $restaurant = $this->restaurantModel->getByVendorId($user['id']);

        if (!$restaurant) {
            $this->redirect('/vendor/profile/create');
            return;
        }

        // Get filters and pagination
        $page = (int)($_GET['page'] ?? 1);
        $limit = 20;
        $offset = ($page - 1) * $limit;
        $category = $_GET['category'] ?? '';
        $status = $_GET['status'] ?? '';
        $search = $_GET['search'] ?? '';

        // Get menu items with filters
        $items = $this->menuItemModel->getRestaurantItems(
            $restaurant['id'],
            $limit,
            $offset,
            $category,
            $status,
            $search
        );

        $totalItems = $this->menuItemModel->countRestaurantItems(
            $restaurant['id'],
            $category,
            $status,
            $search
        );

        $totalPages = ceil($totalItems / $limit);
        $categories = $this->categoryModel->getByRestaurant($restaurant['id']);

        $this->render('vendor/menu/index', [
            'title' => 'Menu Items - Time2Eat',
            'restaurant' => $restaurant,
            'items' => $items,
            'categories' => $categories,
            'currentPage' => $page,
            'totalPages' => $totalPages,
            'totalItems' => $totalItems,
            'filters' => [
                'category' => $category,
                'status' => $status,
                'search' => $search
            ]
        ]);
    }

    /**
     * Show create menu item form
     */
    public function create(): void
    {
        if (!$this->isAuthenticated() || !$this->hasRole(['vendor'])) {
            $this->redirect('/login');
            return;
        }

        $user = $this->getAuthenticatedUser();
        $restaurant = $this->restaurantModel->getByVendorId($user['id']);

        if (!$restaurant) {
            $this->redirect('/vendor/profile/create');
            return;
        }

        $categories = $this->categoryModel->getByRestaurant($restaurant['id']);

        $this->render('vendor/menu/create', [
            'title' => 'Add Menu Item - Time2Eat',
            'restaurant' => $restaurant,
            'categories' => $categories
        ]);
    }

    /**
     * Store new menu item
     */
    public function store(): void
    {
        if (!$this->isAuthenticated() || !$this->hasRole(['vendor'])) {
            $this->jsonResponse(['success' => false, 'message' => 'Unauthorized'], 401);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $restaurant = $this->restaurantModel->getByVendorId($user['id']);

        if (!$restaurant) {
            $this->jsonResponse(['success' => false, 'message' => 'Restaurant not found'], 404);
            return;
        }

        $input = $this->getInput();
        $validation = $this->validateMenuItemData($input);

        if (!$validation['valid']) {
            $this->jsonResponse([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validation['errors']
            ], 400);
            return;
        }

        try {
            // Handle image upload
            $imagePath = null;
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $imagePath = $this->handleImageUpload($_FILES['image']);
                if (!$imagePath) {
                    $this->jsonResponse([
                        'success' => false,
                        'message' => 'Image upload failed'
                    ], 400);
                    return;
                }
            }

            // Create menu item
            $itemId = $this->menuItemModel->createItem([
                'restaurant_id' => $restaurant['id'],
                'category_id' => $input['category_id'],
                'name' => $input['name'],
                'description' => $input['description'],
                'price' => (float)$input['price'],
                'image_url' => $imagePath,
                'is_available' => isset($input['is_available']) ? 1 : 0,
                'stock_quantity' => (int)($input['stock_quantity'] ?? 0),
                'min_stock_level' => (int)($input['min_stock_level'] ?? 5),
                'preparation_time' => (int)($input['preparation_time'] ?? 15),
                'calories' => !empty($input['calories']) ? (int)$input['calories'] : null,
                'ingredients' => $input['ingredients'] ?? null,
                'allergens' => $input['allergens'] ?? null,
                'is_vegetarian' => isset($input['is_vegetarian']) ? 1 : 0,
                'is_vegan' => isset($input['is_vegan']) ? 1 : 0,
                'is_gluten_free' => isset($input['is_gluten_free']) ? 1 : 0,
                'customization_options' => !empty($input['customization_options']) 
                    ? json_encode(explode(',', $input['customization_options'])) 
                    : null
            ]);

            if ($itemId) {
                $this->jsonResponse([
                    'success' => true,
                    'message' => 'Menu item created successfully',
                    'item_id' => $itemId,
                    'redirect' => '/vendor/menu'
                ]);
            } else {
                $this->jsonResponse([
                    'success' => false,
                    'message' => 'Failed to create menu item'
                ], 500);
            }
        } catch (\Exception $e) {
            $this->logError('Menu item creation failed', [
                'restaurant_id' => $restaurant['id'],
                'error' => $e->getMessage()
            ]);

            $this->jsonResponse([
                'success' => false,
                'message' => 'An error occurred while creating the menu item'
            ], 500);
        }
    }

    /**
     * Show edit menu item form
     */
    public function edit(int $id): void
    {
        if (!$this->isAuthenticated() || !$this->hasRole(['vendor'])) {
            $this->redirect('/login');
            return;
        }

        $user = $this->getAuthenticatedUser();
        $restaurant = $this->restaurantModel->getByVendorId($user['id']);

        if (!$restaurant) {
            $this->redirect('/vendor/profile/create');
            return;
        }

        $item = $this->menuItemModel->getById($id);
        if (!$item || $item['restaurant_id'] !== $restaurant['id']) {
            $this->redirect('/vendor/menu');
            return;
        }

        $categories = $this->categoryModel->getByRestaurant($restaurant['id']);

        $this->render('vendor/menu/edit', [
            'title' => 'Edit Menu Item - Time2Eat',
            'restaurant' => $restaurant,
            'item' => $item,
            'categories' => $categories
        ]);
    }

    /**
     * Update menu item
     */
    public function update(int $id): void
    {
        if (!$this->isAuthenticated() || !$this->hasRole(['vendor'])) {
            $this->jsonResponse(['success' => false, 'message' => 'Unauthorized'], 401);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $restaurant = $this->restaurantModel->getByVendorId($user['id']);

        if (!$restaurant) {
            $this->jsonResponse(['success' => false, 'message' => 'Restaurant not found'], 404);
            return;
        }

        $item = $this->menuItemModel->getById($id);
        if (!$item || $item['restaurant_id'] !== $restaurant['id']) {
            $this->jsonResponse(['success' => false, 'message' => 'Menu item not found'], 404);
            return;
        }

        $input = $this->getInput();
        $validation = $this->validateMenuItemData($input, $id);

        if (!$validation['valid']) {
            $this->jsonResponse([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validation['errors']
            ], 400);
            return;
        }

        try {
            // Handle image upload
            $imagePath = $item['image_url'];
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $newImagePath = $this->handleImageUpload($_FILES['image']);
                if ($newImagePath) {
                    // Delete old image
                    if ($imagePath && file_exists(PUBLIC_PATH . $imagePath)) {
                        unlink(PUBLIC_PATH . $imagePath);
                    }
                    $imagePath = $newImagePath;
                }
            }

            // Update menu item
            $success = $this->menuItemModel->updateItem($id, [
                'category_id' => $input['category_id'],
                'name' => $input['name'],
                'description' => $input['description'],
                'price' => (float)$input['price'],
                'image_url' => $imagePath,
                'is_available' => isset($input['is_available']) ? 1 : 0,
                'stock_quantity' => (int)($input['stock_quantity'] ?? 0),
                'min_stock_level' => (int)($input['min_stock_level'] ?? 5),
                'preparation_time' => (int)($input['preparation_time'] ?? 15),
                'calories' => !empty($input['calories']) ? (int)$input['calories'] : null,
                'ingredients' => $input['ingredients'] ?? null,
                'allergens' => $input['allergens'] ?? null,
                'is_vegetarian' => isset($input['is_vegetarian']) ? 1 : 0,
                'is_vegan' => isset($input['is_vegan']) ? 1 : 0,
                'is_gluten_free' => isset($input['is_gluten_free']) ? 1 : 0,
                'customization_options' => !empty($input['customization_options']) 
                    ? json_encode(explode(',', $input['customization_options'])) 
                    : null
            ]);

            if ($success) {
                $this->jsonResponse([
                    'success' => true,
                    'message' => 'Menu item updated successfully',
                    'redirect' => '/vendor/menu'
                ]);
            } else {
                $this->jsonResponse([
                    'success' => false,
                    'message' => 'Failed to update menu item'
                ], 500);
            }
        } catch (\Exception $e) {
            $this->logError('Menu item update failed', [
                'item_id' => $id,
                'error' => $e->getMessage()
            ]);

            $this->jsonResponse([
                'success' => false,
                'message' => 'An error occurred while updating the menu item'
            ], 500);
        }
    }

    /**
     * Delete menu item
     */
    public function delete(int $id): void
    {
        if (!$this->isAuthenticated() || !$this->hasRole(['vendor'])) {
            $this->jsonResponse(['success' => false, 'message' => 'Unauthorized'], 401);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $restaurant = $this->restaurantModel->getByVendorId($user['id']);

        if (!$restaurant) {
            $this->jsonResponse(['success' => false, 'message' => 'Restaurant not found'], 404);
            return;
        }

        $item = $this->menuItemModel->getById($id);
        if (!$item || $item['restaurant_id'] !== $restaurant['id']) {
            $this->jsonResponse(['success' => false, 'message' => 'Menu item not found'], 404);
            return;
        }

        try {
            $success = $this->menuItemModel->deleteItem($id);

            if ($success) {
                // Delete associated image
                if ($item['image_url'] && file_exists(PUBLIC_PATH . $item['image_url'])) {
                    unlink(PUBLIC_PATH . $item['image_url']);
                }

                $this->jsonResponse([
                    'success' => true,
                    'message' => 'Menu item deleted successfully'
                ]);
            } else {
                $this->jsonResponse([
                    'success' => false,
                    'message' => 'Failed to delete menu item'
                ], 500);
            }
        } catch (\Exception $e) {
            $this->logError('Menu item deletion failed', [
                'item_id' => $id,
                'error' => $e->getMessage()
            ]);

            $this->jsonResponse([
                'success' => false,
                'message' => 'An error occurred while deleting the menu item'
            ], 500);
        }
    }

    /**
     * Toggle item availability
     */
    public function toggleAvailability(int $id): void
    {
        if (!$this->isAuthenticated() || !$this->hasRole(['vendor'])) {
            $this->jsonResponse(['success' => false, 'message' => 'Unauthorized'], 401);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $restaurant = $this->restaurantModel->getByVendorId($user['id']);

        if (!$restaurant) {
            $this->jsonResponse(['success' => false, 'message' => 'Restaurant not found'], 404);
            return;
        }

        $item = $this->menuItemModel->getById($id);
        if (!$item || $item['restaurant_id'] !== $restaurant['id']) {
            $this->jsonResponse(['success' => false, 'message' => 'Menu item not found'], 404);
            return;
        }

        try {
            $newStatus = $item['is_available'] ? 0 : 1;
            $success = $this->menuItemModel->updateItem($id, ['is_available' => $newStatus]);

            if ($success) {
                $this->jsonResponse([
                    'success' => true,
                    'message' => 'Item availability updated',
                    'is_available' => $newStatus
                ]);
            } else {
                $this->jsonResponse([
                    'success' => false,
                    'message' => 'Failed to update availability'
                ], 500);
            }
        } catch (\Exception $e) {
            $this->logError('Toggle availability failed', [
                'item_id' => $id,
                'error' => $e->getMessage()
            ]);

            $this->jsonResponse([
                'success' => false,
                'message' => 'An error occurred'
            ], 500);
        }
    }

    /**
     * Update stock quantity
     */
    public function updateStock(int $id): void
    {
        if (!$this->isAuthenticated() || !$this->hasRole(['vendor'])) {
            $this->jsonResponse(['success' => false, 'message' => 'Unauthorized'], 401);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $restaurant = $this->restaurantModel->getByVendorId($user['id']);

        if (!$restaurant) {
            $this->jsonResponse(['success' => false, 'message' => 'Restaurant not found'], 404);
            return;
        }

        $item = $this->menuItemModel->getById($id);
        if (!$item || $item['restaurant_id'] !== $restaurant['id']) {
            $this->jsonResponse(['success' => false, 'message' => 'Menu item not found'], 404);
            return;
        }

        $input = $this->getJsonInput();
        $stockQuantity = (int)($input['stock_quantity'] ?? 0);

        if ($stockQuantity < 0) {
            $this->jsonResponse([
                'success' => false,
                'message' => 'Stock quantity cannot be negative'
            ], 400);
            return;
        }

        try {
            $updateData = ['stock_quantity' => $stockQuantity];

            // Auto-disable if out of stock
            if ($stockQuantity === 0) {
                $updateData['is_available'] = 0;
            } elseif ($stockQuantity > 0 && !$item['is_available']) {
                $updateData['is_available'] = 1;
            }

            $success = $this->menuItemModel->updateItem($id, $updateData);

            if ($success) {
                $this->jsonResponse([
                    'success' => true,
                    'message' => 'Stock updated successfully',
                    'stock_quantity' => $stockQuantity,
                    'is_available' => $updateData['is_available'] ?? $item['is_available']
                ]);
            } else {
                $this->jsonResponse([
                    'success' => false,
                    'message' => 'Failed to update stock'
                ], 500);
            }
        } catch (\Exception $e) {
            $this->logError('Stock update failed', [
                'item_id' => $id,
                'error' => $e->getMessage()
            ]);

            $this->jsonResponse([
                'success' => false,
                'message' => 'An error occurred'
            ], 500);
        }
    }

    /**
     * Bulk CSV import
     */
    public function importCsv(): void
    {
        if (!$this->isAuthenticated() || !$this->hasRole(['vendor'])) {
            $this->jsonResponse(['success' => false, 'message' => 'Unauthorized'], 401);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $restaurant = $this->restaurantModel->getByVendorId($user['id']);

        if (!$restaurant) {
            $this->jsonResponse(['success' => false, 'message' => 'Restaurant not found'], 404);
            return;
        }

        if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
            $this->jsonResponse([
                'success' => false,
                'message' => 'No CSV file uploaded or upload error'
            ], 400);
            return;
        }

        try {
            $results = $this->processCsvImport($_FILES['csv_file'], $restaurant['id']);

            $this->jsonResponse([
                'success' => true,
                'message' => 'CSV import completed',
                'results' => $results
            ]);
        } catch (\Exception $e) {
            $this->logError('CSV import failed', [
                'restaurant_id' => $restaurant['id'],
                'error' => $e->getMessage()
            ]);

            $this->jsonResponse([
                'success' => false,
                'message' => 'CSV import failed: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Show bulk import form
     */
    public function showImport(): void
    {
        if (!$this->isAuthenticated() || !$this->hasRole(['vendor'])) {
            $this->redirect('/login');
            return;
        }

        $user = $this->getAuthenticatedUser();
        $restaurant = $this->restaurantModel->getByVendorId($user['id']);

        if (!$restaurant) {
            $this->redirect('/vendor/profile/create');
            return;
        }

        $categories = $this->categoryModel->getByRestaurant($restaurant['id']);

        $this->render('vendor/menu/import', [
            'title' => 'Import Menu Items - Time2Eat',
            'restaurant' => $restaurant,
            'categories' => $categories
        ]);
    }

    /**
     * Download CSV template
     */
    public function downloadTemplate(): void
    {
        if (!$this->isAuthenticated() || !$this->hasRole(['vendor'])) {
            $this->redirect('/login');
            return;
        }

        $csvContent = $this->generateCsvTemplate();

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="menu_items_template.csv"');
        header('Content-Length: ' . strlen($csvContent));

        echo $csvContent;
        exit;
    }

    /**
     * Handle image upload with GD processing
     */
    private function handleImageUpload(array $file): ?string
    {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
        $maxSize = 5 * 1024 * 1024; // 5MB

        if (!in_array($file['type'], $allowedTypes)) {
            return null;
        }

        if ($file['size'] > $maxSize) {
            return null;
        }

        $uploadDir = PUBLIC_PATH . '/images/menu/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = uniqid('menu_') . '.' . $extension;
        $filepath = $uploadDir . $filename;

        // Create image resource
        switch ($file['type']) {
            case 'image/jpeg':
                $image = imagecreatefromjpeg($file['tmp_name']);
                break;
            case 'image/png':
                $image = imagecreatefrompng($file['tmp_name']);
                break;
            case 'image/webp':
                $image = imagecreatefromwebp($file['tmp_name']);
                break;
            default:
                return null;
        }

        if (!$image) {
            return null;
        }

        // Resize image to max 800x600
        $originalWidth = imagesx($image);
        $originalHeight = imagesy($image);
        $maxWidth = 800;
        $maxHeight = 600;

        if ($originalWidth > $maxWidth || $originalHeight > $maxHeight) {
            $ratio = min($maxWidth / $originalWidth, $maxHeight / $originalHeight);
            $newWidth = (int)($originalWidth * $ratio);
            $newHeight = (int)($originalHeight * $ratio);

            $resizedImage = imagecreatetruecolor($newWidth, $newHeight);

            // Preserve transparency for PNG
            if ($file['type'] === 'image/png') {
                imagealphablending($resizedImage, false);
                imagesavealpha($resizedImage, true);
            }

            imagecopyresampled(
                $resizedImage, $image,
                0, 0, 0, 0,
                $newWidth, $newHeight,
                $originalWidth, $originalHeight
            );

            imagedestroy($image);
            $image = $resizedImage;
        }

        // Save optimized image
        $success = false;
        switch ($file['type']) {
            case 'image/jpeg':
                $success = imagejpeg($image, $filepath, 85);
                break;
            case 'image/png':
                $success = imagepng($image, $filepath, 6);
                break;
            case 'image/webp':
                $success = imagewebp($image, $filepath, 85);
                break;
        }

        imagedestroy($image);

        return $success ? '/images/menu/' . $filename : null;
    }

    /**
     * Validate menu item data
     */
    private function validateMenuItemData(array $data, ?int $itemId = null): array
    {
        $errors = [];

        // Required fields
        if (empty($data['name'])) {
            $errors['name'] = 'Name is required';
        } elseif (strlen($data['name']) > 255) {
            $errors['name'] = 'Name must be less than 255 characters';
        }

        if (empty($data['description'])) {
            $errors['description'] = 'Description is required';
        }

        if (empty($data['price']) || !is_numeric($data['price']) || (float)$data['price'] <= 0) {
            $errors['price'] = 'Valid price is required';
        }

        if (empty($data['category_id']) || !is_numeric($data['category_id'])) {
            $errors['category_id'] = 'Category is required';
        }

        // Optional numeric fields
        if (!empty($data['calories']) && (!is_numeric($data['calories']) || (int)$data['calories'] < 0)) {
            $errors['calories'] = 'Calories must be a positive number';
        }

        if (!empty($data['preparation_time']) && (!is_numeric($data['preparation_time']) || (int)$data['preparation_time'] < 1)) {
            $errors['preparation_time'] = 'Preparation time must be at least 1 minute';
        }

        if (!empty($data['stock_quantity']) && (!is_numeric($data['stock_quantity']) || (int)$data['stock_quantity'] < 0)) {
            $errors['stock_quantity'] = 'Stock quantity must be a non-negative number';
        }

        if (!empty($data['min_stock_level']) && (!is_numeric($data['min_stock_level']) || (int)$data['min_stock_level'] < 0)) {
            $errors['min_stock_level'] = 'Minimum stock level must be a non-negative number';
        }

        return [
            'valid' => empty($errors),
            'errors' => $errors
        ];
    }

    /**
     * Process CSV import
     */
    private function processCsvImport(array $file, int $restaurantId): array
    {
        $results = [
            'total' => 0,
            'imported' => 0,
            'errors' => []
        ];

        $handle = fopen($file['tmp_name'], 'r');
        if (!$handle) {
            throw new \Exception('Could not open CSV file');
        }

        // Read header row
        $headers = fgetcsv($handle);
        if (!$headers) {
            fclose($handle);
            throw new \Exception('Invalid CSV format');
        }

        $expectedHeaders = [
            'name', 'description', 'price', 'category_name', 'stock_quantity',
            'preparation_time', 'calories', 'ingredients', 'allergens',
            'is_vegetarian', 'is_vegan', 'is_gluten_free', 'customization_options'
        ];

        // Validate headers
        foreach ($expectedHeaders as $expected) {
            if (!in_array($expected, $headers)) {
                fclose($handle);
                throw new \Exception("Missing required column: $expected");
            }
        }

        $rowNumber = 1;
        while (($row = fgetcsv($handle)) !== false) {
            $rowNumber++;
            $results['total']++;

            try {
                $data = array_combine($headers, $row);

                // Find or create category
                $categoryId = $this->findOrCreateCategory($data['category_name'], $restaurantId);
                if (!$categoryId) {
                    $results['errors'][] = "Row $rowNumber: Invalid category";
                    continue;
                }

                // Prepare item data
                $itemData = [
                    'restaurant_id' => $restaurantId,
                    'category_id' => $categoryId,
                    'name' => trim($data['name']),
                    'description' => trim($data['description']),
                    'price' => (float)$data['price'],
                    'stock_quantity' => (int)($data['stock_quantity'] ?? 0),
                    'preparation_time' => (int)($data['preparation_time'] ?? 15),
                    'calories' => !empty($data['calories']) ? (int)$data['calories'] : null,
                    'ingredients' => !empty($data['ingredients']) ? trim($data['ingredients']) : null,
                    'allergens' => !empty($data['allergens']) ? trim($data['allergens']) : null,
                    'is_vegetarian' => $this->parseBooleanValue($data['is_vegetarian'] ?? ''),
                    'is_vegan' => $this->parseBooleanValue($data['is_vegan'] ?? ''),
                    'is_gluten_free' => $this->parseBooleanValue($data['is_gluten_free'] ?? ''),
                    'customization_options' => !empty($data['customization_options'])
                        ? json_encode(array_map('trim', explode(',', $data['customization_options'])))
                        : null,
                    'is_available' => 1
                ];

                // Validate data
                $validation = $this->validateMenuItemData($itemData);
                if (!$validation['valid']) {
                    $results['errors'][] = "Row $rowNumber: " . implode(', ', $validation['errors']);
                    continue;
                }

                // Create item
                $itemId = $this->menuItemModel->createItem($itemData);
                if ($itemId) {
                    $results['imported']++;
                } else {
                    $results['errors'][] = "Row $rowNumber: Failed to create item";
                }
            } catch (\Exception $e) {
                $results['errors'][] = "Row $rowNumber: " . $e->getMessage();
            }
        }

        fclose($handle);
        return $results;
    }

    /**
     * Find or create category
     */
    private function findOrCreateCategory(string $categoryName, int $restaurantId): ?int
    {
        $category = $this->categoryModel->findByName($categoryName, $restaurantId);

        if ($category) {
            return $category['id'];
        }

        // Create new category
        return $this->categoryModel->create([
            'restaurant_id' => $restaurantId,
            'name' => $categoryName,
            'description' => "Auto-created category for $categoryName",
            'is_active' => 1
        ]);
    }

    /**
     * Parse boolean value from CSV
     */
    private function parseBooleanValue(string $value): int
    {
        $value = strtolower(trim($value));
        return in_array($value, ['1', 'true', 'yes', 'y']) ? 1 : 0;
    }

    /**
     * Generate CSV template
     */
    private function generateCsvTemplate(): string
    {
        $headers = [
            'name', 'description', 'price', 'category_name', 'stock_quantity',
            'preparation_time', 'calories', 'ingredients', 'allergens',
            'is_vegetarian', 'is_vegan', 'is_gluten_free', 'customization_options'
        ];

        $sampleData = [
            'Jollof Rice', 'Delicious Nigerian jollof rice with chicken', '2500', 'Main Dishes', '50',
            '20', '450', 'Rice, Chicken, Tomatoes, Onions, Spices', 'None',
            'no', 'no', 'yes', 'Extra chicken, Spicy level'
        ];

        $csv = implode(',', $headers) . "\n";
        $csv .= implode(',', array_map(function($value) {
            return '"' . str_replace('"', '""', $value) . '"';
        }, $sampleData)) . "\n";

        return $csv;
    }
}
