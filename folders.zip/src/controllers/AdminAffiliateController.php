<?php

namespace Time2Eat\Controllers;

use Time2Eat\Core\Controller;
use Time2Eat\Models\Affiliate;
use Time2Eat\Models\AffiliateEarning;
use Time2Eat\Models\AffiliateWithdrawal;
use Time2Eat\Models\AffiliatePayout;
use Time2Eat\Models\User;

class AdminAffiliateController extends Controller
{
    private Affiliate $affiliateModel;
    private AffiliateEarning $earningModel;
    private AffiliateWithdrawal $withdrawalModel;
    private AffiliatePayout $payoutModel;
    private User $userModel;

    public function __construct()
    {
        parent::__construct();
        $this->affiliateModel = new Affiliate();
        $this->earningModel = new AffiliateEarning();
        $this->withdrawalModel = new AffiliateWithdrawal();
        $this->payoutModel = new AffiliatePayout();
        $this->userModel = new User();
    }

    public function dashboard(): void
    {
        $this->requireAuth(['admin']);
        $user = $this->getAuthenticatedUser();

        // Get affiliate overview statistics
        $totalAffiliates = $this->affiliateModel->count();
        $activeAffiliates = $this->affiliateModel->countByColumn('status', 'active');
        $totalEarnings = $this->getTotalEarnings();
        $totalWithdrawals = $this->getTotalWithdrawals();
        $pendingWithdrawals = $this->withdrawalModel->getAllPendingWithdrawals();

        // Get top affiliates
        $topAffiliates = $this->affiliateModel->getTopAffiliates(10);

        // Get payout statistics
        $payoutStats = $this->payoutModel->getPayoutStats();

        $this->render('admin/affiliate/dashboard', [
            'title' => 'Affiliate Management - Admin Dashboard',
            'user' => $user,
            'stats' => [
                'total_affiliates' => $totalAffiliates,
                'active_affiliates' => $activeAffiliates,
                'total_earnings' => $totalEarnings,
                'total_withdrawals' => $totalWithdrawals,
                'pending_withdrawals_count' => count($pendingWithdrawals)
            ],
            'top_affiliates' => $topAffiliates,
            'pending_withdrawals' => $pendingWithdrawals,
            'payout_stats' => $payoutStats
        ]);
    }

    public function affiliates(): void
    {
        $this->requireAuth(['admin']);
        $user = $this->getAuthenticatedUser();

        $page = (int)($_GET['page'] ?? 1);
        $search = $_GET['search'] ?? '';
        $status = $_GET['status'] ?? '';

        // Get affiliates with pagination and filters
        $affiliatesData = $this->getAffiliatesWithFilters($page, $search, $status);

        $this->render('admin/affiliate/affiliates', [
            'title' => 'Manage Affiliates - Admin Dashboard',
            'user' => $user,
            'affiliates_data' => $affiliatesData,
            'search' => $search,
            'status' => $status
        ]);
    }

    public function withdrawals(): void
    {
        $this->requireAuth(['admin']);
        $user = $this->getAuthenticatedUser();

        $status = $_GET['status'] ?? 'pending';
        $page = (int)($_GET['page'] ?? 1);

        // Get withdrawals based on status
        $withdrawalsData = $this->getWithdrawalsWithFilters($page, $status);

        $this->render('admin/affiliate/withdrawals', [
            'title' => 'Manage Withdrawals - Admin Dashboard',
            'user' => $user,
            'withdrawals_data' => $withdrawalsData,
            'status' => $status
        ]);
    }

    public function approveWithdrawal(): void
    {
        $this->requireAuth(['admin']);
        
        $validation = $this->validateRequest([
            'withdrawal_id' => 'required|integer',
            'notes' => 'string'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $data = $validation['data'];

        $success = $this->withdrawalModel->approveWithdrawal(
            $data['withdrawal_id'],
            $user['id'],
            $data['notes'] ?? null
        );

        if ($success) {
            $this->jsonResponse([
                'success' => true,
                'message' => 'Withdrawal approved successfully'
            ]);
        } else {
            $this->jsonResponse([
                'success' => false,
                'message' => $this->withdrawalModel->getLastError()
            ], 400);
        }
    }

    public function rejectWithdrawal(): void
    {
        $this->requireAuth(['admin']);
        
        $validation = $this->validateRequest([
            'withdrawal_id' => 'required|integer',
            'reason' => 'required|string'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $data = $validation['data'];

        $success = $this->withdrawalModel->rejectWithdrawal(
            $data['withdrawal_id'],
            $user['id'],
            $data['reason']
        );

        if ($success) {
            $this->jsonResponse([
                'success' => true,
                'message' => 'Withdrawal rejected successfully'
            ]);
        } else {
            $this->jsonResponse([
                'success' => false,
                'message' => $this->withdrawalModel->getLastError()
            ], 400);
        }
    }

    public function updateCommissionRate(): void
    {
        $this->requireAuth(['admin']);
        
        $validation = $this->validateRequest([
            'affiliate_id' => 'required|integer',
            'commission_rate' => 'required|numeric|min:0|max:100'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $data = $validation['data'];

        $success = $this->affiliateModel->updateCommissionRate(
            $data['affiliate_id'],
            $data['commission_rate']
        );

        if ($success) {
            $this->jsonResponse([
                'success' => true,
                'message' => 'Commission rate updated successfully'
            ]);
        } else {
            $this->jsonResponse([
                'success' => false,
                'message' => $this->affiliateModel->getLastError()
            ], 400);
        }
    }

    public function updateAffiliateStatus(): void
    {
        $this->requireAuth(['admin']);
        
        $validation = $this->validateRequest([
            'affiliate_id' => 'required|integer',
            'status' => 'required|string|in:active,inactive,suspended'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $data = $validation['data'];

        $success = $this->affiliateModel->update($data['affiliate_id'], [
            'status' => $data['status'],
            'updated_at' => date('Y-m-d H:i:s')
        ]);

        if ($success) {
            $this->jsonResponse([
                'success' => true,
                'message' => 'Affiliate status updated successfully'
            ]);
        } else {
            $this->jsonResponse([
                'success' => false,
                'message' => 'Failed to update affiliate status'
            ], 400);
        }
    }

    public function payouts(): void
    {
        $this->requireAuth(['admin']);
        $user = $this->getAuthenticatedUser();

        $status = $_GET['status'] ?? 'processing';
        
        // Get payouts based on status
        if ($status === 'processing') {
            $payouts = $this->payoutModel->getProcessingPayouts();
        } else {
            // Get all payouts with pagination
            $payouts = $this->getAllPayouts($status);
        }

        // Get payout statistics
        $payoutStats = $this->payoutModel->getPayoutStats();
        $payoutsByMethod = $this->payoutModel->getPayoutsByMethod();

        $this->render('admin/affiliate/payouts', [
            'title' => 'Manage Payouts - Admin Dashboard',
            'user' => $user,
            'payouts' => $payouts,
            'payout_stats' => $payoutStats,
            'payouts_by_method' => $payoutsByMethod,
            'status' => $status
        ]);
    }

    public function processPayouts(): void
    {
        $this->requireAuth(['admin']);
        
        // Process automatic payouts
        $results = $this->payoutModel->processAutomaticPayouts();
        
        $this->jsonResponse([
            'success' => true,
            'message' => 'Payout processing completed',
            'results' => $results
        ]);
    }

    public function affiliateDetails(): void
    {
        $this->requireAuth(['admin']);
        $user = $this->getAuthenticatedUser();

        $affiliateId = (int)($_GET['id'] ?? 0);
        
        if (!$affiliateId) {
            $this->redirect('/admin/affiliates');
            return;
        }

        $affiliate = $this->affiliateModel->getById($affiliateId);
        if (!$affiliate) {
            $this->redirect('/admin/affiliates');
            return;
        }

        // Get affiliate user details
        $affiliateUser = $this->userModel->getById($affiliate['user_id']);
        
        // Get affiliate statistics
        $stats = $this->affiliateModel->getAffiliateStats($affiliateId);
        
        // Get recent earnings
        $recentEarnings = $this->earningModel->getEarningsByAffiliate($affiliateId);
        $recentEarnings = array_slice($recentEarnings, 0, 20);
        
        // Get recent withdrawals
        $recentWithdrawals = $this->withdrawalModel->getWithdrawalsByAffiliate($affiliateId);
        $recentWithdrawals = array_slice($recentWithdrawals, 0, 10);

        $this->render('admin/affiliate/details', [
            'title' => 'Affiliate Details - Admin Dashboard',
            'user' => $user,
            'affiliate' => $affiliate,
            'affiliate_user' => $affiliateUser,
            'stats' => $stats,
            'recent_earnings' => $recentEarnings,
            'recent_withdrawals' => $recentWithdrawals
        ]);
    }

    private function getTotalEarnings(): float
    {
        $sql = "SELECT COALESCE(SUM(total_earnings), 0) as total FROM affiliates";
        $result = $this->affiliateModel->fetchOne($sql);
        return (float)($result['total'] ?? 0);
    }

    private function getTotalWithdrawals(): float
    {
        $sql = "SELECT COALESCE(SUM(total_withdrawals), 0) as total FROM affiliates";
        $result = $this->affiliateModel->fetchOne($sql);
        return (float)($result['total'] ?? 0);
    }

    private function getAffiliatesWithFilters(int $page, string $search, string $status): array
    {
        $limit = 20;
        $offset = ($page - 1) * $limit;
        
        $conditions = [];
        $params = [];
        
        if (!empty($search)) {
            $conditions[] = "(u.first_name LIKE ? OR u.last_name LIKE ? OR u.email LIKE ? OR a.referral_code LIKE ?)";
            $searchTerm = "%{$search}%";
            $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm, $searchTerm]);
        }
        
        if (!empty($status)) {
            $conditions[] = "a.status = ?";
            $params[] = $status;
        }
        
        $whereClause = !empty($conditions) ? 'WHERE ' . implode(' AND ', $conditions) : '';
        
        $sql = "SELECT a.*, u.first_name, u.last_name, u.email, u.phone
                FROM affiliates a
                JOIN users u ON a.user_id = u.id
                {$whereClause}
                ORDER BY a.total_earnings DESC
                LIMIT ? OFFSET ?";
        
        $params[] = $limit;
        $params[] = $offset;
        
        $affiliates = $this->affiliateModel->fetchAll($sql, $params);
        
        // Get total count
        $countSql = "SELECT COUNT(*) as total
                     FROM affiliates a
                     JOIN users u ON a.user_id = u.id
                     {$whereClause}";
        
        $countParams = array_slice($params, 0, -2); // Remove limit and offset
        $totalResult = $this->affiliateModel->fetchOne($countSql, $countParams);
        $total = $totalResult['total'] ?? 0;
        
        return [
            'affiliates' => $affiliates,
            'total' => $total,
            'page' => $page,
            'limit' => $limit,
            'pages' => ceil($total / $limit)
        ];
    }

    private function getWithdrawalsWithFilters(int $page, string $status): array
    {
        $limit = 20;
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT aw.*, a.referral_code, u.first_name, u.last_name, u.email, u.phone
                FROM affiliate_withdrawals aw
                JOIN affiliates a ON aw.affiliate_id = a.id
                JOIN users u ON a.user_id = u.id
                WHERE aw.status = ?
                ORDER BY aw.requested_at ASC
                LIMIT ? OFFSET ?";
        
        $withdrawals = $this->withdrawalModel->fetchAll($sql, [$status, $limit, $offset]);
        
        // Get total count
        $countSql = "SELECT COUNT(*) as total FROM affiliate_withdrawals WHERE status = ?";
        $totalResult = $this->withdrawalModel->fetchOne($countSql, [$status]);
        $total = $totalResult['total'] ?? 0;
        
        return [
            'withdrawals' => $withdrawals,
            'total' => $total,
            'page' => $page,
            'limit' => $limit,
            'pages' => ceil($total / $limit)
        ];
    }

    private function getAllPayouts(string $status): array
    {
        $sql = "SELECT ap.*, aw.requested_at, a.referral_code, 
                       u.first_name, u.last_name, u.email, u.phone
                FROM affiliate_payouts ap
                JOIN affiliate_withdrawals aw ON ap.withdrawal_id = aw.id
                JOIN affiliates a ON ap.affiliate_id = a.id
                JOIN users u ON a.user_id = u.id";
        
        if ($status !== 'all') {
            $sql .= " WHERE ap.status = ?";
            return $this->payoutModel->fetchAll($sql, [$status]);
        }
        
        $sql .= " ORDER BY ap.created_at DESC";
        return $this->payoutModel->fetchAll($sql);
    }
}
