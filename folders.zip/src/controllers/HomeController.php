<?php

namespace controllers;

use core\Controller;

/**
 * Home Controller
 * Handles public pages and main site functionality
 */
class HomeController extends Controller {
    
    public function index() {
        $data = [
            'title' => 'Time2Eat - Food Delivery in Bamenda',
            'description' => 'Order from local restaurants with real-time tracking',
            'featured_restaurants' => $this->getFeaturedRestaurants(),
            'popular_categories' => $this->getPopularCategories(),
            'popular_dishes' => $this->getPopularDishes(),
            'testimonials' => $this->getTestimonials(),
            'stats' => $this->getStats(),
            'how_it_works_steps' => $this->getHowItWorksSteps()
        ];

        $this->view('home/index_enhanced', $data);
    }
    
    public function browse() {
        $search = $this->input('search', '');
        $category = $this->input('category', '');
        $location = $this->input('location', '');
        $sort = $this->input('sort', 'rating');
        $page = (int)$this->input('page', 1);
        
        $data = [
            'title' => 'Browse Restaurants - Time2Eat',
            'restaurants' => $this->getRestaurants($search, $category, $location, $sort, $page),
            'categories' => $this->getCategories(),
            'locations' => $this->getLocations(),
            'search' => $search,
            'category' => $category,
            'location' => $location,
            'sort' => $sort,
            'page' => $page
        ];
        
        $this->view('home/browse', $data);
    }
    
    public function about() {
        $data = [
            'title' => 'About Us - Time2Eat',
            'description' => 'Learn about Time2Eat and our mission to connect Bamenda with great food',
            'team_stats' => $this->getTeamStats()
        ];
        
        $this->view('home/about', $data);
    }
    
    public function restaurant($id) {
        try {
            $restaurant = $this->getRestaurantById($id);
            
            if (!$restaurant) {
                http_response_code(404);
                $this->view('errors/404');
                return;
            }
            
            $data = [
                'title' => $restaurant['name'] . ' - Time2Eat',
                'description' => $restaurant['description'],
                'restaurant' => $restaurant,
                'menu' => $this->getRestaurantMenu($id),
                'reviews' => $this->getRestaurantReviews($id),
                'similar_restaurants' => $this->getSimilarRestaurants($restaurant['category_id'], $id)
            ];
            
            $this->view('home/restaurant', $data);
            
        } catch (\Exception $e) {
            error_log("Error loading restaurant: " . $e->getMessage());
            http_response_code(500);
            $this->view('errors/500');
        }
    }
    
    private function getFeaturedRestaurants() {
        try {
            $sql = "SELECT r.*, c.name as category_name, 
                           AVG(rv.rating) as avg_rating,
                           COUNT(rv.id) as review_count
                    FROM restaurants r 
                    LEFT JOIN categories c ON r.category_id = c.id
                    LEFT JOIN reviews rv ON r.id = rv.restaurant_id
                    WHERE r.is_active = 1 AND r.is_featured = 1 AND r.deleted_at IS NULL
                    GROUP BY r.id
                    ORDER BY avg_rating DESC, review_count DESC
                    LIMIT 6";
            
            return $this->db->query($sql);
        } catch (\Exception $e) {
            error_log("Error fetching featured restaurants: " . $e->getMessage());
            return [];
        }
    }
    
    private function getPopularCategories() {
        try {
            $sql = "SELECT c.*, COUNT(r.id) as restaurant_count
                    FROM categories c
                    LEFT JOIN restaurants r ON c.id = r.category_id AND r.is_active = 1
                    WHERE c.is_active = 1 AND c.deleted_at IS NULL
                    GROUP BY c.id
                    HAVING restaurant_count > 0
                    ORDER BY restaurant_count DESC
                    LIMIT 8";
            
            return $this->db->query($sql);
        } catch (\Exception $e) {
            error_log("Error fetching popular categories: " . $e->getMessage());
            return [];
        }
    }
    
    private function getStats() {
        try {
            $stats = [];
            
            // Total restaurants
            $result = $this->db->query("SELECT COUNT(*) as count FROM restaurants WHERE is_active = 1 AND deleted_at IS NULL");
            $stats['restaurants'] = $result[0]['count'] ?? 0;
            
            // Total orders
            $result = $this->db->query("SELECT COUNT(*) as count FROM orders WHERE deleted_at IS NULL");
            $stats['orders'] = $result[0]['count'] ?? 0;
            
            // Happy customers
            $result = $this->db->query("SELECT COUNT(DISTINCT user_id) as count FROM orders WHERE status = 'delivered' AND deleted_at IS NULL");
            $stats['customers'] = $result[0]['count'] ?? 0;
            
            // Cities served (for now just Bamenda)
            $stats['cities'] = 1;
            
            return $stats;
        } catch (\Exception $e) {
            error_log("Error fetching stats: " . $e->getMessage());
            return ['restaurants' => 0, 'orders' => 0, 'customers' => 0, 'cities' => 1];
        }
    }
    
    private function getRestaurants($search, $category, $location, $sort, $page) {
        try {
            $perPage = 12;
            $offset = ($page - 1) * $perPage;
            
            $sql = "SELECT r.*, c.name as category_name,
                           AVG(rv.rating) as avg_rating,
                           COUNT(rv.id) as review_count
                    FROM restaurants r
                    LEFT JOIN categories c ON r.category_id = c.id
                    LEFT JOIN reviews rv ON r.id = rv.restaurant_id
                    WHERE r.is_active = 1 AND r.deleted_at IS NULL";
            
            $params = [];
            
            if ($search) {
                $sql .= " AND (r.name LIKE ? OR r.description LIKE ?)";
                $params[] = "%{$search}%";
                $params[] = "%{$search}%";
            }
            
            if ($category) {
                $sql .= " AND r.category_id = ?";
                $params[] = $category;
            }
            
            if ($location) {
                $sql .= " AND r.location LIKE ?";
                $params[] = "%{$location}%";
            }
            
            $sql .= " GROUP BY r.id";
            
            // Sorting
            switch ($sort) {
                case 'rating':
                    $sql .= " ORDER BY avg_rating DESC, review_count DESC";
                    break;
                case 'name':
                    $sql .= " ORDER BY r.name ASC";
                    break;
                case 'newest':
                    $sql .= " ORDER BY r.created_at DESC";
                    break;
                default:
                    $sql .= " ORDER BY avg_rating DESC";
            }
            
            $sql .= " LIMIT ? OFFSET ?";
            $params[] = $perPage;
            $params[] = $offset;
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            
            return $stmt->fetchAll();
        } catch (\Exception $e) {
            error_log("Error fetching restaurants: " . $e->getMessage());
            return [];
        }
    }
    
    private function getCategories() {
        try {
            $sql = "SELECT * FROM categories WHERE is_active = 1 AND deleted_at IS NULL ORDER BY name ASC";
            return $this->db->query($sql);
        } catch (\Exception $e) {
            error_log("Error fetching categories: " . $e->getMessage());
            return [];
        }
    }
    
    private function getLocations() {
        try {
            $sql = "SELECT DISTINCT location FROM restaurants WHERE is_active = 1 AND deleted_at IS NULL AND location IS NOT NULL ORDER BY location ASC";
            return $this->db->query($sql);
        } catch (\Exception $e) {
            error_log("Error fetching locations: " . $e->getMessage());
            return [];
        }
    }
    
    private function getTeamStats() {
        return [
            'founded' => '2024',
            'team_size' => '10+',
            'orders_delivered' => '1000+',
            'partner_restaurants' => '50+'
        ];
    }
    
    private function getRestaurantById($id) {
        try {
            $sql = "SELECT r.*, c.name as category_name
                    FROM restaurants r
                    LEFT JOIN categories c ON r.category_id = c.id
                    WHERE r.id = ? AND r.is_active = 1 AND r.deleted_at IS NULL";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$id]);
            
            return $stmt->fetch();
        } catch (\Exception $e) {
            error_log("Error fetching restaurant: " . $e->getMessage());
            return null;
        }
    }
    
    private function getRestaurantMenu($restaurantId) {
        try {
            $sql = "SELECT mi.*, c.name as category_name
                    FROM menu_items mi
                    LEFT JOIN menu_categories c ON mi.category_id = c.id
                    WHERE mi.restaurant_id = ? AND mi.is_available = 1 AND mi.deleted_at IS NULL
                    ORDER BY c.sort_order ASC, mi.sort_order ASC, mi.name ASC";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$restaurantId]);
            
            return $stmt->fetchAll();
        } catch (\Exception $e) {
            error_log("Error fetching menu: " . $e->getMessage());
            return [];
        }
    }
    
    private function getRestaurantReviews($restaurantId) {
        try {
            $sql = "SELECT r.*, u.username, u.avatar
                    FROM reviews r
                    LEFT JOIN users u ON r.user_id = u.id
                    WHERE r.restaurant_id = ? AND r.deleted_at IS NULL
                    ORDER BY r.created_at DESC
                    LIMIT 10";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$restaurantId]);
            
            return $stmt->fetchAll();
        } catch (\Exception $e) {
            error_log("Error fetching reviews: " . $e->getMessage());
            return [];
        }
    }
    
    private function getSimilarRestaurants($categoryId, $excludeId) {
        try {
            $sql = "SELECT r.*, AVG(rv.rating) as avg_rating
                    FROM restaurants r
                    LEFT JOIN reviews rv ON r.id = rv.restaurant_id
                    WHERE r.category_id = ? AND r.id != ? AND r.is_active = 1 AND r.deleted_at IS NULL
                    GROUP BY r.id
                    ORDER BY avg_rating DESC
                    LIMIT 4";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$categoryId, $excludeId]);
            
            return $stmt->fetchAll();
        } catch (\Exception $e) {
            error_log("Error fetching similar restaurants: " . $e->getMessage());
            return [];
        }
    }

    private function getPopularDishes() {
        try {
            $sql = "SELECT mi.id, mi.name, mi.description, mi.image, mi.price,
                           mi.category_id, mi.restaurant_id, mi.rating,
                           r.name as restaurant_name, r.cuisine_type,
                           c.name as category_name,
                           (SELECT COUNT(*) FROM order_items oi
                            INNER JOIN orders o ON oi.order_id = o.id
                            WHERE oi.menu_item_id = mi.id AND o.status = 'delivered'
                            AND o.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)) as order_count,
                           (SELECT AVG(rating) FROM reviews
                            WHERE reviewable_type = 'menu_item' AND reviewable_id = mi.id) as avg_rating
                    FROM menu_items mi
                    INNER JOIN restaurants r ON mi.restaurant_id = r.id
                    INNER JOIN categories c ON mi.category_id = c.id
                    WHERE mi.is_available = 1 AND r.is_active = 1 AND r.is_open = 1
                    ORDER BY order_count DESC, mi.rating DESC
                    LIMIT 12";

            return $this->db->query($sql);
        } catch (\Exception $e) {
            error_log("Error fetching popular dishes: " . $e->getMessage());
            return [];
        }
    }

    private function getTestimonials() {
        try {
            $sql = "SELECT r.id, r.rating, r.comment, r.created_at,
                           u.first_name, u.last_name, u.avatar,
                           CASE
                               WHEN r.reviewable_type = 'restaurant' THEN rest.name
                               WHEN r.reviewable_type = 'menu_item' THEN mi.name
                               ELSE 'Delivery Service'
                           END as reviewed_item,
                           r.reviewable_type,
                           (SELECT COUNT(*) FROM review_helpful rh WHERE rh.review_id = r.id) as helpful_count
                    FROM reviews r
                    INNER JOIN users u ON r.user_id = u.id
                    LEFT JOIN restaurants rest ON r.reviewable_type = 'restaurant' AND r.reviewable_id = rest.id
                    LEFT JOIN menu_items mi ON r.reviewable_type = 'menu_item' AND r.reviewable_id = mi.id
                    WHERE r.is_approved = 1 AND r.rating >= 4 AND r.comment IS NOT NULL
                      AND LENGTH(r.comment) >= 50
                    ORDER BY r.is_featured DESC, helpful_count DESC, r.rating DESC, r.created_at DESC
                    LIMIT 6";

            return $this->db->query($sql);
        } catch (\Exception $e) {
            error_log("Error fetching testimonials: " . $e->getMessage());
            return [];
        }
    }

    private function getHowItWorksSteps() {
        return [
            [
                'step' => 1,
                'icon' => 'search',
                'title' => 'Browse & Choose',
                'description' => 'Explore local restaurants and discover delicious dishes from your favorite cuisines.',
                'color' => 'bg-red-500'
            ],
            [
                'step' => 2,
                'icon' => 'shopping-cart',
                'title' => 'Order & Pay',
                'description' => 'Add items to cart, customize your order, and pay securely with multiple payment options.',
                'color' => 'bg-orange-500'
            ],
            [
                'step' => 3,
                'icon' => 'truck',
                'title' => 'Track & Receive',
                'description' => 'Track your order in real-time and receive fresh, hot food delivered to your doorstep.',
                'color' => 'bg-green-500'
            ]
        ];
    }
}
