<?php

namespace Time2Eat\Controllers;

use Time2Eat\Core\BaseController;
use Time2Eat\Models\User;
use Time2Eat\Models\Delivery;
use Time2Eat\Models\Order;

class RiderDashboardController extends BaseController
{
    private User $userModel;
    private Delivery $deliveryModel;
    private Order $orderModel;

    public function __construct()
    {
        parent::__construct();
        $this->userModel = new User();
        $this->deliveryModel = new Delivery();
        $this->orderModel = new Order();
    }

    public function index(): void
    {
        $this->requireAuth();
        $this->requireRole('rider');

        $user = $this->getAuthenticatedUser();
        
        // Get rider statistics
        $stats = $this->getRiderStats($user['id']);
        
        // Get active deliveries
        $activeDeliveries = $this->deliveryModel->getActiveDeliveriesByRider($user['id']);
        
        // Get available orders
        $availableOrders = $this->orderModel->getAvailableOrdersForRider($user['id'], 10);
        
        // Get recent activity
        $recentActivity = $this->deliveryModel->getRecentActivityByRider($user['id'], 10);

        $this->render('dashboard/rider', [
            'title' => 'Rider Dashboard - Time2Eat',
            'user' => $user,
            'stats' => $stats,
            'activeDeliveries' => $activeDeliveries,
            'availableOrders' => $availableOrders,
            'recentActivity' => $recentActivity
        ]);
    }

    public function deliveries(): void
    {
        $this->requireAuth();
        $this->requireRole('rider');

        $user = $this->getAuthenticatedUser();
        $status = $_GET['status'] ?? 'active';
        $page = (int)($_GET['page'] ?? 1);
        $limit = 20;
        $offset = ($page - 1) * $limit;

        // Get deliveries with pagination and filtering
        $deliveries = $this->deliveryModel->getDeliveriesByRider($user['id'], $status, $limit, $offset);
        $totalDeliveries = $this->deliveryModel->countDeliveriesByRider($user['id'], $status);
        $totalPages = ceil($totalDeliveries / $limit);

        // Get delivery status counts
        $statusCounts = $this->deliveryModel->getDeliveryStatusCounts($user['id']);

        $this->render('rider/deliveries', [
            'title' => 'My Deliveries - Time2Eat',
            'user' => $user,
            'deliveries' => $deliveries,
            'statusCounts' => $statusCounts,
            'currentStatus' => $status,
            'currentPage' => $page,
            'totalPages' => $totalPages,
            'totalDeliveries' => $totalDeliveries
        ]);
    }

    public function available(): void
    {
        $this->requireAuth();
        $this->requireRole('rider');

        $user = $this->getAuthenticatedUser();
        
        // Check if rider is available
        if (!$user['is_available']) {
            $this->render('rider/unavailable', [
                'title' => 'Go Online - Time2Eat',
                'user' => $user
            ]);
            return;
        }

        $page = (int)($_GET['page'] ?? 1);
        $limit = 20;
        $offset = ($page - 1) * $limit;

        // Get available orders
        $availableOrders = $this->orderModel->getAvailableOrdersForRider($user['id'], $limit, $offset);
        $totalOrders = $this->orderModel->countAvailableOrdersForRider($user['id']);
        $totalPages = ceil($totalOrders / $limit);

        $this->render('rider/available', [
            'title' => 'Available Orders - Time2Eat',
            'user' => $user,
            'availableOrders' => $availableOrders,
            'currentPage' => $page,
            'totalPages' => $totalPages,
            'totalOrders' => $totalOrders
        ]);
    }

    public function earnings(): void
    {
        $this->requireAuth();
        $this->requireRole('rider');

        $user = $this->getAuthenticatedUser();
        $period = $_GET['period'] ?? '7days';
        $page = (int)($_GET['page'] ?? 1);
        $limit = 20;
        $offset = ($page - 1) * $limit;

        // Get earnings data
        $earnings = $this->deliveryModel->getEarningsByRider($user['id'], $period, $limit, $offset);
        $totalEarnings = $this->deliveryModel->getTotalEarnings($user['id']);
        $weeklyEarnings = $this->deliveryModel->getWeeklyEarnings($user['id']);
        $monthlyEarnings = $this->deliveryModel->getMonthlyEarnings($user['id']);

        $totalPages = ceil(count($earnings) / $limit);

        $this->render('rider/earnings', [
            'title' => 'My Earnings - Time2Eat',
            'user' => $user,
            'earnings' => $earnings,
            'totalEarnings' => $totalEarnings,
            'weeklyEarnings' => $weeklyEarnings,
            'monthlyEarnings' => $monthlyEarnings,
            'currentPeriod' => $period,
            'currentPage' => $page,
            'totalPages' => $totalPages
        ]);
    }

    public function schedule(): void
    {
        $this->requireAuth();
        $this->requireRole('rider');

        $user = $this->getAuthenticatedUser();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->updateSchedule();
            return;
        }

        // Get rider's schedule
        $schedule = $this->userModel->getRiderSchedule($user['id']);

        $this->render('rider/schedule', [
            'title' => 'My Schedule - Time2Eat',
            'user' => $user,
            'schedule' => $schedule
        ]);
    }

    public function performance(): void
    {
        $this->requireAuth();
        $this->requireRole('rider');

        $user = $this->getAuthenticatedUser();
        $period = $_GET['period'] ?? '30days';

        // Get performance metrics
        $performance = $this->deliveryModel->getPerformanceMetrics($user['id'], $period);
        $ratings = $this->deliveryModel->getRatingsByRider($user['id'], $period);
        $deliveryTimes = $this->deliveryModel->getDeliveryTimeAnalytics($user['id'], $period);

        $this->render('rider/performance', [
            'title' => 'Performance Metrics - Time2Eat',
            'user' => $user,
            'performance' => $performance,
            'ratings' => $ratings,
            'deliveryTimes' => $deliveryTimes,
            'currentPeriod' => $period
        ]);
    }

    public function toggleAvailability(): void
    {
        $this->requireAuth();
        $this->requireRole('rider');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $isAvailable = !$user['is_available'];

        $updated = $this->userModel->updateAvailability($user['id'], $isAvailable);

        if ($updated) {
            $this->jsonResponse([
                'success' => true,
                'message' => $isAvailable ? 'You are now online' : 'You are now offline',
                'is_available' => $isAvailable
            ]);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to update availability'], 500);
        }
    }

    public function acceptOrder(): void
    {
        $this->requireAuth();
        $this->requireRole('rider');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            return;
        }

        $validation = $this->validateRequest([
            'order_id' => 'required|integer'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $orderId = $validation['data']['order_id'];

        // Check if rider is available
        if (!$user['is_available']) {
            $this->jsonResponse(['success' => false, 'message' => 'You must be online to accept orders'], 400);
            return;
        }

        // Check if order is still available
        $order = $this->orderModel->getById($orderId);
        if (!$order || $order['status'] !== 'ready' || $order['rider_id']) {
            $this->jsonResponse(['success' => false, 'message' => 'Order is no longer available'], 400);
            return;
        }

        // Assign order to rider
        $assigned = $this->orderModel->assignRider($orderId, $user['id']);

        if ($assigned) {
            // Create delivery record
            $deliveryData = [
                'order_id' => $orderId,
                'rider_id' => $user['id'],
                'status' => 'assigned',
                'assigned_at' => date('Y-m-d H:i:s')
            ];
            
            $deliveryId = $this->deliveryModel->create($deliveryData);

            if ($deliveryId) {
                $this->jsonResponse(['success' => true, 'message' => 'Order accepted successfully', 'delivery_id' => $deliveryId]);
            } else {
                $this->jsonResponse(['success' => false, 'message' => 'Failed to create delivery record'], 500);
            }
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to accept order'], 500);
        }
    }

    public function updateDeliveryStatus(): void
    {
        $this->requireAuth();
        $this->requireRole('rider');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            return;
        }

        $validation = $this->validateRequest([
            'delivery_id' => 'required|integer',
            'status' => 'required|in:picked_up,in_transit,delivered',
            'latitude' => 'numeric',
            'longitude' => 'numeric',
            'notes' => 'string|max:500'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $data = $validation['data'];
        $deliveryId = $data['delivery_id'];

        // Verify delivery belongs to this rider
        $delivery = $this->deliveryModel->getById($deliveryId);
        if (!$delivery || $delivery['rider_id'] !== $user['id']) {
            $this->jsonResponse(['success' => false, 'message' => 'Delivery not found'], 404);
            return;
        }

        // Update delivery status
        $updateData = [
            'status' => $data['status'],
            'updated_at' => date('Y-m-d H:i:s')
        ];

        if (isset($data['latitude']) && isset($data['longitude'])) {
            $updateData['current_latitude'] = $data['latitude'];
            $updateData['current_longitude'] = $data['longitude'];
        }

        if (isset($data['notes'])) {
            $updateData['notes'] = $data['notes'];
        }

        // Set timestamp based on status
        switch ($data['status']) {
            case 'picked_up':
                $updateData['picked_up_at'] = date('Y-m-d H:i:s');
                break;
            case 'in_transit':
                $updateData['in_transit_at'] = date('Y-m-d H:i:s');
                break;
            case 'delivered':
                $updateData['delivered_at'] = date('Y-m-d H:i:s');
                // Also update order status
                $this->orderModel->updateStatus($delivery['order_id'], 'delivered');
                break;
        }

        $updated = $this->deliveryModel->update($deliveryId, $updateData);

        if ($updated) {
            // Send notification to customer
            $this->sendDeliveryStatusNotification($delivery, $data['status']);
            
            $this->jsonResponse(['success' => true, 'message' => 'Delivery status updated successfully']);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to update delivery status'], 500);
        }
    }

    private function getRiderStats(int $riderId): array
    {
        return [
            'activeDeliveries' => $this->deliveryModel->countActiveDeliveriesByRider($riderId),
            'todayEarnings' => $this->deliveryModel->getTodayEarnings($riderId),
            'todayDeliveries' => $this->deliveryModel->getTodayDeliveryCount($riderId),
            'averageRating' => $this->deliveryModel->getAverageRating($riderId),
            'totalDeliveries' => $this->deliveryModel->getTotalDeliveryCount($riderId),
            'weeklyEarnings' => $this->deliveryModel->getWeeklyEarnings($riderId),
            'monthlyEarnings' => $this->deliveryModel->getMonthlyEarnings($riderId),
            'completionRate' => $this->deliveryModel->getCompletionRate($riderId)
        ];
    }

    private function updateSchedule(): void
    {
        $validation = $this->validateRequest([
            'schedule' => 'required|json'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $schedule = json_decode($validation['data']['schedule'], true);

        // Validate schedule format
        $validDays = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
        foreach ($schedule as $day => $times) {
            if (!in_array($day, $validDays)) {
                $this->jsonResponse(['success' => false, 'message' => 'Invalid day: ' . $day], 400);
                return;
            }

            if (!isset($times['start']) || !isset($times['end']) || !isset($times['available'])) {
                $this->jsonResponse(['success' => false, 'message' => 'Invalid schedule format'], 400);
                return;
            }
        }

        $updated = $this->userModel->updateRiderSchedule($user['id'], $schedule);

        if ($updated) {
            $this->jsonResponse(['success' => true, 'message' => 'Schedule updated successfully']);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to update schedule'], 500);
        }
    }

    private function sendDeliveryStatusNotification(array $delivery, string $status): void
    {
        $statusMessages = [
            'picked_up' => 'Your order has been picked up and is on the way.',
            'in_transit' => 'Your order is in transit.',
            'delivered' => 'Your order has been delivered. Enjoy your meal!'
        ];

        $message = $statusMessages[$status] ?? 'Your delivery status has been updated.';
        
        // Send notification logic here
        // Example: $this->notificationService->send($delivery['customer_id'], $message);
    }
}
