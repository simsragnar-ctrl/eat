<?php

namespace Time2Eat\Controllers;

use Time2Eat\Core\BaseController;
use Time2Eat\Models\User;
use Time2Eat\Models\Restaurant;
use Time2Eat\Models\Order;
use Time2Eat\Models\MenuItem;

class VendorDashboardController extends BaseController
{
    private User $userModel;
    private Restaurant $restaurantModel;
    private Order $orderModel;
    private MenuItem $menuItemModel;

    public function __construct()
    {
        parent::__construct();
        $this->userModel = new User();
        $this->restaurantModel = new Restaurant();
        $this->orderModel = new Order();
        $this->menuItemModel = new MenuItem();
    }

    public function index(): void
    {
        $this->requireAuth();
        $this->requireRole('vendor');

        $user = $this->getAuthenticatedUser();
        
        // Get vendor's restaurant
        $restaurant = $this->restaurantModel->getByVendorId($user['id']);
        
        if (!$restaurant) {
            $this->redirect('/vendor/setup');
            return;
        }

        // Get vendor statistics
        $stats = $this->getVendorStats($restaurant['id']);
        
        // Get recent orders
        $recentOrders = $this->orderModel->getRecentOrdersByRestaurant($restaurant['id'], 10);
        
        // Get popular menu items
        $popularItems = $this->menuItemModel->getPopularItemsByRestaurant($restaurant['id'], 5);
        
        // Get low stock items
        $lowStockItems = $this->menuItemModel->getLowStockItems($restaurant['id']);

        $this->render('dashboard/vendor', [
            'title' => 'Vendor Dashboard - Time2Eat',
            'user' => $user,
            'restaurant' => $restaurant,
            'stats' => $stats,
            'recentOrders' => $recentOrders,
            'popularItems' => $popularItems,
            'lowStockItems' => $lowStockItems
        ]);
    }

    public function profile(): void
    {
        $this->requireAuth();
        $this->requireRole('vendor');

        $user = $this->getAuthenticatedUser();
        $restaurant = $this->restaurantModel->getByVendorId($user['id']);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->updateRestaurantProfile();
            return;
        }

        $this->render('vendor/profile', [
            'title' => 'Restaurant Profile - Time2Eat',
            'user' => $user,
            'restaurant' => $restaurant
        ]);
    }

    public function menu(): void
    {
        $this->requireAuth();
        $this->requireRole('vendor');

        $user = $this->getAuthenticatedUser();
        $restaurant = $this->restaurantModel->getByVendorId($user['id']);

        if (!$restaurant) {
            $this->redirect('/vendor/setup');
            return;
        }

        $page = (int)($_GET['page'] ?? 1);
        $limit = 20;
        $offset = ($page - 1) * $limit;

        // Get menu items with pagination
        $menuItems = $this->menuItemModel->getByRestaurant($restaurant['id'], $limit, $offset);
        $totalItems = $this->menuItemModel->countByRestaurant($restaurant['id']);
        $totalPages = ceil($totalItems / $limit);

        // Get categories
        $categories = $this->menuItemModel->getCategoriesByRestaurant($restaurant['id']);

        $this->render('vendor/menu', [
            'title' => 'Menu Management - Time2Eat',
            'user' => $user,
            'restaurant' => $restaurant,
            'menuItems' => $menuItems,
            'categories' => $categories,
            'currentPage' => $page,
            'totalPages' => $totalPages,
            'totalItems' => $totalItems
        ]);
    }

    public function orders(): void
    {
        $this->requireAuth();
        $this->requireRole('vendor');

        $user = $this->getAuthenticatedUser();
        $restaurant = $this->restaurantModel->getByVendorId($user['id']);

        if (!$restaurant) {
            $this->redirect('/vendor/setup');
            return;
        }

        $status = $_GET['status'] ?? 'all';
        $page = (int)($_GET['page'] ?? 1);
        $limit = 20;
        $offset = ($page - 1) * $limit;

        // Get orders with pagination and filtering
        $orders = $this->orderModel->getOrdersByRestaurant($restaurant['id'], $status, $limit, $offset);
        $totalOrders = $this->orderModel->countOrdersByRestaurant($restaurant['id'], $status);
        $totalPages = ceil($totalOrders / $limit);

        // Get order status counts
        $statusCounts = $this->orderModel->getOrderStatusCounts($restaurant['id']);

        $this->render('vendor/orders', [
            'title' => 'Order Management - Time2Eat',
            'user' => $user,
            'restaurant' => $restaurant,
            'orders' => $orders,
            'statusCounts' => $statusCounts,
            'currentStatus' => $status,
            'currentPage' => $page,
            'totalPages' => $totalPages,
            'totalOrders' => $totalOrders
        ]);
    }

    public function analytics(): void
    {
        $this->requireAuth();
        $this->requireRole('vendor');

        $user = $this->getAuthenticatedUser();
        $restaurant = $this->restaurantModel->getByVendorId($user['id']);

        if (!$restaurant) {
            $this->redirect('/vendor/setup');
            return;
        }

        $period = $_GET['period'] ?? '7days';
        
        // Get analytics data
        $salesData = $this->orderModel->getSalesAnalytics($restaurant['id'], $period);
        $popularItems = $this->menuItemModel->getPopularItemsAnalytics($restaurant['id'], $period);
        $customerAnalytics = $this->orderModel->getCustomerAnalytics($restaurant['id'], $period);
        $revenueBreakdown = $this->orderModel->getRevenueBreakdown($restaurant['id'], $period);

        $this->render('vendor/analytics', [
            'title' => 'Analytics - Time2Eat',
            'user' => $user,
            'restaurant' => $restaurant,
            'salesData' => $salesData,
            'popularItems' => $popularItems,
            'customerAnalytics' => $customerAnalytics,
            'revenueBreakdown' => $revenueBreakdown,
            'currentPeriod' => $period
        ]);
    }

    public function earnings(): void
    {
        $this->requireAuth();
        $this->requireRole('vendor');

        $user = $this->getAuthenticatedUser();
        $restaurant = $this->restaurantModel->getByVendorId($user['id']);

        if (!$restaurant) {
            $this->redirect('/vendor/setup');
            return;
        }

        $page = (int)($_GET['page'] ?? 1);
        $limit = 20;
        $offset = ($page - 1) * $limit;

        // Get earnings data
        $earnings = $this->orderModel->getEarningsByRestaurant($restaurant['id'], $limit, $offset);
        $totalEarnings = $this->orderModel->getTotalEarnings($restaurant['id']);
        $monthlyEarnings = $this->orderModel->getMonthlyEarnings($restaurant['id']);
        $pendingPayouts = $this->orderModel->getPendingPayouts($restaurant['id']);

        $totalPages = ceil(count($earnings) / $limit);

        $this->render('vendor/earnings', [
            'title' => 'Earnings - Time2Eat',
            'user' => $user,
            'restaurant' => $restaurant,
            'earnings' => $earnings,
            'totalEarnings' => $totalEarnings,
            'monthlyEarnings' => $monthlyEarnings,
            'pendingPayouts' => $pendingPayouts,
            'currentPage' => $page,
            'totalPages' => $totalPages
        ]);
    }

    public function updateOrderStatus(): void
    {
        $this->requireAuth();
        $this->requireRole('vendor');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            return;
        }

        $validation = $this->validateRequest([
            'order_id' => 'required|integer',
            'status' => 'required|in:confirmed,preparing,ready,completed,cancelled'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $restaurant = $this->restaurantModel->getByVendorId($user['id']);

        if (!$restaurant) {
            $this->jsonResponse(['success' => false, 'message' => 'Restaurant not found'], 404);
            return;
        }

        $orderId = $validation['data']['order_id'];
        $status = $validation['data']['status'];

        // Verify order belongs to this restaurant
        $order = $this->orderModel->getById($orderId);
        if (!$order || $order['restaurant_id'] !== $restaurant['id']) {
            $this->jsonResponse(['success' => false, 'message' => 'Order not found'], 404);
            return;
        }

        // Update order status
        $updated = $this->orderModel->updateStatus($orderId, $status);

        if ($updated) {
            // Send notification to customer
            $this->sendOrderStatusNotification($order, $status);
            
            $this->jsonResponse(['success' => true, 'message' => 'Order status updated successfully']);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to update order status'], 500);
        }
    }

    public function toggleAvailability(): void
    {
        $this->requireAuth();
        $this->requireRole('vendor');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $restaurant = $this->restaurantModel->getByVendorId($user['id']);

        if (!$restaurant) {
            $this->jsonResponse(['success' => false, 'message' => 'Restaurant not found'], 404);
            return;
        }

        $isOpen = !$restaurant['is_open'];
        $updated = $this->restaurantModel->updateAvailability($restaurant['id'], $isOpen);

        if ($updated) {
            $this->jsonResponse([
                'success' => true, 
                'message' => $isOpen ? 'Restaurant is now open' : 'Restaurant is now closed',
                'is_open' => $isOpen
            ]);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to update availability'], 500);
        }
    }

    private function getVendorStats(int $restaurantId): array
    {
        return [
            'todayOrders' => $this->orderModel->getTodayOrderCount($restaurantId),
            'todayRevenue' => $this->orderModel->getTodayRevenue($restaurantId),
            'totalMenuItems' => $this->menuItemModel->countByRestaurant($restaurantId),
            'averageRating' => $this->restaurantModel->getAverageRating($restaurantId),
            'totalReviews' => $this->restaurantModel->getReviewCount($restaurantId),
            'monthlyOrders' => $this->orderModel->getMonthlyOrderCount($restaurantId),
            'monthlyRevenue' => $this->orderModel->getMonthlyRevenue($restaurantId),
            'lowStockCount' => $this->menuItemModel->countLowStockItems($restaurantId)
        ];
    }

    private function updateRestaurantProfile(): void
    {
        $validation = $this->validateRequest([
            'name' => 'required|string|max:100',
            'description' => 'string|max:500',
            'cuisine_type' => 'required|string|max:50',
            'phone' => 'required|string|max:20',
            'email' => 'required|email|max:100',
            'address' => 'required|string|max:255',
            'city' => 'required|string|max:100',
            'state' => 'string|max:100',
            'postal_code' => 'string|max:20',
            'country' => 'required|string|max:100',
            'latitude' => 'numeric',
            'longitude' => 'numeric',
            'delivery_fee' => 'required|numeric|min:0',
            'minimum_order' => 'required|numeric|min:0',
            'delivery_time' => 'required|integer|min:10|max:120',
            'opening_hours' => 'required|json',
            'payment_methods' => 'required|json'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $user = $this->getAuthenticatedUser();
        $restaurant = $this->restaurantModel->getByVendorId($user['id']);

        if (!$restaurant) {
            $this->jsonResponse(['success' => false, 'message' => 'Restaurant not found'], 404);
            return;
        }

        $data = $validation['data'];
        
        // Handle file uploads (logo, banner, gallery)
        if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
            $logoPath = $this->uploadImage($_FILES['logo'], 'restaurants/logos');
            if ($logoPath) {
                $data['logo'] = $logoPath;
            }
        }

        if (isset($_FILES['banner']) && $_FILES['banner']['error'] === UPLOAD_ERR_OK) {
            $bannerPath = $this->uploadImage($_FILES['banner'], 'restaurants/banners');
            if ($bannerPath) {
                $data['banner_image'] = $bannerPath;
            }
        }

        $updated = $this->restaurantModel->update($restaurant['id'], $data);

        if ($updated) {
            $this->jsonResponse(['success' => true, 'message' => 'Restaurant profile updated successfully']);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to update restaurant profile'], 500);
        }
    }

    private function sendOrderStatusNotification(array $order, string $status): void
    {
        // Implementation for sending notifications
        // This could be email, SMS, push notification, etc.
        
        $statusMessages = [
            'confirmed' => 'Your order has been confirmed and is being prepared.',
            'preparing' => 'Your order is being prepared.',
            'ready' => 'Your order is ready for pickup/delivery.',
            'completed' => 'Your order has been completed.',
            'cancelled' => 'Your order has been cancelled.'
        ];

        $message = $statusMessages[$status] ?? 'Your order status has been updated.';
        
        // Send notification logic here
        // Example: $this->notificationService->send($order['customer_id'], $message);
    }

    private function uploadImage(array $file, string $directory): ?string
    {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $maxSize = 5 * 1024 * 1024; // 5MB

        if (!in_array($file['type'], $allowedTypes)) {
            return null;
        }

        if ($file['size'] > $maxSize) {
            return null;
        }

        $uploadDir = __DIR__ . '/../../public/uploads/' . $directory;
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '.' . $extension;
        $filepath = $uploadDir . '/' . $filename;

        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            return '/uploads/' . $directory . '/' . $filename;
        }

        return null;
    }
}
