<?php

namespace Time2Eat\Controllers;

use Time2Eat\Core\BaseController;
use Time2Eat\Models\User;
use Time2Eat\Models\Restaurant;
use Time2Eat\Models\Order;
use Time2Eat\Models\Analytics;

class AdminDashboardController extends BaseController
{
    private User $userModel;
    private Restaurant $restaurantModel;
    private Order $orderModel;
    private Analytics $analyticsModel;

    public function __construct()
    {
        parent::__construct();
        $this->userModel = new User();
        $this->restaurantModel = new Restaurant();
        $this->orderModel = new Order();
        $this->analyticsModel = new Analytics();
    }

    public function index(): void
    {
        $this->requireAuth();
        $this->requireRole('admin');

        $user = $this->getAuthenticatedUser();
        
        // Get platform statistics
        $stats = $this->getPlatformStats();
        
        // Get recent activity
        $recentActivity = $this->getRecentActivity(10);
        
        // Get pending approvals
        $pendingApprovals = $this->getPendingApprovals();
        
        // Get system status
        $systemStatus = $this->getSystemStatus();

        $this->render('dashboard/admin', [
            'title' => 'Admin Dashboard - Time2Eat',
            'user' => $user,
            'stats' => $stats,
            'recentActivity' => $recentActivity,
            'pendingApprovals' => $pendingApprovals,
            'systemStatus' => $systemStatus
        ]);
    }

    public function users(): void
    {
        $this->requireAuth();
        $this->requireRole('admin');

        $user = $this->getAuthenticatedUser();
        $role = $_GET['role'] ?? 'all';
        $status = $_GET['status'] ?? 'all';
        $search = $_GET['search'] ?? '';
        $page = (int)($_GET['page'] ?? 1);
        $limit = 20;
        $offset = ($page - 1) * $limit;

        // Get users with filtering and pagination
        $users = $this->userModel->getUsers($role, $status, $search, $limit, $offset);
        $totalUsers = $this->userModel->countUsers($role, $status, $search);
        $totalPages = ceil($totalUsers / $limit);

        // Get user statistics
        $userStats = $this->userModel->getUserStatistics();

        $this->render('admin/users', [
            'title' => 'User Management - Time2Eat',
            'user' => $user,
            'users' => $users,
            'userStats' => $userStats,
            'currentRole' => $role,
            'currentStatus' => $status,
            'currentSearch' => $search,
            'currentPage' => $page,
            'totalPages' => $totalPages,
            'totalUsers' => $totalUsers
        ]);
    }

    public function restaurants(): void
    {
        $this->requireAuth();
        $this->requireRole('admin');

        $user = $this->getAuthenticatedUser();
        $status = $_GET['status'] ?? 'all';
        $search = $_GET['search'] ?? '';
        $page = (int)($_GET['page'] ?? 1);
        $limit = 20;
        $offset = ($page - 1) * $limit;

        // Get restaurants with filtering and pagination
        $restaurants = $this->restaurantModel->getRestaurants($status, $search, $limit, $offset);
        $totalRestaurants = $this->restaurantModel->countRestaurants($status, $search);
        $totalPages = ceil($totalRestaurants / $limit);

        // Get restaurant statistics
        $restaurantStats = $this->restaurantModel->getRestaurantStatistics();

        $this->render('admin/restaurants', [
            'title' => 'Restaurant Management - Time2Eat',
            'user' => $user,
            'restaurants' => $restaurants,
            'restaurantStats' => $restaurantStats,
            'currentStatus' => $status,
            'currentSearch' => $search,
            'currentPage' => $page,
            'totalPages' => $totalPages,
            'totalRestaurants' => $totalRestaurants
        ]);
    }

    public function orders(): void
    {
        $this->requireAuth();
        $this->requireRole('admin');

        $user = $this->getAuthenticatedUser();
        $status = $_GET['status'] ?? 'all';
        $date = $_GET['date'] ?? '';
        $search = $_GET['search'] ?? '';
        $page = (int)($_GET['page'] ?? 1);
        $limit = 20;
        $offset = ($page - 1) * $limit;

        // Get orders with filtering and pagination
        $orders = $this->orderModel->getOrders($status, $date, $search, $limit, $offset);
        $totalOrders = $this->orderModel->countOrders($status, $date, $search);
        $totalPages = ceil($totalOrders / $limit);

        // Get order statistics
        $orderStats = $this->orderModel->getOrderStatistics();

        $this->render('admin/orders', [
            'title' => 'Order Management - Time2Eat',
            'user' => $user,
            'orders' => $orders,
            'orderStats' => $orderStats,
            'currentStatus' => $status,
            'currentDate' => $date,
            'currentSearch' => $search,
            'currentPage' => $page,
            'totalPages' => $totalPages,
            'totalOrders' => $totalOrders
        ]);
    }

    public function analytics(): void
    {
        $this->requireAuth();
        $this->requireRole('admin');

        $user = $this->getAuthenticatedUser();
        $period = $_GET['period'] ?? '30days';
        $metric = $_GET['metric'] ?? 'revenue';

        // Get analytics data
        $revenueData = $this->analyticsModel->getRevenueAnalytics($period);
        $userGrowth = $this->analyticsModel->getUserGrowthAnalytics($period);
        $orderAnalytics = $this->analyticsModel->getOrderAnalytics($period);
        $topRestaurants = $this->analyticsModel->getTopRestaurants($period, 10);
        $topCustomers = $this->analyticsModel->getTopCustomers($period, 10);
        $geographicData = $this->analyticsModel->getGeographicAnalytics($period);

        $this->render('admin/analytics', [
            'title' => 'Analytics Dashboard - Time2Eat',
            'user' => $user,
            'revenueData' => $revenueData,
            'userGrowth' => $userGrowth,
            'orderAnalytics' => $orderAnalytics,
            'topRestaurants' => $topRestaurants,
            'topCustomers' => $topCustomers,
            'geographicData' => $geographicData,
            'currentPeriod' => $period,
            'currentMetric' => $metric
        ]);
    }

    public function financial(): void
    {
        $this->requireAuth();
        $this->requireRole('admin');

        $user = $this->getAuthenticatedUser();
        $period = $_GET['period'] ?? '30days';

        // Get financial data
        $revenueBreakdown = $this->analyticsModel->getRevenueBreakdown($period);
        $commissionData = $this->analyticsModel->getCommissionAnalytics($period);
        $payoutData = $this->analyticsModel->getPayoutAnalytics($period);
        $refundData = $this->analyticsModel->getRefundAnalytics($period);

        $this->render('admin/financial', [
            'title' => 'Financial Management - Time2Eat',
            'user' => $user,
            'revenueBreakdown' => $revenueBreakdown,
            'commissionData' => $commissionData,
            'payoutData' => $payoutData,
            'refundData' => $refundData,
            'currentPeriod' => $period
        ]);
    }

    public function approveRestaurant(): void
    {
        $this->requireAuth();
        $this->requireRole('admin');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            return;
        }

        $validation = $this->validateRequest([
            'restaurant_id' => 'required|integer',
            'action' => 'required|in:approve,reject',
            'notes' => 'string|max:500'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $data = $validation['data'];
        $restaurantId = $data['restaurant_id'];
        $action = $data['action'];
        $notes = $data['notes'] ?? '';

        $restaurant = $this->restaurantModel->getById($restaurantId);
        if (!$restaurant) {
            $this->jsonResponse(['success' => false, 'message' => 'Restaurant not found'], 404);
            return;
        }

        $status = $action === 'approve' ? 'approved' : 'rejected';
        $updated = $this->restaurantModel->updateStatus($restaurantId, $status, $notes);

        if ($updated) {
            // Send notification to vendor
            $this->sendApprovalNotification($restaurant, $status, $notes);
            
            $message = $action === 'approve' ? 'Restaurant approved successfully' : 'Restaurant rejected';
            $this->jsonResponse(['success' => true, 'message' => $message]);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to update restaurant status'], 500);
        }
    }

    public function updateUserStatus(): void
    {
        $this->requireAuth();
        $this->requireRole('admin');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            return;
        }

        $validation = $this->validateRequest([
            'user_id' => 'required|integer',
            'status' => 'required|in:active,suspended,banned',
            'reason' => 'string|max:500'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $data = $validation['data'];
        $userId = $data['user_id'];
        $status = $data['status'];
        $reason = $data['reason'] ?? '';

        $user = $this->userModel->getById($userId);
        if (!$user) {
            $this->jsonResponse(['success' => false, 'message' => 'User not found'], 404);
            return;
        }

        $updated = $this->userModel->updateStatus($userId, $status, $reason);

        if ($updated) {
            // Log admin action
            $this->logAdminAction('user_status_update', [
                'user_id' => $userId,
                'old_status' => $user['status'],
                'new_status' => $status,
                'reason' => $reason
            ]);

            // Send notification to user
            $this->sendStatusUpdateNotification($user, $status, $reason);
            
            $this->jsonResponse(['success' => true, 'message' => 'User status updated successfully']);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to update user status'], 500);
        }
    }

    public function systemStatus(): void
    {
        $this->requireAuth();
        $this->requireRole('admin');

        $status = $this->getSystemStatus();
        $this->jsonResponse(['success' => true, 'data' => $status]);
    }

    private function getPlatformStats(): array
    {
        return [
            'totalUsers' => $this->userModel->getTotalUserCount(),
            'totalRevenue' => $this->orderModel->getTotalRevenue(),
            'activeOrders' => $this->orderModel->getActiveOrderCount(),
            'activeRestaurants' => $this->restaurantModel->getActiveRestaurantCount(),
            'monthlyUsers' => $this->userModel->getMonthlyUserGrowth(),
            'monthlyRevenue' => $this->orderModel->getMonthlyRevenue(),
            'monthlyOrders' => $this->orderModel->getMonthlyOrderCount(),
            'averageOrderValue' => $this->orderModel->getAverageOrderValue()
        ];
    }

    private function getRecentActivity(int $limit): array
    {
        return $this->analyticsModel->getRecentActivity($limit);
    }

    private function getPendingApprovals(): array
    {
        return [
            'restaurants' => $this->restaurantModel->getPendingApprovals(),
            'riders' => $this->userModel->getPendingRiders(),
            'payouts' => $this->analyticsModel->getPendingPayouts(),
            'disputes' => $this->orderModel->getPendingDisputes()
        ];
    }

    private function getSystemStatus(): array
    {
        return [
            'api_server' => $this->checkApiServer(),
            'database' => $this->checkDatabase(),
            'payment_gateway' => $this->checkPaymentGateway(),
            'sms_service' => $this->checkSmsService(),
            'email_service' => $this->checkEmailService(),
            'resources' => $this->getSystemResources()
        ];
    }

    private function checkApiServer(): array
    {
        // Check API server health
        return ['status' => 'operational', 'response_time' => '45ms'];
    }

    private function checkDatabase(): array
    {
        try {
            $this->db->query("SELECT 1");
            return ['status' => 'operational', 'connections' => 12];
        } catch (Exception $e) {
            return ['status' => 'error', 'message' => $e->getMessage()];
        }
    }

    private function checkPaymentGateway(): array
    {
        // Check payment gateway status
        return ['status' => 'degraded', 'message' => 'Slow response times'];
    }

    private function checkSmsService(): array
    {
        // Check SMS service status
        return ['status' => 'operational', 'queue_size' => 5];
    }

    private function checkEmailService(): array
    {
        // Check email service status
        return ['status' => 'operational', 'queue_size' => 12];
    }

    private function getSystemResources(): array
    {
        return [
            'cpu_usage' => 45,
            'memory_usage' => 68,
            'disk_usage' => 32,
            'load_average' => 1.2
        ];
    }

    private function sendApprovalNotification(array $restaurant, string $status, string $notes): void
    {
        // Send notification to vendor about approval/rejection
        $message = $status === 'approved' 
            ? 'Your restaurant has been approved and is now live on Time2Eat!'
            : 'Your restaurant application has been rejected. ' . $notes;
        
        // Send notification logic here
    }

    private function sendStatusUpdateNotification(array $user, string $status, string $reason): void
    {
        // Send notification to user about status update
        $statusMessages = [
            'active' => 'Your account has been reactivated.',
            'suspended' => 'Your account has been suspended. ' . $reason,
            'banned' => 'Your account has been banned. ' . $reason
        ];

        $message = $statusMessages[$status] ?? 'Your account status has been updated.';
        
        // Send notification logic here
    }

    private function logAdminAction(string $action, array $data): void
    {
        $user = $this->getAuthenticatedUser();
        
        $logData = [
            'admin_id' => $user['id'],
            'action' => $action,
            'data' => json_encode($data),
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'created_at' => date('Y-m-d H:i:s')
        ];

        $this->analyticsModel->logAdminAction($logData);
    }
}
