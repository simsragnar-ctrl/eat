<?php

namespace Time2Eat\Controllers;

use Time2Eat\Core\Controller;
use Time2Eat\Models\Affiliate;
use Time2Eat\Models\AffiliateEarning;
use Time2Eat\Models\AffiliateWithdrawal;
use Time2Eat\Models\User;

class AffiliateController extends Controller
{
    private Affiliate $affiliateModel;
    private AffiliateEarning $earningModel;
    private AffiliateWithdrawal $withdrawalModel;
    private User $userModel;

    public function __construct()
    {
        parent::__construct();
        $this->affiliateModel = new Affiliate();
        $this->earningModel = new AffiliateEarning();
        $this->withdrawalModel = new AffiliateWithdrawal();
        $this->userModel = new User();
    }

    public function dashboard(): void
    {
        $this->requireAuth();
        $user = $this->getAuthenticatedUser();

        // Get or create affiliate record
        $affiliate = $this->affiliateModel->getAffiliateByUserId($user['id']);
        if (!$affiliate) {
            $affiliateId = $this->affiliateModel->createAffiliate(['user_id' => $user['id']]);
            $affiliate = $this->affiliateModel->getById($affiliateId);
        }

        // Get affiliate statistics
        $stats = $this->affiliateModel->getAffiliateStats($affiliate['id']);
        
        // Get recent earnings
        $recentEarnings = $this->earningModel->getEarningsByAffiliate($affiliate['id']);
        $recentEarnings = array_slice($recentEarnings, 0, 10); // Last 10 earnings
        
        // Get recent withdrawals
        $recentWithdrawals = $this->withdrawalModel->getWithdrawalsByAffiliate($affiliate['id']);
        $recentWithdrawals = array_slice($recentWithdrawals, 0, 5); // Last 5 withdrawals

        // Get earnings growth data
        $earningsGrowth = $this->earningModel->getEarningsGrowth($affiliate['id']);

        $this->render('affiliate/dashboard', [
            'title' => 'Affiliate Dashboard - Time2Eat',
            'user' => $user,
            'affiliate' => $affiliate,
            'stats' => $stats,
            'recent_earnings' => $recentEarnings,
            'recent_withdrawals' => $recentWithdrawals,
            'earnings_growth' => $earningsGrowth
        ]);
    }

    public function earnings(): void
    {
        $this->requireAuth();
        $user = $this->getAuthenticatedUser();

        $affiliate = $this->affiliateModel->getAffiliateByUserId($user['id']);
        if (!$affiliate) {
            $this->redirect('/affiliate/dashboard');
            return;
        }

        $page = (int)($_GET['page'] ?? 1);
        $filters = [
            'start_date' => $_GET['start_date'] ?? '',
            'end_date' => $_GET['end_date'] ?? '',
            'type' => $_GET['type'] ?? ''
        ];

        // Get earnings with pagination
        $earningsData = $this->affiliateModel->getAffiliateEarnings($affiliate['id'], $page, 20);
        
        // Get earnings statistics
        $earningsStats = $this->earningModel->getEarningsStats($affiliate['id']);
        
        // Get earnings by type
        $earningsByType = $this->earningModel->getEarningsByType($affiliate['id']);

        $this->render('affiliate/earnings', [
            'title' => 'My Earnings - Time2Eat',
            'user' => $user,
            'affiliate' => $affiliate,
            'earnings_data' => $earningsData,
            'earnings_stats' => $earningsStats,
            'earnings_by_type' => $earningsByType,
            'filters' => $filters
        ]);
    }

    public function withdrawals(): void
    {
        $this->requireAuth();
        $user = $this->getAuthenticatedUser();

        $affiliate = $this->affiliateModel->getAffiliateByUserId($user['id']);
        if (!$affiliate) {
            $this->redirect('/affiliate/dashboard');
            return;
        }

        $page = (int)($_GET['page'] ?? 1);
        
        // Get withdrawals with pagination
        $withdrawalsData = $this->affiliateModel->getAffiliateWithdrawals($affiliate['id'], $page, 20);
        
        // Get withdrawal statistics
        $withdrawalStats = $this->withdrawalModel->getWithdrawalStats($affiliate['id']);

        $this->render('affiliate/withdrawals', [
            'title' => 'My Withdrawals - Time2Eat',
            'user' => $user,
            'affiliate' => $affiliate,
            'withdrawals_data' => $withdrawalsData,
            'withdrawal_stats' => $withdrawalStats
        ]);
    }

    public function requestWithdrawal(): void
    {
        $this->requireAuth();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->processWithdrawalRequest();
            return;
        }

        $user = $this->getAuthenticatedUser();
        $affiliate = $this->affiliateModel->getAffiliateByUserId($user['id']);
        
        if (!$affiliate) {
            $this->redirect('/affiliate/dashboard');
            return;
        }

        $this->render('affiliate/request-withdrawal', [
            'title' => 'Request Withdrawal - Time2Eat',
            'user' => $user,
            'affiliate' => $affiliate
        ]);
    }

    public function processWithdrawalRequest(): void
    {
        $this->requireAuth();
        $user = $this->getAuthenticatedUser();

        $validation = $this->validateRequest([
            'amount' => 'required|numeric|min:10000',
            'payment_method' => 'required|string|in:mobile_money,bank_transfer,orange_money,mtn_momo',
            'payment_details' => 'required|array'
        ]);

        if (!$validation['isValid']) {
            $this->jsonResponse(['success' => false, 'errors' => $validation['errors']], 400);
            return;
        }

        $affiliate = $this->affiliateModel->getAffiliateByUserId($user['id']);
        if (!$affiliate) {
            $this->jsonResponse(['success' => false, 'message' => 'Affiliate account not found'], 404);
            return;
        }

        $data = $validation['data'];
        
        // Check if withdrawal is allowed
        $canWithdraw = $this->withdrawalModel->canRequestWithdrawal($affiliate['id'], $data['amount']);
        if (!$canWithdraw['can_withdraw']) {
            $this->jsonResponse(['success' => false, 'message' => $canWithdraw['reason']], 400);
            return;
        }

        // Process withdrawal request
        $withdrawalId = $this->affiliateModel->processWithdrawal($affiliate['id'], $data['amount'], $data);

        if ($withdrawalId) {
            $this->jsonResponse([
                'success' => true,
                'message' => 'Withdrawal request submitted successfully',
                'withdrawal_id' => $withdrawalId
            ]);
        } else {
            $this->jsonResponse([
                'success' => false,
                'message' => $this->affiliateModel->getLastError()
            ], 400);
        }
    }

    public function referrals(): void
    {
        $this->requireAuth();
        $user = $this->getAuthenticatedUser();

        $affiliate = $this->affiliateModel->getAffiliateByUserId($user['id']);
        if (!$affiliate) {
            $this->redirect('/affiliate/dashboard');
            return;
        }

        // Get referred users
        $referredUsers = $this->userModel->getUsersByReferralCode($affiliate['referral_code']);
        
        // Get referral statistics
        $referralStats = $this->getReferralStats($affiliate['id'], $affiliate['referral_code']);

        $this->render('affiliate/referrals', [
            'title' => 'My Referrals - Time2Eat',
            'user' => $user,
            'affiliate' => $affiliate,
            'referred_users' => $referredUsers,
            'referral_stats' => $referralStats
        ]);
    }

    public function validateReferralCode(): void
    {
        $referralCode = $_GET['code'] ?? '';
        
        if (empty($referralCode)) {
            $this->jsonResponse(['valid' => false, 'message' => 'Referral code required']);
            return;
        }

        $affiliate = $this->affiliateModel->getAffiliateByReferralCode($referralCode);
        
        if ($affiliate && $affiliate['status'] === 'active') {
            $user = $this->userModel->getById($affiliate['user_id']);
            $this->jsonResponse([
                'valid' => true,
                'affiliate' => [
                    'name' => $user['first_name'] . ' ' . $user['last_name'],
                    'commission_rate' => $affiliate['commission_rate']
                ]
            ]);
        } else {
            $this->jsonResponse(['valid' => false, 'message' => 'Invalid or inactive referral code']);
        }
    }

    public function getAffiliateStats(): void
    {
        $this->requireAuth();
        $user = $this->getAuthenticatedUser();

        $affiliate = $this->affiliateModel->getAffiliateByUserId($user['id']);
        if (!$affiliate) {
            $this->jsonResponse(['success' => false, 'message' => 'Affiliate not found'], 404);
            return;
        }

        $stats = $this->affiliateModel->getAffiliateStats($affiliate['id']);
        
        $this->jsonResponse([
            'success' => true,
            'stats' => $stats
        ]);
    }

    private function getReferralStats(int $affiliateId, string $referralCode): array
    {
        // Get total referrals
        $totalReferrals = $this->userModel->countByColumn('referred_by', $referralCode);
        
        // Get active referrals (users who have placed orders)
        $activeReferrals = $this->userModel->getActiveReferrals($referralCode);
        
        // Get referrals this month
        $monthlyReferrals = $this->userModel->getMonthlyReferrals($referralCode);
        
        // Get conversion rate
        $conversionRate = $totalReferrals > 0 ? ($activeReferrals / $totalReferrals) * 100 : 0;

        return [
            'total_referrals' => $totalReferrals,
            'active_referrals' => $activeReferrals,
            'monthly_referrals' => $monthlyReferrals,
            'conversion_rate' => round($conversionRate, 2)
        ];
    }
}
