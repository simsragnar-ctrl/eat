<?php

declare(strict_types=1);

namespace Time2Eat\Controllers;

use Time2Eat\Core\Controller;
use Time2Eat\Models\User;
use Time2Eat\Models\Restaurant;
use Time2Eat\Models\Order;
use Time2Eat\Models\Analytics;
use Time2Eat\Models\PopupNotification;
use Time2Eat\Models\SiteSetting;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

/**
 * Admin Tools Controller
 * Handles advanced admin dashboard tools including analytics, approvals, backups, and notifications
 */
class AdminToolsController extends Controller
{
    private User $userModel;
    private Restaurant $restaurantModel;
    private Order $orderModel;
    private Analytics $analyticsModel;
    private PopupNotification $notificationModel;
    private SiteSetting $settingModel;

    public function __construct()
    {
        parent::__construct();
        $this->userModel = new User();
        $this->restaurantModel = new Restaurant();
        $this->orderModel = new Order();
        $this->analyticsModel = new Analytics();
        $this->notificationModel = new PopupNotification();
        $this->settingModel = new SiteSetting();
    }

    /**
     * Analytics Dashboard
     */
    public function analytics(): void
    {
        if (!$this->isAuthenticated() || !$this->hasRole(['admin'])) {
            $this->redirect('/login');
            return;
        }

        $period = $_GET['period'] ?? '30days';
        $export = $_GET['export'] ?? null;

        try {
            // Get comprehensive analytics data
            $analyticsData = $this->getAnalyticsData($period);

            // Handle Excel export
            if ($export === 'excel') {
                $this->exportAnalyticsToExcel($analyticsData, $period);
                return;
            }

            $this->render('admin/tools/analytics', [
                'title' => 'Advanced Analytics - Time2Eat Admin',
                'user' => $this->getAuthenticatedUser(),
                'analyticsData' => $analyticsData,
                'currentPeriod' => $period
            ]);

        } catch (\Exception $e) {
            $this->logError('Analytics dashboard error', [
                'error' => $e->getMessage(),
                'user_id' => $this->getAuthenticatedUser()['id'] ?? null
            ]);

            $this->render('admin/tools/analytics', [
                'title' => 'Advanced Analytics - Time2Eat Admin',
                'user' => $this->getAuthenticatedUser(),
                'error' => 'Failed to load analytics data',
                'currentPeriod' => $period
            ]);
        }
    }

    /**
     * User and Restaurant Approvals
     */
    public function approvals(): void
    {
        if (!$this->isAuthenticated() || !$this->hasRole(['admin'])) {
            $this->redirect('/login');
            return;
        }

        $type = $_GET['type'] ?? 'users';
        $action = $_POST['action'] ?? null;

        try {
            // Handle approval actions
            if ($action && $_SERVER['REQUEST_METHOD'] === 'POST') {
                $this->handleApprovalAction($action, $_POST);
            }

            // Get pending approvals
            $pendingUsers = $this->userModel->getPendingApprovals();
            $pendingRestaurants = $this->restaurantModel->getPendingApprovals();
            $pendingRoleChanges = $this->userModel->getPendingRoleChanges();

            $this->render('admin/tools/approvals', [
                'title' => 'Approvals Management - Time2Eat Admin',
                'user' => $this->getAuthenticatedUser(),
                'pendingUsers' => $pendingUsers,
                'pendingRestaurants' => $pendingRestaurants,
                'pendingRoleChanges' => $pendingRoleChanges,
                'currentType' => $type
            ]);

        } catch (\Exception $e) {
            $this->logError('Approvals management error', [
                'error' => $e->getMessage(),
                'action' => $action,
                'user_id' => $this->getAuthenticatedUser()['id'] ?? null
            ]);

            $this->jsonResponse([
                'success' => false,
                'message' => 'Failed to process approval request'
            ], 500);
        }
    }

    /**
     * Database Backup Management
     */
    public function backups(): void
    {
        if (!$this->isAuthenticated() || !$this->hasRole(['admin'])) {
            $this->redirect('/login');
            return;
        }

        $action = $_POST['action'] ?? $_GET['action'] ?? null;

        try {
            // Handle backup actions
            if ($action && $_SERVER['REQUEST_METHOD'] === 'POST') {
                $this->handleBackupAction($action, $_POST);
                return;
            }

            // Get existing backups
            $backups = $this->getExistingBackups();
            $backupSettings = $this->getBackupSettings();

            $this->render('admin/tools/backups', [
                'title' => 'Database Backups - Time2Eat Admin',
                'user' => $this->getAuthenticatedUser(),
                'backups' => $backups,
                'backupSettings' => $backupSettings
            ]);

        } catch (\Exception $e) {
            $this->logError('Backup management error', [
                'error' => $e->getMessage(),
                'action' => $action,
                'user_id' => $this->getAuthenticatedUser()['id'] ?? null
            ]);

            $this->jsonResponse([
                'success' => false,
                'message' => 'Failed to process backup request'
            ], 500);
        }
    }

    /**
     * Popup Notifications Management
     */
    public function notifications(): void
    {
        if (!$this->isAuthenticated() || !$this->hasRole(['admin'])) {
            $this->redirect('/login');
            return;
        }

        $action = $_POST['action'] ?? null;

        try {
            // Handle notification actions
            if ($action && $_SERVER['REQUEST_METHOD'] === 'POST') {
                $this->handleNotificationAction($action, $_POST);
            }

            // Get notifications
            $activeNotifications = $this->notificationModel->getActiveNotifications();
            $scheduledNotifications = $this->notificationModel->getScheduledNotifications();
            $notificationStats = $this->notificationModel->getNotificationStats();

            $this->render('admin/tools/notifications', [
                'title' => 'Popup Notifications - Time2Eat Admin',
                'user' => $this->getAuthenticatedUser(),
                'activeNotifications' => $activeNotifications,
                'scheduledNotifications' => $scheduledNotifications,
                'notificationStats' => $notificationStats
            ]);

        } catch (\Exception $e) {
            $this->logError('Notification management error', [
                'error' => $e->getMessage(),
                'action' => $action,
                'user_id' => $this->getAuthenticatedUser()['id'] ?? null
            ]);

            $this->jsonResponse([
                'success' => false,
                'message' => 'Failed to process notification request'
            ], 500);
        }
    }

    /**
     * Site Settings and Contact Information
     */
    public function settings(): void
    {
        if (!$this->isAuthenticated() || !$this->hasRole(['admin'])) {
            $this->redirect('/login');
            return;
        }

        $action = $_POST['action'] ?? null;

        try {
            // Handle settings update
            if ($action === 'update' && $_SERVER['REQUEST_METHOD'] === 'POST') {
                $this->updateSiteSettings($_POST);
            }

            // Get all settings grouped by category
            $settings = $this->settingModel->getAllSettingsGrouped();
            $contactSettings = $this->settingModel->getContactSettings();

            $this->render('admin/tools/settings', [
                'title' => 'Site Settings - Time2Eat Admin',
                'user' => $this->getAuthenticatedUser(),
                'settings' => $settings,
                'contactSettings' => $contactSettings
            ]);

        } catch (\Exception $e) {
            $this->logError('Settings management error', [
                'error' => $e->getMessage(),
                'action' => $action,
                'user_id' => $this->getAuthenticatedUser()['id'] ?? null
            ]);

            $this->jsonResponse([
                'success' => false,
                'message' => 'Failed to update settings'
            ], 500);
        }
    }

    /**
     * Get comprehensive analytics data
     */
    private function getAnalyticsData(string $period): array
    {
        return [
            'overview' => [
                'totalUsers' => $this->userModel->getTotalCount(),
                'totalRestaurants' => $this->restaurantModel->getTotalCount(),
                'totalOrders' => $this->orderModel->getTotalCount(),
                'totalRevenue' => $this->orderModel->getTotalRevenue($period),
                'averageOrderValue' => $this->orderModel->getAverageOrderValue($period),
                'conversionRate' => $this->analyticsModel->getConversionRate($period)
            ],
            'userAnalytics' => [
                'userGrowth' => $this->analyticsModel->getUserGrowth($period),
                'usersByRole' => $this->userModel->getUsersByRole(),
                'userRetention' => $this->analyticsModel->getUserRetention($period),
                'topCustomers' => $this->analyticsModel->getTopCustomers($period, 10)
            ],
            'orderAnalytics' => [
                'orderTrends' => $this->analyticsModel->getOrderTrends($period),
                'ordersByStatus' => $this->orderModel->getOrdersByStatus($period),
                'peakHours' => $this->analyticsModel->getPeakHours($period),
                'averageDeliveryTime' => $this->analyticsModel->getAverageDeliveryTime($period)
            ],
            'revenueAnalytics' => [
                'revenueGrowth' => $this->analyticsModel->getRevenueGrowth($period),
                'revenueBySource' => $this->analyticsModel->getRevenueBySource($period),
                'commissionEarnings' => $this->analyticsModel->getCommissionEarnings($period),
                'topRestaurants' => $this->analyticsModel->getTopRestaurants($period, 10)
            ],
            'geographicAnalytics' => [
                'ordersByLocation' => $this->analyticsModel->getOrdersByLocation($period),
                'deliveryHeatmap' => $this->analyticsModel->getDeliveryHeatmap($period),
                'popularAreas' => $this->analyticsModel->getPopularAreas($period)
            ],
            'performanceMetrics' => [
                'systemHealth' => $this->getSystemHealth(),
                'apiResponseTimes' => $this->analyticsModel->getApiResponseTimes($period),
                'errorRates' => $this->analyticsModel->getErrorRates($period),
                'uptime' => $this->analyticsModel->getUptime($period)
            ]
        ];
    }

    /**
     * Export analytics to Excel
     */
    private function exportAnalyticsToExcel(array $data, string $period): void
    {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Set headers
        $sheet->setTitle('Time2Eat Analytics');
        $sheet->setCellValue('A1', 'Time2Eat Analytics Report');
        $sheet->setCellValue('A2', 'Period: ' . ucfirst($period));
        $sheet->setCellValue('A3', 'Generated: ' . date('Y-m-d H:i:s'));

        $row = 5;

        // Overview section
        $sheet->setCellValue('A' . $row, 'OVERVIEW');
        $row += 2;
        foreach ($data['overview'] as $key => $value) {
            $sheet->setCellValue('A' . $row, ucwords(str_replace('_', ' ', $key)));
            $sheet->setCellValue('B' . $row, $value);
            $row++;
        }

        $row += 2;

        // User Analytics section
        $sheet->setCellValue('A' . $row, 'USER ANALYTICS');
        $row += 2;
        
        // Users by role
        $sheet->setCellValue('A' . $row, 'Users by Role');
        $row++;
        foreach ($data['userAnalytics']['usersByRole'] as $role => $count) {
            $sheet->setCellValue('A' . $row, ucfirst($role));
            $sheet->setCellValue('B' . $row, $count);
            $row++;
        }

        // Set filename and headers
        $filename = 'time2eat_analytics_' . $period . '_' . date('Y-m-d') . '.xlsx';
        
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0');

        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
        exit;
    }

    /**
     * Handle approval actions
     */
    private function handleApprovalAction(string $action, array $data): void
    {
        $id = (int)($data['id'] ?? 0);
        $type = $data['type'] ?? '';

        if (!$id || !$type) {
            $this->jsonResponse(['success' => false, 'message' => 'Invalid request'], 400);
            return;
        }

        switch ($action) {
            case 'approve_user':
                $success = $this->userModel->approveUser($id);
                break;
            case 'reject_user':
                $reason = $data['reason'] ?? 'No reason provided';
                $success = $this->userModel->rejectUser($id, $reason);
                break;
            case 'approve_restaurant':
                $success = $this->restaurantModel->approveRestaurant($id);
                break;
            case 'reject_restaurant':
                $reason = $data['reason'] ?? 'No reason provided';
                $success = $this->restaurantModel->rejectRestaurant($id, $reason);
                break;
            case 'approve_role_change':
                $success = $this->userModel->approveRoleChange($id);
                break;
            default:
                $this->jsonResponse(['success' => false, 'message' => 'Invalid action'], 400);
                return;
        }

        if ($success) {
            $this->logAdminAction($action, ['id' => $id, 'type' => $type]);
            $this->jsonResponse(['success' => true, 'message' => 'Action completed successfully']);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to complete action'], 500);
        }
    }

    /**
     * Handle backup actions
     */
    private function handleBackupAction(string $action, array $data): void
    {
        switch ($action) {
            case 'create_backup':
                $this->createDatabaseBackup();
                break;
            case 'download_backup':
                $filename = $data['filename'] ?? '';
                $this->downloadBackup($filename);
                break;
            case 'delete_backup':
                $filename = $data['filename'] ?? '';
                $this->deleteBackup($filename);
                break;
            case 'restore_backup':
                $filename = $data['filename'] ?? '';
                $this->restoreBackup($filename);
                break;
            default:
                $this->jsonResponse(['success' => false, 'message' => 'Invalid backup action'], 400);
        }
    }

    /**
     * Download backup file
     */
    private function downloadBackup(string $filename): void
    {
        if (empty($filename) || !preg_match('/^[a-zA-Z0-9_\-\.]+\.sql$/', $filename)) {
            $this->jsonResponse(['success' => false, 'message' => 'Invalid filename'], 400);
            return;
        }

        $backupDir = __DIR__ . '/../../storage/backups';
        $filepath = $backupDir . '/' . $filename;

        if (!file_exists($filepath)) {
            $this->jsonResponse(['success' => false, 'message' => 'Backup file not found'], 404);
            return;
        }

        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($filepath));
        readfile($filepath);
        exit;
    }

    /**
     * Delete backup file
     */
    private function deleteBackup(string $filename): void
    {
        if (empty($filename) || !preg_match('/^[a-zA-Z0-9_\-\.]+\.sql$/', $filename)) {
            $this->jsonResponse(['success' => false, 'message' => 'Invalid filename'], 400);
            return;
        }

        $backupDir = __DIR__ . '/../../storage/backups';
        $filepath = $backupDir . '/' . $filename;

        if (!file_exists($filepath)) {
            $this->jsonResponse(['success' => false, 'message' => 'Backup file not found'], 404);
            return;
        }

        if (unlink($filepath)) {
            $this->logAdminAction('delete_backup', ['filename' => $filename]);
            $this->jsonResponse(['success' => true, 'message' => 'Backup deleted successfully']);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Failed to delete backup'], 500);
        }
    }

    /**
     * Restore backup file
     */
    private function restoreBackup(string $filename): void
    {
        if (empty($filename) || !preg_match('/^[a-zA-Z0-9_\-\.]+\.sql$/', $filename)) {
            $this->jsonResponse(['success' => false, 'message' => 'Invalid filename'], 400);
            return;
        }

        $backupDir = __DIR__ . '/../../storage/backups';
        $filepath = $backupDir . '/' . $filename;

        if (!file_exists($filepath)) {
            $this->jsonResponse(['success' => false, 'message' => 'Backup file not found'], 404);
            return;
        }

        try {
            $dbHost = $_ENV['DB_HOST'] ?? 'localhost';
            $dbName = $_ENV['DB_NAME'] ?? 'time2eat';
            $dbUser = $_ENV['DB_USER'] ?? 'root';
            $dbPass = $_ENV['DB_PASS'] ?? '';

            $command = sprintf(
                'mysql -h%s -u%s %s %s < %s',
                escapeshellarg($dbHost),
                escapeshellarg($dbUser),
                $dbPass ? '-p' . escapeshellarg($dbPass) : '',
                escapeshellarg($dbName),
                escapeshellarg($filepath)
            );

            exec($command, $output, $returnCode);

            if ($returnCode === 0) {
                $this->logAdminAction('restore_backup', ['filename' => $filename]);
                $this->jsonResponse([
                    'success' => true,
                    'message' => 'Database restored successfully from backup'
                ]);
            } else {
                throw new \Exception('Restore command failed');
            }

        } catch (\Exception $e) {
            $this->logError('Backup restoration failed', ['error' => $e->getMessage()]);
            $this->jsonResponse([
                'success' => false,
                'message' => 'Failed to restore backup: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Create database backup
     */
    private function createDatabaseBackup(): void
    {
        try {
            $backupDir = __DIR__ . '/../../storage/backups';
            if (!is_dir($backupDir)) {
                mkdir($backupDir, 0755, true);
            }

            $filename = 'time2eat_backup_' . date('Y-m-d_H-i-s') . '.sql';
            $filepath = $backupDir . '/' . $filename;

            $dbHost = $_ENV['DB_HOST'] ?? 'localhost';
            $dbName = $_ENV['DB_NAME'] ?? 'time2eat';
            $dbUser = $_ENV['DB_USER'] ?? 'root';
            $dbPass = $_ENV['DB_PASS'] ?? '';

            $command = sprintf(
                'mysqldump -h%s -u%s %s %s > %s',
                escapeshellarg($dbHost),
                escapeshellarg($dbUser),
                $dbPass ? '-p' . escapeshellarg($dbPass) : '',
                escapeshellarg($dbName),
                escapeshellarg($filepath)
            );

            exec($command, $output, $returnCode);

            if ($returnCode === 0 && file_exists($filepath)) {
                $this->logAdminAction('create_backup', ['filename' => $filename]);
                $this->jsonResponse([
                    'success' => true,
                    'message' => 'Backup created successfully',
                    'filename' => $filename
                ]);
            } else {
                throw new \Exception('Backup command failed');
            }

        } catch (\Exception $e) {
            $this->logError('Backup creation failed', ['error' => $e->getMessage()]);
            $this->jsonResponse([
                'success' => false,
                'message' => 'Failed to create backup: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get existing backups
     */
    private function getExistingBackups(): array
    {
        $backupDir = __DIR__ . '/../../storage/backups';
        $backups = [];

        if (is_dir($backupDir)) {
            $files = glob($backupDir . '/*.sql');
            foreach ($files as $file) {
                $backups[] = [
                    'filename' => basename($file),
                    'size' => filesize($file),
                    'created_at' => date('Y-m-d H:i:s', filemtime($file))
                ];
            }
        }

        return $backups;
    }

    /**
     * Get backup settings
     */
    private function getBackupSettings(): array
    {
        return [
            'auto_backup_enabled' => $this->settingModel->get('auto_backup_enabled', false),
            'backup_frequency' => $this->settingModel->get('backup_frequency', 'daily'),
            'backup_retention_days' => $this->settingModel->get('backup_retention_days', 30),
            'backup_location' => 'storage/backups'
        ];
    }

    /**
     * Handle notification actions
     */
    private function handleNotificationAction(string $action, array $data): void
    {
        switch ($action) {
            case 'create_notification':
                $this->createNotification($data);
                break;
            case 'update_notification':
                $this->updateNotification($data);
                break;
            case 'delete_notification':
                $this->deleteNotification($data);
                break;
            case 'send_notification':
                $this->sendNotification($data);
                break;
            default:
                $this->jsonResponse(['success' => false, 'message' => 'Invalid notification action'], 400);
        }
    }

    /**
     * Create popup notification
     */
    private function createNotification(array $data): void
    {
        $validationRules = [
            'title' => 'required|max:255',
            'message' => 'required',
            'type' => 'required|in:info,success,warning,error,promotion',
            'target' => 'required',
            'priority' => 'required|in:low,normal,high,urgent'
        ];

        $errors = $this->validate($data, $validationRules);
        if (!empty($errors)) {
            $this->jsonResponse(['success' => false, 'errors' => $errors], 400);
            return;
        }

        try {
            $notificationData = [
                'title' => $data['title'],
                'message' => $data['message'],
                'type' => $data['type'],
                'target' => $data['target'],
                'priority' => $data['priority'],
                'action_url' => $data['action_url'] ?? null,
                'action_text' => $data['action_text'] ?? null,
                'expires_at' => $data['expires_at'] ?? null,
                'conditions' => isset($data['conditions']) ? json_encode($data['conditions']) : null,
                'created_by' => $this->getAuthenticatedUser()['id']
            ];

            $id = $this->notificationModel->create($notificationData);

            if ($id) {
                $this->logAdminAction('create_notification', ['notification_id' => $id]);
                $this->jsonResponse([
                    'success' => true,
                    'message' => 'Notification created successfully',
                    'notification_id' => $id
                ]);
            } else {
                throw new \Exception('Failed to create notification');
            }

        } catch (\Exception $e) {
            $this->logError('Notification creation failed', ['error' => $e->getMessage()]);
            $this->jsonResponse([
                'success' => false,
                'message' => 'Failed to create notification'
            ], 500);
        }
    }

    /**
     * Update site settings
     */
    private function updateSiteSettings(array $data): void
    {
        try {
            $updated = 0;
            
            foreach ($data as $key => $value) {
                if ($key === 'action') continue; // Skip action field
                
                if ($this->settingModel->updateSetting($key, $value)) {
                    $updated++;
                }
            }

            $this->logAdminAction('update_settings', ['updated_count' => $updated]);
            $this->jsonResponse([
                'success' => true,
                'message' => "Updated {$updated} settings successfully"
            ]);

        } catch (\Exception $e) {
            $this->logError('Settings update failed', ['error' => $e->getMessage()]);
            $this->jsonResponse([
                'success' => false,
                'message' => 'Failed to update settings'
            ], 500);
        }
    }

    /**
     * Get system health metrics
     */
    private function getSystemHealth(): array
    {
        return [
            'database' => $this->checkDatabaseHealth(),
            'storage' => $this->checkStorageHealth(),
            'memory' => $this->getMemoryUsage(),
            'php_version' => PHP_VERSION,
            'server_load' => sys_getloadavg()[0] ?? 0
        ];
    }

    /**
     * Check database health
     */
    private function checkDatabaseHealth(): array
    {
        try {
            $start = microtime(true);
            $this->db->query("SELECT 1");
            $responseTime = (microtime(true) - $start) * 1000;

            return [
                'status' => 'healthy',
                'response_time' => round($responseTime, 2) . 'ms'
            ];
        } catch (\Exception $e) {
            return [
                'status' => 'error',
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Check storage health
     */
    private function checkStorageHealth(): array
    {
        $storageDir = __DIR__ . '/../../storage';
        $freeBytes = disk_free_space($storageDir);
        $totalBytes = disk_total_space($storageDir);
        
        return [
            'free_space' => $this->formatBytes($freeBytes),
            'total_space' => $this->formatBytes($totalBytes),
            'usage_percentage' => round((($totalBytes - $freeBytes) / $totalBytes) * 100, 2)
        ];
    }

    /**
     * Get memory usage
     */
    private function getMemoryUsage(): array
    {
        return [
            'current' => $this->formatBytes(memory_get_usage(true)),
            'peak' => $this->formatBytes(memory_get_peak_usage(true)),
            'limit' => ini_get('memory_limit')
        ];
    }

    /**
     * Format bytes to human readable format
     */
    private function formatBytes(int $bytes): string
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        
        $bytes /= (1 << (10 * $pow));
        
        return round($bytes, 2) . ' ' . $units[$pow];
    }

    /**
     * Log admin action
     */
    private function logAdminAction(string $action, array $data): void
    {
        $user = $this->getAuthenticatedUser();
        
        $logData = [
            'user_id' => $user['id'],
            'action' => $action,
            'details' => json_encode($data),
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'timestamp' => date('Y-m-d H:i:s')
        ];

        $this->analyticsModel->logAction($logData);
    }
}
