<?php

namespace Time2Eat\Models;

use Time2Eat\Core\BaseModel;

class Order extends BaseModel
{
    protected string $table = 'orders';
    protected array $fillable = [
        'order_number', 'customer_id', 'restaurant_id', 'rider_id', 'status',
        'subtotal', 'delivery_fee', 'discount_amount', 'total_amount',
        'payment_method', 'payment_status', 'promo_code', 'affiliate_code',
        'affiliate_commission', 'delivery_address', 'delivery_instructions',
        'estimated_delivery_time', 'placed_at', 'confirmed_at', 'prepared_at',
        'picked_up_at', 'delivered_at', 'cancelled_at', 'cancellation_reason'
    ];

    public function createOrder(array $orderData): ?int
    {
        // Generate unique order number
        $orderData['order_number'] = $this->generateOrderNumber();
        $orderData['placed_at'] = date('Y-m-d H:i:s');
        $orderData['created_at'] = date('Y-m-d H:i:s');
        $orderData['updated_at'] = date('Y-m-d H:i:s');

        return $this->create($orderData);
    }

    public function generateOrderNumber(): string
    {
        $prefix = 'T2E';
        $timestamp = date('ymd');
        $random = str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
        
        $orderNumber = $prefix . $timestamp . $random;
        
        // Ensure uniqueness
        while ($this->orderNumberExists($orderNumber)) {
            $random = str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
            $orderNumber = $prefix . $timestamp . $random;
        }
        
        return $orderNumber;
    }

    private function orderNumberExists(string $orderNumber): bool
    {
        $sql = "SELECT COUNT(*) as count FROM {$this->table} WHERE order_number = ?";
        $result = $this->db->fetch($sql, [$orderNumber]);
        return $result['count'] > 0;
    }

    public function getOrdersByCustomer(int $customerId, int $limit = 20, int $offset = 0): array
    {
        $sql = "
            SELECT 
                o.*,
                r.name as restaurant_name,
                r.image as restaurant_image,
                r.phone as restaurant_phone,
                COUNT(oi.id) as item_count
            FROM {$this->table} o
            JOIN restaurants r ON o.restaurant_id = r.id
            LEFT JOIN order_items oi ON o.id = oi.order_id
            WHERE o.customer_id = ?
            GROUP BY o.id
            ORDER BY o.created_at DESC
            LIMIT ? OFFSET ?
        ";

        return $this->db->fetchAll($sql, [$customerId, $limit, $offset]);
    }

    public function getOrderDetails(int $orderId, int $customerId = null): ?array
    {
        $sql = "
            SELECT 
                o.*,
                r.name as restaurant_name,
                r.image as restaurant_image,
                r.phone as restaurant_phone,
                r.address as restaurant_address,
                u.first_name as customer_first_name,
                u.last_name as customer_last_name,
                u.phone as customer_phone,
                u.email as customer_email,
                rider.first_name as rider_first_name,
                rider.last_name as rider_last_name,
                rider.phone as rider_phone
            FROM {$this->table} o
            JOIN restaurants r ON o.restaurant_id = r.id
            JOIN users u ON o.customer_id = u.id
            LEFT JOIN users rider ON o.rider_id = rider.id
            WHERE o.id = ?
        ";

        $params = [$orderId];
        
        if ($customerId) {
            $sql .= " AND o.customer_id = ?";
            $params[] = $customerId;
        }

        return $this->db->fetch($sql, $params);
    }

    public function getOrderItems(int $orderId): array
    {
        $sql = "
            SELECT 
                oi.*,
                mi.name as item_name,
                mi.description as item_description,
                mi.image as item_image,
                c.name as category_name
            FROM order_items oi
            JOIN menu_items mi ON oi.menu_item_id = mi.id
            JOIN categories c ON mi.category_id = c.id
            WHERE oi.order_id = ?
            ORDER BY oi.id
        ";

        return $this->db->fetchAll($sql, [$orderId]);
    }

    public function updateOrderStatus(int $orderId, string $status, array $additionalData = []): bool
    {
        $updateData = ['status' => $status, 'updated_at' => date('Y-m-d H:i:s')];
        
        // Set timestamp based on status
        switch ($status) {
            case 'confirmed':
                $updateData['confirmed_at'] = date('Y-m-d H:i:s');
                break;
            case 'preparing':
                $updateData['prepared_at'] = date('Y-m-d H:i:s');
                break;
            case 'ready':
                // Calculate estimated delivery time
                $order = $this->getById($orderId);
                if ($order) {
                    $restaurant = $this->db->fetch("SELECT delivery_time FROM restaurants WHERE id = ?", [$order['restaurant_id']]);
                    if ($restaurant) {
                        $estimatedTime = date('Y-m-d H:i:s', strtotime('+' . $restaurant['delivery_time'] . ' minutes'));
                        $updateData['estimated_delivery_time'] = $estimatedTime;
                    }
                }
                break;
            case 'picked_up':
                $updateData['picked_up_at'] = date('Y-m-d H:i:s');
                break;
            case 'delivered':
                $updateData['delivered_at'] = date('Y-m-d H:i:s');
                $updateData['payment_status'] = 'completed';
                break;
            case 'cancelled':
                $updateData['cancelled_at'] = date('Y-m-d H:i:s');
                if (isset($additionalData['cancellation_reason'])) {
                    $updateData['cancellation_reason'] = $additionalData['cancellation_reason'];
                }
                break;
        }

        // Merge additional data
        $updateData = array_merge($updateData, $additionalData);

        return $this->update($orderId, $updateData);
    }

    public function canCancelOrder(int $orderId, int $customerId): bool
    {
        $order = $this->getOrderDetails($orderId, $customerId);
        
        if (!$order) {
            return false;
        }

        // Can cancel if order is pending or confirmed and not yet prepared
        $cancellableStatuses = ['pending', 'confirmed'];
        return in_array($order['status'], $cancellableStatuses);
    }

    public function cancelOrder(int $orderId, int $customerId, string $reason = ''): bool
    {
        if (!$this->canCancelOrder($orderId, $customerId)) {
            return false;
        }

        return $this->updateOrderStatus($orderId, 'cancelled', [
            'cancellation_reason' => $reason ?: 'Cancelled by customer'
        ]);
    }

    public function getRecentOrdersByRestaurant(int $restaurantId, int $limit = 10): array
    {
        $sql = "
            SELECT 
                o.*,
                u.first_name as customer_first_name,
                u.last_name as customer_last_name,
                u.phone as customer_phone,
                COUNT(oi.id) as item_count
            FROM {$this->table} o
            JOIN users u ON o.customer_id = u.id
            LEFT JOIN order_items oi ON o.id = oi.order_id
            WHERE o.restaurant_id = ?
            GROUP BY o.id
            ORDER BY o.created_at DESC
            LIMIT ?
        ";

        return $this->db->fetchAll($sql, [$restaurantId, $limit]);
    }

    public function getOrdersByRestaurant(int $restaurantId, string $status = 'all', int $limit = 20, int $offset = 0): array
    {
        $sql = "
            SELECT 
                o.*,
                u.first_name as customer_first_name,
                u.last_name as customer_last_name,
                u.phone as customer_phone,
                COUNT(oi.id) as item_count
            FROM {$this->table} o
            JOIN users u ON o.customer_id = u.id
            LEFT JOIN order_items oi ON o.id = oi.order_id
            WHERE o.restaurant_id = ?
        ";

        $params = [$restaurantId];

        if ($status !== 'all') {
            $sql .= " AND o.status = ?";
            $params[] = $status;
        }

        $sql .= " GROUP BY o.id ORDER BY o.created_at DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;

        return $this->db->fetchAll($sql, $params);
    }

    public function getAvailableOrdersForRider(int $riderId, int $limit = 10, int $offset = 0): array
    {
        $sql = "
            SELECT 
                o.*,
                r.name as restaurant_name,
                r.address as restaurant_address,
                r.latitude as restaurant_latitude,
                r.longitude as restaurant_longitude,
                u.first_name as customer_first_name,
                u.last_name as customer_last_name,
                COUNT(oi.id) as item_count
            FROM {$this->table} o
            JOIN restaurants r ON o.restaurant_id = r.id
            JOIN users u ON o.customer_id = u.id
            LEFT JOIN order_items oi ON o.id = oi.order_id
            WHERE o.status = 'ready' AND o.rider_id IS NULL
            GROUP BY o.id
            ORDER BY o.created_at ASC
            LIMIT ? OFFSET ?
        ";

        return $this->db->fetchAll($sql, [$limit, $offset]);
    }

    public function assignRider(int $orderId, int $riderId): bool
    {
        return $this->update($orderId, [
            'rider_id' => $riderId,
            'status' => 'assigned',
            'updated_at' => date('Y-m-d H:i:s')
        ]);
    }

    public function calculateAffiliateCommission(float $orderTotal, float $commissionRate): float
    {
        return round($orderTotal * ($commissionRate / 100), 2);
    }

    public function processAffiliateCommission(int $orderId): bool
    {
        $order = $this->getById($orderId);
        
        if (!$order || !$order['affiliate_code'] || $order['affiliate_commission'] > 0) {
            return false;
        }

        // Get affiliate user
        $affiliateSQL = "SELECT * FROM users WHERE affiliate_code = ? AND role = 'customer'";
        $affiliate = $this->db->fetch($affiliateSQL, [$order['affiliate_code']]);
        
        if (!$affiliate) {
            return false;
        }

        $commission = $this->calculateAffiliateCommission($order['subtotal'], $affiliate['affiliate_rate']);
        
        try {
            $this->db->beginTransaction();

            // Update order with commission
            $this->update($orderId, ['affiliate_commission' => $commission]);

            // Add commission to affiliate balance
            $this->db->execute(
                "UPDATE users SET balance = balance + ? WHERE id = ?",
                [$commission, $affiliate['id']]
            );

            // Record affiliate transaction
            $this->db->execute(
                "INSERT INTO affiliate_transactions (user_id, order_id, commission_amount, status, created_at) VALUES (?, ?, ?, 'completed', ?)",
                [$affiliate['id'], $orderId, $commission, date('Y-m-d H:i:s')]
            );

            $this->db->commit();
            return true;

        } catch (Exception $e) {
            $this->db->rollback();
            return false;
        }
    }

    public function getOrderStatistics(): array
    {
        $sql = "
            SELECT 
                COUNT(*) as total_orders,
                COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_orders,
                COUNT(CASE WHEN status = 'confirmed' THEN 1 END) as confirmed_orders,
                COUNT(CASE WHEN status = 'preparing' THEN 1 END) as preparing_orders,
                COUNT(CASE WHEN status = 'ready' THEN 1 END) as ready_orders,
                COUNT(CASE WHEN status = 'delivered' THEN 1 END) as delivered_orders,
                COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled_orders,
                COALESCE(SUM(total_amount), 0) as total_revenue,
                COALESCE(AVG(total_amount), 0) as average_order_value
            FROM {$this->table}
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        ";

        return $this->db->fetch($sql) ?: [];
    }

    public function getTodayOrderCount(int $restaurantId): int
    {
        $sql = "
            SELECT COUNT(*) as count 
            FROM {$this->table} 
            WHERE restaurant_id = ? AND DATE(created_at) = CURDATE()
        ";
        
        $result = $this->db->fetch($sql, [$restaurantId]);
        return (int)($result['count'] ?? 0);
    }

    public function getTodayRevenue(int $restaurantId): float
    {
        $sql = "
            SELECT COALESCE(SUM(subtotal), 0) as revenue 
            FROM {$this->table} 
            WHERE restaurant_id = ? AND DATE(created_at) = CURDATE() AND status != 'cancelled'
        ";
        
        $result = $this->db->fetch($sql, [$restaurantId]);
        return (float)($result['revenue'] ?? 0);
    }

    public function getMonthlyOrderCount(int $restaurantId): int
    {
        $sql = "
            SELECT COUNT(*) as count 
            FROM {$this->table} 
            WHERE restaurant_id = ? AND MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())
        ";
        
        $result = $this->db->fetch($sql, [$restaurantId]);
        return (int)($result['count'] ?? 0);
    }

    public function getMonthlyRevenue(int $restaurantId): float
    {
        $sql = "
            SELECT COALESCE(SUM(subtotal), 0) as revenue 
            FROM {$this->table} 
            WHERE restaurant_id = ? AND MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE()) AND status != 'cancelled'
        ";
        
        $result = $this->db->fetch($sql, [$restaurantId]);
        return (float)($result['revenue'] ?? 0);
    }

    public function countOrdersByCustomer(int $customerId): int
    {
        $sql = "SELECT COUNT(*) as count FROM {$this->table} WHERE customer_id = ?";
        $result = $this->db->fetch($sql, [$customerId]);
        return (int)($result['count'] ?? 0);
    }

    public function getTotalSpentByCustomer(int $customerId): float
    {
        $sql = "
            SELECT COALESCE(SUM(total_amount), 0) as total
            FROM {$this->table}
            WHERE customer_id = ? AND status = 'delivered'
        ";

        $result = $this->db->fetch($sql, [$customerId]);
        return (float)($result['total'] ?? 0);
    }

    /**
     * Get total order count
     */
    public function getTotalCount(): int
    {
        $sql = "SELECT COUNT(*) as count FROM {$this->table}";
        $result = $this->fetchOne($sql);
        return (int)($result['count'] ?? 0);
    }

    /**
     * Get total revenue
     */
    public function getTotalRevenue(string $period = 'all'): float
    {
        $dateCondition = $this->getDateCondition($period);

        $sql = "SELECT COALESCE(SUM(total_amount), 0) as total
                FROM {$this->table}
                WHERE status = 'delivered' {$dateCondition}";

        $result = $this->fetchOne($sql);
        return (float)($result['total'] ?? 0);
    }

    /**
     * Get average order value
     */
    public function getAverageOrderValue(string $period = 'all'): float
    {
        $dateCondition = $this->getDateCondition($period);

        $sql = "SELECT AVG(total_amount) as avg_value
                FROM {$this->table}
                WHERE status = 'delivered' {$dateCondition}";

        $result = $this->fetchOne($sql);
        return round((float)($result['avg_value'] ?? 0), 2);
    }

    /**
     * Get orders by status for a period
     */
    public function getOrdersByStatus(string $period = 'all'): array
    {
        $dateCondition = $this->getDateCondition($period);

        $sql = "SELECT status, COUNT(*) as count
                FROM {$this->table}
                WHERE 1=1 {$dateCondition}
                GROUP BY status";

        $results = $this->fetchAll($sql);
        $counts = [];

        foreach ($results as $result) {
            $counts[$result['status']] = (int)$result['count'];
        }

        return $counts;
    }

    /**
     * Get active order count
     */
    public function getActiveOrderCount(): int
    {
        $sql = "SELECT COUNT(*) as count FROM {$this->table}
                WHERE status IN ('pending', 'confirmed', 'preparing', 'ready', 'out_for_delivery')";
        $result = $this->fetchOne($sql);
        return (int)($result['count'] ?? 0);
    }

    /**
     * Get monthly revenue
     */
    public function getMonthlyRevenue(): float
    {
        $sql = "SELECT COALESCE(SUM(total_amount), 0) as total
                FROM {$this->table}
                WHERE status = 'delivered'
                AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";

        $result = $this->fetchOne($sql);
        return (float)($result['total'] ?? 0);
    }

    /**
     * Get monthly order count
     */
    public function getMonthlyOrderCount(): int
    {
        $sql = "SELECT COUNT(*) as count FROM {$this->table}
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
        $result = $this->fetchOne($sql);
        return (int)($result['count'] ?? 0);
    }

    /**
     * Get orders with filtering and pagination
     */
    public function getOrders(string $status = 'all', string $date = '', string $search = '', int $limit = 20, int $offset = 0): array
    {
        $conditions = ['1=1'];
        $params = [];

        if ($status !== 'all') {
            $conditions[] = 'o.status = ?';
            $params[] = $status;
        }

        if (!empty($date)) {
            $conditions[] = 'DATE(o.created_at) = ?';
            $params[] = $date;
        }

        if (!empty($search)) {
            $conditions[] = '(o.order_number LIKE ? OR c.first_name LIKE ? OR c.last_name LIKE ? OR r.name LIKE ?)';
            $searchTerm = "%{$search}%";
            $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm, $searchTerm]);
        }

        $whereClause = implode(' AND ', $conditions);
        $params[] = $limit;
        $params[] = $offset;

        $sql = "SELECT o.*,
                       c.first_name as customer_first_name, c.last_name as customer_last_name, c.email as customer_email,
                       r.name as restaurant_name,
                       rd.first_name as rider_first_name, rd.last_name as rider_last_name
                FROM {$this->table} o
                LEFT JOIN users c ON o.customer_id = c.id
                LEFT JOIN restaurants r ON o.restaurant_id = r.id
                LEFT JOIN users rd ON o.rider_id = rd.id
                WHERE {$whereClause}
                ORDER BY o.created_at DESC
                LIMIT ? OFFSET ?";

        return $this->fetchAll($sql, $params);
    }

    /**
     * Count orders with filtering
     */
    public function countOrders(string $status = 'all', string $date = '', string $search = ''): int
    {
        $conditions = ['1=1'];
        $params = [];

        if ($status !== 'all') {
            $conditions[] = 'o.status = ?';
            $params[] = $status;
        }

        if (!empty($date)) {
            $conditions[] = 'DATE(o.created_at) = ?';
            $params[] = $date;
        }

        if (!empty($search)) {
            $conditions[] = '(o.order_number LIKE ? OR c.first_name LIKE ? OR c.last_name LIKE ? OR r.name LIKE ?)';
            $searchTerm = "%{$search}%";
            $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm, $searchTerm]);
        }

        $whereClause = implode(' AND ', $conditions);

        $sql = "SELECT COUNT(*) as count
                FROM {$this->table} o
                LEFT JOIN users c ON o.customer_id = c.id
                LEFT JOIN restaurants r ON o.restaurant_id = r.id
                WHERE {$whereClause}";

        $result = $this->fetchOne($sql, $params);
        return (int)($result['count'] ?? 0);
    }

    /**
     * Get order statistics
     */
    public function getOrderStatistics(): array
    {
        $sql = "SELECT
                    COUNT(*) as total_orders,
                    COUNT(CASE WHEN status = 'delivered' THEN 1 END) as completed_orders,
                    COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled_orders,
                    COUNT(CASE WHEN status IN ('pending', 'confirmed', 'preparing', 'ready', 'out_for_delivery') THEN 1 END) as active_orders,
                    AVG(total_amount) as average_order_value,
                    SUM(CASE WHEN status = 'delivered' THEN total_amount ELSE 0 END) as total_revenue
                FROM {$this->table}";

        return $this->fetchOne($sql) ?: [];
    }

    /**
     * Get pending disputes
     */
    public function getPendingDisputes(): array
    {
        // This would require a disputes table in a full implementation
        // For now, return empty array
        return [];
    }

    /**
     * Get date condition for queries
     */
    private function getDateCondition(string $period): string
    {
        switch ($period) {
            case 'today':
                return "AND DATE(created_at) = CURDATE()";
            case 'yesterday':
                return "AND DATE(created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
            case 'week':
            case '7days':
                return "AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
            case 'month':
            case '30days':
                return "AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
            case '90days':
                return "AND created_at >= DATE_SUB(NOW(), INTERVAL 90 DAY)";
            case 'year':
                return "AND created_at >= DATE_SUB(NOW(), INTERVAL 1 YEAR)";
            default:
                return "";
        }
    }
}
