<?php

declare(strict_types=1);

namespace models;

require_once __DIR__ . '/../traits/DatabaseTrait.php';

use traits\DatabaseTrait;

/**
 * User Model for Time2Eat Authentication System
 * Handles user data operations with security and validation
 */
class User
{
    use DatabaseTrait;
    
    protected string $table = 'users';
    protected array $fillable = [
        'username', 'email', 'password', 'first_name', 'last_name', 
        'phone', 'role', 'status', 'affiliate_code', 'affiliate_rate'
    ];
    
    protected array $hidden = ['password', 'remember_token', 'reset_token'];
    protected array $casts = [
        'email_verified_at' => 'datetime',
        'last_login_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'deleted_at' => 'datetime',
        'notification_preferences' => 'json',
        'two_factor_enabled' => 'boolean'
    ];
    
    /**
     * Find user by email
     */
    public function findByEmail(string $email): ?array
    {
        return $this->fetchOne(
            "SELECT * FROM {$this->table} WHERE email = ? AND deleted_at IS NULL",
            [$email]
        );
    }
    
    /**
     * Find user by username
     */
    public function findByUsername(string $username): ?array
    {
        return $this->fetchOne(
            "SELECT * FROM {$this->table} WHERE username = ? AND deleted_at IS NULL",
            [$username]
        );
    }
    
    /**
     * Find user by ID
     */
    public function findById(int $id): ?array
    {
        return $this->fetchOne(
            "SELECT * FROM {$this->table} WHERE id = ? AND deleted_at IS NULL",
            [$id]
        );
    }
    
    /**
     * Find user by affiliate code
     */
    public function findByAffiliateCode(string $code): ?array
    {
        return $this->fetchOne(
            "SELECT * FROM {$this->table} WHERE affiliate_code = ? AND status = 'active' AND deleted_at IS NULL",
            [$code]
        );
    }
    
    /**
     * Create new user
     */
    public function create(array $data): int
    {
        // Hash password if provided
        if (isset($data['password'])) {
            $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        }
        
        // Set default values
        $data['status'] = $data['status'] ?? 'active';
        $data['role'] = $data['role'] ?? 'customer';
        $data['affiliate_rate'] = $data['affiliate_rate'] ?? 0.05;
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['updated_at'] = date('Y-m-d H:i:s');
        
        return $this->insert($this->table, $data);
    }
    
    /**
     * Update user
     */
    public function updateUser(int $id, array $data): bool
    {
        // Hash password if being updated
        if (isset($data['password'])) {
            $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        }
        
        $data['updated_at'] = date('Y-m-d H:i:s');
        
        return $this->update($this->table, $data, ['id' => $id]) > 0;
    }
    
    /**
     * Verify user password
     */
    public function verifyPassword(string $password, string $hash): bool
    {
        return password_verify($password, $hash);
    }
    
    /**
     * Check if email exists
     */
    public function emailExists(string $email, ?int $excludeId = null): bool
    {
        $sql = "SELECT id FROM {$this->table} WHERE email = ? AND deleted_at IS NULL";
        $params = [$email];
        
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        return $this->fetchOne($sql, $params) !== null;
    }
    
    /**
     * Check if username exists
     */
    public function usernameExists(string $username, ?int $excludeId = null): bool
    {
        $sql = "SELECT id FROM {$this->table} WHERE username = ? AND deleted_at IS NULL";
        $params = [$username];
        
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        return $this->fetchOne($sql, $params) !== null;
    }
    
    /**
     * Activate user account
     */
    public function activate(int $id): bool
    {
        return $this->updateUser($id, [
            'status' => 'active',
            'email_verified_at' => date('Y-m-d H:i:s')
        ]);
    }
    
    /**
     * Deactivate user account
     */
    public function deactivate(int $id): bool
    {
        return $this->updateUser($id, ['status' => 'inactive']);
    }
    
    /**
     * Suspend user account
     */
    public function suspend(int $id, ?string $reason = null): bool
    {
        $data = ['status' => 'suspended'];
        if ($reason) {
            $data['suspension_reason'] = $reason;
        }
        
        return $this->updateUser($id, $data);
    }
    
    /**
     * Soft delete user
     */
    public function softDelete(int $id): bool
    {
        return $this->updateUser($id, ['deleted_at' => date('Y-m-d H:i:s')]);
    }
    
    /**
     * Restore soft deleted user
     */
    public function restore(int $id): bool
    {
        return $this->update($this->table, ['deleted_at' => null], ['id' => $id]) > 0;
    }
    
    /**
     * Get users by role
     */
    public function getByRole(string $role, int $limit = 50, int $offset = 0): array
    {
        return $this->fetchAll(
            "SELECT * FROM {$this->table} WHERE role = ? AND deleted_at IS NULL ORDER BY created_at DESC LIMIT ? OFFSET ?",
            [$role, $limit, $offset]
        );
    }
    
    /**
     * Get active users count
     */
    public function getActiveCount(): int
    {
        $result = $this->fetchOne(
            "SELECT COUNT(*) as count FROM {$this->table} WHERE status = 'active' AND deleted_at IS NULL"
        );
        
        return (int) $result['count'];
    }
    
    /**
     * Get users by status
     */
    public function getByStatus(string $status, int $limit = 50, int $offset = 0): array
    {
        return $this->fetchAll(
            "SELECT * FROM {$this->table} WHERE status = ? AND deleted_at IS NULL ORDER BY created_at DESC LIMIT ? OFFSET ?",
            [$status, $limit, $offset]
        );
    }
    
    /**
     * Search users
     */
    public function search(string $query, int $limit = 50, int $offset = 0): array
    {
        $searchTerm = "%{$query}%";
        
        return $this->fetchAll(
            "SELECT * FROM {$this->table} 
             WHERE (first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR username LIKE ?) 
             AND deleted_at IS NULL 
             ORDER BY created_at DESC 
             LIMIT ? OFFSET ?",
            [$searchTerm, $searchTerm, $searchTerm, $searchTerm, $limit, $offset]
        );
    }
    
    /**
     * Update last login
     */
    public function updateLastLogin(int $id, string $ip): bool
    {
        return $this->updateUser($id, [
            'last_login_at' => date('Y-m-d H:i:s'),
            'last_login_ip' => $ip
        ]);
    }
    
    /**
     * Set remember token
     */
    public function setRememberToken(int $id, string $token): bool
    {
        return $this->updateUser($id, ['remember_token' => $token]);
    }
    
    /**
     * Clear remember token
     */
    public function clearRememberToken(int $id): bool
    {
        return $this->updateUser($id, ['remember_token' => null]);
    }
    
    /**
     * Set password reset token
     */
    public function setResetToken(int $id, string $token, int $expiresIn = 3600): bool
    {
        return $this->updateUser($id, [
            'reset_token' => $token,
            'reset_token_expires' => date('Y-m-d H:i:s', time() + $expiresIn)
        ]);
    }
    
    /**
     * Clear password reset token
     */
    public function clearResetToken(int $id): bool
    {
        return $this->updateUser($id, [
            'reset_token' => null,
            'reset_token_expires' => null
        ]);
    }
    
    /**
     * Find user by reset token
     */
    public function findByResetToken(string $token): ?array
    {
        return $this->fetchOne(
            "SELECT * FROM {$this->table} 
             WHERE reset_token = ? 
             AND reset_token_expires > NOW() 
             AND deleted_at IS NULL",
            [$token]
        );
    }
    
    /**
     * Update user balance
     */
    public function updateBalance(int $id, float $amount, string $operation = 'add'): bool
    {
        $operator = $operation === 'add' ? '+' : '-';
        
        return $this->query(
            "UPDATE {$this->table} SET balance = balance {$operator} ?, updated_at = NOW() WHERE id = ?",
            [$amount, $id]
        ) > 0;
    }
    
    /**
     * Get user statistics
     */
    public function getStats(): array
    {
        $stats = $this->fetchOne(
            "SELECT 
                COUNT(*) as total_users,
                SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_users,
                SUM(CASE WHEN role = 'customer' THEN 1 ELSE 0 END) as customers,
                SUM(CASE WHEN role = 'vendor' THEN 1 ELSE 0 END) as vendors,
                SUM(CASE WHEN role = 'rider' THEN 1 ELSE 0 END) as riders,
                SUM(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN 1 ELSE 0 END) as new_users_30d
             FROM {$this->table} 
             WHERE deleted_at IS NULL"
        );
        
        return [
            'total_users' => (int) $stats['total_users'],
            'active_users' => (int) $stats['active_users'],
            'customers' => (int) $stats['customers'],
            'vendors' => (int) $stats['vendors'],
            'riders' => (int) $stats['riders'],
            'new_users_30d' => (int) $stats['new_users_30d']
        ];
    }
    
    /**
     * Get user with profile
     */
    public function getWithProfile(int $id): ?array
    {
        return $this->fetchOne(
            "SELECT u.*, up.*
             FROM {$this->table} u
             LEFT JOIN user_profiles up ON u.id = up.user_id
             WHERE u.id = ? AND u.deleted_at IS NULL",
            [$id]
        );
    }

    /**
     * Get user addresses
     */
    public function getAddressesByUser(int $userId): array
    {
        $sql = "
            SELECT * FROM user_addresses
            WHERE user_id = ? AND deleted_at IS NULL
            ORDER BY is_default DESC, created_at DESC
        ";

        return $this->db->fetchAll($sql, [$userId]);
    }

    /**
     * Get address by ID
     */
    public function getAddressById(int $addressId): ?array
    {
        $sql = "SELECT * FROM user_addresses WHERE id = ? AND deleted_at IS NULL";
        return $this->db->fetch($sql, [$addressId]);
    }

    /**
     * Get user payment methods
     */
    public function getPaymentMethodsByUser(int $userId): array
    {
        $sql = "
            SELECT * FROM payment_methods
            WHERE user_id = ? AND deleted_at IS NULL
            ORDER BY is_default DESC, created_at DESC
        ";

        return $this->db->fetchAll($sql, [$userId]);
    }

    /**
     * Get payment method by ID
     */
    public function getPaymentMethodById(int $paymentMethodId): ?array
    {
        $sql = "SELECT * FROM payment_methods WHERE id = ? AND deleted_at IS NULL";
        return $this->db->fetch($sql, [$paymentMethodId]);
    }

    /**
     * Find user by affiliate code
     */
    public function findByAffiliateCode(string $affiliateCode): ?array
    {
        $sql = "
            SELECT * FROM {$this->table}
            WHERE affiliate_code = ? AND role = 'customer' AND deleted_at IS NULL
        ";

        return $this->db->fetch($sql, [$affiliateCode]);
    }

    public function getUsersByReferralCode(string $referralCode): array
    {
        $sql = "SELECT id, first_name, last_name, email, phone, created_at, status
                FROM {$this->table}
                WHERE referred_by = ? AND deleted_at IS NULL
                ORDER BY created_at DESC";

        return $this->fetchAll($sql, [$referralCode]);
    }

    public function getActiveReferrals(string $referralCode): int
    {
        $sql = "SELECT COUNT(DISTINCT u.id) as count
                FROM {$this->table} u
                JOIN orders o ON u.id = o.customer_id
                WHERE u.referred_by = ? AND u.deleted_at IS NULL
                AND o.status IN ('completed', 'delivered')";

        $result = $this->fetchOne($sql, [$referralCode]);
        return (int)($result['count'] ?? 0);
    }

    public function getMonthlyReferrals(string $referralCode, ?string $month = null): int
    {
        $month = $month ?? date('Y-m');

        $sql = "SELECT COUNT(*) as count
                FROM {$this->table}
                WHERE referred_by = ? AND deleted_at IS NULL
                AND DATE_FORMAT(created_at, '%Y-%m') = ?";

        $result = $this->fetchOne($sql, [$referralCode, $month]);
        return (int)($result['count'] ?? 0);
    }

    /**
     * Get pending user approvals
     */
    public function getPendingApprovals(): array
    {
        $sql = "SELECT * FROM {$this->table}
                WHERE status = 'pending' AND deleted_at IS NULL
                ORDER BY created_at DESC";
        return $this->fetchAll($sql);
    }

    /**
     * Get pending role changes
     */
    public function getPendingRoleChanges(): array
    {
        // This would require a role_change_requests table in a full implementation
        // For now, return empty array
        return [];
    }

    /**
     * Get pending riders
     */
    public function getPendingRiders(): array
    {
        $sql = "SELECT * FROM {$this->table}
                WHERE role = 'rider' AND status = 'pending' AND deleted_at IS NULL
                ORDER BY created_at DESC";
        return $this->fetchAll($sql);
    }

    /**
     * Approve user
     */
    public function approveUser(int $id): bool
    {
        $sql = "UPDATE {$this->table} SET status = 'active', updated_at = NOW() WHERE id = ?";
        return $this->execute($sql, [$id]) > 0;
    }

    /**
     * Reject user
     */
    public function rejectUser(int $id, string $reason = ''): bool
    {
        $sql = "UPDATE {$this->table} SET status = 'suspended', updated_at = NOW() WHERE id = ?";
        return $this->execute($sql, [$id]) > 0;
    }

    /**
     * Approve role change
     */
    public function approveRoleChange(int $id): bool
    {
        // This would require implementation of role change requests
        // For now, return true
        return true;
    }

    /**
     * Get users by role
     */
    public function getUsersByRole(): array
    {
        $sql = "SELECT role, COUNT(*) as count FROM {$this->table}
                WHERE deleted_at IS NULL
                GROUP BY role";

        $results = $this->fetchAll($sql);
        $counts = [];

        foreach ($results as $result) {
            $counts[$result['role']] = (int)$result['count'];
        }

        return $counts;
    }

    /**
     * Get total user count
     */
    public function getTotalCount(): int
    {
        $sql = "SELECT COUNT(*) as count FROM {$this->table} WHERE deleted_at IS NULL";
        $result = $this->fetchOne($sql);
        return (int)($result['count'] ?? 0);
    }

    /**
     * Get users with filtering and pagination
     */
    public function getUsers(string $role = 'all', string $status = 'all', string $search = '', int $limit = 20, int $offset = 0): array
    {
        $conditions = ['deleted_at IS NULL'];
        $params = [];

        if ($role !== 'all') {
            $conditions[] = 'role = ?';
            $params[] = $role;
        }

        if ($status !== 'all') {
            $conditions[] = 'status = ?';
            $params[] = $status;
        }

        if (!empty($search)) {
            $conditions[] = '(first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR username LIKE ?)';
            $searchTerm = "%{$search}%";
            $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm, $searchTerm]);
        }

        $whereClause = implode(' AND ', $conditions);
        $params[] = $limit;
        $params[] = $offset;

        $sql = "SELECT * FROM {$this->table}
                WHERE {$whereClause}
                ORDER BY created_at DESC
                LIMIT ? OFFSET ?";

        return $this->fetchAll($sql, $params);
    }

    /**
     * Count users with filtering
     */
    public function countUsers(string $role = 'all', string $status = 'all', string $search = ''): int
    {
        $conditions = ['deleted_at IS NULL'];
        $params = [];

        if ($role !== 'all') {
            $conditions[] = 'role = ?';
            $params[] = $role;
        }

        if ($status !== 'all') {
            $conditions[] = 'status = ?';
            $params[] = $status;
        }

        if (!empty($search)) {
            $conditions[] = '(first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR username LIKE ?)';
            $searchTerm = "%{$search}%";
            $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm, $searchTerm]);
        }

        $whereClause = implode(' AND ', $conditions);

        $sql = "SELECT COUNT(*) as count FROM {$this->table} WHERE {$whereClause}";
        $result = $this->fetchOne($sql, $params);
        return (int)($result['count'] ?? 0);
    }
}
