<?php

namespace Time2Eat\Models;

use Time2Eat\Core\BaseModel;

class Delivery extends BaseModel
{
    protected string $table = 'deliveries';
    protected array $fillable = [
        'order_id', 'rider_id', 'status', 'pickup_time', 'delivery_time',
        'estimated_delivery_time', 'actual_delivery_time', 'pickup_location',
        'delivery_location', 'current_location', 'distance_km', 'delivery_fee',
        'rider_notes', 'customer_rating', 'delivery_proof', 'tracking_code'
    ];

    public function createDelivery(array $deliveryData): ?int
    {
        $deliveryData['tracking_code'] = $this->generateTrackingCode();
        $deliveryData['status'] = 'assigned';
        $deliveryData['created_at'] = date('Y-m-d H:i:s');
        $deliveryData['updated_at'] = date('Y-m-d H:i:s');

        return $this->create($deliveryData);
    }

    public function generateTrackingCode(): string
    {
        $prefix = 'TRK';
        $timestamp = date('ymdHi');
        $random = str_pad(mt_rand(1, 999), 3, '0', STR_PAD_LEFT);
        
        $trackingCode = $prefix . $timestamp . $random;
        
        // Ensure uniqueness
        while ($this->trackingCodeExists($trackingCode)) {
            $random = str_pad(mt_rand(1, 999), 3, '0', STR_PAD_LEFT);
            $trackingCode = $prefix . $timestamp . $random;
        }
        
        return $trackingCode;
    }

    private function trackingCodeExists(string $trackingCode): bool
    {
        $sql = "SELECT COUNT(*) as count FROM {$this->table} WHERE tracking_code = ?";
        $result = $this->db->fetch($sql, [$trackingCode]);
        return $result['count'] > 0;
    }

    public function getDeliveryByOrder(int $orderId): ?array
    {
        $sql = "
            SELECT 
                d.*,
                o.order_number,
                o.customer_id,
                o.restaurant_id,
                o.total_amount,
                r.first_name as rider_first_name,
                r.last_name as rider_last_name,
                r.phone as rider_phone,
                r.profile_image as rider_image,
                c.first_name as customer_first_name,
                c.last_name as customer_last_name,
                c.phone as customer_phone,
                rest.name as restaurant_name,
                rest.address as restaurant_address,
                rest.latitude as restaurant_latitude,
                rest.longitude as restaurant_longitude
            FROM {$this->table} d
            JOIN orders o ON d.order_id = o.id
            LEFT JOIN users r ON d.rider_id = r.id
            JOIN users c ON o.customer_id = c.id
            JOIN restaurants rest ON o.restaurant_id = rest.id
            WHERE d.order_id = ?
        ";

        return $this->db->fetch($sql, [$orderId]);
    }

    public function getDeliveryByTrackingCode(string $trackingCode): ?array
    {
        $sql = "
            SELECT 
                d.*,
                o.order_number,
                o.customer_id,
                o.restaurant_id,
                o.total_amount,
                o.delivery_address,
                r.first_name as rider_first_name,
                r.last_name as rider_last_name,
                r.phone as rider_phone,
                r.profile_image as rider_image,
                c.first_name as customer_first_name,
                c.last_name as customer_last_name,
                c.phone as customer_phone,
                rest.name as restaurant_name,
                rest.address as restaurant_address,
                rest.latitude as restaurant_latitude,
                rest.longitude as restaurant_longitude
            FROM {$this->table} d
            JOIN orders o ON d.order_id = o.id
            LEFT JOIN users r ON d.rider_id = r.id
            JOIN users c ON o.customer_id = c.id
            JOIN restaurants rest ON o.restaurant_id = rest.id
            WHERE d.tracking_code = ?
        ";

        return $this->db->fetch($sql, [$trackingCode]);
    }

    public function updateDeliveryStatus(int $deliveryId, string $status, array $additionalData = []): bool
    {
        $updateData = ['status' => $status, 'updated_at' => date('Y-m-d H:i:s')];
        
        // Set timestamp based on status
        switch ($status) {
            case 'picked_up':
                $updateData['pickup_time'] = date('Y-m-d H:i:s');
                break;
            case 'out_for_delivery':
                // Calculate estimated delivery time (add 30 minutes from pickup)
                $updateData['estimated_delivery_time'] = date('Y-m-d H:i:s', strtotime('+30 minutes'));
                break;
            case 'delivered':
                $updateData['delivery_time'] = date('Y-m-d H:i:s');
                $updateData['actual_delivery_time'] = date('Y-m-d H:i:s');
                break;
            case 'failed':
            case 'cancelled':
                if (isset($additionalData['rider_notes'])) {
                    $updateData['rider_notes'] = $additionalData['rider_notes'];
                }
                break;
        }

        // Merge additional data
        $updateData = array_merge($updateData, $additionalData);

        return $this->update($deliveryId, $updateData);
    }

    public function updateRiderLocation(int $deliveryId, float $latitude, float $longitude): bool
    {
        $locationData = json_encode([
            'latitude' => $latitude,
            'longitude' => $longitude,
            'timestamp' => time()
        ]);

        return $this->update($deliveryId, [
            'current_location' => $locationData,
            'updated_at' => date('Y-m-d H:i:s')
        ]);
    }

    public function getRiderLocation(int $deliveryId): ?array
    {
        $delivery = $this->getById($deliveryId);
        
        if (!$delivery || empty($delivery['current_location'])) {
            return null;
        }

        $location = json_decode($delivery['current_location'], true);
        return is_array($location) ? $location : null;
    }

    public function getActiveDeliveriesByRider(int $riderId): array
    {
        $sql = "
            SELECT 
                d.*,
                o.order_number,
                o.customer_id,
                o.total_amount,
                o.delivery_address,
                c.first_name as customer_first_name,
                c.last_name as customer_last_name,
                c.phone as customer_phone,
                rest.name as restaurant_name,
                rest.address as restaurant_address
            FROM {$this->table} d
            JOIN orders o ON d.order_id = o.id
            JOIN users c ON o.customer_id = c.id
            JOIN restaurants rest ON o.restaurant_id = rest.id
            WHERE d.rider_id = ? AND d.status IN ('assigned', 'picked_up', 'out_for_delivery')
            ORDER BY d.created_at ASC
        ";

        return $this->db->fetchAll($sql, [$riderId]);
    }

    public function getDeliveryHistory(int $riderId, int $limit = 20, int $offset = 0): array
    {
        $sql = "
            SELECT 
                d.*,
                o.order_number,
                o.total_amount,
                rest.name as restaurant_name
            FROM {$this->table} d
            JOIN orders o ON d.order_id = o.id
            JOIN restaurants rest ON o.restaurant_id = rest.id
            WHERE d.rider_id = ? AND d.status IN ('delivered', 'failed', 'cancelled')
            ORDER BY d.updated_at DESC
            LIMIT ? OFFSET ?
        ";

        return $this->db->fetchAll($sql, [$riderId, $limit, $offset]);
    }

    public function calculateDeliveryTime(int $deliveryId): ?int
    {
        $delivery = $this->getById($deliveryId);
        
        if (!$delivery || !$delivery['pickup_time'] || !$delivery['delivery_time']) {
            return null;
        }

        $pickupTime = strtotime($delivery['pickup_time']);
        $deliveryTime = strtotime($delivery['delivery_time']);
        
        return ($deliveryTime - $pickupTime) / 60; // Return minutes
    }

    public function getRiderEarnings(int $riderId, string $period = 'today'): array
    {
        $whereClause = "d.rider_id = ? AND d.status = 'delivered'";
        $params = [$riderId];

        switch ($period) {
            case 'today':
                $whereClause .= " AND DATE(d.delivery_time) = CURDATE()";
                break;
            case 'week':
                $whereClause .= " AND d.delivery_time >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
                break;
            case 'month':
                $whereClause .= " AND MONTH(d.delivery_time) = MONTH(CURDATE()) AND YEAR(d.delivery_time) = YEAR(CURDATE())";
                break;
        }

        $sql = "
            SELECT 
                COUNT(*) as total_deliveries,
                COALESCE(SUM(d.delivery_fee), 0) as total_earnings,
                COALESCE(AVG(d.delivery_fee), 0) as avg_earning_per_delivery,
                COALESCE(AVG(d.customer_rating), 0) as avg_rating
            FROM {$this->table} d
            WHERE {$whereClause}
        ";

        $result = $this->db->fetch($sql, $params);
        
        return [
            'total_deliveries' => (int)($result['total_deliveries'] ?? 0),
            'total_earnings' => (float)($result['total_earnings'] ?? 0),
            'avg_earning_per_delivery' => (float)($result['avg_earning_per_delivery'] ?? 0),
            'avg_rating' => (float)($result['avg_rating'] ?? 0)
        ];
    }

    public function getDeliveryStatistics(): array
    {
        $sql = "
            SELECT 
                COUNT(*) as total_deliveries,
                COUNT(CASE WHEN status = 'assigned' THEN 1 END) as assigned_deliveries,
                COUNT(CASE WHEN status = 'picked_up' THEN 1 END) as picked_up_deliveries,
                COUNT(CASE WHEN status = 'out_for_delivery' THEN 1 END) as out_for_delivery,
                COUNT(CASE WHEN status = 'delivered' THEN 1 END) as delivered_deliveries,
                COUNT(CASE WHEN status = 'failed' THEN 1 END) as failed_deliveries,
                COALESCE(AVG(CASE WHEN status = 'delivered' AND pickup_time IS NOT NULL AND delivery_time IS NOT NULL 
                    THEN TIMESTAMPDIFF(MINUTE, pickup_time, delivery_time) END), 0) as avg_delivery_time_minutes,
                COALESCE(AVG(customer_rating), 0) as avg_customer_rating
            FROM {$this->table}
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        ";

        $result = $this->db->fetch($sql);
        
        return [
            'total_deliveries' => (int)($result['total_deliveries'] ?? 0),
            'assigned_deliveries' => (int)($result['assigned_deliveries'] ?? 0),
            'picked_up_deliveries' => (int)($result['picked_up_deliveries'] ?? 0),
            'out_for_delivery' => (int)($result['out_for_delivery'] ?? 0),
            'delivered_deliveries' => (int)($result['delivered_deliveries'] ?? 0),
            'failed_deliveries' => (int)($result['failed_deliveries'] ?? 0),
            'avg_delivery_time_minutes' => (float)($result['avg_delivery_time_minutes'] ?? 0),
            'avg_customer_rating' => (float)($result['avg_customer_rating'] ?? 0)
        ];
    }

    public function assignDeliveryToRider(int $orderId, int $riderId): ?int
    {
        // Get order details
        $order = $this->db->fetch("SELECT * FROM orders WHERE id = ?", [$orderId]);
        
        if (!$order) {
            return null;
        }

        // Get restaurant location
        $restaurant = $this->db->fetch("SELECT * FROM restaurants WHERE id = ?", [$order['restaurant_id']]);
        
        if (!$restaurant) {
            return null;
        }

        // Parse delivery address
        $deliveryAddress = json_decode($order['delivery_address'], true);
        
        $deliveryData = [
            'order_id' => $orderId,
            'rider_id' => $riderId,
            'pickup_location' => json_encode([
                'latitude' => $restaurant['latitude'],
                'longitude' => $restaurant['longitude'],
                'address' => $restaurant['address']
            ]),
            'delivery_location' => json_encode([
                'latitude' => $deliveryAddress['latitude'] ?? null,
                'longitude' => $deliveryAddress['longitude'] ?? null,
                'address' => $deliveryAddress['address_line_1'] ?? ''
            ]),
            'delivery_fee' => $order['delivery_fee']
        ];

        return $this->createDelivery($deliveryData);
    }

    public function rateDelivery(int $deliveryId, int $rating, string $feedback = ''): bool
    {
        if ($rating < 1 || $rating > 5) {
            return false;
        }

        return $this->update($deliveryId, [
            'customer_rating' => $rating,
            'customer_feedback' => $feedback,
            'updated_at' => date('Y-m-d H:i:s')
        ]);
    }

    /**
     * Get available deliveries nearby for riders
     */
    public function getAvailableDeliveriesNearby(float $latitude, float $longitude, float $radiusKm, int $limit, int $offset): array
    {
        $sql = "SELECT d.*, o.order_number, o.total_amount, o.preparation_time,
                       r.name as restaurant_name, r.address as restaurant_address,
                       r.latitude as pickup_latitude, r.longitude as pickup_longitude,
                       o.delivery_address, o.delivery_latitude, o.delivery_longitude,
                       (6371 * acos(cos(radians(?)) * cos(radians(r.latitude)) *
                        cos(radians(r.longitude) - radians(?)) +
                        sin(radians(?)) * sin(radians(r.latitude)))) AS distance_to_pickup
                FROM {$this->table} d
                JOIN orders o ON d.order_id = o.id
                JOIN restaurants r ON o.restaurant_id = r.id
                WHERE d.status = 'assigned'
                AND d.rider_id IS NULL
                HAVING distance_to_pickup <= ?
                ORDER BY distance_to_pickup ASC, d.created_at ASC
                LIMIT ? OFFSET ?";

        return $this->db->fetchAll($sql, [$latitude, $longitude, $latitude, $radiusKm, $limit, $offset]);
    }

    /**
     * Accept delivery by rider
     */
    public function acceptDelivery(int $deliveryId, int $riderId): bool
    {
        $sql = "UPDATE {$this->table}
                SET rider_id = ?, status = 'accepted', updated_at = ?
                WHERE id = ? AND status = 'assigned' AND rider_id IS NULL";

        return $this->db->execute($sql, [$riderId, date('Y-m-d H:i:s'), $deliveryId]) > 0;
    }

    /**
     * Get delivery with full details
     */
    public function getDeliveryWithDetails(int $deliveryId): ?array
    {
        $sql = "SELECT d.*, o.order_number, o.customer_id, o.restaurant_id, o.total_amount,
                       o.delivery_address, o.delivery_latitude, o.delivery_longitude,
                       r.name as restaurant_name, r.address as restaurant_address,
                       r.latitude as pickup_latitude, r.longitude as pickup_longitude,
                       r.vendor_id as restaurant_vendor_id,
                       c.first_name as customer_first_name, c.last_name as customer_last_name,
                       c.phone as customer_phone,
                       rider.first_name as rider_first_name, rider.last_name as rider_last_name,
                       rider.phone as rider_phone
                FROM {$this->table} d
                JOIN orders o ON d.order_id = o.id
                JOIN restaurants r ON o.restaurant_id = r.id
                JOIN users c ON o.customer_id = c.id
                LEFT JOIN users rider ON d.rider_id = rider.id
                WHERE d.id = ?";

        return $this->db->fetch($sql, [$deliveryId]);
    }

    /**
     * Update delivery
     */
    public function updateDelivery(int $deliveryId, array $data): bool
    {
        $data['updated_at'] = date('Y-m-d H:i:s');

        return $this->update($deliveryId, $data);
    }

    /**
     * Log rider rejection
     */
    public function logRiderRejection(int $deliveryId, int $riderId, string $reason): bool
    {
        // This could be logged to a separate table for analytics
        // For now, we'll just log it
        error_log("Rider $riderId rejected delivery $deliveryId: $reason");
        return true;
    }

    /**
     * Get rider statistics for period
     */
    public function getRiderStats(int $riderId, string $period): array
    {
        $dateCondition = $this->getDateCondition($period);

        $sql = "SELECT
                    COUNT(*) as total_deliveries,
                    COUNT(CASE WHEN status = 'delivered' THEN 1 END) as completed_deliveries,
                    COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled_deliveries,
                    AVG(CASE WHEN status = 'delivered' AND pickup_time IS NOT NULL AND delivery_time IS NOT NULL
                        THEN TIMESTAMPDIFF(MINUTE, pickup_time, delivery_time) END) as avg_delivery_time,
                    AVG(CASE WHEN status = 'delivered' THEN customer_rating END) as avg_rating,
                    SUM(distance_km) as total_distance
                FROM {$this->table}
                WHERE rider_id = ? $dateCondition";

        return $this->db->fetch($sql, [$riderId]) ?: [];
    }

    /**
     * Get delivery by ID
     */
    public function getById(int $id): ?array
    {
        $sql = "SELECT * FROM {$this->table} WHERE id = ?";
        return $this->db->fetch($sql, [$id]);
    }

    /**
     * Get date condition for queries
     */
    private function getDateCondition(string $period): string
    {
        switch ($period) {
            case 'today':
                return "AND DATE(created_at) = CURDATE()";
            case 'week':
                return "AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
            case 'month':
                return "AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
            case '30days':
                return "AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
            default:
                return "";
        }
    }
}
