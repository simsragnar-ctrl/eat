<?php

namespace Time2Eat\Models;

use Time2Eat\Core\Model;

class Review extends Model
{
    protected string $table = 'reviews';
    protected array $fillable = [
        'user_id', 'order_id', 'reviewable_type', 'reviewable_id', 
        'rating', 'comment', 'is_verified', 'is_featured'
    ];

    /**
     * Get reviews for a specific entity
     */
    public function getReviewsByEntity(string $type, int $id, int $page = 1, int $limit = 10): array
    {
        $offset = ($page - 1) * $limit;
        
        $sql = "
            SELECT r.*, 
                   u.first_name, u.last_name, u.avatar,
                   o.order_number,
                   (SELECT COUNT(*) FROM review_helpful rh WHERE rh.review_id = r.id) as helpful_count,
                   (SELECT COUNT(*) FROM review_reports rr WHERE rr.review_id = r.id) as report_count
            FROM {$this->table} r
            INNER JOIN users u ON r.user_id = u.id
            LEFT JOIN orders o ON r.order_id = o.id
            WHERE r.reviewable_type = :type 
              AND r.reviewable_id = :id 
              AND r.is_approved = 1
            ORDER BY r.is_featured DESC, r.created_at DESC
            LIMIT :limit OFFSET :offset
        ";

        return $this->db->query($sql, [
            'type' => $type,
            'id' => $id,
            'limit' => $limit,
            'offset' => $offset
        ])->fetchAll();
    }

    /**
     * Get review statistics for an entity
     */
    public function getReviewStats(string $type, int $id): array
    {
        $sql = "
            SELECT 
                COUNT(*) as total_reviews,
                AVG(rating) as average_rating,
                SUM(CASE WHEN rating = 5 THEN 1 ELSE 0 END) as five_star,
                SUM(CASE WHEN rating = 4 THEN 1 ELSE 0 END) as four_star,
                SUM(CASE WHEN rating = 3 THEN 1 ELSE 0 END) as three_star,
                SUM(CASE WHEN rating = 2 THEN 1 ELSE 0 END) as two_star,
                SUM(CASE WHEN rating = 1 THEN 1 ELSE 0 END) as one_star
            FROM {$this->table}
            WHERE reviewable_type = :type 
              AND reviewable_id = :id 
              AND is_approved = 1
        ";

        $stats = $this->db->query($sql, ['type' => $type, 'id' => $id])->fetch();
        
        if (!$stats || $stats['total_reviews'] == 0) {
            return [
                'total_reviews' => 0,
                'average_rating' => 0,
                'rating_distribution' => [5 => 0, 4 => 0, 3 => 0, 2 => 0, 1 => 0],
                'rating_percentages' => [5 => 0, 4 => 0, 3 => 0, 2 => 0, 1 => 0]
            ];
        }

        $total = (int)$stats['total_reviews'];
        $distribution = [
            5 => (int)$stats['five_star'],
            4 => (int)$stats['four_star'],
            3 => (int)$stats['three_star'],
            2 => (int)$stats['two_star'],
            1 => (int)$stats['one_star']
        ];

        $percentages = [];
        foreach ($distribution as $rating => $count) {
            $percentages[$rating] = $total > 0 ? round(($count / $total) * 100, 1) : 0;
        }

        return [
            'total_reviews' => $total,
            'average_rating' => round((float)$stats['average_rating'], 1),
            'rating_distribution' => $distribution,
            'rating_percentages' => $percentages
        ];
    }

    /**
     * Get review for a specific order
     */
    public function getOrderReview(int $orderId): ?array
    {
        $sql = "
            SELECT * FROM {$this->table}
            WHERE order_id = :order_id
            LIMIT 1
        ";

        $result = $this->db->query($sql, ['order_id' => $orderId])->fetch();
        return $result ?: null;
    }

    /**
     * Get reviews by user
     */
    public function getReviewsByUser(int $userId, int $page = 1, int $limit = 10): array
    {
        $offset = ($page - 1) * $limit;
        
        $sql = "
            SELECT r.*, 
                   CASE 
                       WHEN r.reviewable_type = 'restaurant' THEN rest.name
                       WHEN r.reviewable_type = 'menu_item' THEN mi.name
                       WHEN r.reviewable_type = 'rider' THEN CONCAT(u.first_name, ' ', u.last_name)
                   END as reviewable_name,
                   o.order_number
            FROM {$this->table} r
            LEFT JOIN restaurants rest ON r.reviewable_type = 'restaurant' AND r.reviewable_id = rest.id
            LEFT JOIN menu_items mi ON r.reviewable_type = 'menu_item' AND r.reviewable_id = mi.id
            LEFT JOIN users u ON r.reviewable_type = 'rider' AND r.reviewable_id = u.id
            LEFT JOIN orders o ON r.order_id = o.id
            WHERE r.user_id = :user_id
            ORDER BY r.created_at DESC
            LIMIT :limit OFFSET :offset
        ";

        return $this->db->query($sql, [
            'user_id' => $userId,
            'limit' => $limit,
            'offset' => $offset
        ])->fetchAll();
    }

    /**
     * Get featured reviews
     */
    public function getFeaturedReviews(int $limit = 6): array
    {
        $sql = "
            SELECT r.*, 
                   u.first_name, u.last_name, u.avatar,
                   CASE 
                       WHEN r.reviewable_type = 'restaurant' THEN rest.name
                       WHEN r.reviewable_type = 'menu_item' THEN mi.name
                   END as reviewable_name,
                   CASE 
                       WHEN r.reviewable_type = 'restaurant' THEN rest.slug
                       WHEN r.reviewable_type = 'menu_item' THEN rest2.slug
                   END as reviewable_slug
            FROM {$this->table} r
            INNER JOIN users u ON r.user_id = u.id
            LEFT JOIN restaurants rest ON r.reviewable_type = 'restaurant' AND r.reviewable_id = rest.id
            LEFT JOIN menu_items mi ON r.reviewable_type = 'menu_item' AND r.reviewable_id = mi.id
            LEFT JOIN restaurants rest2 ON r.reviewable_type = 'menu_item' AND mi.restaurant_id = rest2.id
            WHERE r.is_featured = 1 
              AND r.is_approved = 1 
              AND r.rating >= 4
            ORDER BY r.created_at DESC
            LIMIT :limit
        ";

        return $this->db->query($sql, ['limit' => $limit])->fetchAll();
    }

    /**
     * Get recent reviews for admin dashboard
     */
    public function getRecentReviews(int $limit = 10): array
    {
        $sql = "
            SELECT r.*, 
                   u.first_name, u.last_name,
                   CASE 
                       WHEN r.reviewable_type = 'restaurant' THEN rest.name
                       WHEN r.reviewable_type = 'menu_item' THEN mi.name
                       WHEN r.reviewable_type = 'rider' THEN CONCAT(rider.first_name, ' ', rider.last_name)
                   END as reviewable_name
            FROM {$this->table} r
            INNER JOIN users u ON r.user_id = u.id
            LEFT JOIN restaurants rest ON r.reviewable_type = 'restaurant' AND r.reviewable_id = rest.id
            LEFT JOIN menu_items mi ON r.reviewable_type = 'menu_item' AND r.reviewable_id = mi.id
            LEFT JOIN users rider ON r.reviewable_type = 'rider' AND r.reviewable_id = rider.id
            ORDER BY r.created_at DESC
            LIMIT :limit
        ";

        return $this->db->query($sql, ['limit' => $limit])->fetchAll();
    }

    /**
     * Get reviews pending approval
     */
    public function getPendingReviews(int $page = 1, int $limit = 20): array
    {
        $offset = ($page - 1) * $limit;
        
        $sql = "
            SELECT r.*, 
                   u.first_name, u.last_name,
                   CASE 
                       WHEN r.reviewable_type = 'restaurant' THEN rest.name
                       WHEN r.reviewable_type = 'menu_item' THEN mi.name
                       WHEN r.reviewable_type = 'rider' THEN CONCAT(rider.first_name, ' ', rider.last_name)
                   END as reviewable_name
            FROM {$this->table} r
            INNER JOIN users u ON r.user_id = u.id
            LEFT JOIN restaurants rest ON r.reviewable_type = 'restaurant' AND r.reviewable_id = rest.id
            LEFT JOIN menu_items mi ON r.reviewable_type = 'menu_item' AND r.reviewable_id = mi.id
            LEFT JOIN users rider ON r.reviewable_type = 'rider' AND r.reviewable_id = rider.id
            WHERE r.is_approved = 0
            ORDER BY r.created_at ASC
            LIMIT :limit OFFSET :offset
        ";

        return $this->db->query($sql, [
            'limit' => $limit,
            'offset' => $offset
        ])->fetchAll();
    }

    /**
     * Toggle helpful status for a review
     */
    public function toggleHelpful(int $reviewId, int $userId): bool
    {
        // Check if user already marked as helpful
        $existingSql = "
            SELECT id FROM review_helpful 
            WHERE review_id = :review_id AND user_id = :user_id
        ";
        
        $existing = $this->db->query($existingSql, [
            'review_id' => $reviewId,
            'user_id' => $userId
        ])->fetch();

        if ($existing) {
            // Remove helpful mark
            $deleteSql = "
                DELETE FROM review_helpful 
                WHERE review_id = :review_id AND user_id = :user_id
            ";
            $this->db->query($deleteSql, [
                'review_id' => $reviewId,
                'user_id' => $userId
            ]);
        } else {
            // Add helpful mark
            $insertSql = "
                INSERT INTO review_helpful (review_id, user_id, created_at)
                VALUES (:review_id, :user_id, NOW())
            ";
            $this->db->query($insertSql, [
                'review_id' => $reviewId,
                'user_id' => $userId
            ]);
        }

        return true;
    }

    /**
     * Get helpful count for a review
     */
    public function getHelpfulCount(int $reviewId): int
    {
        $sql = "
            SELECT COUNT(*) as count 
            FROM review_helpful 
            WHERE review_id = :review_id
        ";

        $result = $this->db->query($sql, ['review_id' => $reviewId])->fetch();
        return (int)($result['count'] ?? 0);
    }

    /**
     * Report a review
     */
    public function reportReview(int $reviewId, int $userId, string $reason): bool
    {
        // Check if user already reported this review
        $existingSql = "
            SELECT id FROM review_reports 
            WHERE review_id = :review_id AND user_id = :user_id
        ";
        
        $existing = $this->db->query($existingSql, [
            'review_id' => $reviewId,
            'user_id' => $userId
        ])->fetch();

        if ($existing) {
            return false; // Already reported
        }

        $insertSql = "
            INSERT INTO review_reports (review_id, user_id, reason, created_at)
            VALUES (:review_id, :user_id, :reason, NOW())
        ";
        
        $this->db->query($insertSql, [
            'review_id' => $reviewId,
            'user_id' => $userId,
            'reason' => $reason
        ]);

        return true;
    }

    /**
     * Approve review
     */
    public function approve(int $id): bool
    {
        return $this->update($id, [
            'is_approved' => 1,
            'approved_at' => date('Y-m-d H:i:s')
        ]);
    }

    /**
     * Reject review
     */
    public function reject(int $id, string $reason = ''): bool
    {
        return $this->update($id, [
            'is_approved' => 0,
            'rejection_reason' => $reason,
            'rejected_at' => date('Y-m-d H:i:s')
        ]);
    }

    /**
     * Feature review
     */
    public function feature(int $id): bool
    {
        return $this->update($id, ['is_featured' => 1]);
    }

    /**
     * Unfeature review
     */
    public function unfeature(int $id): bool
    {
        return $this->update($id, ['is_featured' => 0]);
    }

    /**
     * Get review analytics
     */
    public function getAnalytics(array $filters = []): array
    {
        $whereClause = "WHERE 1=1";
        $params = [];

        if (!empty($filters['date_from'])) {
            $whereClause .= " AND DATE(r.created_at) >= :date_from";
            $params['date_from'] = $filters['date_from'];
        }

        if (!empty($filters['date_to'])) {
            $whereClause .= " AND DATE(r.created_at) <= :date_to";
            $params['date_to'] = $filters['date_to'];
        }

        if (!empty($filters['type'])) {
            $whereClause .= " AND r.reviewable_type = :type";
            $params['type'] = $filters['type'];
        }

        $sql = "
            SELECT 
                COUNT(*) as total_reviews,
                AVG(rating) as average_rating,
                COUNT(CASE WHEN rating = 5 THEN 1 END) as five_star_count,
                COUNT(CASE WHEN rating = 4 THEN 1 END) as four_star_count,
                COUNT(CASE WHEN rating = 3 THEN 1 END) as three_star_count,
                COUNT(CASE WHEN rating = 2 THEN 1 END) as two_star_count,
                COUNT(CASE WHEN rating = 1 THEN 1 END) as one_star_count,
                COUNT(CASE WHEN is_verified = 1 THEN 1 END) as verified_reviews,
                COUNT(CASE WHEN is_featured = 1 THEN 1 END) as featured_reviews
            FROM {$this->table} r
            {$whereClause}
        ";

        return $this->db->query($sql, $params)->fetch() ?: [];
    }

    /**
     * Get top rated entities
     */
    public function getTopRated(string $type, int $limit = 10): array
    {
        $sql = "
            SELECT 
                r.reviewable_id,
                AVG(r.rating) as average_rating,
                COUNT(r.id) as review_count,
                CASE 
                    WHEN r.reviewable_type = 'restaurant' THEN rest.name
                    WHEN r.reviewable_type = 'menu_item' THEN mi.name
                END as name
            FROM {$this->table} r
            LEFT JOIN restaurants rest ON r.reviewable_type = 'restaurant' AND r.reviewable_id = rest.id
            LEFT JOIN menu_items mi ON r.reviewable_type = 'menu_item' AND r.reviewable_id = mi.id
            WHERE r.reviewable_type = :type 
              AND r.is_approved = 1
            GROUP BY r.reviewable_id
            HAVING COUNT(r.id) >= 3
            ORDER BY average_rating DESC, review_count DESC
            LIMIT :limit
        ";

        return $this->db->query($sql, [
            'type' => $type,
            'limit' => $limit
        ])->fetchAll();
    }
}
