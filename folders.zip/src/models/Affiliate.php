<?php

namespace Time2Eat\Models;

use Time2Eat\Core\Model;
use Time2Eat\Traits\DatabaseTrait;
use Time2Eat\Traits\ValidationTrait;

class Affiliate extends Model
{
    use DatabaseTrait, ValidationTrait;

    protected string $table = 'affiliates';
    protected array $fillable = [
        'user_id', 'referral_code', 'commission_rate', 'total_earnings', 
        'available_balance', 'total_withdrawals', 'total_referrals',
        'status', 'joined_at'
    ];

    public function createAffiliate(array $data): ?int
    {
        $validation = $this->validateAffiliateData($data);
        if (!$validation['isValid']) {
            $this->setErrors($validation['errors']);
            return null;
        }

        $affiliateData = [
            'user_id' => $data['user_id'],
            'referral_code' => $this->generateUniqueReferralCode(),
            'commission_rate' => $data['commission_rate'] ?? $this->getDefaultCommissionRate(),
            'total_earnings' => 0,
            'available_balance' => 0,
            'total_withdrawals' => 0,
            'total_referrals' => 0,
            'status' => 'active',
            'joined_at' => date('Y-m-d H:i:s'),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        return $this->create($affiliateData);
    }

    public function generateUniqueReferralCode(): string
    {
        do {
            $code = 'REF' . strtoupper(substr(uniqid(), -8));
            $exists = $this->findByColumn('referral_code', $code);
        } while ($exists);

        return $code;
    }

    public function getAffiliateByUserId(int $userId): ?array
    {
        return $this->findByColumn('user_id', $userId);
    }

    public function getAffiliateByReferralCode(string $referralCode): ?array
    {
        return $this->findByColumn('referral_code', $referralCode);
    }

    public function addEarning(int $affiliateId, float $amount, int $orderId, string $type = 'referral'): bool
    {
        $this->beginTransaction();

        try {
            // Update affiliate balance
            $sql = "UPDATE {$this->table} SET 
                    total_earnings = total_earnings + ?, 
                    available_balance = available_balance + ?,
                    updated_at = NOW()
                    WHERE id = ?";
            
            $this->execute($sql, [$amount, $amount, $affiliateId]);

            // Record the earning
            $earningData = [
                'affiliate_id' => $affiliateId,
                'order_id' => $orderId,
                'amount' => $amount,
                'type' => $type,
                'status' => 'confirmed',
                'earned_at' => date('Y-m-d H:i:s'),
                'created_at' => date('Y-m-d H:i:s')
            ];

            $earningModel = new AffiliateEarning();
            $earningModel->create($earningData);

            $this->commit();
            return true;
        } catch (\Exception $e) {
            $this->rollback();
            $this->setError('Failed to add earning: ' . $e->getMessage());
            return false;
        }
    }

    public function processWithdrawal(int $affiliateId, float $amount, array $withdrawalData): ?int
    {
        $affiliate = $this->getById($affiliateId);
        if (!$affiliate) {
            $this->setError('Affiliate not found');
            return null;
        }

        // Check minimum withdrawal threshold (10,000 XAF)
        $minWithdrawal = 10000;
        if ($amount < $minWithdrawal) {
            $this->setError("Minimum withdrawal amount is {$minWithdrawal} XAF");
            return null;
        }

        // Check available balance
        if ($affiliate['available_balance'] < $amount) {
            $this->setError('Insufficient balance');
            return null;
        }

        $this->beginTransaction();

        try {
            // Update affiliate balance
            $sql = "UPDATE {$this->table} SET 
                    available_balance = available_balance - ?,
                    total_withdrawals = total_withdrawals + ?,
                    updated_at = NOW()
                    WHERE id = ?";
            
            $this->execute($sql, [$amount, $amount, $affiliateId]);

            // Create withdrawal request
            $withdrawalRequestData = [
                'affiliate_id' => $affiliateId,
                'amount' => $amount,
                'payment_method' => $withdrawalData['payment_method'],
                'payment_details' => json_encode($withdrawalData['payment_details']),
                'status' => 'pending',
                'requested_at' => date('Y-m-d H:i:s'),
                'created_at' => date('Y-m-d H:i:s')
            ];

            $withdrawalModel = new AffiliateWithdrawal();
            $withdrawalId = $withdrawalModel->create($withdrawalRequestData);

            $this->commit();
            return $withdrawalId;
        } catch (\Exception $e) {
            $this->rollback();
            $this->setError('Failed to process withdrawal: ' . $e->getMessage());
            return null;
        }
    }

    public function getAffiliateStats(int $affiliateId): array
    {
        $affiliate = $this->getById($affiliateId);
        if (!$affiliate) {
            return [];
        }

        // Get referral count
        $userModel = new User();
        $referralCount = $userModel->countByColumn('referred_by', $affiliate['referral_code']);

        // Get earnings this month
        $earningModel = new AffiliateEarning();
        $monthlyEarnings = $earningModel->getMonthlyEarnings($affiliateId);

        // Get pending withdrawals
        $withdrawalModel = new AffiliateWithdrawal();
        $pendingWithdrawals = $withdrawalModel->getPendingWithdrawals($affiliateId);

        return [
            'total_earnings' => $affiliate['total_earnings'],
            'available_balance' => $affiliate['available_balance'],
            'total_withdrawals' => $affiliate['total_withdrawals'],
            'total_referrals' => $referralCount,
            'monthly_earnings' => $monthlyEarnings,
            'pending_withdrawals' => $pendingWithdrawals,
            'commission_rate' => $affiliate['commission_rate'],
            'referral_code' => $affiliate['referral_code']
        ];
    }

    public function getTopAffiliates(int $limit = 10): array
    {
        $sql = "SELECT a.*, u.first_name, u.last_name, u.email, u.phone
                FROM {$this->table} a
                JOIN users u ON a.user_id = u.id
                WHERE a.status = 'active'
                ORDER BY a.total_earnings DESC
                LIMIT ?";
        
        return $this->fetchAll($sql, [$limit]);
    }

    public function updateCommissionRate(int $affiliateId, float $rate): bool
    {
        if ($rate < 0 || $rate > 100) {
            $this->setError('Commission rate must be between 0 and 100');
            return false;
        }

        return $this->update($affiliateId, [
            'commission_rate' => $rate,
            'updated_at' => date('Y-m-d H:i:s')
        ]);
    }

    public function getAffiliateEarnings(int $affiliateId, int $page = 1, int $limit = 20): array
    {
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT ae.*, o.order_number, u.first_name, u.last_name
                FROM affiliate_earnings ae
                LEFT JOIN orders o ON ae.order_id = o.id
                LEFT JOIN users u ON o.customer_id = u.id
                WHERE ae.affiliate_id = ?
                ORDER BY ae.earned_at DESC
                LIMIT ? OFFSET ?";
        
        $earnings = $this->fetchAll($sql, [$affiliateId, $limit, $offset]);
        
        // Get total count
        $countSql = "SELECT COUNT(*) as total FROM affiliate_earnings WHERE affiliate_id = ?";
        $totalResult = $this->fetchOne($countSql, [$affiliateId]);
        $total = $totalResult['total'] ?? 0;
        
        return [
            'earnings' => $earnings,
            'total' => $total,
            'page' => $page,
            'limit' => $limit,
            'pages' => ceil($total / $limit)
        ];
    }

    public function getAffiliateWithdrawals(int $affiliateId, int $page = 1, int $limit = 20): array
    {
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT * FROM affiliate_withdrawals 
                WHERE affiliate_id = ?
                ORDER BY requested_at DESC
                LIMIT ? OFFSET ?";
        
        $withdrawals = $this->fetchAll($sql, [$affiliateId, $limit, $offset]);
        
        // Get total count
        $countSql = "SELECT COUNT(*) as total FROM affiliate_withdrawals WHERE affiliate_id = ?";
        $totalResult = $this->fetchOne($countSql, [$affiliateId]);
        $total = $totalResult['total'] ?? 0;
        
        return [
            'withdrawals' => $withdrawals,
            'total' => $total,
            'page' => $page,
            'limit' => $limit,
            'pages' => ceil($total / $limit)
        ];
    }

    private function getDefaultCommissionRate(): float
    {
        // Get from settings or return default
        return 5.0; // 5% default commission
    }

    private function validateAffiliateData(array $data): array
    {
        $rules = [
            'user_id' => 'required|integer',
            'commission_rate' => 'numeric|min:0|max:100'
        ];

        return $this->validate($data, $rules);
    }
}
