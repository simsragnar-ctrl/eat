<?php
/**
 * Enhanced Home Page with Mobile-First Design
 * Features: Featured Restaurants Carousel, How It Works, Testimonials, Popular Dishes
 */

// Helper function for safe output
function e($string) {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}
?>

<!DOCTYPE html>
<html lang="en" class="tw-scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?= e($description) ?>">
    <title><?= e($title) ?></title>
    
    <!-- Preload critical resources -->
    <link rel="preload" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" as="style">
    <link rel="preload" href="https://unpkg.com/feather-icons" as="script">
    
    <!-- Stylesheets -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="/public/css/app.css" rel="stylesheet">
    
    <!-- PWA Meta Tags -->
    <meta name="theme-color" content="#dc2626">
    <link rel="manifest" href="/manifest.json">
    <link rel="apple-touch-icon" href="/public/images/icons/icon-192x192.png">
    
    <!-- Structured Data -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "FoodEstablishment",
        "name": "Time2Eat",
        "description": "Food delivery service in Bamenda, Cameroon",
        "url": "<?= $_SERVER['HTTP_HOST'] ?>",
        "telephone": "+237-xxx-xxx-xxx",
        "address": {
            "@type": "PostalAddress",
            "addressLocality": "Bamenda",
            "addressCountry": "CM"
        }
    }
    </script>
</head>

<body class="tw-font-sans tw-antialiased tw-bg-gray-50">
    <!-- Skip to main content -->
    <a href="#main-content" class="tw-sr-only focus:tw-not-sr-only focus:tw-absolute focus:tw-top-4 focus:tw-left-4 tw-bg-primary-600 tw-text-white tw-px-4 tw-py-2 tw-rounded tw-z-50">
        Skip to main content
    </a>

    <!-- Navigation -->
    <?php include __DIR__ . '/../partials/header.php'; ?>

    <!-- Main Content -->
    <main id="main-content" role="main">
        <!-- Hero Section -->
        <section class="tw-relative tw-min-h-screen tw-flex tw-items-center tw-justify-center tw-overflow-hidden" role="banner" aria-label="Hero section">
            <!-- Background with lazy loading -->
            <div class="tw-absolute tw-inset-0 tw-z-0">
                <img
                    src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1200 800'%3E%3Crect fill='%23dc2626' width='1200' height='800'/%3E%3C/svg%3E"
                    data-src="/public/images/hero.webp"
                    alt="Delicious Cameroonian food delivery"
                    class="tw-w-full tw-h-full tw-object-cover lazy-load"
                    loading="lazy"
                >
                <div class="tw-absolute tw-inset-0 tw-bg-gradient-to-br tw-from-black/60 tw-to-black/40"></div>
            </div>

            <!-- Hero Content -->
            <header class="tw-relative tw-z-20 tw-container tw-mx-auto tw-px-4 tw-text-center">
                <div class="tw-max-w-4xl tw-mx-auto">
                    <h1 class="tw-text-4xl md:tw-text-6xl lg:tw-text-7xl tw-font-bold tw-text-white tw-mb-6 tw-animate-fade-in">
                        <span class="tw-bg-gradient-to-r tw-from-red-400 tw-to-orange-400 tw-bg-clip-text tw-text-transparent">
                            Time2Eat
                        </span>
                        <br>
                        <span class="tw-text-2xl md:tw-text-4xl lg:tw-text-5xl">
                            Bamenda's #1 Food Delivery
                        </span>
                    </h1>

                    <p class="tw-text-lg md:tw-text-xl tw-text-gray-200 tw-mb-8 tw-animate-slide-up tw-max-w-2xl tw-mx-auto" style="animation-delay: 0.3s;">
                        Order from your favorite local restaurants with real-time tracking and fast delivery
                    </p>

                    <!-- CTA Buttons -->
                    <nav class="tw-flex tw-flex-col sm:tw-flex-row tw-gap-4 tw-justify-center tw-animate-slide-up tw-mb-12" style="animation-delay: 0.6s;">
                        <a href="/browse" class="tw-btn-primary tw-text-lg tw-px-8 tw-py-4 tw-min-h-[56px] tw-flex tw-items-center tw-justify-center">
                            <i data-feather="utensils" class="tw-w-5 tw-h-5 tw-mr-2"></i>
                            Browse Restaurants
                        </a>
                        <a href="/register" class="tw-btn-outline tw-text-lg tw-px-8 tw-py-4 tw-bg-white/10 tw-backdrop-blur-sm tw-border-white/30 tw-text-white hover:tw-bg-white hover:tw-text-gray-800 tw-min-h-[56px] tw-flex tw-items-center tw-justify-center">
                            <i data-feather="user-plus" class="tw-w-5 tw-h-5 tw-mr-2"></i>
                            Join Time2Eat
                        </a>
                    </nav>
                </div>
            </header>

            <!-- Platform Statistics -->
            <aside class="tw-absolute tw-bottom-8 tw-left-1/2 tw-transform -tw-translate-x-1/2 tw-z-20 tw-w-full tw-max-w-4xl tw-px-4">
                <div class="tw-grid tw-grid-cols-2 md:tw-grid-cols-4 tw-gap-4">
                    <div class="tw-glass-card tw-p-4 tw-text-center tw-animate-slide-up" style="animation-delay: 0.9s;">
                        <div class="tw-text-2xl md:tw-text-3xl tw-font-bold tw-text-white tw-mb-1">
                            <?= number_format($stats['restaurants'] ?? 50) ?>+
                        </div>
                        <div class="tw-text-sm tw-text-gray-300">Restaurants</div>
                    </div>
                    <div class="tw-glass-card tw-p-4 tw-text-center tw-animate-slide-up" style="animation-delay: 1.1s;">
                        <div class="tw-text-2xl md:tw-text-3xl tw-font-bold tw-text-white tw-mb-1">
                            <?= number_format($stats['orders'] ?? 1000) ?>+
                        </div>
                        <div class="tw-text-sm tw-text-gray-300">Orders</div>
                    </div>
                    <div class="tw-glass-card tw-p-4 tw-text-center tw-animate-slide-up" style="animation-delay: 1.3s;">
                        <div class="tw-text-2xl md:tw-text-3xl tw-font-bold tw-text-white tw-mb-1">
                            <?= number_format($stats['customers'] ?? 500) ?>+
                        </div>
                        <div class="tw-text-sm tw-text-gray-300">Customers</div>
                    </div>
                    <div class="tw-glass-card tw-p-4 tw-text-center tw-animate-slide-up" style="animation-delay: 1.5s;">
                        <div class="tw-text-2xl md:tw-text-3xl tw-font-bold tw-text-white tw-mb-1">
                            25min
                        </div>
                        <div class="tw-text-sm tw-text-gray-300">Avg Delivery</div>
                    </div>
                </div>
            </aside>
        </section>

        <!-- How It Works Section -->
        <section class="tw-py-16 lg:tw-py-20 tw-bg-gradient-to-br tw-from-orange-50 tw-to-red-50" aria-labelledby="how-it-works-heading">
            <div class="tw-container tw-mx-auto tw-px-4">
                <header class="tw-text-center tw-mb-12 lg:tw-mb-16">
                    <h2 id="how-it-works-heading" class="tw-text-3xl md:tw-text-4xl tw-font-bold tw-text-gray-800 tw-mb-4">
                        How It Works
                    </h2>
                    <p class="tw-text-lg md:tw-text-xl tw-text-gray-600 tw-max-w-2xl tw-mx-auto">
                        Getting your favorite food delivered is easier than ever
                    </p>
                </header>

                <div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-3 tw-gap-8 lg:tw-gap-12 tw-max-w-6xl tw-mx-auto">
                    <?php foreach ($how_it_works_steps as $step): ?>
                    <article class="tw-text-center tw-group">
                        <div class="tw-relative tw-mb-6">
                            <!-- Step Circle -->
                            <div class="tw-w-20 tw-h-20 md:tw-w-24 md:tw-h-24 <?= $step['color'] ?> tw-rounded-full tw-flex tw-items-center tw-justify-center tw-mx-auto tw-shadow-lg tw-transition-transform tw-duration-300 group-hover:tw-scale-110">
                                <i data-feather="<?= $step['icon'] ?>" class="tw-w-8 tw-h-8 md:tw-w-10 md:tw-h-10 tw-text-white"></i>
                            </div>
                            <!-- Step Number -->
                            <div class="tw-absolute -tw-top-2 -tw-right-2 tw-w-8 tw-h-8 tw-bg-white tw-rounded-full tw-flex tw-items-center tw-justify-center tw-shadow-lg tw-border-2 tw-border-gray-200">
                                <span class="tw-text-sm tw-font-bold tw-text-gray-800"><?= $step['step'] ?></span>
                            </div>
                        </div>
                        <h3 class="tw-text-xl md:tw-text-2xl tw-font-bold tw-text-gray-800 tw-mb-4"><?= e($step['title']) ?></h3>
                        <p class="tw-text-gray-600 tw-leading-relaxed"><?= e($step['description']) ?></p>
                    </article>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <!-- Featured Restaurants Section -->
        <section class="tw-py-16 lg:tw-py-20 tw-bg-white" aria-labelledby="featured-heading">
            <div class="tw-container tw-mx-auto tw-px-4">
                <header class="tw-text-center tw-mb-12 lg:tw-mb-16">
                    <h2 id="featured-heading" class="tw-text-3xl md:tw-text-4xl tw-font-bold tw-text-gray-800 tw-mb-4">
                        Featured Restaurants
                    </h2>
                    <p class="tw-text-lg md:tw-text-xl tw-text-gray-600 tw-max-w-2xl tw-mx-auto">
                        Top-rated restaurants in Bamenda delivering authentic flavors to your doorstep
                    </p>
                </header>

                <!-- Mobile Carousel Container -->
                <div class="tw-relative tw-overflow-hidden">
                    <!-- Carousel Navigation Buttons -->
                    <button id="prev-restaurant" class="tw-absolute tw-left-2 tw-top-1/2 tw-transform -tw-translate-y-1/2 tw-z-10 tw-bg-white tw-rounded-full tw-p-3 tw-shadow-lg tw-transition-all tw-duration-200 hover:tw-bg-gray-50 md:tw-hidden" aria-label="Previous restaurants">
                        <i data-feather="chevron-left" class="tw-w-5 tw-h-5 tw-text-gray-600"></i>
                    </button>
                    <button id="next-restaurant" class="tw-absolute tw-right-2 tw-top-1/2 tw-transform -tw-translate-y-1/2 tw-z-10 tw-bg-white tw-rounded-full tw-p-3 tw-shadow-lg tw-transition-all tw-duration-200 hover:tw-bg-gray-50 md:tw-hidden" aria-label="Next restaurants">
                        <i data-feather="chevron-right" class="tw-w-5 tw-h-5 tw-text-gray-600"></i>
                    </button>

                    <!-- Carousel Wrapper -->
                    <div id="featured-carousel" class="tw-flex tw-transition-transform tw-duration-300 tw-ease-in-out md:tw-grid md:tw-grid-cols-2 lg:tw-grid-cols-3 xl:tw-grid-cols-4 md:tw-gap-6 lg:tw-gap-8" role="list">
                        <?php
                        // Default featured restaurants if none from database
                        $default_restaurants = [
                            [
                                'id' => 1,
                                'name' => 'Mama\'s Kitchen',
                                'description' => 'Authentic Cameroonian dishes made with love',
                                'rating' => 4.8,
                                'delivery_time' => '25-35',
                                'image' => 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=400&h=300&fit=crop',
                                'cuisine_type' => 'Cameroonian',
                                'is_open' => true,
                                'total_reviews' => 156,
                                'delivery_fee' => 500
                            ],
                            [
                                'id' => 2,
                                'name' => 'Spice Garden',
                                'description' => 'Fresh ingredients, bold flavors, fast delivery',
                                'rating' => 4.6,
                                'delivery_time' => '20-30',
                                'image' => 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=400&h=300&fit=crop',
                                'cuisine_type' => 'Continental',
                                'is_open' => true,
                                'total_reviews' => 89,
                                'delivery_fee' => 750
                            ],
                            [
                                'id' => 3,
                                'name' => 'Bamenda Bites',
                                'description' => 'Local favorites and international cuisine',
                                'rating' => 4.7,
                                'delivery_time' => '30-40',
                                'image' => 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=400&h=300&fit=crop',
                                'cuisine_type' => 'Mixed',
                                'is_open' => false,
                                'total_reviews' => 234,
                                'delivery_fee' => 600
                            ],
                            [
                                'id' => 4,
                                'name' => 'Urban Fusion',
                                'description' => 'Modern fusion cuisine with local ingredients',
                                'rating' => 4.9,
                                'delivery_time' => '25-35',
                                'image' => 'https://images.unsplash.com/photo-1552566626-52f8b828add9?w=400&h=300&fit=crop',
                                'cuisine_type' => 'Fusion',
                                'is_open' => true,
                                'total_reviews' => 112,
                                'delivery_fee' => 800
                            ]
                        ];
                        
                        $restaurants_to_show = !empty($featured_restaurants) ? $featured_restaurants : $default_restaurants;
                        ?>
                        <?php foreach ($restaurants_to_show as $index => $restaurant): ?>
                        <article class="tw-flex-shrink-0 tw-w-80 tw-mr-6 md:tw-mr-0 md:tw-w-auto tw-group" role="listitem">
                            <div class="tw-card tw-overflow-hidden tw-transition-all tw-duration-300 group-hover:tw-scale-105 group-hover:tw-shadow-2xl tw-border-2 tw-border-transparent group-hover:tw-border-red-200 tw-h-full">
                                <!-- Restaurant Image -->
                                <div class="tw-relative tw-h-48 tw-bg-gray-200 tw-overflow-hidden">
                                    <img
                                        src="<?= $restaurant['image'] ?? 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=400&h=300&fit=crop' ?>"
                                        alt="<?= e($restaurant['name']) ?> restaurant"
                                        class="tw-w-full tw-h-full tw-object-cover tw-transition-transform tw-duration-300 group-hover:tw-scale-110 lazy-load"
                                        loading="lazy"
                                    >
                                    
                                    <!-- Status Badge -->
                                    <div class="tw-absolute tw-top-3 tw-left-3">
                                        <?php if ($restaurant['is_open']): ?>
                                            <span class="tw-bg-green-500 tw-text-white tw-px-3 tw-py-1 tw-rounded-full tw-text-sm tw-font-medium tw-shadow-lg tw-animate-pulse">
                                                <i data-feather="clock" class="tw-w-3 tw-h-3 tw-inline tw-mr-1"></i>
                                                Open
                                            </span>
                                        <?php else: ?>
                                            <span class="tw-bg-red-500 tw-text-white tw-px-3 tw-py-1 tw-rounded-full tw-text-sm tw-font-medium tw-shadow-lg">
                                                <i data-feather="clock" class="tw-w-3 tw-h-3 tw-inline tw-mr-1"></i>
                                                Closed
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <!-- Rating Badge -->
                                    <div class="tw-absolute tw-top-3 tw-right-3">
                                        <span class="tw-bg-white/90 tw-backdrop-blur-sm tw-text-gray-800 tw-px-2 tw-py-1 tw-rounded-full tw-text-sm tw-font-semibold tw-shadow-lg tw-flex tw-items-center">
                                            <i data-feather="star" class="tw-w-3 tw-h-3 tw-text-yellow-400 tw-fill-current tw-mr-1"></i>
                                            <?= number_format($restaurant['rating'], 1) ?>
                                        </span>
                                    </div>
                                    
                                    <!-- Delivery Fee Badge -->
                                    <?php if (isset($restaurant['delivery_fee']) && $restaurant['delivery_fee'] > 0): ?>
                                    <div class="tw-absolute tw-bottom-3 tw-left-3">
                                        <span class="tw-bg-orange-500 tw-text-white tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium tw-shadow-lg">
                                            <?= number_format($restaurant['delivery_fee']) ?> XAF delivery
                                        </span>
                                    </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Restaurant Info -->
                                <div class="tw-p-6">
                                    <div class="tw-flex tw-items-start tw-justify-between tw-mb-3">
                                        <h3 class="tw-text-xl tw-font-bold tw-text-gray-800 tw-leading-tight">
                                            <?= e($restaurant['name']) ?>
                                        </h3>
                                        <span class="tw-text-sm tw-text-gray-500 tw-bg-gray-100 tw-px-2 tw-py-1 tw-rounded">
                                            <?= e($restaurant['cuisine_type']) ?>
                                        </span>
                                    </div>

                                    <p class="tw-text-gray-600 tw-text-sm tw-mb-4 tw-line-clamp-2">
                                        <?= e($restaurant['description']) ?>
                                    </p>

                                    <!-- Restaurant Stats -->
                                    <div class="tw-flex tw-items-center tw-justify-between tw-text-sm tw-text-gray-500 tw-mb-4">
                                        <div class="tw-flex tw-items-center">
                                            <i data-feather="clock" class="tw-w-4 tw-h-4 tw-mr-1"></i>
                                            <?= e($restaurant['delivery_time']) ?> min
                                        </div>
                                        <div class="tw-flex tw-items-center">
                                            <i data-feather="users" class="tw-w-4 tw-h-4 tw-mr-1"></i>
                                            <?= number_format($restaurant['total_reviews'] ?? 0) ?> reviews
                                        </div>
                                    </div>

                                    <!-- Action Button -->
                                    <a
                                        href="/restaurant/<?= $restaurant['id'] ?>"
                                        class="tw-btn-primary tw-w-full tw-text-center tw-min-h-[48px] tw-flex tw-items-center tw-justify-center tw-font-semibold tw-transition-all tw-duration-200 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-red-500 focus:tw-ring-offset-2"
                                        aria-label="View menu for <?= e($restaurant['name']) ?>"
                                    >
                                        <i data-feather="menu" class="tw-w-4 tw-h-4 tw-mr-2"></i>
                                        View Menu
                                    </a>
                                </div>
                            </div>
                        </article>
                        <?php endforeach; ?>
                    </div>

                    <!-- Carousel Indicators -->
                    <div class="tw-flex tw-justify-center tw-mt-6 tw-space-x-2 md:tw-hidden">
                        <?php for ($i = 0; $i < count($restaurants_to_show); $i++): ?>
                        <button class="tw-w-2 tw-h-2 tw-rounded-full tw-bg-gray-300 tw-transition-colors tw-duration-200 carousel-indicator <?= $i === 0 ? 'tw-bg-red-500' : '' ?>" data-slide="<?= $i ?>"></button>
                        <?php endfor; ?>
                    </div>
                </div>

                <!-- View All Button -->
                <div class="tw-text-center tw-mt-12">
                    <a href="/browse" class="tw-btn-outline tw-px-8 tw-py-3 tw-text-lg tw-font-semibold">
                        <i data-feather="grid" class="tw-w-5 tw-h-5 tw-mr-2"></i>
                        View All Restaurants
                    </a>
                </div>
            </div>
        </section>

        <!-- Popular Dishes Section -->
        <section class="tw-py-16 lg:tw-py-20 tw-bg-gradient-to-br tw-from-red-50 tw-to-orange-50" aria-labelledby="popular-dishes-heading">
            <div class="tw-container tw-mx-auto tw-px-4">
                <header class="tw-text-center tw-mb-12 lg:tw-mb-16">
                    <h2 id="popular-dishes-heading" class="tw-text-3xl md:tw-text-4xl tw-font-bold tw-text-gray-800 tw-mb-4">
                        Popular Dishes
                    </h2>
                    <p class="tw-text-lg md:tw-text-xl tw-text-gray-600 tw-max-w-2xl tw-mx-auto">
                        Most ordered dishes from our top restaurants this month
                    </p>
                </header>

                <div class="tw-grid tw-grid-cols-1 sm:tw-grid-cols-2 lg:tw-grid-cols-3 xl:tw-grid-cols-4 tw-gap-6 lg:tw-gap-8">
                    <?php
                    // Default popular dishes if none from database
                    $default_dishes = [
                        [
                            'id' => 1,
                            'name' => 'Ndolé with Plantain',
                            'description' => 'Traditional Cameroonian dish with groundnuts and vegetables',
                            'price' => 2500,
                            'image' => 'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=400&h=300&fit=crop',
                            'restaurant_name' => 'Mama\'s Kitchen',
                            'category_name' => 'Traditional',
                            'rating' => 4.8,
                            'order_count' => 156
                        ],
                        [
                            'id' => 2,
                            'name' => 'Jollof Rice Special',
                            'description' => 'Spicy rice with chicken and vegetables',
                            'price' => 2000,
                            'image' => 'https://images.unsplash.com/photo-1596797038530-2c107229654b?w=400&h=300&fit=crop',
                            'restaurant_name' => 'Spice Garden',
                            'category_name' => 'Rice Dishes',
                            'rating' => 4.6,
                            'order_count' => 134
                        ],
                        [
                            'id' => 3,
                            'name' => 'Grilled Fish & Chips',
                            'description' => 'Fresh tilapia with crispy plantain chips',
                            'price' => 3000,
                            'image' => 'https://images.unsplash.com/photo-1544943910-4c1dc44aab44?w=400&h=300&fit=crop',
                            'restaurant_name' => 'Urban Fusion',
                            'category_name' => 'Seafood',
                            'rating' => 4.9,
                            'order_count' => 98
                        ],
                        [
                            'id' => 4,
                            'name' => 'Pepper Soup',
                            'description' => 'Spicy traditional soup with meat and spices',
                            'price' => 1800,
                            'image' => 'https://images.unsplash.com/photo-1547592180-85f173990554?w=400&h=300&fit=crop',
                            'restaurant_name' => 'Local Delights',
                            'category_name' => 'Soups',
                            'rating' => 4.7,
                            'order_count' => 87
                        ],
                        [
                            'id' => 5,
                            'name' => 'Chicken Shawarma',
                            'description' => 'Grilled chicken wrap with vegetables and sauce',
                            'price' => 1500,
                            'image' => 'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?w=400&h=300&fit=crop',
                            'restaurant_name' => 'Quick Bites',
                            'category_name' => 'Fast Food',
                            'rating' => 4.5,
                            'order_count' => 76
                        ],
                        [
                            'id' => 6,
                            'name' => 'Eru with Fufu',
                            'description' => 'Traditional vegetable dish with cassava fufu',
                            'price' => 2200,
                            'image' => 'https://images.unsplash.com/photo-1565299507177-b0ac66763828?w=400&h=300&fit=crop',
                            'restaurant_name' => 'Heritage Kitchen',
                            'category_name' => 'Traditional',
                            'rating' => 4.8,
                            'order_count' => 65
                        ]
                    ];

                    $dishes_to_show = !empty($popular_dishes) ? $popular_dishes : $default_dishes;
                    ?>
                    <?php foreach ($dishes_to_show as $dish): ?>
                    <article class="tw-group tw-cursor-pointer" role="listitem">
                        <div class="tw-card tw-overflow-hidden tw-transition-all tw-duration-300 group-hover:tw-scale-105 group-hover:tw-shadow-2xl tw-border-2 tw-border-transparent group-hover:tw-border-orange-200 tw-h-full">
                            <!-- Dish Image -->
                            <div class="tw-relative tw-h-48 tw-bg-gray-200 tw-overflow-hidden">
                                <img
                                    src="<?= $dish['image'] ?>"
                                    alt="<?= e($dish['name']) ?>"
                                    class="tw-w-full tw-h-full tw-object-cover tw-transition-transform tw-duration-300 group-hover:tw-scale-110 lazy-load"
                                    loading="lazy"
                                >

                                <!-- Price Badge -->
                                <div class="tw-absolute tw-top-3 tw-left-3">
                                    <span class="tw-bg-green-500 tw-text-white tw-px-3 tw-py-1 tw-rounded-full tw-text-sm tw-font-bold tw-shadow-lg">
                                        <?= number_format($dish['price']) ?> XAF
                                    </span>
                                </div>

                                <!-- Rating Badge -->
                                <div class="tw-absolute tw-top-3 tw-right-3">
                                    <span class="tw-bg-white/90 tw-backdrop-blur-sm tw-text-gray-800 tw-px-2 tw-py-1 tw-rounded-full tw-text-sm tw-font-semibold tw-shadow-lg tw-flex tw-items-center">
                                        <i data-feather="star" class="tw-w-3 tw-h-3 tw-text-yellow-400 tw-fill-current tw-mr-1"></i>
                                        <?= number_format($dish['rating'], 1) ?>
                                    </span>
                                </div>

                                <!-- Order Count Badge -->
                                <div class="tw-absolute tw-bottom-3 tw-right-3">
                                    <span class="tw-bg-red-500 tw-text-white tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium tw-shadow-lg">
                                        <?= $dish['order_count'] ?> orders
                                    </span>
                                </div>
                            </div>

                            <!-- Dish Info -->
                            <div class="tw-p-6">
                                <div class="tw-flex tw-items-start tw-justify-between tw-mb-3">
                                    <h3 class="tw-text-lg tw-font-bold tw-text-gray-800 tw-leading-tight tw-flex-1">
                                        <?= e($dish['name']) ?>
                                    </h3>
                                </div>

                                <p class="tw-text-gray-600 tw-text-sm tw-mb-3 tw-line-clamp-2">
                                    <?= e($dish['description']) ?>
                                </p>

                                <!-- Restaurant & Category -->
                                <div class="tw-flex tw-items-center tw-justify-between tw-text-sm tw-text-gray-500 tw-mb-4">
                                    <span class="tw-flex tw-items-center">
                                        <i data-feather="home" class="tw-w-3 tw-h-3 tw-mr-1"></i>
                                        <?= e($dish['restaurant_name']) ?>
                                    </span>
                                    <span class="tw-bg-gray-100 tw-px-2 tw-py-1 tw-rounded tw-text-xs">
                                        <?= e($dish['category_name']) ?>
                                    </span>
                                </div>

                                <!-- Add to Cart Button -->
                                <button
                                    class="tw-btn-primary tw-w-full tw-text-center tw-min-h-[44px] tw-flex tw-items-center tw-justify-center tw-font-semibold tw-transition-all tw-duration-200 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-orange-500 focus:tw-ring-offset-2"
                                    onclick="addToCart(<?= $dish['id'] ?>)"
                                    aria-label="Add <?= e($dish['name']) ?> to cart"
                                >
                                    <i data-feather="plus" class="tw-w-4 tw-h-4 tw-mr-2"></i>
                                    Add to Cart
                                </button>
                            </div>
                        </div>
                    </article>
                    <?php endforeach; ?>
                </div>

                <!-- View All Button -->
                <div class="tw-text-center tw-mt-12">
                    <a href="/browse?sort=popular" class="tw-btn-outline tw-px-8 tw-py-3 tw-text-lg tw-font-semibold">
                        <i data-feather="trending-up" class="tw-w-5 tw-h-5 tw-mr-2"></i>
                        View All Popular Dishes
                    </a>
                </div>
            </div>
        </section>

        <!-- Testimonials Section -->
        <section class="tw-py-16 lg:tw-py-20 tw-bg-white" aria-labelledby="testimonials-heading">
            <div class="tw-container tw-mx-auto tw-px-4">
                <header class="tw-text-center tw-mb-12 lg:tw-mb-16">
                    <h2 id="testimonials-heading" class="tw-text-3xl md:tw-text-4xl tw-font-bold tw-text-gray-800 tw-mb-4">
                        What Our Customers Say
                    </h2>
                    <p class="tw-text-lg md:tw-text-xl tw-text-gray-600 tw-max-w-2xl tw-mx-auto">
                        Real reviews from satisfied customers across Bamenda
                    </p>
                </header>

                <div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 lg:tw-grid-cols-3 tw-gap-8 tw-max-w-6xl tw-mx-auto">
                    <?php
                    // Default testimonials if none from database
                    $default_testimonials = [
                        [
                            'id' => 1,
                            'rating' => 5,
                            'comment' => 'Time2Eat has made ordering food so convenient! The delivery is always fast and the food arrives hot. My favorite is the ndolé from Mama\'s Kitchen.',
                            'first_name' => 'Sarah',
                            'last_name' => 'Mbah',
                            'avatar' => null,
                            'reviewed_item' => 'Mama\'s Kitchen',
                            'reviewable_type' => 'restaurant',
                            'created_at' => '2024-01-15 14:30:00',
                            'helpful_count' => 12
                        ],
                        [
                            'id' => 2,
                            'rating' => 5,
                            'comment' => 'Excellent service! I ordered jollof rice and it was perfectly spiced. The app is easy to use and tracking is very accurate. Highly recommend!',
                            'first_name' => 'John',
                            'last_name' => 'Fon',
                            'avatar' => null,
                            'reviewed_item' => 'Jollof Rice Special',
                            'reviewable_type' => 'menu_item',
                            'created_at' => '2024-01-20 19:45:00',
                            'helpful_count' => 8
                        ],
                        [
                            'id' => 3,
                            'rating' => 4,
                            'comment' => 'Great variety of restaurants and the food quality is consistently good. The delivery riders are professional and friendly.',
                            'first_name' => 'Grace',
                            'last_name' => 'Tabi',
                            'avatar' => null,
                            'reviewed_item' => 'Delivery Service',
                            'reviewable_type' => 'rider',
                            'created_at' => '2024-01-25 12:15:00',
                            'helpful_count' => 15
                        ],
                        [
                            'id' => 4,
                            'rating' => 5,
                            'comment' => 'Love the real-time tracking feature! I can see exactly where my order is. The food from Urban Fusion is always fresh and delicious.',
                            'first_name' => 'Peter',
                            'last_name' => 'Nkeng',
                            'avatar' => null,
                            'reviewed_item' => 'Urban Fusion',
                            'reviewable_type' => 'restaurant',
                            'created_at' => '2024-02-01 16:20:00',
                            'helpful_count' => 6
                        ],
                        [
                            'id' => 5,
                            'rating' => 4,
                            'comment' => 'The pepper soup from Local Delights is amazing! Authentic taste and generous portions. Will definitely order again.',
                            'first_name' => 'Mary',
                            'last_name' => 'Che',
                            'avatar' => null,
                            'reviewed_item' => 'Pepper Soup',
                            'reviewable_type' => 'menu_item',
                            'created_at' => '2024-02-05 20:10:00',
                            'helpful_count' => 9
                        ],
                        [
                            'id' => 6,
                            'rating' => 5,
                            'comment' => 'Best food delivery app in Bamenda! Fast, reliable, and great customer service. The variety of local and international dishes is impressive.',
                            'first_name' => 'David',
                            'last_name' => 'Tanyi',
                            'avatar' => null,
                            'reviewed_item' => 'Time2Eat Platform',
                            'reviewable_type' => 'platform',
                            'created_at' => '2024-02-10 11:30:00',
                            'helpful_count' => 18
                        ]
                    ];

                    $testimonials_to_show = !empty($testimonials) ? $testimonials : $default_testimonials;
                    ?>
                    <?php foreach ($testimonials_to_show as $testimonial): ?>
                    <article class="tw-card tw-p-6 tw-text-center tw-group tw-transition-all tw-duration-300 hover:tw-shadow-2xl hover:tw-scale-105">
                        <!-- Rating Stars -->
                        <div class="tw-flex tw-justify-center tw-mb-4">
                            <div class="tw-flex tw-space-x-1">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <i data-feather="star" class="tw-w-5 tw-h-5 <?= $i <= $testimonial['rating'] ? 'tw-text-yellow-400 tw-fill-current' : 'tw-text-gray-300' ?>"></i>
                                <?php endfor; ?>
                            </div>
                        </div>

                        <!-- Review Text -->
                        <blockquote class="tw-text-gray-700 tw-mb-6 tw-italic tw-leading-relaxed">
                            "<?= e($testimonial['comment']) ?>"
                        </blockquote>

                        <!-- Reviewer Info -->
                        <footer class="tw-border-t tw-pt-4">
                            <div class="tw-flex tw-items-center tw-justify-center tw-mb-3">
                                <?php if ($testimonial['avatar']): ?>
                                    <img src="<?= e($testimonial['avatar']) ?>" alt="<?= e($testimonial['first_name']) ?>" class="tw-w-12 tw-h-12 tw-rounded-full tw-mr-3">
                                <?php else: ?>
                                    <div class="tw-w-12 tw-h-12 tw-bg-gradient-to-br tw-from-red-500 tw-to-orange-500 tw-rounded-full tw-flex tw-items-center tw-justify-center tw-mr-3">
                                        <span class="tw-text-white tw-font-bold tw-text-lg">
                                            <?= strtoupper(substr($testimonial['first_name'], 0, 1)) ?>
                                        </span>
                                    </div>
                                <?php endif; ?>
                                <div class="tw-text-left">
                                    <div class="tw-font-semibold tw-text-gray-800">
                                        <?= e($testimonial['first_name']) ?> <?= e(substr($testimonial['last_name'], 0, 1)) ?>.
                                    </div>
                                    <div class="tw-text-sm tw-text-gray-500">
                                        Reviewed <?= e($testimonial['reviewed_item']) ?>
                                    </div>
                                </div>
                            </div>

                            <!-- Review Meta -->
                            <div class="tw-flex tw-items-center tw-justify-between tw-text-xs tw-text-gray-400">
                                <span><?= date('M j, Y', strtotime($testimonial['created_at'])) ?></span>
                                <span class="tw-flex tw-items-center">
                                    <i data-feather="thumbs-up" class="tw-w-3 tw-h-3 tw-mr-1"></i>
                                    <?= $testimonial['helpful_count'] ?> helpful
                                </span>
                            </div>
                        </footer>
                    </article>
                    <?php endforeach; ?>
                </div>

                <!-- View All Reviews Button -->
                <div class="tw-text-center tw-mt-12">
                    <a href="/reviews" class="tw-btn-outline tw-px-8 tw-py-3 tw-text-lg tw-font-semibold">
                        <i data-feather="message-circle" class="tw-w-5 tw-h-5 tw-mr-2"></i>
                        View All Reviews
                    </a>
                </div>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <?php include __DIR__ . '/../partials/footer.php'; ?>

    <!-- Scripts -->
    <script src="https://unpkg.com/feather-icons"></script>
    <script src="/public/js/app.js"></script>
    <script src="/public/js/home-enhanced.js"></script>

    <!-- Enhanced Mobile Carousel Script -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize Feather Icons
            feather.replace();

            // Mobile Carousel Functionality
            const carousel = document.getElementById('featured-carousel');
            const prevBtn = document.getElementById('prev-restaurant');
            const nextBtn = document.getElementById('next-restaurant');
            const indicators = document.querySelectorAll('.carousel-indicator');

            if (carousel && prevBtn && nextBtn) {
                let currentSlide = 0;
                const totalSlides = carousel.children.length;
                const slideWidth = 320; // 80 * 4 (w-80 + mr-6)

                // Update carousel position
                function updateCarousel() {
                    const translateX = -currentSlide * slideWidth;
                    carousel.style.transform = `translateX(${translateX}px)`;

                    // Update indicators
                    indicators.forEach((indicator, index) => {
                        indicator.classList.toggle('tw-bg-red-500', index === currentSlide);
                        indicator.classList.toggle('tw-bg-gray-300', index !== currentSlide);
                    });
                }

                // Next slide
                nextBtn.addEventListener('click', () => {
                    currentSlide = (currentSlide + 1) % totalSlides;
                    updateCarousel();
                });

                // Previous slide
                prevBtn.addEventListener('click', () => {
                    currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
                    updateCarousel();
                });

                // Indicator clicks
                indicators.forEach((indicator, index) => {
                    indicator.addEventListener('click', () => {
                        currentSlide = index;
                        updateCarousel();
                    });
                });

                // Auto-play carousel
                setInterval(() => {
                    if (window.innerWidth < 768) { // Only on mobile
                        currentSlide = (currentSlide + 1) % totalSlides;
                        updateCarousel();
                    }
                }, 5000);

                // Touch/swipe support
                let startX = 0;
                let isDragging = false;

                carousel.addEventListener('touchstart', (e) => {
                    startX = e.touches[0].clientX;
                    isDragging = true;
                });

                carousel.addEventListener('touchmove', (e) => {
                    if (!isDragging) return;
                    e.preventDefault();
                });

                carousel.addEventListener('touchend', (e) => {
                    if (!isDragging) return;
                    isDragging = false;

                    const endX = e.changedTouches[0].clientX;
                    const diffX = startX - endX;

                    if (Math.abs(diffX) > 50) { // Minimum swipe distance
                        if (diffX > 0) {
                            // Swipe left - next slide
                            currentSlide = (currentSlide + 1) % totalSlides;
                        } else {
                            // Swipe right - previous slide
                            currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
                        }
                        updateCarousel();
                    }
                });
            }

            // Lazy loading for images
            const lazyImages = document.querySelectorAll('.lazy-load');
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        if (img.dataset.src) {
                            img.src = img.dataset.src;
                            img.classList.remove('lazy-load');
                            observer.unobserve(img);
                        }
                    }
                });
            });

            lazyImages.forEach(img => imageObserver.observe(img));

            // Smooth scroll for anchor links
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();
                    const target = document.querySelector(this.getAttribute('href'));
                    if (target) {
                        target.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }
                });
            });

            // Add to cart functionality
            window.addToCart = function(dishId) {
                // Show loading state
                const button = event.target.closest('button');
                const originalText = button.innerHTML;
                button.innerHTML = '<i data-feather="loader" class="tw-w-4 tw-h-4 tw-mr-2 tw-animate-spin"></i>Adding...';
                button.disabled = true;

                // Simulate API call
                setTimeout(() => {
                    button.innerHTML = '<i data-feather="check" class="tw-w-4 tw-h-4 tw-mr-2"></i>Added!';
                    button.classList.add('tw-bg-green-500');

                    setTimeout(() => {
                        button.innerHTML = originalText;
                        button.classList.remove('tw-bg-green-500');
                        button.disabled = false;
                        feather.replace();
                    }, 2000);
                }, 1000);

                feather.replace();
            };

            // Animation on scroll
            const observerOptions = {
                threshold: 0.1,
                rootMargin: '0px 0px -50px 0px'
            };

            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('tw-animate-fade-in');
                    }
                });
            }, observerOptions);

            // Observe all cards and sections
            document.querySelectorAll('.tw-card, section').forEach(el => {
                observer.observe(el);
            });
        });
    </script>
</body>
</html>
