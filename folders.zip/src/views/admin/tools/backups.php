<?php
/**
 * Admin Database Backups Management
 * Create, download, and restore database backups
 */

$title = $title ?? 'Database Backups - Time2Eat Admin';
$user = $user ?? [];
$backups = $backups ?? [];
$backupSettings = $backupSettings ?? [];

// Include header
include __DIR__ . '/../../layouts/admin_header.php';
?>

<div class="tw-min-h-screen tw-bg-gray-50">
    <!-- Header -->
    <div class="tw-bg-white tw-shadow-sm tw-border-b tw-border-gray-200">
        <div class="tw-max-w-7xl tw-mx-auto tw-px-4 sm:tw-px-6 lg:tw-px-8">
            <div class="tw-flex tw-justify-between tw-items-center tw-py-6">
                <div>
                    <h1 class="tw-text-3xl tw-font-bold tw-text-gray-900">Database Backups</h1>
                    <p class="tw-mt-1 tw-text-sm tw-text-gray-500">Create, manage, and restore database backups</p>
                </div>
                <div class="tw-flex tw-space-x-3">
                    <button id="createBackup" class="tw-bg-blue-600 tw-text-white tw-px-4 tw-py-2 tw-rounded-lg hover:tw-bg-blue-700 tw-transition-colors tw-flex tw-items-center tw-space-x-2">
                        <i data-feather="database" class="tw-h-4 tw-w-4"></i>
                        <span>Create Backup</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="tw-max-w-7xl tw-mx-auto tw-px-4 sm:tw-px-6 lg:tw-px-8 tw-py-8">
        <!-- Backup Settings -->
        <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200 tw-mb-8">
            <div class="tw-p-6 tw-border-b tw-border-gray-200">
                <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Backup Settings</h2>
                <p class="tw-text-sm tw-text-gray-500">Configure automatic backup preferences</p>
            </div>
            <div class="tw-p-6">
                <div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-3 tw-gap-6">
                    <div class="tw-text-center tw-p-4 tw-bg-gray-50 tw-rounded-lg">
                        <div class="tw-text-2xl tw-font-bold tw-text-blue-600">
                            <?= $backupSettings['auto_backup_enabled'] ? 'Enabled' : 'Disabled' ?>
                        </div>
                        <div class="tw-text-sm tw-text-gray-500">Auto Backup</div>
                    </div>
                    <div class="tw-text-center tw-p-4 tw-bg-gray-50 tw-rounded-lg">
                        <div class="tw-text-2xl tw-font-bold tw-text-green-600">
                            <?= ucfirst($backupSettings['backup_frequency'] ?? 'Daily') ?>
                        </div>
                        <div class="tw-text-sm tw-text-gray-500">Frequency</div>
                    </div>
                    <div class="tw-text-center tw-p-4 tw-bg-gray-50 tw-rounded-lg">
                        <div class="tw-text-2xl tw-font-bold tw-text-orange-600">
                            <?= $backupSettings['backup_retention_days'] ?? 30 ?> Days
                        </div>
                        <div class="tw-text-sm tw-text-gray-500">Retention</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Existing Backups -->
        <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
            <div class="tw-p-6 tw-border-b tw-border-gray-200">
                <div class="tw-flex tw-justify-between tw-items-center">
                    <div>
                        <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Existing Backups</h2>
                        <p class="tw-text-sm tw-text-gray-500">Manage your database backup files</p>
                    </div>
                    <span class="tw-inline-flex tw-items-center tw-px-3 tw-py-1 tw-rounded-full tw-text-sm tw-font-medium tw-bg-blue-100 tw-text-blue-800">
                        <?= count($backups) ?> Backups
                    </span>
                </div>
            </div>
            <div class="tw-p-6">
                <?php if (empty($backups)): ?>
                    <div class="tw-text-center tw-py-12">
                        <i data-feather="database" class="tw-h-12 tw-w-12 tw-text-gray-400 tw-mx-auto tw-mb-4"></i>
                        <h3 class="tw-text-lg tw-font-medium tw-text-gray-900 tw-mb-2">No Backups Found</h3>
                        <p class="tw-text-gray-500 tw-mb-4">Create your first database backup to get started.</p>
                        <button class="create-backup-btn tw-bg-blue-600 tw-text-white tw-px-4 tw-py-2 tw-rounded-lg hover:tw-bg-blue-700 tw-transition-colors">
                            Create First Backup
                        </button>
                    </div>
                <?php else: ?>
                    <div class="tw-overflow-x-auto">
                        <table class="tw-min-w-full tw-divide-y tw-divide-gray-200">
                            <thead class="tw-bg-gray-50">
                                <tr>
                                    <th class="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-500 tw-uppercase tw-tracking-wider">
                                        Backup File
                                    </th>
                                    <th class="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-500 tw-uppercase tw-tracking-wider">
                                        Size
                                    </th>
                                    <th class="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-500 tw-uppercase tw-tracking-wider">
                                        Created
                                    </th>
                                    <th class="tw-px-6 tw-py-3 tw-text-right tw-text-xs tw-font-medium tw-text-gray-500 tw-uppercase tw-tracking-wider">
                                        Actions
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="tw-bg-white tw-divide-y tw-divide-gray-200">
                                <?php foreach ($backups as $backup): ?>
                                    <tr class="hover:tw-bg-gray-50">
                                        <td class="tw-px-6 tw-py-4 tw-whitespace-nowrap">
                                            <div class="tw-flex tw-items-center">
                                                <i data-feather="file" class="tw-h-5 tw-w-5 tw-text-gray-400 tw-mr-3"></i>
                                                <div>
                                                    <div class="tw-text-sm tw-font-medium tw-text-gray-900">
                                                        <?= htmlspecialchars($backup['filename']) ?>
                                                    </div>
                                                    <div class="tw-text-sm tw-text-gray-500">
                                                        SQL Database Backup
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="tw-px-6 tw-py-4 tw-whitespace-nowrap tw-text-sm tw-text-gray-900">
                                            <?= $this->formatBytes($backup['size']) ?>
                                        </td>
                                        <td class="tw-px-6 tw-py-4 tw-whitespace-nowrap tw-text-sm tw-text-gray-500">
                                            <?= date('M j, Y g:i A', strtotime($backup['created_at'])) ?>
                                        </td>
                                        <td class="tw-px-6 tw-py-4 tw-whitespace-nowrap tw-text-right tw-text-sm tw-font-medium">
                                            <div class="tw-flex tw-justify-end tw-space-x-2">
                                                <button class="download-backup tw-text-blue-600 hover:tw-text-blue-900 tw-p-2 tw-rounded-lg hover:tw-bg-blue-50"
                                                        data-filename="<?= htmlspecialchars($backup['filename']) ?>"
                                                        title="Download">
                                                    <i data-feather="download" class="tw-h-4 tw-w-4"></i>
                                                </button>
                                                <button class="restore-backup tw-text-green-600 hover:tw-text-green-900 tw-p-2 tw-rounded-lg hover:tw-bg-green-50"
                                                        data-filename="<?= htmlspecialchars($backup['filename']) ?>"
                                                        title="Restore">
                                                    <i data-feather="refresh-cw" class="tw-h-4 tw-w-4"></i>
                                                </button>
                                                <button class="delete-backup tw-text-red-600 hover:tw-text-red-900 tw-p-2 tw-rounded-lg hover:tw-bg-red-50"
                                                        data-filename="<?= htmlspecialchars($backup['filename']) ?>"
                                                        title="Delete">
                                                    <i data-feather="trash-2" class="tw-h-4 tw-w-4"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Backup Instructions -->
        <div class="tw-bg-blue-50 tw-border tw-border-blue-200 tw-rounded-xl tw-p-6 tw-mt-8">
            <div class="tw-flex">
                <i data-feather="info" class="tw-h-5 tw-w-5 tw-text-blue-400 tw-mt-0.5"></i>
                <div class="tw-ml-3">
                    <h3 class="tw-text-sm tw-font-medium tw-text-blue-800">Backup Information</h3>
                    <div class="tw-mt-2 tw-text-sm tw-text-blue-700">
                        <ul class="tw-list-disc tw-list-inside tw-space-y-1">
                            <li>Backups are stored in the <code class="tw-bg-blue-100 tw-px-1 tw-rounded">storage/backups</code> directory</li>
                            <li>Manual backups can be created at any time using the "Create Backup" button</li>
                            <li>Automatic backups run based on your configured schedule</li>
                            <li>Restore operations will replace the current database - use with caution</li>
                            <li>Always test restored backups in a development environment first</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Confirmation Modal -->
<div id="confirmationModal" class="tw-fixed tw-inset-0 tw-bg-gray-600 tw-bg-opacity-50 tw-overflow-y-auto tw-h-full tw-w-full tw-hidden">
    <div class="tw-relative tw-top-20 tw-mx-auto tw-p-5 tw-border tw-w-96 tw-shadow-lg tw-rounded-md tw-bg-white">
        <div class="tw-mt-3">
            <div class="tw-flex tw-items-center tw-mb-4">
                <i data-feather="alert-triangle" class="tw-h-6 tw-w-6 tw-text-yellow-500 tw-mr-3"></i>
                <h3 class="tw-text-lg tw-font-medium tw-text-gray-900" id="modalTitle">Confirm Action</h3>
            </div>
            <p class="tw-text-sm tw-text-gray-600 tw-mb-4" id="modalMessage">Are you sure you want to proceed?</p>
            <div class="tw-flex tw-justify-end tw-space-x-3">
                <button id="cancelAction" class="tw-px-4 tw-py-2 tw-bg-gray-300 tw-text-gray-700 tw-rounded-lg hover:tw-bg-gray-400">
                    Cancel
                </button>
                <button id="confirmAction" class="tw-px-4 tw-py-2 tw-bg-red-600 tw-text-white tw-rounded-lg hover:tw-bg-red-700">
                    Confirm
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Loading Modal -->
<div id="loadingModal" class="tw-fixed tw-inset-0 tw-bg-gray-600 tw-bg-opacity-50 tw-overflow-y-auto tw-h-full tw-w-full tw-hidden">
    <div class="tw-relative tw-top-20 tw-mx-auto tw-p-5 tw-border tw-w-96 tw-shadow-lg tw-rounded-md tw-bg-white">
        <div class="tw-text-center">
            <div class="tw-animate-spin tw-rounded-full tw-h-12 tw-w-12 tw-border-b-2 tw-border-blue-600 tw-mx-auto tw-mb-4"></div>
            <h3 class="tw-text-lg tw-font-medium tw-text-gray-900 tw-mb-2" id="loadingTitle">Processing...</h3>
            <p class="tw-text-sm tw-text-gray-600" id="loadingMessage">Please wait while we process your request.</p>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    let currentAction = null;
    let currentFilename = null;

    // Create backup handlers
    document.querySelectorAll('#createBackup, .create-backup-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            createBackup();
        });
    });

    // Download backup handlers
    document.querySelectorAll('.download-backup').forEach(btn => {
        btn.addEventListener('click', function() {
            const filename = this.dataset.filename;
            downloadBackup(filename);
        });
    });

    // Restore backup handlers
    document.querySelectorAll('.restore-backup').forEach(btn => {
        btn.addEventListener('click', function() {
            const filename = this.dataset.filename;
            showConfirmation(
                'Restore Database',
                `Are you sure you want to restore the database from "${filename}"? This will replace all current data and cannot be undone.`,
                'restore_backup',
                filename
            );
        });
    });

    // Delete backup handlers
    document.querySelectorAll('.delete-backup').forEach(btn => {
        btn.addEventListener('click', function() {
            const filename = this.dataset.filename;
            showConfirmation(
                'Delete Backup',
                `Are you sure you want to delete the backup file "${filename}"? This action cannot be undone.`,
                'delete_backup',
                filename
            );
        });
    });

    // Modal handlers
    document.getElementById('cancelAction').addEventListener('click', function() {
        hideConfirmation();
    });

    document.getElementById('confirmAction').addEventListener('click', function() {
        if (currentAction && currentFilename) {
            executeAction(currentAction, currentFilename);
        }
        hideConfirmation();
    });

    function createBackup() {
        showLoading('Creating Backup', 'Please wait while we create a database backup...');
        
        const formData = new FormData();
        formData.append('action', 'create_backup');

        fetch('/admin/tools/backups', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            hideLoading();
            if (data.success) {
                showSuccess('Backup created successfully!');
                setTimeout(() => location.reload(), 1500);
            } else {
                showError('Failed to create backup: ' + data.message);
            }
        })
        .catch(error => {
            hideLoading();
            console.error('Error:', error);
            showError('An error occurred while creating the backup.');
        });
    }

    function downloadBackup(filename) {
        const formData = new FormData();
        formData.append('action', 'download_backup');
        formData.append('filename', filename);

        // Create a temporary form to trigger download
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '/admin/tools/backups';
        form.style.display = 'none';

        const actionInput = document.createElement('input');
        actionInput.type = 'hidden';
        actionInput.name = 'action';
        actionInput.value = 'download_backup';

        const filenameInput = document.createElement('input');
        filenameInput.type = 'hidden';
        filenameInput.name = 'filename';
        filenameInput.value = filename;

        form.appendChild(actionInput);
        form.appendChild(filenameInput);
        document.body.appendChild(form);
        form.submit();
        document.body.removeChild(form);
    }

    function executeAction(action, filename) {
        const loadingTitles = {
            'restore_backup': 'Restoring Database',
            'delete_backup': 'Deleting Backup'
        };

        const loadingMessages = {
            'restore_backup': 'Please wait while we restore the database...',
            'delete_backup': 'Please wait while we delete the backup file...'
        };

        showLoading(loadingTitles[action] || 'Processing', loadingMessages[action] || 'Please wait...');

        const formData = new FormData();
        formData.append('action', action);
        formData.append('filename', filename);

        fetch('/admin/tools/backups', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            hideLoading();
            if (data.success) {
                showSuccess(data.message);
                setTimeout(() => location.reload(), 1500);
            } else {
                showError('Failed: ' + data.message);
            }
        })
        .catch(error => {
            hideLoading();
            console.error('Error:', error);
            showError('An error occurred while processing the request.');
        });
    }

    function showConfirmation(title, message, action, filename) {
        document.getElementById('modalTitle').textContent = title;
        document.getElementById('modalMessage').textContent = message;
        document.getElementById('confirmationModal').classList.remove('tw-hidden');
        currentAction = action;
        currentFilename = filename;
    }

    function hideConfirmation() {
        document.getElementById('confirmationModal').classList.add('tw-hidden');
        currentAction = null;
        currentFilename = null;
    }

    function showLoading(title, message) {
        document.getElementById('loadingTitle').textContent = title;
        document.getElementById('loadingMessage').textContent = message;
        document.getElementById('loadingModal').classList.remove('tw-hidden');
    }

    function hideLoading() {
        document.getElementById('loadingModal').classList.add('tw-hidden');
    }

    function showSuccess(message) {
        // You can implement a toast notification here
        alert('Success: ' + message);
    }

    function showError(message) {
        // You can implement a toast notification here
        alert('Error: ' + message);
    }
});
</script>

<?php
// Helper function to format bytes
function formatBytes($bytes, $precision = 2) {
    $units = array('B', 'KB', 'MB', 'GB', 'TB');
    
    for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
        $bytes /= 1024;
    }
    
    return round($bytes, $precision) . ' ' . $units[$i];
}
?>

<?php include __DIR__ . '/../../layouts/admin_footer.php'; ?>
