<?php
/**
 * Admin Analytics Dashboard
 * Advanced analytics with Chart.js integration and Excel export
 */

$title = $title ?? 'Advanced Analytics - Time2Eat Admin';
$user = $user ?? [];
$analyticsData = $analyticsData ?? [];
$currentPeriod = $currentPeriod ?? '30days';
$error = $error ?? null;

// Include header
include __DIR__ . '/../../layouts/admin_header.php';
?>

<div class="tw-min-h-screen tw-bg-gray-50">
    <!-- Header -->
    <div class="tw-bg-white tw-shadow-sm tw-border-b tw-border-gray-200">
        <div class="tw-max-w-7xl tw-mx-auto tw-px-4 sm:tw-px-6 lg:tw-px-8">
            <div class="tw-flex tw-justify-between tw-items-center tw-py-6">
                <div>
                    <h1 class="tw-text-3xl tw-font-bold tw-text-gray-900">Advanced Analytics</h1>
                    <p class="tw-mt-1 tw-text-sm tw-text-gray-500">Comprehensive platform insights and reporting</p>
                </div>
                <div class="tw-flex tw-space-x-3">
                    <!-- Period Selector -->
                    <select id="periodSelector" class="tw-rounded-lg tw-border-gray-300 tw-shadow-sm focus:tw-border-blue-500 focus:tw-ring-blue-500">
                        <option value="today" <?= $currentPeriod === 'today' ? 'selected' : '' ?>>Today</option>
                        <option value="week" <?= $currentPeriod === 'week' ? 'selected' : '' ?>>Last 7 Days</option>
                        <option value="30days" <?= $currentPeriod === '30days' ? 'selected' : '' ?>>Last 30 Days</option>
                        <option value="90days" <?= $currentPeriod === '90days' ? 'selected' : '' ?>>Last 90 Days</option>
                        <option value="year" <?= $currentPeriod === 'year' ? 'selected' : '' ?>>Last Year</option>
                    </select>
                    
                    <!-- Export Button -->
                    <button id="exportExcel" class="tw-bg-green-600 tw-text-white tw-px-4 tw-py-2 tw-rounded-lg hover:tw-bg-green-700 tw-transition-colors tw-flex tw-items-center tw-space-x-2">
                        <i data-feather="download" class="tw-h-4 tw-w-4"></i>
                        <span>Export Excel</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="tw-max-w-7xl tw-mx-auto tw-px-4 sm:tw-px-6 lg:tw-px-8 tw-py-8">
        <?php if ($error): ?>
            <div class="tw-bg-red-50 tw-border tw-border-red-200 tw-rounded-lg tw-p-4 tw-mb-6">
                <div class="tw-flex">
                    <i data-feather="alert-circle" class="tw-h-5 tw-w-5 tw-text-red-400"></i>
                    <div class="tw-ml-3">
                        <h3 class="tw-text-sm tw-font-medium tw-text-red-800">Error Loading Analytics</h3>
                        <p class="tw-mt-1 tw-text-sm tw-text-red-700"><?= htmlspecialchars($error) ?></p>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <!-- Overview Cards -->
            <div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 lg:tw-grid-cols-4 tw-gap-6 tw-mb-8">
                <div class="tw-bg-white tw-p-6 tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                    <div class="tw-flex tw-items-center tw-justify-between">
                        <div>
                            <p class="tw-text-sm tw-font-medium tw-text-gray-600">Total Users</p>
                            <p class="tw-text-3xl tw-font-bold tw-text-gray-900"><?= number_format($analyticsData['overview']['totalUsers'] ?? 0) ?></p>
                            <p class="tw-text-sm tw-text-green-600">Active platform users</p>
                        </div>
                        <div class="tw-p-3 tw-bg-blue-100 tw-rounded-full">
                            <i data-feather="users" class="tw-h-6 tw-w-6 tw-text-blue-600"></i>
                        </div>
                    </div>
                </div>

                <div class="tw-bg-white tw-p-6 tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                    <div class="tw-flex tw-items-center tw-justify-between">
                        <div>
                            <p class="tw-text-sm tw-font-medium tw-text-gray-600">Total Revenue</p>
                            <p class="tw-text-3xl tw-font-bold tw-text-gray-900"><?= number_format($analyticsData['overview']['totalRevenue'] ?? 0) ?> FCFA</p>
                            <p class="tw-text-sm tw-text-green-600">Platform earnings</p>
                        </div>
                        <div class="tw-p-3 tw-bg-green-100 tw-rounded-full">
                            <i data-feather="dollar-sign" class="tw-h-6 tw-w-6 tw-text-green-600"></i>
                        </div>
                    </div>
                </div>

                <div class="tw-bg-white tw-p-6 tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                    <div class="tw-flex tw-items-center tw-justify-between">
                        <div>
                            <p class="tw-text-sm tw-font-medium tw-text-gray-600">Total Orders</p>
                            <p class="tw-text-3xl tw-font-bold tw-text-gray-900"><?= number_format($analyticsData['overview']['totalOrders'] ?? 0) ?></p>
                            <p class="tw-text-sm tw-text-blue-600">All time orders</p>
                        </div>
                        <div class="tw-p-3 tw-bg-orange-100 tw-rounded-full">
                            <i data-feather="shopping-bag" class="tw-h-6 tw-w-6 tw-text-orange-600"></i>
                        </div>
                    </div>
                </div>

                <div class="tw-bg-white tw-p-6 tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                    <div class="tw-flex tw-items-center tw-justify-between">
                        <div>
                            <p class="tw-text-sm tw-font-medium tw-text-gray-600">Avg Order Value</p>
                            <p class="tw-text-3xl tw-font-bold tw-text-gray-900"><?= number_format($analyticsData['overview']['averageOrderValue'] ?? 0) ?> FCFA</p>
                            <p class="tw-text-sm tw-text-purple-600">Per order average</p>
                        </div>
                        <div class="tw-p-3 tw-bg-purple-100 tw-rounded-full">
                            <i data-feather="trending-up" class="tw-h-6 tw-w-6 tw-text-purple-600"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Charts Row 1 -->
            <div class="tw-grid tw-grid-cols-1 lg:tw-grid-cols-2 tw-gap-8 tw-mb-8">
                <!-- Revenue Growth Chart -->
                <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                    <div class="tw-p-6 tw-border-b tw-border-gray-200">
                        <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Revenue Growth</h2>
                        <p class="tw-text-sm tw-text-gray-500">Daily revenue trends over selected period</p>
                    </div>
                    <div class="tw-p-6">
                        <canvas id="revenueChart" width="400" height="200"></canvas>
                    </div>
                </div>

                <!-- Order Trends Chart -->
                <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                    <div class="tw-p-6 tw-border-b tw-border-gray-200">
                        <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Order Trends</h2>
                        <p class="tw-text-sm tw-text-gray-500">Order volume and completion rates</p>
                    </div>
                    <div class="tw-p-6">
                        <canvas id="orderChart" width="400" height="200"></canvas>
                    </div>
                </div>
            </div>

            <!-- Charts Row 2 -->
            <div class="tw-grid tw-grid-cols-1 lg:tw-grid-cols-2 tw-gap-8 tw-mb-8">
                <!-- User Growth Chart -->
                <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                    <div class="tw-p-6 tw-border-b tw-border-gray-200">
                        <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">User Growth</h2>
                        <p class="tw-text-sm tw-text-gray-500">New user registrations by role</p>
                    </div>
                    <div class="tw-p-6">
                        <canvas id="userGrowthChart" width="400" height="200"></canvas>
                    </div>
                </div>

                <!-- Peak Hours Chart -->
                <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                    <div class="tw-p-6 tw-border-b tw-border-gray-200">
                        <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Peak Hours</h2>
                        <p class="tw-text-sm tw-text-gray-500">Order distribution by hour of day</p>
                    </div>
                    <div class="tw-p-6">
                        <canvas id="peakHoursChart" width="400" height="200"></canvas>
                    </div>
                </div>
            </div>

            <!-- Top Performers -->
            <div class="tw-grid tw-grid-cols-1 lg:tw-grid-cols-2 tw-gap-8 tw-mb-8">
                <!-- Top Restaurants -->
                <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                    <div class="tw-p-6 tw-border-b tw-border-gray-200">
                        <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Top Restaurants</h2>
                        <p class="tw-text-sm tw-text-gray-500">Highest performing restaurants by revenue</p>
                    </div>
                    <div class="tw-p-6">
                        <div class="tw-space-y-4">
                            <?php foreach (($analyticsData['revenueAnalytics']['topRestaurants'] ?? []) as $index => $restaurant): ?>
                                <div class="tw-flex tw-items-center tw-justify-between tw-p-3 tw-bg-gray-50 tw-rounded-lg">
                                    <div class="tw-flex tw-items-center tw-space-x-3">
                                        <div class="tw-w-8 tw-h-8 tw-bg-blue-100 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                                            <span class="tw-text-sm tw-font-semibold tw-text-blue-600"><?= $index + 1 ?></span>
                                        </div>
                                        <div>
                                            <p class="tw-font-medium tw-text-gray-900"><?= htmlspecialchars($restaurant['name'] ?? '') ?></p>
                                            <p class="tw-text-sm tw-text-gray-500"><?= number_format($restaurant['total_orders'] ?? 0) ?> orders</p>
                                        </div>
                                    </div>
                                    <div class="tw-text-right">
                                        <p class="tw-font-semibold tw-text-gray-900"><?= number_format($restaurant['total_revenue'] ?? 0) ?> FCFA</p>
                                        <p class="tw-text-sm tw-text-gray-500"><?= number_format($restaurant['avg_order_value'] ?? 0) ?> avg</p>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- Top Customers -->
                <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                    <div class="tw-p-6 tw-border-b tw-border-gray-200">
                        <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Top Customers</h2>
                        <p class="tw-text-sm tw-text-gray-500">Highest spending customers</p>
                    </div>
                    <div class="tw-p-6">
                        <div class="tw-space-y-4">
                            <?php foreach (($analyticsData['userAnalytics']['topCustomers'] ?? []) as $index => $customer): ?>
                                <div class="tw-flex tw-items-center tw-justify-between tw-p-3 tw-bg-gray-50 tw-rounded-lg">
                                    <div class="tw-flex tw-items-center tw-space-x-3">
                                        <div class="tw-w-8 tw-h-8 tw-bg-green-100 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                                            <span class="tw-text-sm tw-font-semibold tw-text-green-600"><?= $index + 1 ?></span>
                                        </div>
                                        <div>
                                            <p class="tw-font-medium tw-text-gray-900"><?= htmlspecialchars(($customer['first_name'] ?? '') . ' ' . ($customer['last_name'] ?? '')) ?></p>
                                            <p class="tw-text-sm tw-text-gray-500"><?= number_format($customer['total_orders'] ?? 0) ?> orders</p>
                                        </div>
                                    </div>
                                    <div class="tw-text-right">
                                        <p class="tw-font-semibold tw-text-gray-900"><?= number_format($customer['total_spent'] ?? 0) ?> FCFA</p>
                                        <p class="tw-text-sm tw-text-gray-500"><?= number_format($customer['avg_order_value'] ?? 0) ?> avg</p>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- System Health -->
            <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                <div class="tw-p-6 tw-border-b tw-border-gray-200">
                    <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">System Health</h2>
                    <p class="tw-text-sm tw-text-gray-500">Platform performance metrics</p>
                </div>
                <div class="tw-p-6">
                    <div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-3 tw-gap-6">
                        <div class="tw-text-center">
                            <div class="tw-text-2xl tw-font-bold tw-text-green-600"><?= $analyticsData['performanceMetrics']['uptime'] ?? 99.8 ?>%</div>
                            <div class="tw-text-sm tw-text-gray-500">Uptime</div>
                        </div>
                        <div class="tw-text-center">
                            <div class="tw-text-2xl tw-font-bold tw-text-blue-600"><?= $analyticsData['performanceMetrics']['apiResponseTimes']['avg_response_time'] ?? 120 ?>ms</div>
                            <div class="tw-text-sm tw-text-gray-500">Avg Response Time</div>
                        </div>
                        <div class="tw-text-center">
                            <div class="tw-text-2xl tw-font-bold tw-text-orange-600"><?= $analyticsData['performanceMetrics']['errorRates']['error_rate'] ?? 0.45 ?>%</div>
                            <div class="tw-text-sm tw-text-gray-500">Error Rate</div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Chart.js Scripts -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Period selector change handler
    document.getElementById('periodSelector').addEventListener('change', function() {
        window.location.href = '?period=' + this.value;
    });

    // Export Excel handler
    document.getElementById('exportExcel').addEventListener('click', function() {
        window.location.href = '?period=<?= $currentPeriod ?>&export=excel';
    });

    <?php if (!$error && !empty($analyticsData)): ?>
    // Revenue Growth Chart
    const revenueCtx = document.getElementById('revenueChart').getContext('2d');
    new Chart(revenueCtx, {
        type: 'line',
        data: {
            labels: <?= json_encode(array_column($analyticsData['revenueAnalytics']['revenueGrowth'] ?? [], 'date')) ?>,
            datasets: [{
                label: 'Revenue',
                data: <?= json_encode(array_column($analyticsData['revenueAnalytics']['revenueGrowth'] ?? [], 'revenue')) ?>,
                borderColor: 'rgb(34, 197, 94)',
                backgroundColor: 'rgba(34, 197, 94, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return value.toLocaleString() + ' FCFA';
                        }
                    }
                }
            }
        }
    });

    // Order Trends Chart
    const orderCtx = document.getElementById('orderChart').getContext('2d');
    new Chart(orderCtx, {
        type: 'bar',
        data: {
            labels: <?= json_encode(array_column($analyticsData['orderAnalytics']['orderTrends'] ?? [], 'date')) ?>,
            datasets: [{
                label: 'Total Orders',
                data: <?= json_encode(array_column($analyticsData['orderAnalytics']['orderTrends'] ?? [], 'total_orders')) ?>,
                backgroundColor: 'rgba(59, 130, 246, 0.8)'
            }, {
                label: 'Completed Orders',
                data: <?= json_encode(array_column($analyticsData['orderAnalytics']['orderTrends'] ?? [], 'completed_orders')) ?>,
                backgroundColor: 'rgba(34, 197, 94, 0.8)'
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Peak Hours Chart
    const peakHoursCtx = document.getElementById('peakHoursChart').getContext('2d');
    new Chart(peakHoursCtx, {
        type: 'bar',
        data: {
            labels: <?= json_encode(array_map(function($h) { return $h . ':00'; }, array_column($analyticsData['orderAnalytics']['peakHours'] ?? [], 'hour'))) ?>,
            datasets: [{
                label: 'Orders',
                data: <?= json_encode(array_column($analyticsData['orderAnalytics']['peakHours'] ?? [], 'order_count')) ?>,
                backgroundColor: 'rgba(147, 51, 234, 0.8)'
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
    <?php endif; ?>
});
</script>

<?php include __DIR__ . '/../../layouts/admin_footer.php'; ?>
