<?php
/**
 * Admin Site Settings Management
 * Edit contact information and site configuration
 */

$title = $title ?? 'Site Settings - Time2Eat Admin';
$user = $user ?? [];
$settings = $settings ?? [];
$contactSettings = $contactSettings ?? [];

// Include header
include __DIR__ . '/../../layouts/admin_header.php';
?>

<div class="tw-min-h-screen tw-bg-gray-50">
    <!-- Header -->
    <div class="tw-bg-white tw-shadow-sm tw-border-b tw-border-gray-200">
        <div class="tw-max-w-7xl tw-mx-auto tw-px-4 sm:tw-px-6 lg:tw-px-8">
            <div class="tw-flex tw-justify-between tw-items-center tw-py-6">
                <div>
                    <h1 class="tw-text-3xl tw-font-bold tw-text-gray-900">Site Settings</h1>
                    <p class="tw-mt-1 tw-text-sm tw-text-gray-500">Manage site configuration and contact information</p>
                </div>
                <div class="tw-flex tw-space-x-3">
                    <button id="saveAllSettings" class="tw-bg-blue-600 tw-text-white tw-px-4 tw-py-2 tw-rounded-lg hover:tw-bg-blue-700 tw-transition-colors tw-flex tw-items-center tw-space-x-2">
                        <i data-feather="save" class="tw-h-4 tw-w-4"></i>
                        <span>Save All Changes</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="tw-max-w-7xl tw-mx-auto tw-px-4 sm:tw-px-6 lg:tw-px-8 tw-py-8">
        <form id="settingsForm" class="tw-space-y-8">
            <!-- General Settings -->
            <?php if (isset($settings['general'])): ?>
            <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                <div class="tw-p-6 tw-border-b tw-border-gray-200">
                    <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">General Settings</h2>
                    <p class="tw-text-sm tw-text-gray-500">Basic site information and branding</p>
                </div>
                <div class="tw-p-6">
                    <div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
                        <?php foreach ($settings['general'] as $key => $setting): ?>
                            <div>
                                <label class="tw-block tw-text-sm tw-font-medium tw-text-gray-700 tw-mb-2">
                                    <?= ucwords(str_replace('_', ' ', $key)) ?>
                                </label>
                                <?php if ($setting['type'] === 'text'): ?>
                                    <textarea name="<?= htmlspecialchars($key) ?>" rows="3"
                                              class="tw-w-full tw-p-3 tw-border tw-border-gray-300 tw-rounded-lg focus:tw-ring-blue-500 focus:tw-border-blue-500"><?= htmlspecialchars($setting['value']) ?></textarea>
                                <?php elseif ($setting['type'] === 'boolean'): ?>
                                    <select name="<?= htmlspecialchars($key) ?>"
                                            class="tw-w-full tw-p-3 tw-border tw-border-gray-300 tw-rounded-lg focus:tw-ring-blue-500 focus:tw-border-blue-500">
                                        <option value="1" <?= $setting['value'] ? 'selected' : '' ?>>Yes</option>
                                        <option value="0" <?= !$setting['value'] ? 'selected' : '' ?>>No</option>
                                    </select>
                                <?php else: ?>
                                    <input type="<?= $setting['type'] === 'integer' ? 'number' : ($setting['type'] === 'float' ? 'number' : 'text') ?>"
                                           name="<?= htmlspecialchars($key) ?>"
                                           value="<?= htmlspecialchars($setting['value']) ?>"
                                           <?= $setting['type'] === 'float' ? 'step="0.01"' : '' ?>
                                           class="tw-w-full tw-p-3 tw-border tw-border-gray-300 tw-rounded-lg focus:tw-ring-blue-500 focus:tw-border-blue-500">
                                <?php endif; ?>
                                <?php if ($setting['description']): ?>
                                    <p class="tw-text-xs tw-text-gray-500 tw-mt-1"><?= htmlspecialchars($setting['description']) ?></p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Contact Settings -->
            <?php if (isset($settings['contact'])): ?>
            <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                <div class="tw-p-6 tw-border-b tw-border-gray-200">
                    <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Contact Information</h2>
                    <p class="tw-text-sm tw-text-gray-500">Customer support and business contact details</p>
                </div>
                <div class="tw-p-6">
                    <div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
                        <?php foreach ($settings['contact'] as $key => $setting): ?>
                            <div>
                                <label class="tw-block tw-text-sm tw-font-medium tw-text-gray-700 tw-mb-2">
                                    <?= ucwords(str_replace('_', ' ', $key)) ?>
                                </label>
                                <?php if ($key === 'contact_address'): ?>
                                    <textarea name="<?= htmlspecialchars($key) ?>" rows="3"
                                              class="tw-w-full tw-p-3 tw-border tw-border-gray-300 tw-rounded-lg focus:tw-ring-blue-500 focus:tw-border-blue-500"><?= htmlspecialchars($setting['value']) ?></textarea>
                                <?php elseif (strpos($key, 'email') !== false): ?>
                                    <input type="email" name="<?= htmlspecialchars($key) ?>"
                                           value="<?= htmlspecialchars($setting['value']) ?>"
                                           class="tw-w-full tw-p-3 tw-border tw-border-gray-300 tw-rounded-lg focus:tw-ring-blue-500 focus:tw-border-blue-500">
                                <?php elseif (strpos($key, 'phone') !== false || strpos($key, 'whatsapp') !== false): ?>
                                    <input type="tel" name="<?= htmlspecialchars($key) ?>"
                                           value="<?= htmlspecialchars($setting['value']) ?>"
                                           class="tw-w-full tw-p-3 tw-border tw-border-gray-300 tw-rounded-lg focus:tw-ring-blue-500 focus:tw-border-blue-500">
                                <?php else: ?>
                                    <input type="text" name="<?= htmlspecialchars($key) ?>"
                                           value="<?= htmlspecialchars($setting['value']) ?>"
                                           class="tw-w-full tw-p-3 tw-border tw-border-gray-300 tw-rounded-lg focus:tw-ring-blue-500 focus:tw-border-blue-500">
                                <?php endif; ?>
                                <?php if ($setting['description']): ?>
                                    <p class="tw-text-xs tw-text-gray-500 tw-mt-1"><?= htmlspecialchars($setting['description']) ?></p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Business Settings -->
            <?php if (isset($settings['business'])): ?>
            <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                <div class="tw-p-6 tw-border-b tw-border-gray-200">
                    <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Business Settings</h2>
                    <p class="tw-text-sm tw-text-gray-500">Pricing, fees, and business configuration</p>
                </div>
                <div class="tw-p-6">
                    <div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
                        <?php foreach ($settings['business'] as $key => $setting): ?>
                            <div>
                                <label class="tw-block tw-text-sm tw-font-medium tw-text-gray-700 tw-mb-2">
                                    <?= ucwords(str_replace('_', ' ', $key)) ?>
                                </label>
                                <?php if ($setting['type'] === 'integer'): ?>
                                    <div class="tw-relative">
                                        <input type="number" name="<?= htmlspecialchars($key) ?>"
                                               value="<?= htmlspecialchars($setting['value']) ?>"
                                               class="tw-w-full tw-p-3 tw-border tw-border-gray-300 tw-rounded-lg focus:tw-ring-blue-500 focus:tw-border-blue-500">
                                        <?php if (strpos($key, 'fee') !== false || strpos($key, 'minimum') !== false): ?>
                                            <span class="tw-absolute tw-right-3 tw-top-3 tw-text-gray-500">FCFA</span>
                                        <?php elseif (strpos($key, 'distance') !== false): ?>
                                            <span class="tw-absolute tw-right-3 tw-top-3 tw-text-gray-500">KM</span>
                                        <?php elseif (strpos($key, 'timeout') !== false): ?>
                                            <span class="tw-absolute tw-right-3 tw-top-3 tw-text-gray-500">min</span>
                                        <?php endif; ?>
                                    </div>
                                <?php elseif ($setting['type'] === 'float'): ?>
                                    <div class="tw-relative">
                                        <input type="number" step="0.01" name="<?= htmlspecialchars($key) ?>"
                                               value="<?= htmlspecialchars($setting['value']) ?>"
                                               class="tw-w-full tw-p-3 tw-border tw-border-gray-300 tw-rounded-lg focus:tw-ring-blue-500 focus:tw-border-blue-500">
                                        <?php if (strpos($key, 'rate') !== false): ?>
                                            <span class="tw-absolute tw-right-3 tw-top-3 tw-text-gray-500">%</span>
                                        <?php endif; ?>
                                    </div>
                                <?php else: ?>
                                    <input type="text" name="<?= htmlspecialchars($key) ?>"
                                           value="<?= htmlspecialchars($setting['value']) ?>"
                                           class="tw-w-full tw-p-3 tw-border tw-border-gray-300 tw-rounded-lg focus:tw-ring-blue-500 focus:tw-border-blue-500">
                                <?php endif; ?>
                                <?php if ($setting['description']): ?>
                                    <p class="tw-text-xs tw-text-gray-500 tw-mt-1"><?= htmlspecialchars($setting['description']) ?></p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Email Settings -->
            <?php if (isset($settings['email'])): ?>
            <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                <div class="tw-p-6 tw-border-b tw-border-gray-200">
                    <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Email Settings</h2>
                    <p class="tw-text-sm tw-text-gray-500">SMTP configuration for email notifications</p>
                </div>
                <div class="tw-p-6">
                    <div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
                        <?php foreach ($settings['email'] as $key => $setting): ?>
                            <div>
                                <label class="tw-block tw-text-sm tw-font-medium tw-text-gray-700 tw-mb-2">
                                    <?= ucwords(str_replace(['_', 'smtp'], [' ', 'SMTP'], $key)) ?>
                                </label>
                                <?php if ($key === 'smtp_password'): ?>
                                    <input type="password" name="<?= htmlspecialchars($key) ?>"
                                           value="<?= htmlspecialchars($setting['value']) ?>"
                                           class="tw-w-full tw-p-3 tw-border tw-border-gray-300 tw-rounded-lg focus:tw-ring-blue-500 focus:tw-border-blue-500">
                                <?php elseif ($key === 'smtp_port'): ?>
                                    <input type="number" name="<?= htmlspecialchars($key) ?>"
                                           value="<?= htmlspecialchars($setting['value']) ?>"
                                           class="tw-w-full tw-p-3 tw-border tw-border-gray-300 tw-rounded-lg focus:tw-ring-blue-500 focus:tw-border-blue-500">
                                <?php elseif ($key === 'smtp_encryption'): ?>
                                    <select name="<?= htmlspecialchars($key) ?>"
                                            class="tw-w-full tw-p-3 tw-border tw-border-gray-300 tw-rounded-lg focus:tw-ring-blue-500 focus:tw-border-blue-500">
                                        <option value="tls" <?= $setting['value'] === 'tls' ? 'selected' : '' ?>>TLS</option>
                                        <option value="ssl" <?= $setting['value'] === 'ssl' ? 'selected' : '' ?>>SSL</option>
                                        <option value="" <?= empty($setting['value']) ? 'selected' : '' ?>>None</option>
                                    </select>
                                <?php elseif (strpos($key, 'email') !== false): ?>
                                    <input type="email" name="<?= htmlspecialchars($key) ?>"
                                           value="<?= htmlspecialchars($setting['value']) ?>"
                                           class="tw-w-full tw-p-3 tw-border tw-border-gray-300 tw-rounded-lg focus:tw-ring-blue-500 focus:tw-border-blue-500">
                                <?php else: ?>
                                    <input type="text" name="<?= htmlspecialchars($key) ?>"
                                           value="<?= htmlspecialchars($setting['value']) ?>"
                                           class="tw-w-full tw-p-3 tw-border tw-border-gray-300 tw-rounded-lg focus:tw-ring-blue-500 focus:tw-border-blue-500">
                                <?php endif; ?>
                                <?php if ($setting['description']): ?>
                                    <p class="tw-text-xs tw-text-gray-500 tw-mt-1"><?= htmlspecialchars($setting['description']) ?></p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Social Media Settings -->
            <?php if (isset($settings['social'])): ?>
            <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                <div class="tw-p-6 tw-border-b tw-border-gray-200">
                    <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Social Media</h2>
                    <p class="tw-text-sm tw-text-gray-500">Social media profiles and links</p>
                </div>
                <div class="tw-p-6">
                    <div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
                        <?php foreach ($settings['social'] as $key => $setting): ?>
                            <div>
                                <label class="tw-block tw-text-sm tw-font-medium tw-text-gray-700 tw-mb-2">
                                    <?= ucwords(str_replace('_url', '', $key)) ?> URL
                                </label>
                                <input type="url" name="<?= htmlspecialchars($key) ?>"
                                       value="<?= htmlspecialchars($setting['value']) ?>"
                                       placeholder="https://..."
                                       class="tw-w-full tw-p-3 tw-border tw-border-gray-300 tw-rounded-lg focus:tw-ring-blue-500 focus:tw-border-blue-500">
                                <?php if ($setting['description']): ?>
                                    <p class="tw-text-xs tw-text-gray-500 tw-mt-1"><?= htmlspecialchars($setting['description']) ?></p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- System Settings -->
            <?php if (isset($settings['system'])): ?>
            <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                <div class="tw-p-6 tw-border-b tw-border-gray-200">
                    <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">System Settings</h2>
                    <p class="tw-text-sm tw-text-gray-500">System configuration and maintenance options</p>
                </div>
                <div class="tw-p-6">
                    <div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
                        <?php foreach ($settings['system'] as $key => $setting): ?>
                            <div>
                                <label class="tw-block tw-text-sm tw-font-medium tw-text-gray-700 tw-mb-2">
                                    <?= ucwords(str_replace('_', ' ', $key)) ?>
                                </label>
                                <?php if ($setting['type'] === 'boolean'): ?>
                                    <select name="<?= htmlspecialchars($key) ?>"
                                            class="tw-w-full tw-p-3 tw-border tw-border-gray-300 tw-rounded-lg focus:tw-ring-blue-500 focus:tw-border-blue-500">
                                        <option value="1" <?= $setting['value'] ? 'selected' : '' ?>>Enabled</option>
                                        <option value="0" <?= !$setting['value'] ? 'selected' : '' ?>>Disabled</option>
                                    </select>
                                <?php elseif ($key === 'backup_frequency'): ?>
                                    <select name="<?= htmlspecialchars($key) ?>"
                                            class="tw-w-full tw-p-3 tw-border tw-border-gray-300 tw-rounded-lg focus:tw-ring-blue-500 focus:tw-border-blue-500">
                                        <option value="hourly" <?= $setting['value'] === 'hourly' ? 'selected' : '' ?>>Hourly</option>
                                        <option value="daily" <?= $setting['value'] === 'daily' ? 'selected' : '' ?>>Daily</option>
                                        <option value="weekly" <?= $setting['value'] === 'weekly' ? 'selected' : '' ?>>Weekly</option>
                                        <option value="monthly" <?= $setting['value'] === 'monthly' ? 'selected' : '' ?>>Monthly</option>
                                    </select>
                                <?php elseif ($setting['type'] === 'integer'): ?>
                                    <input type="number" name="<?= htmlspecialchars($key) ?>"
                                           value="<?= htmlspecialchars($setting['value']) ?>"
                                           class="tw-w-full tw-p-3 tw-border tw-border-gray-300 tw-rounded-lg focus:tw-ring-blue-500 focus:tw-border-blue-500">
                                <?php else: ?>
                                    <input type="text" name="<?= htmlspecialchars($key) ?>"
                                           value="<?= htmlspecialchars($setting['value']) ?>"
                                           class="tw-w-full tw-p-3 tw-border tw-border-gray-300 tw-rounded-lg focus:tw-ring-blue-500 focus:tw-border-blue-500">
                                <?php endif; ?>
                                <?php if ($setting['description']): ?>
                                    <p class="tw-text-xs tw-text-gray-500 tw-mt-1"><?= htmlspecialchars($setting['description']) ?></p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Save Button -->
            <div class="tw-flex tw-justify-end tw-space-x-3">
                <button type="button" id="resetSettings" class="tw-px-6 tw-py-3 tw-bg-gray-300 tw-text-gray-700 tw-rounded-lg hover:tw-bg-gray-400 tw-transition-colors">
                    Reset Changes
                </button>
                <button type="submit" class="tw-px-6 tw-py-3 tw-bg-blue-600 tw-text-white tw-rounded-lg hover:tw-bg-blue-700 tw-transition-colors tw-flex tw-items-center tw-space-x-2">
                    <i data-feather="save" class="tw-h-4 tw-w-4"></i>
                    <span>Save All Settings</span>
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Success/Error Messages -->
<div id="messageContainer" class="tw-fixed tw-top-4 tw-right-4 tw-z-50"></div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('settingsForm');
    const originalFormData = new FormData(form);

    // Save settings
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        saveSettings();
    });

    // Save all settings button
    document.getElementById('saveAllSettings').addEventListener('click', function() {
        saveSettings();
    });

    // Reset settings
    document.getElementById('resetSettings').addEventListener('click', function() {
        if (confirm('Are you sure you want to reset all changes?')) {
            form.reset();
            // Restore original values
            for (let [key, value] of originalFormData.entries()) {
                const field = form.querySelector(`[name="${key}"]`);
                if (field) {
                    field.value = value;
                }
            }
        }
    });

    function saveSettings() {
        const formData = new FormData(form);
        formData.append('action', 'update');

        // Show loading state
        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<div class="tw-animate-spin tw-rounded-full tw-h-4 tw-w-4 tw-border-b-2 tw-border-white tw-mr-2"></div>Saving...';
        submitBtn.disabled = true;

        fetch('/admin/tools/settings', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showMessage('Settings saved successfully!', 'success');
                // Update original form data
                originalFormData = new FormData(form);
            } else {
                showMessage('Error: ' + (data.message || 'Failed to save settings'), 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showMessage('An error occurred while saving settings.', 'error');
        })
        .finally(() => {
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        });
    }

    function showMessage(message, type) {
        const messageContainer = document.getElementById('messageContainer');
        const messageDiv = document.createElement('div');
        
        const bgColor = type === 'success' ? 'tw-bg-green-500' : 'tw-bg-red-500';
        const icon = type === 'success' ? 'check-circle' : 'x-circle';
        
        messageDiv.className = `tw-flex tw-items-center tw-p-4 tw-mb-4 tw-text-white tw-rounded-lg tw-shadow-lg ${bgColor}`;
        messageDiv.innerHTML = `
            <i data-feather="${icon}" class="tw-h-5 tw-w-5 tw-mr-3"></i>
            <span>${message}</span>
            <button class="tw-ml-auto tw-text-white hover:tw-text-gray-200" onclick="this.parentElement.remove()">
                <i data-feather="x" class="tw-h-4 tw-w-4"></i>
            </button>
        `;
        
        messageContainer.appendChild(messageDiv);
        
        // Initialize Feather icons for the new message
        feather.replace();
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (messageDiv.parentElement) {
                messageDiv.remove();
            }
        }, 5000);
    }

    // Track form changes
    let hasUnsavedChanges = false;
    
    form.addEventListener('input', function() {
        hasUnsavedChanges = true;
    });

    // Warn about unsaved changes
    window.addEventListener('beforeunload', function(e) {
        if (hasUnsavedChanges) {
            e.preventDefault();
            e.returnValue = '';
        }
    });

    // Reset unsaved changes flag when form is submitted
    form.addEventListener('submit', function() {
        hasUnsavedChanges = false;
    });
});
</script>

<?php include __DIR__ . '/../../layouts/admin_footer.php'; ?>
