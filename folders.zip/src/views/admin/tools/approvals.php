<?php
/**
 * Admin Approvals Management
 * User and restaurant approval interface
 */

$title = $title ?? 'Approvals Management - Time2Eat Admin';
$user = $user ?? [];
$pendingUsers = $pendingUsers ?? [];
$pendingRestaurants = $pendingRestaurants ?? [];
$pendingRoleChanges = $pendingRoleChanges ?? [];
$currentType = $currentType ?? 'users';

// Include header
include __DIR__ . '/../../layouts/admin_header.php';
?>

<div class="tw-min-h-screen tw-bg-gray-50">
    <!-- Header -->
    <div class="tw-bg-white tw-shadow-sm tw-border-b tw-border-gray-200">
        <div class="tw-max-w-7xl tw-mx-auto tw-px-4 sm:tw-px-6 lg:tw-px-8">
            <div class="tw-flex tw-justify-between tw-items-center tw-py-6">
                <div>
                    <h1 class="tw-text-3xl tw-font-bold tw-text-gray-900">Approvals Management</h1>
                    <p class="tw-mt-1 tw-text-sm tw-text-gray-500">Review and approve user registrations and restaurant applications</p>
                </div>
                <div class="tw-flex tw-space-x-2">
                    <span class="tw-inline-flex tw-items-center tw-px-3 tw-py-1 tw-rounded-full tw-text-sm tw-font-medium tw-bg-red-100 tw-text-red-800">
                        <?= count($pendingUsers) + count($pendingRestaurants) + count($pendingRoleChanges) ?> Pending
                    </span>
                </div>
            </div>
        </div>
    </div>

    <div class="tw-max-w-7xl tw-mx-auto tw-px-4 sm:tw-px-6 lg:tw-px-8 tw-py-8">
        <!-- Tab Navigation -->
        <div class="tw-mb-8">
            <nav class="tw-flex tw-space-x-8">
                <button class="approval-tab tw-px-3 tw-py-2 tw-text-sm tw-font-medium tw-rounded-md <?= $currentType === 'users' ? 'tw-bg-blue-100 tw-text-blue-700' : 'tw-text-gray-500 hover:tw-text-gray-700' ?>" 
                        data-tab="users">
                    User Registrations
                    <?php if (count($pendingUsers) > 0): ?>
                        <span class="tw-ml-2 tw-inline-flex tw-items-center tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium tw-bg-red-100 tw-text-red-800">
                            <?= count($pendingUsers) ?>
                        </span>
                    <?php endif; ?>
                </button>
                
                <button class="approval-tab tw-px-3 tw-py-2 tw-text-sm tw-font-medium tw-rounded-md <?= $currentType === 'restaurants' ? 'tw-bg-blue-100 tw-text-blue-700' : 'tw-text-gray-500 hover:tw-text-gray-700' ?>" 
                        data-tab="restaurants">
                    Restaurant Applications
                    <?php if (count($pendingRestaurants) > 0): ?>
                        <span class="tw-ml-2 tw-inline-flex tw-items-center tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium tw-bg-red-100 tw-text-red-800">
                            <?= count($pendingRestaurants) ?>
                        </span>
                    <?php endif; ?>
                </button>
                
                <button class="approval-tab tw-px-3 tw-py-2 tw-text-sm tw-font-medium tw-rounded-md <?= $currentType === 'role_changes' ? 'tw-bg-blue-100 tw-text-blue-700' : 'tw-text-gray-500 hover:tw-text-gray-700' ?>" 
                        data-tab="role_changes">
                    Role Changes
                    <?php if (count($pendingRoleChanges) > 0): ?>
                        <span class="tw-ml-2 tw-inline-flex tw-items-center tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium tw-bg-red-100 tw-text-red-800">
                            <?= count($pendingRoleChanges) ?>
                        </span>
                    <?php endif; ?>
                </button>
            </nav>
        </div>

        <!-- User Registrations Tab -->
        <div id="users-tab" class="tab-content <?= $currentType === 'users' ? '' : 'tw-hidden' ?>">
            <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                <div class="tw-p-6 tw-border-b tw-border-gray-200">
                    <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Pending User Registrations</h2>
                    <p class="tw-text-sm tw-text-gray-500">Review and approve new user accounts</p>
                </div>
                <div class="tw-p-6">
                    <?php if (empty($pendingUsers)): ?>
                        <div class="tw-text-center tw-py-12">
                            <i data-feather="check-circle" class="tw-h-12 tw-w-12 tw-text-green-400 tw-mx-auto tw-mb-4"></i>
                            <h3 class="tw-text-lg tw-font-medium tw-text-gray-900 tw-mb-2">No Pending Users</h3>
                            <p class="tw-text-gray-500">All user registrations have been processed.</p>
                        </div>
                    <?php else: ?>
                        <div class="tw-space-y-4">
                            <?php foreach ($pendingUsers as $pendingUser): ?>
                                <div class="tw-border tw-border-gray-200 tw-rounded-lg tw-p-4">
                                    <div class="tw-flex tw-items-center tw-justify-between">
                                        <div class="tw-flex tw-items-center tw-space-x-4">
                                            <div class="tw-w-12 tw-h-12 tw-bg-gray-200 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                                                <i data-feather="user" class="tw-h-6 tw-w-6 tw-text-gray-500"></i>
                                            </div>
                                            <div>
                                                <h3 class="tw-font-medium tw-text-gray-900">
                                                    <?= htmlspecialchars(($pendingUser['first_name'] ?? '') . ' ' . ($pendingUser['last_name'] ?? '')) ?>
                                                </h3>
                                                <p class="tw-text-sm tw-text-gray-500"><?= htmlspecialchars($pendingUser['email'] ?? '') ?></p>
                                                <div class="tw-flex tw-items-center tw-space-x-4 tw-mt-1">
                                                    <span class="tw-inline-flex tw-items-center tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium tw-bg-blue-100 tw-text-blue-800">
                                                        <?= ucfirst($pendingUser['role'] ?? 'customer') ?>
                                                    </span>
                                                    <span class="tw-text-xs tw-text-gray-500">
                                                        Registered: <?= date('M j, Y', strtotime($pendingUser['created_at'] ?? '')) ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tw-flex tw-space-x-2">
                                            <button class="approve-user tw-bg-green-600 tw-text-white tw-px-4 tw-py-2 tw-rounded-lg hover:tw-bg-green-700 tw-transition-colors tw-text-sm"
                                                    data-id="<?= $pendingUser['id'] ?>" data-type="user">
                                                Approve
                                            </button>
                                            <button class="reject-user tw-bg-red-600 tw-text-white tw-px-4 tw-py-2 tw-rounded-lg hover:tw-bg-red-700 tw-transition-colors tw-text-sm"
                                                    data-id="<?= $pendingUser['id'] ?>" data-type="user">
                                                Reject
                                            </button>
                                        </div>
                                    </div>
                                    <?php if (!empty($pendingUser['phone'])): ?>
                                        <div class="tw-mt-3 tw-text-sm tw-text-gray-600">
                                            <span class="tw-font-medium">Phone:</span> <?= htmlspecialchars($pendingUser['phone']) ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Restaurant Applications Tab -->
        <div id="restaurants-tab" class="tab-content <?= $currentType === 'restaurants' ? '' : 'tw-hidden' ?>">
            <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                <div class="tw-p-6 tw-border-b tw-border-gray-200">
                    <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Pending Restaurant Applications</h2>
                    <p class="tw-text-sm tw-text-gray-500">Review and approve restaurant registrations</p>
                </div>
                <div class="tw-p-6">
                    <?php if (empty($pendingRestaurants)): ?>
                        <div class="tw-text-center tw-py-12">
                            <i data-feather="check-circle" class="tw-h-12 tw-w-12 tw-text-green-400 tw-mx-auto tw-mb-4"></i>
                            <h3 class="tw-text-lg tw-font-medium tw-text-gray-900 tw-mb-2">No Pending Restaurants</h3>
                            <p class="tw-text-gray-500">All restaurant applications have been processed.</p>
                        </div>
                    <?php else: ?>
                        <div class="tw-space-y-6">
                            <?php foreach ($pendingRestaurants as $restaurant): ?>
                                <div class="tw-border tw-border-gray-200 tw-rounded-lg tw-p-6">
                                    <div class="tw-flex tw-items-start tw-justify-between">
                                        <div class="tw-flex tw-space-x-4">
                                            <div class="tw-w-16 tw-h-16 tw-bg-gray-200 tw-rounded-lg tw-flex tw-items-center tw-justify-center">
                                                <?php if (!empty($restaurant['image'])): ?>
                                                    <img src="<?= htmlspecialchars($restaurant['image']) ?>" alt="Restaurant" class="tw-w-full tw-h-full tw-object-cover tw-rounded-lg">
                                                <?php else: ?>
                                                    <i data-feather="store" class="tw-h-8 tw-w-8 tw-text-gray-500"></i>
                                                <?php endif; ?>
                                            </div>
                                            <div class="tw-flex-1">
                                                <h3 class="tw-font-semibold tw-text-gray-900 tw-text-lg">
                                                    <?= htmlspecialchars($restaurant['name'] ?? '') ?>
                                                </h3>
                                                <p class="tw-text-sm tw-text-gray-600 tw-mt-1">
                                                    <?= htmlspecialchars($restaurant['description'] ?? '') ?>
                                                </p>
                                                <div class="tw-mt-3 tw-space-y-2">
                                                    <div class="tw-flex tw-items-center tw-text-sm tw-text-gray-600">
                                                        <i data-feather="map-pin" class="tw-h-4 tw-w-4 tw-mr-2"></i>
                                                        <?= htmlspecialchars($restaurant['address'] ?? '') ?>
                                                    </div>
                                                    <div class="tw-flex tw-items-center tw-text-sm tw-text-gray-600">
                                                        <i data-feather="phone" class="tw-h-4 tw-w-4 tw-mr-2"></i>
                                                        <?= htmlspecialchars($restaurant['phone'] ?? '') ?>
                                                    </div>
                                                    <div class="tw-flex tw-items-center tw-text-sm tw-text-gray-600">
                                                        <i data-feather="user" class="tw-h-4 tw-w-4 tw-mr-2"></i>
                                                        Owner: <?= htmlspecialchars(($restaurant['owner_first_name'] ?? '') . ' ' . ($restaurant['owner_last_name'] ?? '')) ?>
                                                    </div>
                                                </div>
                                                <div class="tw-mt-3 tw-flex tw-items-center tw-space-x-4">
                                                    <span class="tw-inline-flex tw-items-center tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium tw-bg-orange-100 tw-text-orange-800">
                                                        <?= ucfirst($restaurant['cuisine_type'] ?? 'General') ?>
                                                    </span>
                                                    <span class="tw-text-xs tw-text-gray-500">
                                                        Applied: <?= date('M j, Y', strtotime($restaurant['created_at'] ?? '')) ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tw-flex tw-flex-col tw-space-y-2">
                                            <button class="approve-restaurant tw-bg-green-600 tw-text-white tw-px-4 tw-py-2 tw-rounded-lg hover:tw-bg-green-700 tw-transition-colors tw-text-sm"
                                                    data-id="<?= $restaurant['id'] ?>" data-type="restaurant">
                                                Approve
                                            </button>
                                            <button class="reject-restaurant tw-bg-red-600 tw-text-white tw-px-4 tw-py-2 tw-rounded-lg hover:tw-bg-red-700 tw-transition-colors tw-text-sm"
                                                    data-id="<?= $restaurant['id'] ?>" data-type="restaurant">
                                                Reject
                                            </button>
                                            <button class="view-details tw-bg-gray-600 tw-text-white tw-px-4 tw-py-2 tw-rounded-lg hover:tw-bg-gray-700 tw-transition-colors tw-text-sm"
                                                    data-id="<?= $restaurant['id'] ?>">
                                                View Details
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Role Changes Tab -->
        <div id="role_changes-tab" class="tab-content <?= $currentType === 'role_changes' ? '' : 'tw-hidden' ?>">
            <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                <div class="tw-p-6 tw-border-b tw-border-gray-200">
                    <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Pending Role Changes</h2>
                    <p class="tw-text-sm tw-text-gray-500">Review and approve user role change requests</p>
                </div>
                <div class="tw-p-6">
                    <?php if (empty($pendingRoleChanges)): ?>
                        <div class="tw-text-center tw-py-12">
                            <i data-feather="check-circle" class="tw-h-12 tw-w-12 tw-text-green-400 tw-mx-auto tw-mb-4"></i>
                            <h3 class="tw-text-lg tw-font-medium tw-text-gray-900 tw-mb-2">No Pending Role Changes</h3>
                            <p class="tw-text-gray-500">All role change requests have been processed.</p>
                        </div>
                    <?php else: ?>
                        <div class="tw-space-y-4">
                            <?php foreach ($pendingRoleChanges as $roleChange): ?>
                                <div class="tw-border tw-border-gray-200 tw-rounded-lg tw-p-4">
                                    <div class="tw-flex tw-items-center tw-justify-between">
                                        <div class="tw-flex tw-items-center tw-space-x-4">
                                            <div class="tw-w-12 tw-h-12 tw-bg-gray-200 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                                                <i data-feather="user" class="tw-h-6 tw-w-6 tw-text-gray-500"></i>
                                            </div>
                                            <div>
                                                <h3 class="tw-font-medium tw-text-gray-900">
                                                    <?= htmlspecialchars(($roleChange['first_name'] ?? '') . ' ' . ($roleChange['last_name'] ?? '')) ?>
                                                </h3>
                                                <p class="tw-text-sm tw-text-gray-500"><?= htmlspecialchars($roleChange['email'] ?? '') ?></p>
                                                <div class="tw-flex tw-items-center tw-space-x-2 tw-mt-1">
                                                    <span class="tw-inline-flex tw-items-center tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium tw-bg-gray-100 tw-text-gray-800">
                                                        From: <?= ucfirst($roleChange['current_role'] ?? '') ?>
                                                    </span>
                                                    <i data-feather="arrow-right" class="tw-h-4 tw-w-4 tw-text-gray-400"></i>
                                                    <span class="tw-inline-flex tw-items-center tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium tw-bg-blue-100 tw-text-blue-800">
                                                        To: <?= ucfirst($roleChange['requested_role'] ?? '') ?>
                                                    </span>
                                                </div>
                                                <p class="tw-text-xs tw-text-gray-500 tw-mt-1">
                                                    Requested: <?= date('M j, Y', strtotime($roleChange['requested_at'] ?? '')) ?>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="tw-flex tw-space-x-2">
                                            <button class="approve-role-change tw-bg-green-600 tw-text-white tw-px-4 tw-py-2 tw-rounded-lg hover:tw-bg-green-700 tw-transition-colors tw-text-sm"
                                                    data-id="<?= $roleChange['id'] ?>" data-type="role_change">
                                                Approve
                                            </button>
                                            <button class="reject-role-change tw-bg-red-600 tw-text-white tw-px-4 tw-py-2 tw-rounded-lg hover:tw-bg-red-700 tw-transition-colors tw-text-sm"
                                                    data-id="<?= $roleChange['id'] ?>" data-type="role_change">
                                                Reject
                                            </button>
                                        </div>
                                    </div>
                                    <?php if (!empty($roleChange['reason'])): ?>
                                        <div class="tw-mt-3 tw-p-3 tw-bg-gray-50 tw-rounded-lg">
                                            <p class="tw-text-sm tw-text-gray-700">
                                                <span class="tw-font-medium">Reason:</span> <?= htmlspecialchars($roleChange['reason']) ?>
                                            </p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Rejection Modal -->
<div id="rejectionModal" class="tw-fixed tw-inset-0 tw-bg-gray-600 tw-bg-opacity-50 tw-overflow-y-auto tw-h-full tw-w-full tw-hidden">
    <div class="tw-relative tw-top-20 tw-mx-auto tw-p-5 tw-border tw-w-96 tw-shadow-lg tw-rounded-md tw-bg-white">
        <div class="tw-mt-3">
            <h3 class="tw-text-lg tw-font-medium tw-text-gray-900 tw-mb-4">Rejection Reason</h3>
            <textarea id="rejectionReason" class="tw-w-full tw-p-3 tw-border tw-border-gray-300 tw-rounded-lg tw-resize-none" 
                      rows="4" placeholder="Please provide a reason for rejection..."></textarea>
            <div class="tw-flex tw-justify-end tw-space-x-3 tw-mt-4">
                <button id="cancelRejection" class="tw-px-4 tw-py-2 tw-bg-gray-300 tw-text-gray-700 tw-rounded-lg hover:tw-bg-gray-400">
                    Cancel
                </button>
                <button id="confirmRejection" class="tw-px-4 tw-py-2 tw-bg-red-600 tw-text-white tw-rounded-lg hover:tw-bg-red-700">
                    Reject
                </button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    let currentRejectionData = null;

    // Tab switching
    document.querySelectorAll('.approval-tab').forEach(tab => {
        tab.addEventListener('click', function() {
            const tabName = this.dataset.tab;
            
            // Update active tab
            document.querySelectorAll('.approval-tab').forEach(t => {
                t.classList.remove('tw-bg-blue-100', 'tw-text-blue-700');
                t.classList.add('tw-text-gray-500', 'hover:tw-text-gray-700');
            });
            this.classList.add('tw-bg-blue-100', 'tw-text-blue-700');
            this.classList.remove('tw-text-gray-500', 'hover:tw-text-gray-700');
            
            // Show/hide tab content
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.add('tw-hidden');
            });
            document.getElementById(tabName + '-tab').classList.remove('tw-hidden');
        });
    });

    // Approval handlers
    document.querySelectorAll('.approve-user, .approve-restaurant, .approve-role-change').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.dataset.id;
            const type = this.dataset.type;
            const action = type === 'user' ? 'approve_user' : 
                          type === 'restaurant' ? 'approve_restaurant' : 'approve_role_change';
            
            if (confirm('Are you sure you want to approve this ' + type + '?')) {
                processApproval(action, id, type);
            }
        });
    });

    // Rejection handlers
    document.querySelectorAll('.reject-user, .reject-restaurant, .reject-role-change').forEach(btn => {
        btn.addEventListener('click', function() {
            currentRejectionData = {
                id: this.dataset.id,
                type: this.dataset.type,
                action: this.dataset.type === 'user' ? 'reject_user' : 
                       this.dataset.type === 'restaurant' ? 'reject_restaurant' : 'reject_role_change'
            };
            
            document.getElementById('rejectionModal').classList.remove('tw-hidden');
        });
    });

    // Modal handlers
    document.getElementById('cancelRejection').addEventListener('click', function() {
        document.getElementById('rejectionModal').classList.add('tw-hidden');
        document.getElementById('rejectionReason').value = '';
        currentRejectionData = null;
    });

    document.getElementById('confirmRejection').addEventListener('click', function() {
        const reason = document.getElementById('rejectionReason').value.trim();
        if (!reason) {
            alert('Please provide a reason for rejection.');
            return;
        }
        
        if (currentRejectionData) {
            processApproval(currentRejectionData.action, currentRejectionData.id, currentRejectionData.type, reason);
        }
        
        document.getElementById('rejectionModal').classList.add('tw-hidden');
        document.getElementById('rejectionReason').value = '';
        currentRejectionData = null;
    });

    function processApproval(action, id, type, reason = null) {
        const formData = new FormData();
        formData.append('action', action);
        formData.append('id', id);
        formData.append('type', type);
        if (reason) {
            formData.append('reason', reason);
        }

        fetch('/admin/tools/approvals', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while processing the request.');
        });
    }
});
</script>

<?php include __DIR__ . '/../../layouts/admin_footer.php'; ?>
