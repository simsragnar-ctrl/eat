<?php
$title = $title ?? 'Checkout - Time2Eat';
$user = $user ?? null;
$cartItems = $cartItems ?? [];
$cartTotals = $cartTotals ?? [];
$addresses = $addresses ?? [];
$paymentMethods = $paymentMethods ?? [];
$appliedPromo = $appliedPromo ?? null;
$discount = $discount ?? 0;
?>

<!DOCTYPE html>
<html lang="en" class="tw-h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title) ?></title>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            prefix: 'tw-',
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#fff7ed',
                            500: '#f97316',
                            600: '#ea580c',
                            700: '#c2410c'
                        }
                    }
                }
            }
        }
    </script>
    
    <!-- Feather Icons -->
    <script src="https://unpkg.com/feather-icons"></script>
</head>
<body class="tw-min-h-full tw-bg-gray-50">
    <!-- Header -->
    <header class="tw-bg-white tw-shadow-sm tw-border-b tw-border-gray-200">
        <div class="tw-max-w-7xl tw-mx-auto tw-px-4 sm:tw-px-6 lg:tw-px-8">
            <div class="tw-flex tw-justify-between tw-items-center tw-py-4">
                <div class="tw-flex tw-items-center">
                    <a href="/" class="tw-flex tw-items-center">
                        <div class="tw-h-8 tw-w-8 tw-bg-gradient-to-r tw-from-orange-500 tw-to-red-500 tw-rounded-lg tw-flex tw-items-center tw-justify-center">
                            <i data-feather="zap" class="tw-h-5 tw-w-5 tw-text-white"></i>
                        </div>
                        <h1 class="tw-ml-3 tw-text-xl tw-font-bold tw-text-gray-900">Time2Eat</h1>
                    </a>
                </div>
                <nav class="tw-flex tw-items-center tw-space-x-4">
                    <a href="/cart" class="tw-text-gray-600 hover:tw-text-gray-900 tw-transition-colors">
                        <i data-feather="arrow-left" class="tw-h-5 tw-w-5 tw-inline tw-mr-1"></i>
                        Back to Cart
                    </a>
                </nav>
            </div>
        </div>
    </header>

    <main class="tw-max-w-7xl tw-mx-auto tw-px-4 sm:tw-px-6 lg:tw-px-8 tw-py-8">
        <!-- Progress Steps -->
        <div class="tw-mb-8">
            <div class="tw-flex tw-items-center tw-justify-center tw-space-x-4">
                <div class="tw-flex tw-items-center">
                    <div class="tw-h-8 tw-w-8 tw-bg-green-500 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                        <i data-feather="check" class="tw-h-5 tw-w-5 tw-text-white"></i>
                    </div>
                    <span class="tw-ml-2 tw-text-sm tw-font-medium tw-text-gray-900">Cart</span>
                </div>
                <div class="tw-h-px tw-w-12 tw-bg-gray-300"></div>
                <div class="tw-flex tw-items-center">
                    <div class="tw-h-8 tw-w-8 tw-bg-primary-500 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                        <span class="tw-text-sm tw-font-medium tw-text-white">2</span>
                    </div>
                    <span class="tw-ml-2 tw-text-sm tw-font-medium tw-text-primary-600">Checkout</span>
                </div>
                <div class="tw-h-px tw-w-12 tw-bg-gray-300"></div>
                <div class="tw-flex tw-items-center">
                    <div class="tw-h-8 tw-w-8 tw-bg-gray-300 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                        <span class="tw-text-sm tw-font-medium tw-text-gray-600">3</span>
                    </div>
                    <span class="tw-ml-2 tw-text-sm tw-font-medium tw-text-gray-600">Confirmation</span>
                </div>
            </div>
        </div>

        <div class="tw-grid tw-grid-cols-1 lg:tw-grid-cols-3 tw-gap-8">
            <!-- Checkout Form -->
            <div class="lg:tw-col-span-2">
                <form id="checkout-form" class="tw-space-y-8">
                    <!-- Delivery Address -->
                    <div class="tw-bg-white tw-rounded-lg tw-shadow-md tw-p-6">
                        <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900 tw-mb-4">
                            <i data-feather="map-pin" class="tw-h-5 tw-w-5 tw-inline tw-mr-2"></i>
                            Delivery Address
                        </h2>

                        <?php if (empty($addresses)): ?>
                            <div class="tw-text-center tw-py-8">
                                <p class="tw-text-gray-600 tw-mb-4">No delivery addresses found</p>
                                <a href="/profile/addresses/add" class="tw-inline-flex tw-items-center tw-px-4 tw-py-2 tw-bg-primary-500 tw-text-white tw-rounded-lg hover:tw-bg-primary-600 tw-transition-colors">
                                    <i data-feather="plus" class="tw-h-4 tw-w-4 tw-mr-2"></i>
                                    Add Address
                                </a>
                            </div>
                        <?php else: ?>
                            <div class="tw-space-y-3">
                                <?php foreach ($addresses as $address): ?>
                                    <label class="tw-flex tw-items-start tw-p-4 tw-border tw-border-gray-200 tw-rounded-lg tw-cursor-pointer hover:tw-border-primary-300 tw-transition-colors">
                                        <input type="radio" name="delivery_address_id" value="<?= $address['id'] ?>" class="tw-mt-1 tw-text-primary-500 focus:tw-ring-primary-500" required>
                                        <div class="tw-ml-3 tw-flex-1">
                                            <div class="tw-flex tw-items-center tw-justify-between">
                                                <h3 class="tw-font-medium tw-text-gray-900"><?= e($address['label']) ?></h3>
                                                <?php if ($address['is_default']): ?>
                                                    <span class="tw-px-2 tw-py-1 tw-bg-green-100 tw-text-green-800 tw-text-xs tw-font-medium tw-rounded">Default</span>
                                                <?php endif; ?>
                                            </div>
                                            <p class="tw-text-sm tw-text-gray-600 tw-mt-1">
                                                <?= e($address['address_line_1']) ?>
                                                <?php if ($address['address_line_2']): ?>, <?= e($address['address_line_2']) ?><?php endif; ?>
                                            </p>
                                            <p class="tw-text-sm tw-text-gray-600">
                                                <?= e($address['city']) ?>, <?= e($address['state']) ?> <?= e($address['postal_code']) ?>
                                            </p>
                                        </div>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Payment Method -->
                    <div class="tw-bg-white tw-rounded-lg tw-shadow-md tw-p-6">
                        <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900 tw-mb-4">
                            <i data-feather="credit-card" class="tw-h-5 tw-w-5 tw-inline tw-mr-2"></i>
                            Payment Method
                        </h2>

                        <?php if (empty($paymentMethods)): ?>
                            <div class="tw-text-center tw-py-8">
                                <p class="tw-text-gray-600 tw-mb-4">No payment methods found</p>
                                <a href="/profile/payment-methods/add" class="tw-inline-flex tw-items-center tw-px-4 tw-py-2 tw-bg-primary-500 tw-text-white tw-rounded-lg hover:tw-bg-primary-600 tw-transition-colors">
                                    <i data-feather="plus" class="tw-h-4 tw-w-4 tw-mr-2"></i>
                                    Add Payment Method
                                </a>
                            </div>
                        <?php else: ?>
                            <div class="tw-space-y-3">
                                <?php foreach ($paymentMethods as $method): ?>
                                    <label class="tw-flex tw-items-center tw-p-4 tw-border tw-border-gray-200 tw-rounded-lg tw-cursor-pointer hover:tw-border-primary-300 tw-transition-colors">
                                        <input type="radio" name="payment_method_id" value="<?= $method['id'] ?>" class="tw-text-primary-500 focus:tw-ring-primary-500" required>
                                        <div class="tw-ml-3 tw-flex-1">
                                            <div class="tw-flex tw-items-center">
                                                <i data-feather="<?= $method['type'] === 'card' ? 'credit-card' : 'smartphone' ?>" class="tw-h-5 tw-w-5 tw-text-gray-400 tw-mr-2"></i>
                                                <h3 class="tw-font-medium tw-text-gray-900"><?= e($method['name']) ?></h3>
                                                <?php if ($method['is_default']): ?>
                                                    <span class="tw-ml-2 tw-px-2 tw-py-1 tw-bg-green-100 tw-text-green-800 tw-text-xs tw-font-medium tw-rounded">Default</span>
                                                <?php endif; ?>
                                            </div>
                                            <p class="tw-text-sm tw-text-gray-600 tw-mt-1">
                                                <?php if ($method['type'] === 'card'): ?>
                                                    **** **** **** <?= e($method['last_four']) ?>
                                                <?php else: ?>
                                                    <?= e($method['phone_number']) ?>
                                                <?php endif; ?>
                                            </p>
                                        </div>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Delivery Instructions -->
                    <div class="tw-bg-white tw-rounded-lg tw-shadow-md tw-p-6">
                        <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900 tw-mb-4">
                            <i data-feather="message-square" class="tw-h-5 tw-w-5 tw-inline tw-mr-2"></i>
                            Delivery Instructions
                        </h2>
                        <textarea name="delivery_instructions" rows="3" placeholder="Any special instructions for delivery..." class="tw-w-full tw-px-3 tw-py-2 tw-border tw-border-gray-300 tw-rounded-lg focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-primary-500 focus:tw-border-transparent tw-resize-none"></textarea>
                    </div>

                    <!-- Affiliate Code -->
                    <div class="tw-bg-white tw-rounded-lg tw-shadow-md tw-p-6">
                        <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900 tw-mb-4">
                            <i data-feather="users" class="tw-h-5 tw-w-5 tw-inline tw-mr-2"></i>
                            Affiliate Code (Optional)
                        </h2>
                        <div class="tw-flex tw-space-x-2">
                            <input type="text" name="affiliate_code" id="affiliate-code" placeholder="Enter affiliate code" class="tw-flex-1 tw-px-3 tw-py-2 tw-border tw-border-gray-300 tw-rounded-lg focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-primary-500 focus:tw-border-transparent">
                            <button type="button" onclick="validateAffiliateCode()" class="tw-px-4 tw-py-2 tw-bg-gray-200 hover:tw-bg-gray-300 tw-text-gray-700 tw-font-medium tw-rounded-lg tw-transition-colors">
                                Validate
                            </button>
                        </div>
                        <div id="affiliate-message" class="tw-mt-2 tw-text-sm tw-hidden"></div>
                    </div>
                </form>
            </div>

            <!-- Order Summary -->
            <div class="lg:tw-col-span-1">
                <div class="tw-bg-white tw-rounded-lg tw-shadow-md tw-p-6 tw-sticky tw-top-4">
                    <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900 tw-mb-4">Order Summary</h2>
                    
                    <!-- Order Items -->
                    <div class="tw-space-y-3 tw-mb-4 tw-max-h-64 tw-overflow-y-auto">
                        <?php foreach ($cartItems as $item): ?>
                            <div class="tw-flex tw-items-center tw-space-x-3">
                                <img src="<?= e($item['item_image'] ?: '/images/placeholder-food.jpg') ?>" alt="<?= e($item['item_name']) ?>" class="tw-w-12 tw-h-12 tw-object-cover tw-rounded-lg tw-flex-shrink-0">
                                <div class="tw-flex-1 tw-min-w-0">
                                    <h4 class="tw-text-sm tw-font-medium tw-text-gray-900 tw-truncate"><?= e($item['item_name']) ?></h4>
                                    <p class="tw-text-xs tw-text-gray-600"><?= e($item['restaurant_name']) ?></p>
                                    <p class="tw-text-xs tw-text-gray-500">Qty: <?= $item['quantity'] ?></p>
                                </div>
                                <span class="tw-text-sm tw-font-medium tw-text-gray-900"><?= number_format($item['total_price']) ?> XAF</span>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Totals -->
                    <div class="tw-space-y-3 tw-border-t tw-border-gray-200 tw-pt-4">
                        <div class="tw-flex tw-justify-between tw-text-sm">
                            <span class="tw-text-gray-600">Subtotal</span>
                            <span class="tw-font-medium tw-text-gray-900"><?= number_format($cartTotals['subtotal'] ?? 0) ?> XAF</span>
                        </div>
                        <div class="tw-flex tw-justify-between tw-text-sm">
                            <span class="tw-text-gray-600">Delivery Fee</span>
                            <span class="tw-font-medium tw-text-gray-900"><?= number_format($cartTotals['delivery_fee'] ?? 0) ?> XAF</span>
                        </div>
                        
                        <?php if ($discount > 0): ?>
                            <div class="tw-flex tw-justify-between tw-text-sm">
                                <span class="tw-text-green-600">Discount (<?= e($appliedPromo['code']) ?>)</span>
                                <span class="tw-font-medium tw-text-green-600">-<?= number_format($discount) ?> XAF</span>
                            </div>
                        <?php endif; ?>
                        
                        <div class="tw-border-t tw-border-gray-200 tw-pt-3">
                            <div class="tw-flex tw-justify-between">
                                <span class="tw-font-semibold tw-text-gray-900">Total</span>
                                <span class="tw-font-semibold tw-text-gray-900">
                                    <?= number_format(($cartTotals['total'] ?? 0) - $discount) ?> XAF
                                </span>
                            </div>
                        </div>
                    </div>

                    <!-- Place Order Button -->
                    <button type="submit" form="checkout-form" class="tw-w-full tw-mt-6 tw-bg-gradient-to-r tw-from-orange-500 tw-to-red-500 tw-text-white tw-py-3 tw-px-4 tw-rounded-lg tw-font-medium hover:tw-from-orange-600 hover:tw-to-red-600 tw-transition-all tw-duration-200 tw-disabled:opacity-50 tw-disabled:cursor-not-allowed" id="place-order-btn">
                        <i data-feather="shopping-bag" class="tw-h-5 tw-w-5 tw-inline tw-mr-2"></i>
                        Place Order
                    </button>

                    <!-- Security Notice -->
                    <div class="tw-mt-4 tw-flex tw-items-center tw-text-xs tw-text-gray-500">
                        <i data-feather="shield" class="tw-h-4 tw-w-4 tw-mr-1"></i>
                        Your payment information is secure and encrypted
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script>
        // Initialize Feather icons
        feather.replace();

        // Form submission
        document.getElementById('checkout-form').addEventListener('submit', function(e) {
            e.preventDefault();
            placeOrder();
        });

        function placeOrder() {
            const form = document.getElementById('checkout-form');
            const formData = new FormData(form);
            const data = Object.fromEntries(formData.entries());
            
            const submitBtn = document.getElementById('place-order-btn');
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i data-feather="loader" class="tw-h-5 tw-w-5 tw-inline tw-mr-2 tw-animate-spin"></i>Processing...';
            feather.replace();

            fetch('/checkout/place-order', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.href = data.redirect || '/orders';
                } else {
                    alert(data.message || 'Failed to place order');
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = '<i data-feather="shopping-bag" class="tw-h-5 tw-w-5 tw-inline tw-mr-2"></i>Place Order';
                    feather.replace();
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to place order. Please try again.');
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<i data-feather="shopping-bag" class="tw-h-5 tw-w-5 tw-inline tw-mr-2"></i>Place Order';
                feather.replace();
            });
        }

        function validateAffiliateCode() {
            const affiliateCode = document.getElementById('affiliate-code').value.trim();
            const messageDiv = document.getElementById('affiliate-message');

            if (!affiliateCode) {
                showAffiliateMessage('Please enter an affiliate code', 'error');
                return;
            }

            fetch('/checkout/validate-affiliate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    affiliate_code: affiliateCode
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showAffiliateMessage(
                        `Valid code! ${data.affiliate.name} will earn ${data.affiliate.commission_rate}% commission (≈${Math.round(data.affiliate.estimated_commission)} XAF)`,
                        'success'
                    );
                } else {
                    showAffiliateMessage(data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAffiliateMessage('Failed to validate affiliate code', 'error');
            });
        }

        function showAffiliateMessage(message, type) {
            const messageDiv = document.getElementById('affiliate-message');
            messageDiv.textContent = message;
            messageDiv.className = `tw-mt-2 tw-text-sm ${type === 'success' ? 'tw-text-green-600' : 'tw-text-red-600'}`;
            messageDiv.classList.remove('tw-hidden');
        }
    </script>
</body>
</html>
