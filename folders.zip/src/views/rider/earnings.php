<?php
/**
 * Rider Earnings View
 * Displays earnings tracking and statistics for riders
 */

$pageTitle = 'Earnings';
$currentPage = 'rider-earnings';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?> - Time2Eat</title>
    <link href="/css/tailwind.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .tw-earnings-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .tw-stat-card {
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .tw-stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }
        .tw-period-tab {
            transition: all 0.2s;
        }
        .tw-period-tab.active {
            background-color: #3b82f6;
            color: white;
        }
        .tw-chart-container {
            position: relative;
            height: 300px;
        }
    </style>
</head>
<body class="tw-bg-gray-50">
    <!-- Navigation -->
    <nav class="tw-bg-white tw-shadow-sm tw-border-b tw-border-gray-200">
        <div class="tw-max-w-7xl tw-mx-auto tw-px-4 sm:tw-px-6 lg:tw-px-8">
            <div class="tw-flex tw-justify-between tw-h-16">
                <div class="tw-flex tw-items-center">
                    <a href="/rider/dashboard" class="tw-text-gray-600 hover:tw-text-gray-900">
                        <svg class="tw-w-6 tw-h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
                        </svg>
                    </a>
                    <h1 class="tw-ml-4 tw-text-xl tw-font-semibold tw-text-gray-900">Earnings</h1>
                </div>
                <div class="tw-flex tw-items-center tw-space-x-4">
                    <span class="tw-text-sm tw-text-gray-600">
                        <?= htmlspecialchars($_SESSION['user']['first_name'] ?? 'Rider') ?>
                    </span>
                </div>
            </div>
        </div>
    </nav>

    <div class="tw-max-w-7xl tw-mx-auto tw-px-4 sm:tw-px-6 lg:tw-px-8 tw-py-6">
        <!-- Period Selector -->
        <div class="tw-mb-6">
            <div class="tw-flex tw-space-x-1 tw-bg-gray-100 tw-p-1 tw-rounded-lg tw-w-fit">
                <button class="tw-period-tab active tw-px-4 tw-py-2 tw-rounded-md tw-text-sm tw-font-medium tw-transition-all" data-period="today">
                    Today
                </button>
                <button class="tw-period-tab tw-px-4 tw-py-2 tw-rounded-md tw-text-sm tw-font-medium tw-transition-all" data-period="week">
                    This Week
                </button>
                <button class="tw-period-tab tw-px-4 tw-py-2 tw-rounded-md tw-text-sm tw-font-medium tw-transition-all" data-period="month">
                    This Month
                </button>
                <button class="tw-period-tab tw-px-4 tw-py-2 tw-rounded-md tw-text-sm tw-font-medium tw-transition-all" data-period="all">
                    All Time
                </button>
            </div>
        </div>

        <!-- Earnings Summary Cards -->
        <div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 lg:tw-grid-cols-4 tw-gap-6 tw-mb-8">
            <!-- Total Earnings -->
            <div class="tw-earnings-card tw-p-6 tw-rounded-lg tw-shadow">
                <div class="tw-flex tw-items-center tw-justify-between">
                    <div>
                        <p class="tw-text-white tw-text-sm tw-opacity-90">Total Earnings</p>
                        <p id="totalEarnings" class="tw-text-2xl tw-font-bold tw-text-white">0 XAF</p>
                    </div>
                    <div class="tw-bg-white tw-bg-opacity-20 tw-p-3 tw-rounded-full">
                        <svg class="tw-w-6 tw-h-6 tw-text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
                        </svg>
                    </div>
                </div>
            </div>

            <!-- Total Deliveries -->
            <div class="tw-bg-white tw-p-6 tw-rounded-lg tw-shadow tw-stat-card">
                <div class="tw-flex tw-items-center tw-justify-between">
                    <div>
                        <p class="tw-text-gray-600 tw-text-sm">Total Deliveries</p>
                        <p id="totalDeliveries" class="tw-text-2xl tw-font-bold tw-text-gray-900">0</p>
                    </div>
                    <div class="tw-bg-blue-100 tw-p-3 tw-rounded-full">
                        <svg class="tw-w-6 tw-h-6 tw-text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path>
                        </svg>
                    </div>
                </div>
            </div>

            <!-- Average per Delivery -->
            <div class="tw-bg-white tw-p-6 tw-rounded-lg tw-shadow tw-stat-card">
                <div class="tw-flex tw-items-center tw-justify-between">
                    <div>
                        <p class="tw-text-gray-600 tw-text-sm">Avg per Delivery</p>
                        <p id="avgPerDelivery" class="tw-text-2xl tw-font-bold tw-text-gray-900">0 XAF</p>
                    </div>
                    <div class="tw-bg-green-100 tw-p-3 tw-rounded-full">
                        <svg class="tw-w-6 tw-h-6 tw-text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path>
                        </svg>
                    </div>
                </div>
            </div>

            <!-- Completion Rate -->
            <div class="tw-bg-white tw-p-6 tw-rounded-lg tw-shadow tw-stat-card">
                <div class="tw-flex tw-items-center tw-justify-between">
                    <div>
                        <p class="tw-text-gray-600 tw-text-sm">Completion Rate</p>
                        <p id="completionRate" class="tw-text-2xl tw-font-bold tw-text-gray-900">0%</p>
                    </div>
                    <div class="tw-bg-yellow-100 tw-p-3 tw-rounded-full">
                        <svg class="tw-w-6 tw-h-6 tw-text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </div>
                </div>
            </div>
        </div>

        <div class="tw-grid tw-grid-cols-1 lg:tw-grid-cols-2 tw-gap-8">
            <!-- Earnings Chart -->
            <div class="tw-bg-white tw-rounded-lg tw-shadow">
                <div class="tw-p-6 tw-border-b tw-border-gray-200">
                    <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Earnings Trend</h2>
                </div>
                <div class="tw-p-6">
                    <div class="tw-chart-container">
                        <canvas id="earningsChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- Performance Stats -->
            <div class="tw-bg-white tw-rounded-lg tw-shadow">
                <div class="tw-p-6 tw-border-b tw-border-gray-200">
                    <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Performance Stats</h2>
                </div>
                <div class="tw-p-6 tw-space-y-6">
                    <!-- Average Rating -->
                    <div class="tw-flex tw-items-center tw-justify-between">
                        <div>
                            <p class="tw-text-sm tw-text-gray-600">Average Rating</p>
                            <div class="tw-flex tw-items-center tw-space-x-2">
                                <span id="avgRating" class="tw-text-lg tw-font-semibold tw-text-gray-900">0.0</span>
                                <div class="tw-flex tw-text-yellow-400">
                                    <svg class="tw-w-4 tw-h-4" fill="currentColor" viewBox="0 0 20 20">
                                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                        <div class="tw-text-right">
                            <div id="ratingProgress" class="tw-w-16 tw-h-2 tw-bg-gray-200 tw-rounded-full">
                                <div class="tw-h-full tw-bg-yellow-400 tw-rounded-full" style="width: 0%"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Average Delivery Time -->
                    <div class="tw-flex tw-items-center tw-justify-between">
                        <div>
                            <p class="tw-text-sm tw-text-gray-600">Avg Delivery Time</p>
                            <p id="avgDeliveryTime" class="tw-text-lg tw-font-semibold tw-text-gray-900">0 min</p>
                        </div>
                        <div class="tw-bg-blue-100 tw-p-2 tw-rounded-full">
                            <svg class="tw-w-4 tw-h-4 tw-text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                        </div>
                    </div>

                    <!-- Total Distance -->
                    <div class="tw-flex tw-items-center tw-justify-between">
                        <div>
                            <p class="tw-text-sm tw-text-gray-600">Total Distance</p>
                            <p id="totalDistance" class="tw-text-lg tw-font-semibold tw-text-gray-900">0 km</p>
                        </div>
                        <div class="tw-bg-green-100 tw-p-2 tw-rounded-full">
                            <svg class="tw-w-4 tw-h-4 tw-text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                            </svg>
                        </div>
                    </div>

                    <!-- Cancelled Deliveries -->
                    <div class="tw-flex tw-items-center tw-justify-between">
                        <div>
                            <p class="tw-text-sm tw-text-gray-600">Cancelled Deliveries</p>
                            <p id="cancelledDeliveries" class="tw-text-lg tw-font-semibold tw-text-gray-900">0</p>
                        </div>
                        <div class="tw-bg-red-100 tw-p-2 tw-rounded-full">
                            <svg class="tw-w-4 tw-h-4 tw-text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Deliveries -->
        <div class="tw-mt-8 tw-bg-white tw-rounded-lg tw-shadow">
            <div class="tw-p-6 tw-border-b tw-border-gray-200">
                <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Recent Deliveries</h2>
            </div>
            <div class="tw-overflow-x-auto">
                <table class="tw-min-w-full tw-divide-y tw-divide-gray-200">
                    <thead class="tw-bg-gray-50">
                        <tr>
                            <th class="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-500 tw-uppercase tw-tracking-wider">
                                Order
                            </th>
                            <th class="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-500 tw-uppercase tw-tracking-wider">
                                Restaurant
                            </th>
                            <th class="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-500 tw-uppercase tw-tracking-wider">
                                Date
                            </th>
                            <th class="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-500 tw-uppercase tw-tracking-wider">
                                Status
                            </th>
                            <th class="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-500 tw-uppercase tw-tracking-wider">
                                Earnings
                            </th>
                            <th class="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-500 tw-uppercase tw-tracking-wider">
                                Rating
                            </th>
                        </tr>
                    </thead>
                    <tbody id="recentDeliveries" class="tw-bg-white tw-divide-y tw-divide-gray-200">
                        <!-- Recent deliveries will be populated here -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        // Global variables
        let currentPeriod = 'today';
        let earningsChart = null;

        // Initialize page
        document.addEventListener('DOMContentLoaded', function() {
            setupPeriodTabs();
            loadEarningsData(currentPeriod);
        });

        // Setup period tabs
        function setupPeriodTabs() {
            const tabs = document.querySelectorAll('.tw-period-tab');
            
            tabs.forEach(tab => {
                tab.addEventListener('click', function() {
                    // Remove active class from all tabs
                    tabs.forEach(t => t.classList.remove('active'));
                    
                    // Add active class to clicked tab
                    this.classList.add('active');
                    
                    // Update current period and load data
                    currentPeriod = this.dataset.period;
                    loadEarningsData(currentPeriod);
                });
            });
        }

        // Load earnings data
        function loadEarningsData(period) {
            fetch(`/api/rider/earnings?period=${period}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        updateEarningsDisplay(data.earnings, data.stats);
                        updateEarningsChart(data.earnings, period);
                        loadRecentDeliveries(period);
                    } else {
                        showError('Failed to load earnings data');
                    }
                })
                .catch(error => {
                    console.error('Error loading earnings data:', error);
                    showError('Failed to load earnings data');
                });
        }

        // Update earnings display
        function updateEarningsDisplay(earnings, stats) {
            document.getElementById('totalEarnings').textContent = `${earnings.total_earnings || 0} XAF`;
            document.getElementById('totalDeliveries').textContent = earnings.total_deliveries || 0;
            document.getElementById('avgPerDelivery').textContent = `${Math.round(earnings.avg_earnings_per_delivery || 0)} XAF`;
            
            const completionRate = earnings.total_deliveries > 0 
                ? Math.round((earnings.completed_deliveries / earnings.total_deliveries) * 100)
                : 0;
            document.getElementById('completionRate').textContent = `${completionRate}%`;
            
            // Update performance stats
            document.getElementById('avgRating').textContent = (stats.avg_rating || 0).toFixed(1);
            document.getElementById('avgDeliveryTime').textContent = `${Math.round(stats.avg_delivery_time || 0)} min`;
            document.getElementById('totalDistance').textContent = `${(stats.total_distance || 0).toFixed(1)} km`;
            document.getElementById('cancelledDeliveries').textContent = stats.cancelled_deliveries || 0;
            
            // Update rating progress bar
            const ratingProgress = document.getElementById('ratingProgress').querySelector('div');
            const ratingPercentage = ((stats.avg_rating || 0) / 5) * 100;
            ratingProgress.style.width = `${ratingPercentage}%`;
        }

        // Update earnings chart
        function updateEarningsChart(earnings, period) {
            const ctx = document.getElementById('earningsChart').getContext('2d');
            
            // Destroy existing chart
            if (earningsChart) {
                earningsChart.destroy();
            }
            
            // Generate sample data based on period
            const chartData = generateChartData(earnings, period);
            
            earningsChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: chartData.labels,
                    datasets: [{
                        label: 'Earnings (XAF)',
                        data: chartData.data,
                        borderColor: '#3b82f6',
                        backgroundColor: 'rgba(59, 130, 246, 0.1)',
                        borderWidth: 2,
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return value + ' XAF';
                                }
                            }
                        }
                    }
                }
            });
        }

        // Generate chart data
        function generateChartData(earnings, period) {
            // This is a simplified implementation
            // In production, you would get actual historical data from the API
            
            let labels = [];
            let data = [];
            
            switch (period) {
                case 'today':
                    labels = ['6 AM', '9 AM', '12 PM', '3 PM', '6 PM', '9 PM'];
                    data = [0, 500, 1200, 2000, 2800, earnings.total_earnings || 0];
                    break;
                case 'week':
                    labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
                    const dailyAvg = (earnings.total_earnings || 0) / 7;
                    data = Array(7).fill(0).map((_, i) => Math.round(dailyAvg * (i + 1)));
                    break;
                case 'month':
                    labels = ['Week 1', 'Week 2', 'Week 3', 'Week 4'];
                    const weeklyAvg = (earnings.total_earnings || 0) / 4;
                    data = Array(4).fill(0).map((_, i) => Math.round(weeklyAvg * (i + 1)));
                    break;
                default:
                    labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
                    const monthlyAvg = (earnings.total_earnings || 0) / 6;
                    data = Array(6).fill(0).map((_, i) => Math.round(monthlyAvg * (i + 1)));
            }
            
            return { labels, data };
        }

        // Load recent deliveries
        function loadRecentDeliveries(period) {
            // This would load recent delivery history
            // For now, show a placeholder
            const tbody = document.getElementById('recentDeliveries');
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" class="tw-px-6 tw-py-4 tw-text-center tw-text-gray-500">
                        Loading recent deliveries...
                    </td>
                </tr>
            `;
        }

        // Show error
        function showError(message) {
            const notification = document.createElement('div');
            notification.className = 'tw-fixed tw-top-4 tw-right-4 tw-p-4 tw-rounded-md tw-shadow-lg tw-z-50 tw-bg-red-500 tw-text-white';
            notification.textContent = message;
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.remove();
            }, 5000);
        }
    </script>
</body>
</html>
