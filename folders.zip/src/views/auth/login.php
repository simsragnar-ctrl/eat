<?php
$title = $title ?? 'Login - Time2Eat';
$page = $page ?? 'login';
$errors = $errors ?? [];
$old = $old ?? [];
$error = $error ?? '';
?>

<?php include_once __DIR__ . '/../layouts/app.php'; ?>

<div class="tw-min-h-screen tw-bg-gradient-to-br tw-from-orange-50 tw-to-red-50 tw-flex tw-items-center tw-justify-center tw-py-12 tw-px-4 sm:tw-px-6 lg:tw-px-8">
    <div class="tw-max-w-md tw-w-full tw-space-y-8">
        <!-- Header -->
        <div class="tw-text-center">
            <div class="tw-mx-auto tw-h-16 tw-w-16 tw-bg-gradient-to-r tw-from-orange-500 tw-to-red-500 tw-rounded-full tw-flex tw-items-center tw-justify-center tw-shadow-lg">
                <i data-feather="user" class="tw-h-8 tw-w-8 tw-text-white"></i>
            </div>
            <h2 class="tw-mt-6 tw-text-3xl tw-font-bold tw-text-gray-900">Welcome back</h2>
            <p class="tw-mt-2 tw-text-sm tw-text-gray-600">Sign in to your Time2Eat account</p>
        </div>

        <!-- Login Form -->
        <form class="tw-mt-8 tw-space-y-6" method="POST" action="/login" id="loginForm">
            <?= csrf_field() ?>
            
            <!-- Error Messages -->
            <?php if ($error): ?>
                <div class="tw-bg-red-50 tw-border tw-border-red-200 tw-rounded-lg tw-p-4">
                    <div class="tw-flex">
                        <i data-feather="alert-circle" class="tw-h-5 tw-w-5 tw-text-red-400"></i>
                        <div class="tw-ml-3">
                            <p class="tw-text-sm tw-text-red-800"><?= e($error) ?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <div class="tw-space-y-4">
                <!-- Email Field -->
                <div>
                    <label for="email" class="tw-block tw-text-sm tw-font-medium tw-text-gray-700 tw-mb-2">
                        Email Address
                    </label>
                    <div class="tw-relative">
                        <div class="tw-absolute tw-inset-y-0 tw-left-0 tw-pl-3 tw-flex tw-items-center tw-pointer-events-none">
                            <i data-feather="mail" class="tw-h-5 tw-w-5 tw-text-gray-400"></i>
                        </div>
                        <input 
                            id="email" 
                            name="email" 
                            type="email" 
                            autocomplete="email" 
                            required
                            value="<?= e($old['email'] ?? '') ?>"
                            class="tw-block tw-w-full tw-pl-10 tw-pr-3 tw-py-3 tw-border <?= isset($errors['email']) ? 'tw-border-red-300' : 'tw-border-gray-300' ?> tw-rounded-lg tw-placeholder-gray-400 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-orange-500 focus:tw-border-transparent tw-transition-colors"
                            placeholder="Enter your email"
                        >
                    </div>
                    <?php if (isset($errors['email'])): ?>
                        <p class="tw-mt-1 tw-text-sm tw-text-red-600"><?= e($errors['email'][0]) ?></p>
                    <?php endif; ?>
                </div>

                <!-- Password Field -->
                <div>
                    <label for="password" class="tw-block tw-text-sm tw-font-medium tw-text-gray-700 tw-mb-2">
                        Password
                    </label>
                    <div class="tw-relative">
                        <div class="tw-absolute tw-inset-y-0 tw-left-0 tw-pl-3 tw-flex tw-items-center tw-pointer-events-none">
                            <i data-feather="lock" class="tw-h-5 tw-w-5 tw-text-gray-400"></i>
                        </div>
                        <input 
                            id="password" 
                            name="password" 
                            type="password" 
                            autocomplete="current-password" 
                            required
                            class="tw-block tw-w-full tw-pl-10 tw-pr-12 tw-py-3 tw-border <?= isset($errors['password']) ? 'tw-border-red-300' : 'tw-border-gray-300' ?> tw-rounded-lg tw-placeholder-gray-400 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-orange-500 focus:tw-border-transparent tw-transition-colors"
                            placeholder="Enter your password"
                        >
                        <button 
                            type="button" 
                            class="tw-absolute tw-inset-y-0 tw-right-0 tw-pr-3 tw-flex tw-items-center"
                            onclick="togglePassword('password')"
                        >
                            <i data-feather="eye" class="tw-h-5 tw-w-5 tw-text-gray-400 hover:tw-text-gray-600"></i>
                        </button>
                    </div>
                    <?php if (isset($errors['password'])): ?>
                        <p class="tw-mt-1 tw-text-sm tw-text-red-600"><?= e($errors['password'][0]) ?></p>
                    <?php endif; ?>
                </div>

                <!-- Remember Me & Forgot Password -->
                <div class="tw-flex tw-items-center tw-justify-between">
                    <div class="tw-flex tw-items-center">
                        <input 
                            id="remember" 
                            name="remember" 
                            type="checkbox" 
                            class="tw-h-4 tw-w-4 tw-text-orange-600 focus:tw-ring-orange-500 tw-border-gray-300 tw-rounded"
                        >
                        <label for="remember" class="tw-ml-2 tw-block tw-text-sm tw-text-gray-700">
                            Remember me
                        </label>
                    </div>
                    <div class="tw-text-sm">
                        <a href="/forgot-password" class="tw-font-medium tw-text-orange-600 hover:tw-text-orange-500 tw-transition-colors">
                            Forgot password?
                        </a>
                    </div>
                </div>
            </div>

            <!-- CAPTCHA -->
            <div class="tw-bg-gray-50 tw-p-4 tw-rounded-lg tw-border">
                <div class="tw-flex tw-items-center tw-space-x-3">
                    <div class="tw-bg-white tw-p-3 tw-rounded tw-border tw-font-mono tw-text-lg tw-tracking-wider tw-select-none" id="captcha-display">
                        <!-- CAPTCHA will be generated here -->
                    </div>
                    <button type="button" onclick="refreshCaptcha()" class="tw-p-2 tw-text-gray-500 hover:tw-text-gray-700 tw-transition-colors">
                        <i data-feather="refresh-cw" class="tw-h-5 tw-w-5"></i>
                    </button>
                </div>
                <input 
                    type="text" 
                    name="captcha" 
                    placeholder="Enter CAPTCHA" 
                    required
                    class="tw-mt-3 tw-block tw-w-full tw-px-3 tw-py-2 tw-border tw-border-gray-300 tw-rounded-md tw-placeholder-gray-400 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-orange-500 focus:tw-border-transparent"
                >
                <input type="hidden" name="captcha_token" id="captcha-token">
            </div>

            <!-- Submit Button -->
            <div>
                <button 
                    type="submit" 
                    class="tw-group tw-relative tw-w-full tw-flex tw-justify-center tw-py-3 tw-px-4 tw-border tw-border-transparent tw-text-sm tw-font-medium tw-rounded-lg tw-text-white tw-bg-gradient-to-r tw-from-orange-500 tw-to-red-500 hover:tw-from-orange-600 hover:tw-to-red-600 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-offset-2 focus:tw-ring-orange-500 tw-transition-all tw-duration-200 tw-shadow-lg hover:tw-shadow-xl disabled:tw-opacity-50 disabled:tw-cursor-not-allowed"
                    id="loginButton"
                >
                    <span class="tw-absolute tw-left-0 tw-inset-y-0 tw-flex tw-items-center tw-pl-3">
                        <i data-feather="log-in" class="tw-h-5 tw-w-5 group-hover:tw-text-orange-300"></i>
                    </span>
                    <span id="loginButtonText">Sign In</span>
                    <div class="tw-hidden" id="loginSpinner">
                        <div class="tw-animate-spin tw-rounded-full tw-h-5 tw-w-5 tw-border-b-2 tw-border-white"></div>
                    </div>
                </button>
            </div>

            <!-- Sign Up Link -->
            <div class="tw-text-center">
                <p class="tw-text-sm tw-text-gray-600">
                    Don't have an account? 
                    <a href="/register" class="tw-font-medium tw-text-orange-600 hover:tw-text-orange-500 tw-transition-colors">
                        Sign up now
                    </a>
                </p>
            </div>
        </form>

        <!-- Social Login (Optional) -->
        <div class="tw-mt-6">
            <div class="tw-relative">
                <div class="tw-absolute tw-inset-0 tw-flex tw-items-center">
                    <div class="tw-w-full tw-border-t tw-border-gray-300"></div>
                </div>
                <div class="tw-relative tw-flex tw-justify-center tw-text-sm">
                    <span class="tw-px-2 tw-bg-gray-50 tw-text-gray-500">Or continue with</span>
                </div>
            </div>

            <div class="tw-mt-6 tw-grid tw-grid-cols-2 tw-gap-3">
                <button class="tw-w-full tw-inline-flex tw-justify-center tw-py-2 tw-px-4 tw-border tw-border-gray-300 tw-rounded-md tw-shadow-sm tw-bg-white tw-text-sm tw-font-medium tw-text-gray-500 hover:tw-bg-gray-50 tw-transition-colors">
                    <i data-feather="smartphone" class="tw-h-5 tw-w-5"></i>
                    <span class="tw-ml-2">SMS</span>
                </button>
                <button class="tw-w-full tw-inline-flex tw-justify-center tw-py-2 tw-px-4 tw-border tw-border-gray-300 tw-rounded-md tw-shadow-sm tw-bg-white tw-text-sm tw-font-medium tw-text-gray-500 hover:tw-bg-gray-50 tw-transition-colors">
                    <i data-feather="mail" class="tw-h-5 tw-w-5"></i>
                    <span class="tw-ml-2">Email</span>
                </button>
            </div>
        </div>
    </div>
</div>

<script>
// CAPTCHA functionality
function generateCaptcha() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let captcha = '';
    for (let i = 0; i < 6; i++) {
        captcha += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    document.getElementById('captcha-display').textContent = captcha;
    document.getElementById('captcha-token').value = btoa(captcha);
}

function refreshCaptcha() {
    generateCaptcha();
}

function togglePassword(fieldId) {
    const field = document.getElementById(fieldId);
    const icon = field.nextElementSibling.querySelector('i');
    
    if (field.type === 'password') {
        field.type = 'text';
        icon.setAttribute('data-feather', 'eye-off');
    } else {
        field.type = 'password';
        icon.setAttribute('data-feather', 'eye');
    }
    feather.replace();
}

// Form submission with loading state
document.getElementById('loginForm').addEventListener('submit', function(e) {
    const button = document.getElementById('loginButton');
    const buttonText = document.getElementById('loginButtonText');
    const spinner = document.getElementById('loginSpinner');
    
    button.disabled = true;
    buttonText.classList.add('tw-hidden');
    spinner.classList.remove('tw-hidden');
});

// Rate limiting client-side
let loginAttempts = parseInt(localStorage.getItem('loginAttempts') || '0');
let lastAttempt = parseInt(localStorage.getItem('lastLoginAttempt') || '0');

if (loginAttempts >= 5 && Date.now() - lastAttempt < 900000) { // 15 minutes
    const button = document.getElementById('loginButton');
    const timeLeft = Math.ceil((900000 - (Date.now() - lastAttempt)) / 60000);
    button.disabled = true;
    button.textContent = `Try again in ${timeLeft} minutes`;
}

// Initialize CAPTCHA
document.addEventListener('DOMContentLoaded', function() {
    generateCaptcha();
});
</script>
