<?php
$title = $title ?? 'Register - Time2Eat';
$page = $page ?? 'register';
$errors = $errors ?? [];
$old = $old ?? [];
$error = $error ?? '';
?>

<?php include_once __DIR__ . '/../layouts/app.php'; ?>

<div class="tw-min-h-screen tw-bg-gradient-to-br tw-from-orange-50 tw-to-red-50 tw-flex tw-items-center tw-justify-center tw-py-12 tw-px-4 sm:tw-px-6 lg:tw-px-8">
    <div class="tw-max-w-2xl tw-w-full tw-space-y-8">
        <!-- Header -->
        <div class="tw-text-center">
            <div class="tw-mx-auto tw-h-16 tw-w-16 tw-bg-gradient-to-r tw-from-orange-500 tw-to-red-500 tw-rounded-full tw-flex tw-items-center tw-justify-center tw-shadow-lg">
                <i data-feather="user-plus" class="tw-h-8 tw-w-8 tw-text-white"></i>
            </div>
            <h2 class="tw-mt-6 tw-text-3xl tw-font-bold tw-text-gray-900">Join Time2Eat</h2>
            <p class="tw-mt-2 tw-text-sm tw-text-gray-600">Create your account and start ordering delicious food</p>
        </div>

        <!-- Registration Form -->
        <form class="tw-mt-8 tw-space-y-6 tw-bg-white tw-p-8 tw-rounded-xl tw-shadow-lg" method="POST" action="/register" id="registerForm">
            <?= csrf_field() ?>
            
            <!-- Error Messages -->
            <?php if ($error): ?>
                <div class="tw-bg-red-50 tw-border tw-border-red-200 tw-rounded-lg tw-p-4">
                    <div class="tw-flex">
                        <i data-feather="alert-circle" class="tw-h-5 tw-w-5 tw-text-red-400"></i>
                        <div class="tw-ml-3">
                            <p class="tw-text-sm tw-text-red-800"><?= e($error) ?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Personal Information -->
            <div class="tw-space-y-4">
                <h3 class="tw-text-lg tw-font-medium tw-text-gray-900 tw-border-b tw-border-gray-200 tw-pb-2">
                    Personal Information
                </h3>

                <div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-4">
                    <!-- First Name -->
                    <div>
                        <label for="first_name" class="tw-block tw-text-sm tw-font-medium tw-text-gray-700 tw-mb-2">
                            First Name *
                        </label>
                        <input 
                            id="first_name" 
                            name="first_name" 
                            type="text" 
                            required
                            value="<?= e($old['first_name'] ?? '') ?>"
                            class="tw-block tw-w-full tw-px-3 tw-py-3 tw-border <?= isset($errors['first_name']) ? 'tw-border-red-300' : 'tw-border-gray-300' ?> tw-rounded-lg tw-placeholder-gray-400 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-orange-500 focus:tw-border-transparent tw-transition-colors"
                            placeholder="Enter your first name"
                        >
                        <?php if (isset($errors['first_name'])): ?>
                            <p class="tw-mt-1 tw-text-sm tw-text-red-600"><?= e($errors['first_name'][0]) ?></p>
                        <?php endif; ?>
                    </div>

                    <!-- Last Name -->
                    <div>
                        <label for="last_name" class="tw-block tw-text-sm tw-font-medium tw-text-gray-700 tw-mb-2">
                            Last Name *
                        </label>
                        <input 
                            id="last_name" 
                            name="last_name" 
                            type="text" 
                            required
                            value="<?= e($old['last_name'] ?? '') ?>"
                            class="tw-block tw-w-full tw-px-3 tw-py-3 tw-border <?= isset($errors['last_name']) ? 'tw-border-red-300' : 'tw-border-gray-300' ?> tw-rounded-lg tw-placeholder-gray-400 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-orange-500 focus:tw-border-transparent tw-transition-colors"
                            placeholder="Enter your last name"
                        >
                        <?php if (isset($errors['last_name'])): ?>
                            <p class="tw-mt-1 tw-text-sm tw-text-red-600"><?= e($errors['last_name'][0]) ?></p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Email -->
                <div>
                    <label for="email" class="tw-block tw-text-sm tw-font-medium tw-text-gray-700 tw-mb-2">
                        Email Address *
                    </label>
                    <div class="tw-relative">
                        <div class="tw-absolute tw-inset-y-0 tw-left-0 tw-pl-3 tw-flex tw-items-center tw-pointer-events-none">
                            <i data-feather="mail" class="tw-h-5 tw-w-5 tw-text-gray-400"></i>
                        </div>
                        <input 
                            id="email" 
                            name="email" 
                            type="email" 
                            autocomplete="email" 
                            required
                            value="<?= e($old['email'] ?? '') ?>"
                            class="tw-block tw-w-full tw-pl-10 tw-pr-3 tw-py-3 tw-border <?= isset($errors['email']) ? 'tw-border-red-300' : 'tw-border-gray-300' ?> tw-rounded-lg tw-placeholder-gray-400 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-orange-500 focus:tw-border-transparent tw-transition-colors"
                            placeholder="Enter your email address"
                        >
                    </div>
                    <?php if (isset($errors['email'])): ?>
                        <p class="tw-mt-1 tw-text-sm tw-text-red-600"><?= e($errors['email'][0]) ?></p>
                    <?php endif; ?>
                </div>

                <!-- Phone -->
                <div>
                    <label for="phone" class="tw-block tw-text-sm tw-font-medium tw-text-gray-700 tw-mb-2">
                        Phone Number *
                    </label>
                    <div class="tw-relative">
                        <div class="tw-absolute tw-inset-y-0 tw-left-0 tw-pl-3 tw-flex tw-items-center tw-pointer-events-none">
                            <i data-feather="phone" class="tw-h-5 tw-w-5 tw-text-gray-400"></i>
                        </div>
                        <input 
                            id="phone" 
                            name="phone" 
                            type="tel" 
                            required
                            value="<?= e($old['phone'] ?? '') ?>"
                            class="tw-block tw-w-full tw-pl-10 tw-pr-3 tw-py-3 tw-border <?= isset($errors['phone']) ? 'tw-border-red-300' : 'tw-border-gray-300' ?> tw-rounded-lg tw-placeholder-gray-400 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-orange-500 focus:tw-border-transparent tw-transition-colors"
                            placeholder="+237 6XX XXX XXX"
                        >
                    </div>
                    <?php if (isset($errors['phone'])): ?>
                        <p class="tw-mt-1 tw-text-sm tw-text-red-600"><?= e($errors['phone'][0]) ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Account Information -->
            <div class="tw-space-y-4">
                <h3 class="tw-text-lg tw-font-medium tw-text-gray-900 tw-border-b tw-border-gray-200 tw-pb-2">
                    Account Information
                </h3>

                <!-- Role Selection -->
                <div>
                    <label class="tw-block tw-text-sm tw-font-medium tw-text-gray-700 tw-mb-3">
                        I want to join as *
                    </label>
                    <div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-3 tw-gap-4">
                        <label class="tw-relative tw-flex tw-cursor-pointer tw-rounded-lg tw-border tw-p-4 focus:tw-outline-none <?= ($old['role'] ?? 'customer') === 'customer' ? 'tw-border-orange-500 tw-bg-orange-50' : 'tw-border-gray-300' ?>">
                            <input type="radio" name="role" value="customer" class="tw-sr-only" <?= ($old['role'] ?? 'customer') === 'customer' ? 'checked' : '' ?>>
                            <div class="tw-flex tw-flex-col tw-items-center tw-text-center">
                                <i data-feather="user" class="tw-h-8 tw-w-8 tw-text-orange-500 tw-mb-2"></i>
                                <span class="tw-block tw-text-sm tw-font-medium tw-text-gray-900">Customer</span>
                                <span class="tw-block tw-text-xs tw-text-gray-500">Order food from restaurants</span>
                            </div>
                        </label>

                        <label class="tw-relative tw-flex tw-cursor-pointer tw-rounded-lg tw-border tw-p-4 focus:tw-outline-none <?= ($old['role'] ?? '') === 'vendor' ? 'tw-border-orange-500 tw-bg-orange-50' : 'tw-border-gray-300' ?>">
                            <input type="radio" name="role" value="vendor" class="tw-sr-only" <?= ($old['role'] ?? '') === 'vendor' ? 'checked' : '' ?>>
                            <div class="tw-flex tw-flex-col tw-items-center tw-text-center">
                                <i data-feather="store" class="tw-h-8 tw-w-8 tw-text-orange-500 tw-mb-2"></i>
                                <span class="tw-block tw-text-sm tw-font-medium tw-text-gray-900">Restaurant</span>
                                <span class="tw-block tw-text-xs tw-text-gray-500">Sell food to customers</span>
                            </div>
                        </label>

                        <label class="tw-relative tw-flex tw-cursor-pointer tw-rounded-lg tw-border tw-p-4 focus:tw-outline-none <?= ($old['role'] ?? '') === 'rider' ? 'tw-border-orange-500 tw-bg-orange-50' : 'tw-border-gray-300' ?>">
                            <input type="radio" name="role" value="rider" class="tw-sr-only" <?= ($old['role'] ?? '') === 'rider' ? 'checked' : '' ?>>
                            <div class="tw-flex tw-flex-col tw-items-center tw-text-center">
                                <i data-feather="truck" class="tw-h-8 tw-w-8 tw-text-orange-500 tw-mb-2"></i>
                                <span class="tw-block tw-text-sm tw-font-medium tw-text-gray-900">Rider</span>
                                <span class="tw-block tw-text-xs tw-text-gray-500">Deliver food to customers</span>
                            </div>
                        </label>
                    </div>
                    <?php if (isset($errors['role'])): ?>
                        <p class="tw-mt-1 tw-text-sm tw-text-red-600"><?= e($errors['role'][0]) ?></p>
                    <?php endif; ?>
                </div>

                <!-- Password -->
                <div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-4">
                    <div>
                        <label for="password" class="tw-block tw-text-sm tw-font-medium tw-text-gray-700 tw-mb-2">
                            Password *
                        </label>
                        <div class="tw-relative">
                            <div class="tw-absolute tw-inset-y-0 tw-left-0 tw-pl-3 tw-flex tw-items-center tw-pointer-events-none">
                                <i data-feather="lock" class="tw-h-5 tw-w-5 tw-text-gray-400"></i>
                            </div>
                            <input 
                                id="password" 
                                name="password" 
                                type="password" 
                                required
                                class="tw-block tw-w-full tw-pl-10 tw-pr-12 tw-py-3 tw-border <?= isset($errors['password']) ? 'tw-border-red-300' : 'tw-border-gray-300' ?> tw-rounded-lg tw-placeholder-gray-400 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-orange-500 focus:tw-border-transparent tw-transition-colors"
                                placeholder="Create a password"
                            >
                            <button 
                                type="button" 
                                class="tw-absolute tw-inset-y-0 tw-right-0 tw-pr-3 tw-flex tw-items-center"
                                onclick="togglePassword('password')"
                            >
                                <i data-feather="eye" class="tw-h-5 tw-w-5 tw-text-gray-400 hover:tw-text-gray-600"></i>
                            </button>
                        </div>
                        <?php if (isset($errors['password'])): ?>
                            <p class="tw-mt-1 tw-text-sm tw-text-red-600"><?= e($errors['password'][0]) ?></p>
                        <?php endif; ?>
                    </div>

                    <div>
                        <label for="confirm_password" class="tw-block tw-text-sm tw-font-medium tw-text-gray-700 tw-mb-2">
                            Confirm Password *
                        </label>
                        <div class="tw-relative">
                            <div class="tw-absolute tw-inset-y-0 tw-left-0 tw-pl-3 tw-flex tw-items-center tw-pointer-events-none">
                                <i data-feather="lock" class="tw-h-5 tw-w-5 tw-text-gray-400"></i>
                            </div>
                            <input 
                                id="confirm_password" 
                                name="confirm_password" 
                                type="password" 
                                required
                                class="tw-block tw-w-full tw-pl-10 tw-pr-12 tw-py-3 tw-border <?= isset($errors['confirm_password']) ? 'tw-border-red-300' : 'tw-border-gray-300' ?> tw-rounded-lg tw-placeholder-gray-400 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-orange-500 focus:tw-border-transparent tw-transition-colors"
                                placeholder="Confirm your password"
                            >
                            <button 
                                type="button" 
                                class="tw-absolute tw-inset-y-0 tw-right-0 tw-pr-3 tw-flex tw-items-center"
                                onclick="togglePassword('confirm_password')"
                            >
                                <i data-feather="eye" class="tw-h-5 tw-w-5 tw-text-gray-400 hover:tw-text-gray-600"></i>
                            </button>
                        </div>
                        <?php if (isset($errors['confirm_password'])): ?>
                            <p class="tw-mt-1 tw-text-sm tw-text-red-600"><?= e($errors['confirm_password'][0]) ?></p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Password Strength Indicator -->
                <div class="tw-mt-2">
                    <div class="tw-text-sm tw-text-gray-600 tw-mb-2">Password strength:</div>
                    <div class="tw-flex tw-space-x-1">
                        <div class="tw-h-2 tw-w-1/4 tw-bg-gray-200 tw-rounded" id="strength-1"></div>
                        <div class="tw-h-2 tw-w-1/4 tw-bg-gray-200 tw-rounded" id="strength-2"></div>
                        <div class="tw-h-2 tw-w-1/4 tw-bg-gray-200 tw-rounded" id="strength-3"></div>
                        <div class="tw-h-2 tw-w-1/4 tw-bg-gray-200 tw-rounded" id="strength-4"></div>
                    </div>
                    <div class="tw-text-xs tw-text-gray-500 tw-mt-1" id="strength-text">
                        Use 8+ characters with letters, numbers, and symbols
                    </div>
                </div>
            </div>

            <!-- CAPTCHA -->
            <div class="tw-bg-gray-50 tw-p-4 tw-rounded-lg tw-border">
                <div class="tw-flex tw-items-center tw-space-x-3">
                    <div class="tw-bg-white tw-p-3 tw-rounded tw-border tw-font-mono tw-text-lg tw-tracking-wider tw-select-none" id="captcha-display">
                        <!-- CAPTCHA will be generated here -->
                    </div>
                    <button type="button" onclick="refreshCaptcha()" class="tw-p-2 tw-text-gray-500 hover:tw-text-gray-700 tw-transition-colors">
                        <i data-feather="refresh-cw" class="tw-h-5 tw-w-5"></i>
                    </button>
                </div>
                <input 
                    type="text" 
                    name="captcha" 
                    placeholder="Enter CAPTCHA" 
                    required
                    class="tw-mt-3 tw-block tw-w-full tw-px-3 tw-py-2 tw-border tw-border-gray-300 tw-rounded-md tw-placeholder-gray-400 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-orange-500 focus:tw-border-transparent"
                >
                <input type="hidden" name="captcha_token" id="captcha-token">
            </div>

            <!-- Terms and Conditions -->
            <div class="tw-flex tw-items-start">
                <div class="tw-flex tw-items-center tw-h-5">
                    <input 
                        id="terms" 
                        name="terms" 
                        type="checkbox" 
                        required
                        class="tw-h-4 tw-w-4 tw-text-orange-600 focus:tw-ring-orange-500 tw-border-gray-300 tw-rounded"
                    >
                </div>
                <div class="tw-ml-3 tw-text-sm">
                    <label for="terms" class="tw-text-gray-700">
                        I agree to the 
                        <a href="/terms" class="tw-text-orange-600 hover:tw-text-orange-500 tw-underline" target="_blank">Terms of Service</a> 
                        and 
                        <a href="/privacy" class="tw-text-orange-600 hover:tw-text-orange-500 tw-underline" target="_blank">Privacy Policy</a>
                    </label>
                    <?php if (isset($errors['terms'])): ?>
                        <p class="tw-mt-1 tw-text-sm tw-text-red-600"><?= e($errors['terms'][0]) ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Submit Button -->
            <div>
                <button 
                    type="submit" 
                    class="tw-group tw-relative tw-w-full tw-flex tw-justify-center tw-py-3 tw-px-4 tw-border tw-border-transparent tw-text-sm tw-font-medium tw-rounded-lg tw-text-white tw-bg-gradient-to-r tw-from-orange-500 tw-to-red-500 hover:tw-from-orange-600 hover:tw-to-red-600 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-offset-2 focus:tw-ring-orange-500 tw-transition-all tw-duration-200 tw-shadow-lg hover:tw-shadow-xl disabled:tw-opacity-50 disabled:tw-cursor-not-allowed"
                    id="registerButton"
                >
                    <span class="tw-absolute tw-left-0 tw-inset-y-0 tw-flex tw-items-center tw-pl-3">
                        <i data-feather="user-plus" class="tw-h-5 tw-w-5 group-hover:tw-text-orange-300"></i>
                    </span>
                    <span id="registerButtonText">Create Account</span>
                    <div class="tw-hidden" id="registerSpinner">
                        <div class="tw-animate-spin tw-rounded-full tw-h-5 tw-w-5 tw-border-b-2 tw-border-white"></div>
                    </div>
                </button>
            </div>

            <!-- Sign In Link -->
            <div class="tw-text-center">
                <p class="tw-text-sm tw-text-gray-600">
                    Already have an account? 
                    <a href="/login" class="tw-font-medium tw-text-orange-600 hover:tw-text-orange-500 tw-transition-colors">
                        Sign in here
                    </a>
                </p>
            </div>
        </form>
    </div>
</div>

<script>
// Role selection functionality
document.querySelectorAll('input[name="role"]').forEach(radio => {
    radio.addEventListener('change', function() {
        document.querySelectorAll('label[for="role"]').forEach(label => {
            label.classList.remove('tw-border-orange-500', 'tw-bg-orange-50');
            label.classList.add('tw-border-gray-300');
        });
        
        this.closest('label').classList.remove('tw-border-gray-300');
        this.closest('label').classList.add('tw-border-orange-500', 'tw-bg-orange-50');
    });
});

// Password strength checker
document.getElementById('password').addEventListener('input', function() {
    const password = this.value;
    const strength = calculatePasswordStrength(password);
    updatePasswordStrengthUI(strength);
});

function calculatePasswordStrength(password) {
    let score = 0;
    
    if (password.length >= 8) score++;
    if (/[a-z]/.test(password)) score++;
    if (/[A-Z]/.test(password)) score++;
    if (/[0-9]/.test(password)) score++;
    if (/[^A-Za-z0-9]/.test(password)) score++;
    
    return Math.min(score, 4);
}

function updatePasswordStrengthUI(strength) {
    const colors = ['tw-bg-red-500', 'tw-bg-orange-500', 'tw-bg-yellow-500', 'tw-bg-green-500'];
    const texts = ['Very Weak', 'Weak', 'Fair', 'Strong'];
    
    for (let i = 1; i <= 4; i++) {
        const element = document.getElementById(`strength-${i}`);
        element.className = `tw-h-2 tw-w-1/4 tw-rounded ${i <= strength ? colors[strength - 1] : 'tw-bg-gray-200'}`;
    }
    
    document.getElementById('strength-text').textContent = strength > 0 ? texts[strength - 1] : 'Use 8+ characters with letters, numbers, and symbols';
}

// CAPTCHA functionality
function generateCaptcha() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let captcha = '';
    for (let i = 0; i < 6; i++) {
        captcha += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    document.getElementById('captcha-display').textContent = captcha;
    document.getElementById('captcha-token').value = btoa(captcha);
}

function refreshCaptcha() {
    generateCaptcha();
}

function togglePassword(fieldId) {
    const field = document.getElementById(fieldId);
    const icon = field.nextElementSibling.querySelector('i');
    
    if (field.type === 'password') {
        field.type = 'text';
        icon.setAttribute('data-feather', 'eye-off');
    } else {
        field.type = 'password';
        icon.setAttribute('data-feather', 'eye');
    }
    feather.replace();
}

// Form submission with loading state
document.getElementById('registerForm').addEventListener('submit', function(e) {
    const button = document.getElementById('registerButton');
    const buttonText = document.getElementById('registerButtonText');
    const spinner = document.getElementById('registerSpinner');
    
    button.disabled = true;
    buttonText.classList.add('tw-hidden');
    spinner.classList.remove('tw-hidden');
});

// Initialize CAPTCHA
document.addEventListener('DOMContentLoaded', function() {
    generateCaptcha();
});
</script>
