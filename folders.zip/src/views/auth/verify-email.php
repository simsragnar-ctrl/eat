<?php
$title = $title ?? 'Verify Email - Time2Eat';
$page = $page ?? 'verify-email';
$email = $_GET['email'] ?? '';
?>

<?php include_once __DIR__ . '/../layouts/app.php'; ?>

<div class="tw-min-h-screen tw-bg-gradient-to-br tw-from-orange-50 tw-to-red-50 tw-flex tw-items-center tw-justify-center tw-py-12 tw-px-4 sm:tw-px-6 lg:tw-px-8">
    <div class="tw-max-w-md tw-w-full tw-space-y-8">
        <!-- Header -->
        <div class="tw-text-center">
            <div class="tw-mx-auto tw-h-16 tw-w-16 tw-bg-gradient-to-r tw-from-orange-500 tw-to-red-500 tw-rounded-full tw-flex tw-items-center tw-justify-center tw-shadow-lg">
                <i data-feather="mail" class="tw-h-8 tw-w-8 tw-text-white"></i>
            </div>
            <h2 class="tw-mt-6 tw-text-3xl tw-font-bold tw-text-gray-900">Verify your email</h2>
            <p class="tw-mt-2 tw-text-sm tw-text-gray-600">
                We've sent a verification link to 
                <span class="tw-font-medium tw-text-gray-900"><?= e($email) ?></span>
            </p>
        </div>

        <!-- Verification Instructions -->
        <div class="tw-bg-white tw-p-6 tw-rounded-xl tw-shadow-lg tw-space-y-4">
            <div class="tw-flex tw-items-start tw-space-x-3">
                <div class="tw-flex-shrink-0">
                    <div class="tw-w-8 tw-h-8 tw-bg-blue-100 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                        <span class="tw-text-blue-600 tw-font-semibold tw-text-sm">1</span>
                    </div>
                </div>
                <div>
                    <h3 class="tw-text-sm tw-font-medium tw-text-gray-900">Check your email</h3>
                    <p class="tw-text-sm tw-text-gray-600">Look for an email from Time2Eat in your inbox.</p>
                </div>
            </div>

            <div class="tw-flex tw-items-start tw-space-x-3">
                <div class="tw-flex-shrink-0">
                    <div class="tw-w-8 tw-h-8 tw-bg-blue-100 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                        <span class="tw-text-blue-600 tw-font-semibold tw-text-sm">2</span>
                    </div>
                </div>
                <div>
                    <h3 class="tw-text-sm tw-font-medium tw-text-gray-900">Click the verification link</h3>
                    <p class="tw-text-sm tw-text-gray-600">Click the link in the email to verify your account.</p>
                </div>
            </div>

            <div class="tw-flex tw-items-start tw-space-x-3">
                <div class="tw-flex-shrink-0">
                    <div class="tw-w-8 tw-h-8 tw-bg-blue-100 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                        <span class="tw-text-blue-600 tw-font-semibold tw-text-sm">3</span>
                    </div>
                </div>
                <div>
                    <h3 class="tw-text-sm tw-font-medium tw-text-gray-900">Start ordering</h3>
                    <p class="tw-text-sm tw-text-gray-600">Once verified, you can start using Time2Eat!</p>
                </div>
            </div>
        </div>

        <!-- Resend Email -->
        <div class="tw-text-center tw-space-y-4">
            <p class="tw-text-sm tw-text-gray-600">Didn't receive the email?</p>
            
            <form method="POST" action="/resend-verification" id="resendForm">
                <?= csrf_field() ?>
                <input type="hidden" name="email" value="<?= e($email) ?>">
                
                <button 
                    type="submit" 
                    class="tw-inline-flex tw-items-center tw-px-4 tw-py-2 tw-border tw-border-transparent tw-text-sm tw-font-medium tw-rounded-md tw-text-orange-600 tw-bg-orange-100 hover:tw-bg-orange-200 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-offset-2 focus:tw-ring-orange-500 tw-transition-colors disabled:tw-opacity-50 disabled:tw-cursor-not-allowed"
                    id="resendButton"
                >
                    <i data-feather="refresh-cw" class="tw-h-4 tw-w-4 tw-mr-2"></i>
                    <span id="resendText">Resend verification email</span>
                    <div class="tw-hidden tw-ml-2" id="resendSpinner">
                        <div class="tw-animate-spin tw-rounded-full tw-h-4 tw-w-4 tw-border-b-2 tw-border-orange-600"></div>
                    </div>
                </button>
            </form>

            <div class="tw-text-xs tw-text-gray-500" id="resendTimer"></div>
        </div>

        <!-- Help Section -->
        <div class="tw-bg-gray-50 tw-p-4 tw-rounded-lg">
            <h3 class="tw-text-sm tw-font-medium tw-text-gray-900 tw-mb-2">Need help?</h3>
            <ul class="tw-text-xs tw-text-gray-600 tw-space-y-1">
                <li>• Check your spam or junk folder</li>
                <li>• Make sure <?= e($email) ?> is correct</li>
                <li>• Add noreply@time2eat.cm to your contacts</li>
                <li>• Contact support if you still need help</li>
            </ul>
        </div>

        <!-- Back to Login -->
        <div class="tw-text-center">
            <a href="/login" class="tw-text-sm tw-text-orange-600 hover:tw-text-orange-500 tw-transition-colors">
                ← Back to login
            </a>
        </div>
    </div>
</div>

<script>
// Resend email functionality with cooldown
let resendCooldown = 60; // 60 seconds
let resendTimer = null;

function startResendCooldown() {
    const button = document.getElementById('resendButton');
    const text = document.getElementById('resendText');
    const timer = document.getElementById('resendTimer');
    
    button.disabled = true;
    
    resendTimer = setInterval(() => {
        resendCooldown--;
        timer.textContent = `You can resend in ${resendCooldown} seconds`;
        
        if (resendCooldown <= 0) {
            clearInterval(resendTimer);
            button.disabled = false;
            timer.textContent = '';
            resendCooldown = 60;
        }
    }, 1000);
}

// Form submission
document.getElementById('resendForm').addEventListener('submit', function(e) {
    const button = document.getElementById('resendButton');
    const text = document.getElementById('resendText');
    const spinner = document.getElementById('resendSpinner');
    
    button.disabled = true;
    text.textContent = 'Sending...';
    spinner.classList.remove('tw-hidden');
    
    // Start cooldown after form submission
    setTimeout(() => {
        text.textContent = 'Resend verification email';
        spinner.classList.add('tw-hidden');
        startResendCooldown();
    }, 2000);
});

// Auto-refresh page when verification is complete
function checkVerificationStatus() {
    fetch('/api/check-verification?email=' + encodeURIComponent('<?= e($email) ?>'))
        .then(response => response.json())
        .then(data => {
            if (data.verified) {
                window.location.href = '/dashboard';
            }
        })
        .catch(error => {
            // Silently handle errors
        });
}

// Check verification status every 10 seconds
setInterval(checkVerificationStatus, 10000);
</script>
