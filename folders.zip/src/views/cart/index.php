<?php
$title = $title ?? 'Shopping Cart - Time2Eat';
$user = $user ?? null;
$cartItems = $cartItems ?? [];
$cartTotals = $cartTotals ?? [];
$addresses = $addresses ?? [];
$recentItems = $recentItems ?? [];
?>

<!DOCTYPE html>
<html lang="en" class="tw-h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title) ?></title>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            prefix: 'tw-',
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#fff7ed',
                            500: '#f97316',
                            600: '#ea580c',
                            700: '#c2410c'
                        }
                    }
                }
            }
        }
    </script>
    
    <!-- Feather Icons -->
    <script src="https://unpkg.com/feather-icons"></script>
</head>
<body class="tw-min-h-full tw-bg-gray-50">
    <!-- Header -->
    <header class="tw-bg-white tw-shadow-sm tw-border-b tw-border-gray-200">
        <div class="tw-max-w-7xl tw-mx-auto tw-px-4 sm:tw-px-6 lg:tw-px-8">
            <div class="tw-flex tw-justify-between tw-items-center tw-py-4">
                <div class="tw-flex tw-items-center">
                    <a href="/" class="tw-flex tw-items-center">
                        <div class="tw-h-8 tw-w-8 tw-bg-gradient-to-r tw-from-orange-500 tw-to-red-500 tw-rounded-lg tw-flex tw-items-center tw-justify-center">
                            <i data-feather="zap" class="tw-h-5 tw-w-5 tw-text-white"></i>
                        </div>
                        <h1 class="tw-ml-3 tw-text-xl tw-font-bold tw-text-gray-900">Time2Eat</h1>
                    </a>
                </div>
                <nav class="tw-flex tw-items-center tw-space-x-4">
                    <a href="/browse" class="tw-text-gray-600 hover:tw-text-gray-900 tw-transition-colors">Browse</a>
                    <a href="/orders" class="tw-text-gray-600 hover:tw-text-gray-900 tw-transition-colors">Orders</a>
                    <a href="/profile" class="tw-text-gray-600 hover:tw-text-gray-900 tw-transition-colors">Profile</a>
                </nav>
            </div>
        </div>
    </header>

    <main class="tw-max-w-7xl tw-mx-auto tw-px-4 sm:tw-px-6 lg:tw-px-8 tw-py-8">
        <!-- Page Header -->
        <div class="tw-mb-8">
            <h1 class="tw-text-3xl tw-font-bold tw-text-gray-900">Shopping Cart</h1>
            <p class="tw-mt-2 tw-text-gray-600">Review your items and proceed to checkout</p>
        </div>

        <?php if (empty($cartItems)): ?>
            <!-- Empty Cart -->
            <div class="tw-text-center tw-py-12">
                <div class="tw-mx-auto tw-h-24 tw-w-24 tw-bg-gray-100 tw-rounded-full tw-flex tw-items-center tw-justify-center tw-mb-6">
                    <i data-feather="shopping-cart" class="tw-h-12 tw-w-12 tw-text-gray-400"></i>
                </div>
                <h2 class="tw-text-2xl tw-font-semibold tw-text-gray-900 tw-mb-2">Your cart is empty</h2>
                <p class="tw-text-gray-600 tw-mb-8">Start adding some delicious items to your cart!</p>
                <a href="/browse" class="tw-inline-flex tw-items-center tw-px-6 tw-py-3 tw-bg-gradient-to-r tw-from-orange-500 tw-to-red-500 tw-text-white tw-font-medium tw-rounded-lg hover:tw-from-orange-600 hover:tw-to-red-600 tw-transition-all tw-duration-200">
                    <i data-feather="search" class="tw-h-5 tw-w-5 tw-mr-2"></i>
                    Browse Restaurants
                </a>

                <?php if (!empty($recentItems)): ?>
                    <!-- Recent Items -->
                    <div class="tw-mt-12">
                        <h3 class="tw-text-lg tw-font-semibold tw-text-gray-900 tw-mb-4">Recently Viewed</h3>
                        <div class="tw-grid tw-grid-cols-1 sm:tw-grid-cols-2 lg:tw-grid-cols-3 tw-gap-4">
                            <?php foreach ($recentItems as $item): ?>
                                <div class="tw-bg-white tw-rounded-lg tw-shadow-md tw-p-4">
                                    <img src="<?= e($item['image'] ?: '/images/placeholder-food.jpg') ?>" alt="<?= e($item['name']) ?>" class="tw-w-full tw-h-32 tw-object-cover tw-rounded-lg tw-mb-3">
                                    <h4 class="tw-font-medium tw-text-gray-900 tw-mb-1"><?= e($item['name']) ?></h4>
                                    <p class="tw-text-sm tw-text-gray-600 tw-mb-2"><?= e($item['restaurant_name']) ?></p>
                                    <div class="tw-flex tw-items-center tw-justify-between">
                                        <span class="tw-font-semibold tw-text-gray-900"><?= number_format($item['price']) ?> XAF</span>
                                        <button onclick="quickAddToCart(<?= $item['id'] ?>)" class="tw-bg-primary-500 hover:tw-bg-primary-600 tw-text-white tw-px-3 tw-py-1 tw-rounded-md tw-text-sm tw-font-medium tw-transition-colors">
                                            Add
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <!-- Cart Items -->
            <div class="tw-grid tw-grid-cols-1 lg:tw-grid-cols-3 tw-gap-8">
                <!-- Cart Items List -->
                <div class="lg:tw-col-span-2">
                    <div class="tw-bg-white tw-rounded-lg tw-shadow-md tw-overflow-hidden">
                        <div class="tw-px-6 tw-py-4 tw-border-b tw-border-gray-200">
                            <div class="tw-flex tw-items-center tw-justify-between">
                                <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Cart Items (<?= $cartTotals['item_count'] ?? 0 ?>)</h2>
                                <button onclick="clearCart()" class="tw-text-red-600 hover:tw-text-red-700 tw-text-sm tw-font-medium tw-transition-colors">
                                    Clear Cart
                                </button>
                            </div>
                        </div>

                        <div class="tw-divide-y tw-divide-gray-200" id="cart-items">
                            <?php 
                            $currentRestaurant = null;
                            foreach ($cartItems as $item): 
                                if ($currentRestaurant !== $item['restaurant_id']):
                                    $currentRestaurant = $item['restaurant_id'];
                            ?>
                                <!-- Restaurant Header -->
                                <div class="tw-px-6 tw-py-3 tw-bg-gray-50">
                                    <div class="tw-flex tw-items-center">
                                        <i data-feather="store" class="tw-h-5 tw-w-5 tw-text-gray-400 tw-mr-2"></i>
                                        <h3 class="tw-font-medium tw-text-gray-900"><?= e($item['restaurant_name']) ?></h3>
                                        <span class="tw-ml-2 tw-text-sm tw-text-gray-500">
                                            (Delivery: <?= number_format($item['delivery_fee']) ?> XAF, Min: <?= number_format($item['minimum_order']) ?> XAF)
                                        </span>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <!-- Cart Item -->
                            <div class="tw-px-6 tw-py-4 cart-item" data-item-id="<?= $item['id'] ?>">
                                <div class="tw-flex tw-items-start tw-space-x-4">
                                    <img src="<?= e($item['item_image'] ?: '/images/placeholder-food.jpg') ?>" alt="<?= e($item['item_name']) ?>" class="tw-w-16 tw-h-16 tw-object-cover tw-rounded-lg tw-flex-shrink-0">
                                    
                                    <div class="tw-flex-1 tw-min-w-0">
                                        <h4 class="tw-font-medium tw-text-gray-900"><?= e($item['item_name']) ?></h4>
                                        <p class="tw-text-sm tw-text-gray-600 tw-mt-1"><?= e($item['category_name']) ?></p>
                                        
                                        <?php if (!empty($item['customizations']) && $item['customizations'] !== '{}'): ?>
                                            <div class="tw-mt-2">
                                                <p class="tw-text-xs tw-text-gray-500 tw-font-medium">Customizations:</p>
                                                <?php 
                                                $customizations = json_decode($item['customizations'], true);
                                                if ($customizations):
                                                    foreach ($customizations as $option):
                                                ?>
                                                    <p class="tw-text-xs tw-text-gray-600">
                                                        <?= e($option['option']['name']) ?>: 
                                                        <?= implode(', ', array_column($option['values'], 'name')) ?>
                                                    </p>
                                                <?php 
                                                    endforeach;
                                                endif; 
                                                ?>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <?php if (!empty($item['special_instructions'])): ?>
                                            <p class="tw-text-xs tw-text-gray-600 tw-mt-1">
                                                <span class="tw-font-medium">Note:</span> <?= e($item['special_instructions']) ?>
                                            </p>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="tw-flex tw-items-center tw-space-x-3">
                                        <!-- Quantity Controls -->
                                        <div class="tw-flex tw-items-center tw-border tw-border-gray-300 tw-rounded-lg">
                                            <button onclick="updateQuantity(<?= $item['id'] ?>, <?= $item['quantity'] - 1 ?>)" class="tw-p-1 tw-text-gray-500 hover:tw-text-gray-700 tw-transition-colors" <?= $item['quantity'] <= 1 ? 'disabled' : '' ?>>
                                                <i data-feather="minus" class="tw-h-4 tw-w-4"></i>
                                            </button>
                                            <span class="tw-px-3 tw-py-1 tw-text-sm tw-font-medium tw-text-gray-900"><?= $item['quantity'] ?></span>
                                            <button onclick="updateQuantity(<?= $item['id'] ?>, <?= $item['quantity'] + 1 ?>)" class="tw-p-1 tw-text-gray-500 hover:tw-text-gray-700 tw-transition-colors">
                                                <i data-feather="plus" class="tw-h-4 tw-w-4"></i>
                                            </button>
                                        </div>
                                        
                                        <!-- Price -->
                                        <div class="tw-text-right">
                                            <p class="tw-font-semibold tw-text-gray-900"><?= number_format($item['total_price']) ?> XAF</p>
                                            <?php if ($item['quantity'] > 1): ?>
                                                <p class="tw-text-xs tw-text-gray-500"><?= number_format($item['unit_price']) ?> XAF each</p>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <!-- Remove Button -->
                                        <button onclick="removeFromCart(<?= $item['id'] ?>)" class="tw-p-1 tw-text-red-500 hover:tw-text-red-700 tw-transition-colors">
                                            <i data-feather="trash-2" class="tw-h-4 tw-w-4"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- Order Summary -->
                <div class="lg:tw-col-span-1">
                    <div class="tw-bg-white tw-rounded-lg tw-shadow-md tw-p-6 tw-sticky tw-top-4">
                        <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900 tw-mb-4">Order Summary</h2>
                        
                        <div class="tw-space-y-3 tw-mb-4">
                            <div class="tw-flex tw-justify-between tw-text-sm">
                                <span class="tw-text-gray-600">Subtotal</span>
                                <span class="tw-font-medium tw-text-gray-900"><?= number_format($cartTotals['subtotal'] ?? 0) ?> XAF</span>
                            </div>
                            <div class="tw-flex tw-justify-between tw-text-sm">
                                <span class="tw-text-gray-600">Delivery Fee</span>
                                <span class="tw-font-medium tw-text-gray-900"><?= number_format($cartTotals['delivery_fee'] ?? 0) ?> XAF</span>
                            </div>
                            <div class="tw-border-t tw-border-gray-200 tw-pt-3">
                                <div class="tw-flex tw-justify-between">
                                    <span class="tw-font-semibold tw-text-gray-900">Total</span>
                                    <span class="tw-font-semibold tw-text-gray-900"><?= number_format($cartTotals['total'] ?? 0) ?> XAF</span>
                                </div>
                            </div>
                        </div>

                        <!-- Promo Code -->
                        <div class="tw-mb-6">
                            <div class="tw-flex tw-space-x-2">
                                <input type="text" id="promo-code" placeholder="Promo code" class="tw-flex-1 tw-px-3 tw-py-2 tw-border tw-border-gray-300 tw-rounded-md tw-text-sm focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-primary-500 focus:tw-border-transparent">
                                <button onclick="applyPromoCode()" class="tw-px-4 tw-py-2 tw-bg-gray-200 hover:tw-bg-gray-300 tw-text-gray-700 tw-text-sm tw-font-medium tw-rounded-md tw-transition-colors">
                                    Apply
                                </button>
                            </div>
                            <div id="promo-message" class="tw-mt-2 tw-text-sm tw-hidden"></div>
                        </div>

                        <!-- Checkout Button -->
                        <a href="/checkout" class="tw-block tw-w-full tw-bg-gradient-to-r tw-from-orange-500 tw-to-red-500 tw-text-white tw-text-center tw-py-3 tw-px-4 tw-rounded-lg tw-font-medium hover:tw-from-orange-600 hover:tw-to-red-600 tw-transition-all tw-duration-200">
                            Proceed to Checkout
                        </a>

                        <!-- Continue Shopping -->
                        <a href="/browse" class="tw-block tw-w-full tw-text-center tw-py-2 tw-px-4 tw-text-gray-600 hover:tw-text-gray-900 tw-text-sm tw-font-medium tw-transition-colors tw-mt-3">
                            Continue Shopping
                        </a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </main>

    <script>
        // Initialize Feather icons
        feather.replace();

        // Cart management functions
        function updateQuantity(cartItemId, newQuantity) {
            if (newQuantity < 1) return;

            fetch('/cart/update', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    cart_item_id: cartItemId,
                    quantity: newQuantity
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.message || 'Failed to update cart');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to update cart');
            });
        }

        function removeFromCart(cartItemId) {
            if (!confirm('Remove this item from your cart?')) return;

            fetch('/cart/remove', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    cart_item_id: cartItemId
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.message || 'Failed to remove item');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to remove item');
            });
        }

        function clearCart() {
            if (!confirm('Clear all items from your cart?')) return;

            fetch('/cart/clear', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.message || 'Failed to clear cart');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to clear cart');
            });
        }

        function applyPromoCode() {
            const promoCode = document.getElementById('promo-code').value.trim();
            const messageDiv = document.getElementById('promo-message');

            if (!promoCode) {
                showPromoMessage('Please enter a promo code', 'error');
                return;
            }

            fetch('/cart/apply-promo', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    promo_code: promoCode
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showPromoMessage(data.message, 'success');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    showPromoMessage(data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showPromoMessage('Failed to apply promo code', 'error');
            });
        }

        function showPromoMessage(message, type) {
            const messageDiv = document.getElementById('promo-message');
            messageDiv.textContent = message;
            messageDiv.className = `tw-mt-2 tw-text-sm ${type === 'success' ? 'tw-text-green-600' : 'tw-text-red-600'}`;
            messageDiv.classList.remove('tw-hidden');
        }

        function quickAddToCart(menuItemId) {
            fetch('/cart/quick-add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    menu_item_id: menuItemId
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.message || 'Failed to add item to cart');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to add item to cart');
            });
        }
    </script>
</body>
</html>
