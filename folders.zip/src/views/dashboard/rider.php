<?php
$title = $title ?? 'Rider Dashboard - Time2Eat';
$currentPage = 'dashboard';
$user = $user ?? null;

// Start output buffering for content
ob_start();
?>

<!-- Page header -->
<div class="tw-mb-8">
    <div class="tw-flex tw-items-center tw-justify-between">
        <div>
            <h1 class="tw-text-2xl tw-font-bold tw-text-gray-900">Rider Dashboard</h1>
            <p class="tw-mt-1 tw-text-sm tw-text-gray-500">
                Manage your deliveries and track your earnings.
            </p>
        </div>
        <div class="tw-flex tw-items-center tw-space-x-3">
            <button onclick="toggleAvailability()" class="tw-inline-flex tw-items-center tw-px-4 tw-py-2 tw-rounded-lg tw-text-sm tw-font-medium tw-transition-colors <?= ($user['is_available'] ?? false) ? 'tw-bg-red-100 tw-text-red-800 hover:tw-bg-red-200' : 'tw-bg-green-100 tw-text-green-800 hover:tw-bg-green-200' ?>" id="availability-btn">
                <i data-feather="power" class="tw-h-4 tw-w-4 tw-mr-2"></i>
                <?= ($user['is_available'] ?? false) ? 'Go Offline' : 'Go Online' ?>
            </button>
            <span class="tw-inline-flex tw-items-center tw-px-3 tw-py-1 tw-rounded-full tw-text-sm tw-font-medium tw-bg-blue-100 tw-text-blue-800">
                <i data-feather="dollar-sign" class="tw-h-4 tw-w-4 tw-mr-1"></i>
                <?= number_format($user['balance'] ?? 0) ?> XAF
            </span>
        </div>
    </div>
</div>

<!-- Status Cards -->
<div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-4 tw-gap-6 tw-mb-8">
    <div class="tw-bg-white tw-p-6 tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
        <div class="tw-flex tw-items-center tw-justify-between">
            <div>
                <p class="tw-text-sm tw-font-medium tw-text-gray-600">Active Deliveries</p>
                <p class="tw-text-3xl tw-font-bold tw-text-gray-900">2</p>
                <p class="tw-text-sm tw-text-blue-600">In progress</p>
            </div>
            <div class="tw-p-3 tw-bg-blue-100 tw-rounded-full">
                <i data-feather="truck" class="tw-h-6 tw-w-6 tw-text-blue-600"></i>
            </div>
        </div>
    </div>

    <div class="tw-bg-white tw-p-6 tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
        <div class="tw-flex tw-items-center tw-justify-between">
            <div>
                <p class="tw-text-sm tw-font-medium tw-text-gray-600">Today's Earnings</p>
                <p class="tw-text-3xl tw-font-bold tw-text-gray-900">15,500</p>
                <p class="tw-text-sm tw-text-green-600">+8 deliveries</p>
            </div>
            <div class="tw-p-3 tw-bg-green-100 tw-rounded-full">
                <i data-feather="dollar-sign" class="tw-h-6 tw-w-6 tw-text-green-600"></i>
            </div>
        </div>
    </div>

    <div class="tw-bg-white tw-p-6 tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
        <div class="tw-flex tw-items-center tw-justify-between">
            <div>
                <p class="tw-text-sm tw-font-medium tw-text-gray-600">Completed Today</p>
                <p class="tw-text-3xl tw-font-bold tw-text-gray-900">8</p>
                <p class="tw-text-sm tw-text-gray-500">Deliveries</p>
            </div>
            <div class="tw-p-3 tw-bg-yellow-100 tw-rounded-full">
                <i data-feather="check-circle" class="tw-h-6 tw-w-6 tw-text-yellow-600"></i>
            </div>
        </div>
    </div>

    <div class="tw-bg-white tw-p-6 tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
        <div class="tw-flex tw-items-center tw-justify-between">
            <div>
                <p class="tw-text-sm tw-font-medium tw-text-gray-600">Rating</p>
                <p class="tw-text-3xl tw-font-bold tw-text-gray-900">4.9</p>
                <p class="tw-text-sm tw-text-green-600">Excellent</p>
            </div>
            <div class="tw-p-3 tw-bg-purple-100 tw-rounded-full">
                <i data-feather="star" class="tw-h-6 tw-w-6 tw-text-purple-600"></i>
            </div>
        </div>
    </div>
</div>

<!-- Active Deliveries & Available Orders -->
<div class="tw-grid tw-grid-cols-1 lg:tw-grid-cols-2 tw-gap-8 tw-mb-8">
    <!-- Active Deliveries -->
    <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
        <div class="tw-p-6 tw-border-b tw-border-gray-200">
            <div class="tw-flex tw-items-center tw-justify-between">
                <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Active Deliveries</h2>
                <span class="tw-inline-flex tw-items-center tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium tw-bg-blue-100 tw-text-blue-800">
                    2 Active
                </span>
            </div>
        </div>
        <div class="tw-p-6 tw-space-y-4">
            <!-- Delivery Item -->
            <div class="tw-border tw-border-gray-200 tw-rounded-lg tw-p-4">
                <div class="tw-flex tw-items-center tw-justify-between tw-mb-3">
                    <div class="tw-flex tw-items-center tw-space-x-3">
                        <div class="tw-h-10 tw-w-10 tw-bg-blue-100 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                            <span class="tw-text-blue-600 tw-font-medium tw-text-sm">#001</span>
                        </div>
                        <div>
                            <h3 class="tw-font-medium tw-text-gray-900">Pizza Palace</h3>
                            <p class="tw-text-sm tw-text-gray-500">2 items • 3.2 km</p>
                        </div>
                    </div>
                    <span class="tw-inline-flex tw-items-center tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium tw-bg-yellow-100 tw-text-yellow-800">
                        Picked Up
                    </span>
                </div>
                <div class="tw-flex tw-items-center tw-justify-between tw-text-sm">
                    <div class="tw-text-gray-600">
                        <p>Delivery: Bamenda, Commercial Ave</p>
                        <p>Customer: John Doe</p>
                    </div>
                    <div class="tw-text-right">
                        <p class="tw-font-medium tw-text-gray-900">2,500 XAF</p>
                        <p class="tw-text-green-600">Earning</p>
                    </div>
                </div>
                <div class="tw-mt-3 tw-flex tw-space-x-2">
                    <button class="tw-flex-1 tw-bg-green-500 hover:tw-bg-green-600 tw-text-white tw-px-3 tw-py-2 tw-rounded-md tw-text-sm tw-font-medium tw-transition-colors">
                        <i data-feather="check" class="tw-h-4 tw-w-4 tw-inline tw-mr-1"></i>
                        Mark Delivered
                    </button>
                    <button class="tw-bg-blue-500 hover:tw-bg-blue-600 tw-text-white tw-px-3 tw-py-2 tw-rounded-md tw-text-sm tw-font-medium tw-transition-colors">
                        <i data-feather="map" class="tw-h-4 tw-w-4"></i>
                    </button>
                    <button class="tw-bg-gray-500 hover:tw-bg-gray-600 tw-text-white tw-px-3 tw-py-2 tw-rounded-md tw-text-sm tw-font-medium tw-transition-colors">
                        <i data-feather="phone" class="tw-h-4 tw-w-4"></i>
                    </button>
                </div>
            </div>

            <!-- Delivery Item -->
            <div class="tw-border tw-border-gray-200 tw-rounded-lg tw-p-4">
                <div class="tw-flex tw-items-center tw-justify-between tw-mb-3">
                    <div class="tw-flex tw-items-center tw-space-x-3">
                        <div class="tw-h-10 tw-w-10 tw-bg-orange-100 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                            <span class="tw-text-orange-600 tw-font-medium tw-text-sm">#002</span>
                        </div>
                        <div>
                            <h3 class="tw-font-medium tw-text-gray-900">Burger House</h3>
                            <p class="tw-text-sm tw-text-gray-500">1 item • 1.8 km</p>
                        </div>
                    </div>
                    <span class="tw-inline-flex tw-items-center tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium tw-bg-blue-100 tw-text-blue-800">
                        Ready for Pickup
                    </span>
                </div>
                <div class="tw-flex tw-items-center tw-justify-between tw-text-sm">
                    <div class="tw-text-gray-600">
                        <p>Pickup: Bamenda, Food Street</p>
                        <p>Customer: Jane Smith</p>
                    </div>
                    <div class="tw-text-right">
                        <p class="tw-font-medium tw-text-gray-900">1,800 XAF</p>
                        <p class="tw-text-green-600">Earning</p>
                    </div>
                </div>
                <div class="tw-mt-3 tw-flex tw-space-x-2">
                    <button class="tw-flex-1 tw-bg-orange-500 hover:tw-bg-orange-600 tw-text-white tw-px-3 tw-py-2 tw-rounded-md tw-text-sm tw-font-medium tw-transition-colors">
                        <i data-feather="package" class="tw-h-4 tw-w-4 tw-inline tw-mr-1"></i>
                        Pick Up Order
                    </button>
                    <button class="tw-bg-blue-500 hover:tw-bg-blue-600 tw-text-white tw-px-3 tw-py-2 tw-rounded-md tw-text-sm tw-font-medium tw-transition-colors">
                        <i data-feather="map" class="tw-h-4 tw-w-4"></i>
                    </button>
                    <button class="tw-bg-gray-500 hover:tw-bg-gray-600 tw-text-white tw-px-3 tw-py-2 tw-rounded-md tw-text-sm tw-font-medium tw-transition-colors">
                        <i data-feather="phone" class="tw-h-4 tw-w-4"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Available Orders -->
    <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
        <div class="tw-p-6 tw-border-b tw-border-gray-200">
            <div class="tw-flex tw-items-center tw-justify-between">
                <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Available Orders</h2>
                <button class="tw-text-orange-600 hover:tw-text-orange-500 tw-text-sm tw-font-medium">
                    <i data-feather="refresh-cw" class="tw-h-4 tw-w-4 tw-inline tw-mr-1"></i>
                    Refresh
                </button>
            </div>
        </div>
        <div class="tw-p-6 tw-space-y-4">
            <!-- Available Order -->
            <div class="tw-border tw-border-gray-200 tw-rounded-lg tw-p-4 hover:tw-border-orange-300 tw-transition-colors">
                <div class="tw-flex tw-items-center tw-justify-between tw-mb-3">
                    <div class="tw-flex tw-items-center tw-space-x-3">
                        <div class="tw-h-10 tw-w-10 tw-bg-green-100 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                            <i data-feather="clock" class="tw-h-5 tw-w-5 tw-text-green-600"></i>
                        </div>
                        <div>
                            <h3 class="tw-font-medium tw-text-gray-900">Asian Kitchen</h3>
                            <p class="tw-text-sm tw-text-gray-500">3 items • 2.5 km • 15 min</p>
                        </div>
                    </div>
                    <div class="tw-text-right">
                        <p class="tw-font-medium tw-text-gray-900">3,200 XAF</p>
                        <p class="tw-text-green-600 tw-text-sm">Earning</p>
                    </div>
                </div>
                <div class="tw-text-sm tw-text-gray-600 tw-mb-3">
                    <p>Pickup: Bamenda, Nkwen</p>
                    <p>Delivery: Bamenda, Mile 4</p>
                </div>
                <div class="tw-flex tw-space-x-2">
                    <button class="tw-flex-1 tw-bg-green-500 hover:tw-bg-green-600 tw-text-white tw-px-3 tw-py-2 tw-rounded-md tw-text-sm tw-font-medium tw-transition-colors">
                        Accept Order
                    </button>
                    <button class="tw-bg-gray-200 hover:tw-bg-gray-300 tw-text-gray-700 tw-px-3 tw-py-2 tw-rounded-md tw-text-sm tw-font-medium tw-transition-colors">
                        View Details
                    </button>
                </div>
            </div>

            <!-- Available Order -->
            <div class="tw-border tw-border-gray-200 tw-rounded-lg tw-p-4 hover:tw-border-orange-300 tw-transition-colors">
                <div class="tw-flex tw-items-center tw-justify-between tw-mb-3">
                    <div class="tw-flex tw-items-center tw-space-x-3">
                        <div class="tw-h-10 tw-w-10 tw-bg-purple-100 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                            <i data-feather="clock" class="tw-h-5 tw-w-5 tw-text-purple-600"></i>
                        </div>
                        <div>
                            <h3 class="tw-font-medium tw-text-gray-900">Sweet Dreams</h3>
                            <p class="tw-text-sm tw-text-gray-500">2 items • 1.2 km • 8 min</p>
                        </div>
                    </div>
                    <div class="tw-text-right">
                        <p class="tw-font-medium tw-text-gray-900">1,500 XAF</p>
                        <p class="tw-text-green-600 tw-text-sm">Earning</p>
                    </div>
                </div>
                <div class="tw-text-sm tw-text-gray-600 tw-mb-3">
                    <p>Pickup: Bamenda, Commercial Ave</p>
                    <p>Delivery: Bamenda, Up Station</p>
                </div>
                <div class="tw-flex tw-space-x-2">
                    <button class="tw-flex-1 tw-bg-green-500 hover:tw-bg-green-600 tw-text-white tw-px-3 tw-py-2 tw-rounded-md tw-text-sm tw-font-medium tw-transition-colors">
                        Accept Order
                    </button>
                    <button class="tw-bg-gray-200 hover:tw-bg-gray-300 tw-text-gray-700 tw-px-3 tw-py-2 tw-rounded-md tw-text-sm tw-font-medium tw-transition-colors">
                        View Details
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Earnings Chart & Recent Activity -->
<div class="tw-grid tw-grid-cols-1 lg:tw-grid-cols-2 tw-gap-8">
    <!-- Earnings Chart -->
    <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
        <div class="tw-p-6 tw-border-b tw-border-gray-200">
            <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Weekly Earnings</h2>
        </div>
        <div class="tw-p-6">
            <canvas id="earningsChart" width="400" height="200"></canvas>
        </div>
    </div>

    <!-- Recent Activity -->
    <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
        <div class="tw-p-6 tw-border-b tw-border-gray-200">
            <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Recent Activity</h2>
        </div>
        <div class="tw-p-6 tw-space-y-4">
            <div class="tw-flex tw-items-center tw-space-x-3">
                <div class="tw-h-8 tw-w-8 tw-bg-green-100 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                    <i data-feather="check" class="tw-h-4 tw-w-4 tw-text-green-600"></i>
                </div>
                <div class="tw-flex-1">
                    <p class="tw-text-sm tw-font-medium tw-text-gray-900">Delivered order #003</p>
                    <p class="tw-text-xs tw-text-gray-500">2 minutes ago • +2,500 XAF</p>
                </div>
            </div>

            <div class="tw-flex tw-items-center tw-space-x-3">
                <div class="tw-h-8 tw-w-8 tw-bg-blue-100 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                    <i data-feather="package" class="tw-h-4 tw-w-4 tw-text-blue-600"></i>
                </div>
                <div class="tw-flex-1">
                    <p class="tw-text-sm tw-font-medium tw-text-gray-900">Picked up order #002</p>
                    <p class="tw-text-xs tw-text-gray-500">15 minutes ago</p>
                </div>
            </div>

            <div class="tw-flex tw-items-center tw-space-x-3">
                <div class="tw-h-8 tw-w-8 tw-bg-green-100 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                    <i data-feather="check" class="tw-h-4 tw-w-4 tw-text-green-600"></i>
                </div>
                <div class="tw-flex-1">
                    <p class="tw-text-sm tw-font-medium tw-text-gray-900">Delivered order #001</p>
                    <p class="tw-text-xs tw-text-gray-500">32 minutes ago • +1,800 XAF</p>
                </div>
            </div>

            <div class="tw-flex tw-items-center tw-space-x-3">
                <div class="tw-h-8 tw-w-8 tw-bg-yellow-100 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                    <i data-feather="clock" class="tw-h-4 tw-w-4 tw-text-yellow-600"></i>
                </div>
                <div class="tw-flex-1">
                    <p class="tw-text-sm tw-font-medium tw-text-gray-900">Accepted new order</p>
                    <p class="tw-text-xs tw-text-gray-500">45 minutes ago</p>
                </div>
            </div>

            <div class="tw-flex tw-items-center tw-space-x-3">
                <div class="tw-h-8 tw-w-8 tw-bg-green-100 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                    <i data-feather="power" class="tw-h-4 tw-w-4 tw-text-green-600"></i>
                </div>
                <div class="tw-flex-1">
                    <p class="tw-text-sm tw-font-medium tw-text-gray-900">Went online</p>
                    <p class="tw-text-xs tw-text-gray-500">2 hours ago</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Availability toggle
function toggleAvailability() {
    const btn = document.getElementById('availability-btn');
    const isOnline = btn.textContent.includes('Go Offline');
    
    fetch('/api/rider/toggle-availability', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify({ available: !isOnline })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            if (isOnline) {
                btn.innerHTML = '<i data-feather="power" class="tw-h-4 tw-w-4 tw-mr-2"></i>Go Online';
                btn.className = btn.className.replace('tw-bg-red-100 tw-text-red-800 hover:tw-bg-red-200', 'tw-bg-green-100 tw-text-green-800 hover:tw-bg-green-200');
            } else {
                btn.innerHTML = '<i data-feather="power" class="tw-h-4 tw-w-4 tw-mr-2"></i>Go Offline';
                btn.className = btn.className.replace('tw-bg-green-100 tw-text-green-800 hover:tw-bg-green-200', 'tw-bg-red-100 tw-text-red-800 hover:tw-bg-red-200');
            }
            feather.replace();
        }
    })
    .catch(error => {
        console.error('Error toggling availability:', error);
    });
}

// Earnings Chart
document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('earningsChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            datasets: [{
                label: 'Earnings (XAF)',
                data: [12000, 15000, 18000, 14000, 16000, 22000, 15500],
                backgroundColor: 'rgba(34, 197, 94, 0.8)',
                borderColor: 'rgb(34, 197, 94)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return value.toLocaleString() + ' XAF';
                        }
                    }
                }
            }
        }
    });
});

// Auto-refresh available orders
setInterval(function() {
    // Refresh available orders every 30 seconds
    fetch('/api/rider/available-orders')
        .then(response => response.json())
        .then(data => {
            // Update available orders section
            console.log('Available orders updated');
        })
        .catch(error => console.log('Failed to refresh orders:', error));
}, 30000);
</script>

<?php
// Capture the content
$content = ob_get_clean();

// Include the dashboard layout
include __DIR__ . '/../components/dashboard-layout.php';
?>
