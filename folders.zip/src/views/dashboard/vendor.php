<?php
$title = $title ?? 'Vendor Dashboard - Time2Eat';
$currentPage = 'dashboard';
$user = $user ?? null;

// Start output buffering for content
ob_start();
?>

<!-- Page header -->
<div class="tw-mb-8">
    <div class="tw-flex tw-items-center tw-justify-between">
        <div>
            <h1 class="tw-text-2xl tw-font-bold tw-text-gray-900">Restaurant Dashboard</h1>
            <p class="tw-mt-1 tw-text-sm tw-text-gray-500">
                Manage your restaurant and track your performance.
            </p>
        </div>
        <div class="tw-flex tw-items-center tw-space-x-3">
            <span class="tw-inline-flex tw-items-center tw-px-3 tw-py-1 tw-rounded-full tw-text-sm tw-font-medium <?= ($user['status'] ?? 'pending') === 'approved' ? 'tw-bg-green-100 tw-text-green-800' : 'tw-bg-yellow-100 tw-text-yellow-800' ?>">
                <i data-feather="<?= ($user['status'] ?? 'pending') === 'approved' ? 'check-circle' : 'clock' ?>" class="tw-h-4 tw-w-4 tw-mr-1"></i>
                <?= ucfirst($user['status'] ?? 'Pending') ?>
            </span>
            <span class="tw-inline-flex tw-items-center tw-px-3 tw-py-1 tw-rounded-full tw-text-sm tw-font-medium tw-bg-blue-100 tw-text-blue-800">
                <i data-feather="dollar-sign" class="tw-h-4 tw-w-4 tw-mr-1"></i>
                <?= number_format($user['balance'] ?? 0) ?> XAF
            </span>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="tw-mb-8">
    <div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-4 tw-gap-4">
        <a href="/vendor/menu/add" class="tw-bg-gradient-to-r tw-from-orange-500 tw-to-red-500 tw-text-white tw-p-6 tw-rounded-xl tw-shadow-lg hover:tw-shadow-xl tw-transition-all tw-duration-200 tw-group">
            <div class="tw-flex tw-items-center tw-space-x-3">
                <i data-feather="plus" class="tw-h-8 tw-w-8 group-hover:tw-scale-110 tw-transition-transform"></i>
                <div>
                    <h3 class="tw-text-lg tw-font-semibold">Add Menu Item</h3>
                    <p class="tw-text-orange-100 tw-text-sm">Expand your menu</p>
                </div>
            </div>
        </a>

        <a href="/vendor/orders" class="tw-bg-white tw-p-6 tw-rounded-xl tw-shadow-lg hover:tw-shadow-xl tw-transition-all tw-duration-200 tw-group tw-border tw-border-gray-200">
            <div class="tw-flex tw-items-center tw-space-x-3">
                <i data-feather="shopping-bag" class="tw-h-8 tw-w-8 tw-text-blue-500 group-hover:tw-scale-110 tw-transition-transform"></i>
                <div>
                    <h3 class="tw-text-lg tw-font-semibold tw-text-gray-900">Orders</h3>
                    <p class="tw-text-gray-500 tw-text-sm">Manage orders</p>
                </div>
                <span class="tw-inline-flex tw-items-center tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium tw-bg-red-100 tw-text-red-800">
                    3 New
                </span>
            </div>
        </a>

        <a href="/vendor/menu" class="tw-bg-white tw-p-6 tw-rounded-xl tw-shadow-lg hover:tw-shadow-xl tw-transition-all tw-duration-200 tw-group tw-border tw-border-gray-200">
            <div class="tw-flex tw-items-center tw-space-x-3">
                <i data-feather="menu" class="tw-h-8 tw-w-8 tw-text-green-500 group-hover:tw-scale-110 tw-transition-transform"></i>
                <div>
                    <h3 class="tw-text-lg tw-font-semibold tw-text-gray-900">Menu</h3>
                    <p class="tw-text-gray-500 tw-text-sm">Manage items</p>
                </div>
            </div>
        </a>

        <a href="/vendor/analytics" class="tw-bg-white tw-p-6 tw-rounded-xl tw-shadow-lg hover:tw-shadow-xl tw-transition-all tw-duration-200 tw-group tw-border tw-border-gray-200">
            <div class="tw-flex tw-items-center tw-space-x-3">
                <i data-feather="bar-chart-2" class="tw-h-8 tw-w-8 tw-text-purple-500 group-hover:tw-scale-110 tw-transition-transform"></i>
                <div>
                    <h3 class="tw-text-lg tw-font-semibold tw-text-gray-900">Analytics</h3>
                    <p class="tw-text-gray-500 tw-text-sm">View reports</p>
                </div>
            </div>
        </a>
    </div>
</div>

<!-- Stats Cards -->
<div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-4 tw-gap-6 tw-mb-8">
    <div class="tw-bg-white tw-p-6 tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
        <div class="tw-flex tw-items-center tw-justify-between">
            <div>
                <p class="tw-text-sm tw-font-medium tw-text-gray-600">Today's Orders</p>
                <p class="tw-text-3xl tw-font-bold tw-text-gray-900">12</p>
                <p class="tw-text-sm tw-text-green-600">+3 from yesterday</p>
            </div>
            <div class="tw-p-3 tw-bg-blue-100 tw-rounded-full">
                <i data-feather="shopping-bag" class="tw-h-6 tw-w-6 tw-text-blue-600"></i>
            </div>
        </div>
    </div>

    <div class="tw-bg-white tw-p-6 tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
        <div class="tw-flex tw-items-center tw-justify-between">
            <div>
                <p class="tw-text-sm tw-font-medium tw-text-gray-600">Today's Revenue</p>
                <p class="tw-text-3xl tw-font-bold tw-text-gray-900">85,000</p>
                <p class="tw-text-sm tw-text-green-600">+12% from yesterday</p>
            </div>
            <div class="tw-p-3 tw-bg-green-100 tw-rounded-full">
                <i data-feather="dollar-sign" class="tw-h-6 tw-w-6 tw-text-green-600"></i>
            </div>
        </div>
    </div>

    <div class="tw-bg-white tw-p-6 tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
        <div class="tw-flex tw-items-center tw-justify-between">
            <div>
                <p class="tw-text-sm tw-font-medium tw-text-gray-600">Menu Items</p>
                <p class="tw-text-3xl tw-font-bold tw-text-gray-900">45</p>
                <p class="tw-text-sm tw-text-gray-500">5 out of stock</p>
            </div>
            <div class="tw-p-3 tw-bg-yellow-100 tw-rounded-full">
                <i data-feather="menu" class="tw-h-6 tw-w-6 tw-text-yellow-600"></i>
            </div>
        </div>
    </div>

    <div class="tw-bg-white tw-p-6 tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
        <div class="tw-flex tw-items-center tw-justify-between">
            <div>
                <p class="tw-text-sm tw-font-medium tw-text-gray-600">Rating</p>
                <p class="tw-text-3xl tw-font-bold tw-text-gray-900">4.8</p>
                <p class="tw-text-sm tw-text-green-600">Based on 124 reviews</p>
            </div>
            <div class="tw-p-3 tw-bg-purple-100 tw-rounded-full">
                <i data-feather="star" class="tw-h-6 tw-w-6 tw-text-purple-600"></i>
            </div>
        </div>
    </div>
</div>

<!-- Recent Orders & Performance Chart -->
<div class="tw-grid tw-grid-cols-1 lg:tw-grid-cols-2 tw-gap-8 tw-mb-8">
    <!-- Recent Orders -->
    <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
        <div class="tw-p-6 tw-border-b tw-border-gray-200">
            <div class="tw-flex tw-items-center tw-justify-between">
                <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Recent Orders</h2>
                <a href="/vendor/orders" class="tw-text-orange-600 hover:tw-text-orange-500 tw-text-sm tw-font-medium">View all</a>
            </div>
        </div>
        <div class="tw-p-6 tw-space-y-4">
            <!-- Order Item -->
            <div class="tw-flex tw-items-center tw-justify-between tw-p-4 tw-bg-gray-50 tw-rounded-lg">
                <div class="tw-flex tw-items-center tw-space-x-3">
                    <div class="tw-h-10 tw-w-10 tw-bg-blue-100 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                        <span class="tw-text-blue-600 tw-font-medium tw-text-sm">#001</span>
                    </div>
                    <div>
                        <h3 class="tw-font-medium tw-text-gray-900">Margherita Pizza x2</h3>
                        <p class="tw-text-sm tw-text-gray-500">John Doe • 5 min ago</p>
                    </div>
                </div>
                <div class="tw-flex tw-items-center tw-space-x-3">
                    <span class="tw-inline-flex tw-items-center tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium tw-bg-yellow-100 tw-text-yellow-800">
                        Preparing
                    </span>
                    <span class="tw-font-medium tw-text-gray-900">7,000 XAF</span>
                </div>
            </div>

            <!-- Order Item -->
            <div class="tw-flex tw-items-center tw-justify-between tw-p-4 tw-bg-gray-50 tw-rounded-lg">
                <div class="tw-flex tw-items-center tw-space-x-3">
                    <div class="tw-h-10 tw-w-10 tw-bg-green-100 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                        <span class="tw-text-green-600 tw-font-medium tw-text-sm">#002</span>
                    </div>
                    <div>
                        <h3 class="tw-font-medium tw-text-gray-900">Chicken Burger</h3>
                        <p class="tw-text-sm tw-text-gray-500">Jane Smith • 15 min ago</p>
                    </div>
                </div>
                <div class="tw-flex tw-items-center tw-space-x-3">
                    <span class="tw-inline-flex tw-items-center tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium tw-bg-blue-100 tw-text-blue-800">
                        Ready
                    </span>
                    <span class="tw-font-medium tw-text-gray-900">3,500 XAF</span>
                </div>
            </div>

            <!-- Order Item -->
            <div class="tw-flex tw-items-center tw-justify-between tw-p-4 tw-bg-gray-50 tw-rounded-lg">
                <div class="tw-flex tw-items-center tw-space-x-3">
                    <div class="tw-h-10 tw-w-10 tw-bg-gray-100 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                        <span class="tw-text-gray-600 tw-font-medium tw-text-sm">#003</span>
                    </div>
                    <div>
                        <h3 class="tw-font-medium tw-text-gray-900">Caesar Salad</h3>
                        <p class="tw-text-sm tw-text-gray-500">Mike Johnson • 30 min ago</p>
                    </div>
                </div>
                <div class="tw-flex tw-items-center tw-space-x-3">
                    <span class="tw-inline-flex tw-items-center tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium tw-bg-green-100 tw-text-green-800">
                        Delivered
                    </span>
                    <span class="tw-font-medium tw-text-gray-900">2,500 XAF</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Performance Chart -->
    <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
        <div class="tw-p-6 tw-border-b tw-border-gray-200">
            <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Sales Performance</h2>
        </div>
        <div class="tw-p-6">
            <canvas id="salesChart" width="400" height="200"></canvas>
        </div>
    </div>
</div>

<!-- Popular Items & Low Stock Alert -->
<div class="tw-grid tw-grid-cols-1 lg:tw-grid-cols-2 tw-gap-8">
    <!-- Popular Items -->
    <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
        <div class="tw-p-6 tw-border-b tw-border-gray-200">
            <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Popular Items</h2>
        </div>
        <div class="tw-p-6 tw-space-y-4">
            <div class="tw-flex tw-items-center tw-justify-between">
                <div class="tw-flex tw-items-center tw-space-x-3">
                    <img src="https://via.placeholder.com/50x50?text=🍕" alt="Pizza" class="tw-w-12 tw-h-12 tw-rounded-lg tw-object-cover">
                    <div>
                        <h3 class="tw-font-medium tw-text-gray-900">Margherita Pizza</h3>
                        <p class="tw-text-sm tw-text-gray-500">45 orders this week</p>
                    </div>
                </div>
                <div class="tw-text-right">
                    <p class="tw-font-medium tw-text-gray-900">3,500 XAF</p>
                    <p class="tw-text-sm tw-text-green-600">+15%</p>
                </div>
            </div>

            <div class="tw-flex tw-items-center tw-justify-between">
                <div class="tw-flex tw-items-center tw-space-x-3">
                    <img src="https://via.placeholder.com/50x50?text=🍔" alt="Burger" class="tw-w-12 tw-h-12 tw-rounded-lg tw-object-cover">
                    <div>
                        <h3 class="tw-font-medium tw-text-gray-900">Chicken Burger</h3>
                        <p class="tw-text-sm tw-text-gray-500">32 orders this week</p>
                    </div>
                </div>
                <div class="tw-text-right">
                    <p class="tw-font-medium tw-text-gray-900">3,000 XAF</p>
                    <p class="tw-text-sm tw-text-green-600">+8%</p>
                </div>
            </div>

            <div class="tw-flex tw-items-center tw-justify-between">
                <div class="tw-flex tw-items-center tw-space-x-3">
                    <img src="https://via.placeholder.com/50x50?text=🥗" alt="Salad" class="tw-w-12 tw-h-12 tw-rounded-lg tw-object-cover">
                    <div>
                        <h3 class="tw-font-medium tw-text-gray-900">Caesar Salad</h3>
                        <p class="tw-text-sm tw-text-gray-500">28 orders this week</p>
                    </div>
                </div>
                <div class="tw-text-right">
                    <p class="tw-font-medium tw-text-gray-900">2,500 XAF</p>
                    <p class="tw-text-sm tw-text-red-600">-3%</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Low Stock Alert -->
    <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
        <div class="tw-p-6 tw-border-b tw-border-gray-200">
            <div class="tw-flex tw-items-center tw-justify-between">
                <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Low Stock Alert</h2>
                <span class="tw-inline-flex tw-items-center tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium tw-bg-red-100 tw-text-red-800">
                    5 Items
                </span>
            </div>
        </div>
        <div class="tw-p-6 tw-space-y-4">
            <div class="tw-flex tw-items-center tw-justify-between tw-p-3 tw-bg-red-50 tw-rounded-lg tw-border tw-border-red-200">
                <div class="tw-flex tw-items-center tw-space-x-3">
                    <i data-feather="alert-triangle" class="tw-h-5 tw-w-5 tw-text-red-500"></i>
                    <div>
                        <h3 class="tw-font-medium tw-text-gray-900">Chicken Wings</h3>
                        <p class="tw-text-sm tw-text-red-600">Only 2 left</p>
                    </div>
                </div>
                <button class="tw-text-red-600 hover:tw-text-red-700 tw-text-sm tw-font-medium">
                    Restock
                </button>
            </div>

            <div class="tw-flex tw-items-center tw-justify-between tw-p-3 tw-bg-yellow-50 tw-rounded-lg tw-border tw-border-yellow-200">
                <div class="tw-flex tw-items-center tw-space-x-3">
                    <i data-feather="alert-circle" class="tw-h-5 tw-w-5 tw-text-yellow-500"></i>
                    <div>
                        <h3 class="tw-font-medium tw-text-gray-900">French Fries</h3>
                        <p class="tw-text-sm tw-text-yellow-600">5 left</p>
                    </div>
                </div>
                <button class="tw-text-yellow-600 hover:tw-text-yellow-700 tw-text-sm tw-font-medium">
                    Restock
                </button>
            </div>

            <div class="tw-flex tw-items-center tw-justify-between tw-p-3 tw-bg-yellow-50 tw-rounded-lg tw-border tw-border-yellow-200">
                <div class="tw-flex tw-items-center tw-space-x-3">
                    <i data-feather="alert-circle" class="tw-h-5 tw-w-5 tw-text-yellow-500"></i>
                    <div>
                        <h3 class="tw-font-medium tw-text-gray-900">Chocolate Cake</h3>
                        <p class="tw-text-sm tw-text-yellow-600">3 left</p>
                    </div>
                </div>
                <button class="tw-text-yellow-600 hover:tw-text-yellow-700 tw-text-sm tw-font-medium">
                    Restock
                </button>
            </div>
        </div>
    </div>
</div>

<script>
// Sales Chart
document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('salesChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            datasets: [{
                label: 'Sales (XAF)',
                data: [45000, 52000, 48000, 61000, 55000, 67000, 85000],
                borderColor: 'rgb(249, 115, 22)',
                backgroundColor: 'rgba(249, 115, 22, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return value.toLocaleString() + ' XAF';
                        }
                    }
                }
            }
        }
    });
});
</script>

<?php
// Capture the content
$content = ob_get_clean();

// Include the dashboard layout
include __DIR__ . '/../components/dashboard-layout.php';
?>
