<?php
$title = $title ?? 'Customer Dashboard - Time2Eat';
$currentPage = 'dashboard';
$user = $user ?? null;

// Start output buffering for content
ob_start();
?>

<!-- Page header -->
<div class="tw-mb-8">
    <div class="tw-flex tw-items-center tw-justify-between">
        <div>
            <h1 class="tw-text-2xl tw-font-bold tw-text-gray-900">Welcome back, <?= e($user['first_name'] ?? 'Customer') ?>!</h1>
            <p class="tw-mt-1 tw-text-sm tw-text-gray-500">
                Here's what's happening with your orders today.
            </p>
        </div>
        <div class="tw-flex tw-items-center tw-space-x-3">
            <span class="tw-inline-flex tw-items-center tw-px-3 tw-py-1 tw-rounded-full tw-text-sm tw-font-medium tw-bg-green-100 tw-text-green-800">
                <i data-feather="dollar-sign" class="tw-h-4 tw-w-4 tw-mr-1"></i>
                <?= number_format($user['balance'] ?? 0) ?> XAF
            </span>
            <?php if (!empty($user['affiliate_code'])): ?>
                <span class="tw-inline-flex tw-items-center tw-px-3 tw-py-1 tw-rounded-full tw-text-sm tw-font-medium tw-bg-purple-100 tw-text-purple-800">
                    <i data-feather="users" class="tw-h-4 tw-w-4 tw-mr-1"></i>
                    Affiliate: <?= e($user['affiliate_code']) ?>
                </span>
            <?php endif; ?>
        </div>
    </div>
</div>
<!-- Quick Actions -->
<div class="tw-mb-8">
    <div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-4 tw-gap-4">
        <a href="/browse" class="tw-bg-gradient-to-r tw-from-orange-500 tw-to-red-500 tw-text-white tw-p-6 tw-rounded-xl tw-shadow-lg hover:tw-shadow-xl tw-transition-all tw-duration-200 tw-group">
            <div class="tw-flex tw-items-center tw-space-x-3">
                <i data-feather="search" class="tw-h-8 tw-w-8 group-hover:tw-scale-110 tw-transition-transform"></i>
                <div>
                    <h3 class="tw-text-lg tw-font-semibold">Browse Food</h3>
                    <p class="tw-text-orange-100 tw-text-sm">Find delicious meals</p>
                </div>
            </div>
        </a>

        <a href="/customer/orders" class="tw-bg-white tw-p-6 tw-rounded-xl tw-shadow-lg hover:tw-shadow-xl tw-transition-all tw-duration-200 tw-group tw-border tw-border-gray-200">
            <div class="tw-flex tw-items-center tw-space-x-3">
                <i data-feather="package" class="tw-h-8 tw-w-8 tw-text-blue-500 group-hover:tw-scale-110 tw-transition-transform"></i>
                <div>
                    <h3 class="tw-text-lg tw-font-semibold tw-text-gray-900">My Orders</h3>
                    <p class="tw-text-gray-500 tw-text-sm">Track your orders</p>
                </div>
            </div>
        </a>

        <a href="/customer/favorites" class="tw-bg-white tw-p-6 tw-rounded-xl tw-shadow-lg hover:tw-shadow-xl tw-transition-all tw-duration-200 tw-group tw-border tw-border-gray-200">
            <div class="tw-flex tw-items-center tw-space-x-3">
                <i data-feather="heart" class="tw-h-8 tw-w-8 tw-text-pink-500 group-hover:tw-scale-110 tw-transition-transform"></i>
                <div>
                    <h3 class="tw-text-lg tw-font-semibold tw-text-gray-900">Favorites</h3>
                    <p class="tw-text-gray-500 tw-text-sm">Your saved items</p>
                </div>
            </div>
        </a>

        <a href="/customer/profile" class="tw-bg-white tw-p-6 tw-rounded-xl tw-shadow-lg hover:tw-shadow-xl tw-transition-all tw-duration-200 tw-group tw-border tw-border-gray-200">
            <div class="tw-flex tw-items-center tw-space-x-3">
                <i data-feather="user" class="tw-h-8 tw-w-8 tw-text-green-500 group-hover:tw-scale-110 tw-transition-transform"></i>
                <div>
                    <h3 class="tw-text-lg tw-font-semibold tw-text-gray-900">Profile</h3>
                    <p class="tw-text-gray-500 tw-text-sm">Manage account</p>
                </div>
            </div>
        </a>
    </div>
</div>

        <!-- Stats Cards -->
        <div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-3 tw-gap-6 tw-mb-8">
            <div class="tw-bg-white tw-p-6 tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                <div class="tw-flex tw-items-center tw-justify-between">
                    <div>
                        <p class="tw-text-sm tw-font-medium tw-text-gray-600">Total Orders</p>
                        <p class="tw-text-3xl tw-font-bold tw-text-gray-900">24</p>
                        <p class="tw-text-sm tw-text-green-600">+2 this month</p>
                    </div>
                    <div class="tw-p-3 tw-bg-blue-100 tw-rounded-full">
                        <i data-feather="shopping-bag" class="tw-h-6 tw-w-6 tw-text-blue-600"></i>
                    </div>
                </div>
            </div>

            <div class="tw-bg-white tw-p-6 tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                <div class="tw-flex tw-items-center tw-justify-between">
                    <div>
                        <p class="tw-text-sm tw-font-medium tw-text-gray-600">Total Spent</p>
                        <p class="tw-text-3xl tw-font-bold tw-text-gray-900">45,000 XAF</p>
                        <p class="tw-text-sm tw-text-green-600">+5,000 this month</p>
                    </div>
                    <div class="tw-p-3 tw-bg-green-100 tw-rounded-full">
                        <i data-feather="credit-card" class="tw-h-6 tw-w-6 tw-text-green-600"></i>
                    </div>
                </div>
            </div>

            <div class="tw-bg-white tw-p-6 tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                <div class="tw-flex tw-items-center tw-justify-between">
                    <div>
                        <p class="tw-text-sm tw-font-medium tw-text-gray-600">Favorite Restaurants</p>
                        <p class="tw-text-3xl tw-font-bold tw-text-gray-900">8</p>
                        <p class="tw-text-sm tw-text-gray-500">Saved favorites</p>
                    </div>
                    <div class="tw-p-3 tw-bg-pink-100 tw-rounded-full">
                        <i data-feather="heart" class="tw-h-6 tw-w-6 tw-text-pink-600"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Orders & Recommendations -->
        <div class="tw-grid tw-grid-cols-1 lg:tw-grid-cols-2 tw-gap-8">
            <!-- Recent Orders -->
            <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                <div class="tw-p-6 tw-border-b tw-border-gray-200">
                    <div class="tw-flex tw-items-center tw-justify-between">
                        <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Recent Orders</h2>
                        <a href="/orders" class="tw-text-orange-600 hover:tw-text-orange-500 tw-text-sm tw-font-medium">View all</a>
                    </div>
                </div>
                <div class="tw-p-6 tw-space-y-4">
                    <!-- Order Item -->
                    <div class="tw-flex tw-items-center tw-space-x-4 tw-p-4 tw-bg-gray-50 tw-rounded-lg">
                        <img src="https://via.placeholder.com/60x60?text=🍕" alt="Pizza" class="tw-w-15 tw-h-15 tw-rounded-lg tw-object-cover">
                        <div class="tw-flex-1">
                            <h3 class="tw-font-medium tw-text-gray-900">Margherita Pizza</h3>
                            <p class="tw-text-sm tw-text-gray-500">Pizza Palace • 2 days ago</p>
                            <p class="tw-text-sm tw-font-medium tw-text-green-600">Delivered</p>
                        </div>
                        <div class="tw-text-right">
                            <p class="tw-font-medium tw-text-gray-900">3,500 XAF</p>
                            <button class="tw-text-orange-600 hover:tw-text-orange-500 tw-text-sm">Reorder</button>
                        </div>
                    </div>

                    <!-- Order Item -->
                    <div class="tw-flex tw-items-center tw-space-x-4 tw-p-4 tw-bg-gray-50 tw-rounded-lg">
                        <img src="https://via.placeholder.com/60x60?text=🍔" alt="Burger" class="tw-w-15 tw-h-15 tw-rounded-lg tw-object-cover">
                        <div class="tw-flex-1">
                            <h3 class="tw-font-medium tw-text-gray-900">Beef Burger Combo</h3>
                            <p class="tw-text-sm tw-text-gray-500">Burger House • 5 days ago</p>
                            <p class="tw-text-sm tw-font-medium tw-text-green-600">Delivered</p>
                        </div>
                        <div class="tw-text-right">
                            <p class="tw-font-medium tw-text-gray-900">2,800 XAF</p>
                            <button class="tw-text-orange-600 hover:tw-text-orange-500 tw-text-sm">Reorder</button>
                        </div>
                    </div>

                    <!-- Order Item -->
                    <div class="tw-flex tw-items-center tw-space-x-4 tw-p-4 tw-bg-gray-50 tw-rounded-lg">
                        <img src="https://via.placeholder.com/60x60?text=🍜" alt="Noodles" class="tw-w-15 tw-h-15 tw-rounded-lg tw-object-cover">
                        <div class="tw-flex-1">
                            <h3 class="tw-font-medium tw-text-gray-900">Chicken Noodles</h3>
                            <p class="tw-text-sm tw-text-gray-500">Asian Kitchen • 1 week ago</p>
                            <p class="tw-text-sm tw-font-medium tw-text-green-600">Delivered</p>
                        </div>
                        <div class="tw-text-right">
                            <p class="tw-font-medium tw-text-gray-900">2,200 XAF</p>
                            <button class="tw-text-orange-600 hover:tw-text-orange-500 tw-text-sm">Reorder</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recommendations -->
            <div class="tw-bg-white tw-rounded-xl tw-shadow-lg tw-border tw-border-gray-200">
                <div class="tw-p-6 tw-border-b tw-border-gray-200">
                    <h2 class="tw-text-lg tw-font-semibold tw-text-gray-900">Recommended for You</h2>
                </div>
                <div class="tw-p-6 tw-space-y-4">
                    <!-- Recommendation Item -->
                    <div class="tw-flex tw-items-center tw-space-x-4 tw-p-4 tw-bg-gradient-to-r tw-from-orange-50 tw-to-red-50 tw-rounded-lg tw-border tw-border-orange-200">
                        <img src="https://via.placeholder.com/60x60?text=🍗" alt="Chicken" class="tw-w-15 tw-h-15 tw-rounded-lg tw-object-cover">
                        <div class="tw-flex-1">
                            <h3 class="tw-font-medium tw-text-gray-900">Grilled Chicken</h3>
                            <p class="tw-text-sm tw-text-gray-500">Healthy Bites • 4.8 ⭐</p>
                            <p class="tw-text-sm tw-text-orange-600 tw-font-medium">Popular in your area</p>
                        </div>
                        <div class="tw-text-right">
                            <p class="tw-font-medium tw-text-gray-900">3,200 XAF</p>
                            <button class="tw-bg-orange-500 hover:tw-bg-orange-600 tw-text-white tw-px-3 tw-py-1 tw-rounded-md tw-text-sm tw-transition-colors">Order Now</button>
                        </div>
                    </div>

                    <!-- Recommendation Item -->
                    <div class="tw-flex tw-items-center tw-space-x-4 tw-p-4 tw-bg-gray-50 tw-rounded-lg">
                        <img src="https://via.placeholder.com/60x60?text=🥗" alt="Salad" class="tw-w-15 tw-h-15 tw-rounded-lg tw-object-cover">
                        <div class="tw-flex-1">
                            <h3 class="tw-font-medium tw-text-gray-900">Caesar Salad</h3>
                            <p class="tw-text-sm tw-text-gray-500">Fresh Garden • 4.6 ⭐</p>
                            <p class="tw-text-sm tw-text-green-600 tw-font-medium">Healthy choice</p>
                        </div>
                        <div class="tw-text-right">
                            <p class="tw-font-medium tw-text-gray-900">2,500 XAF</p>
                            <button class="tw-bg-gray-200 hover:tw-bg-gray-300 tw-text-gray-700 tw-px-3 tw-py-1 tw-rounded-md tw-text-sm tw-transition-colors">Add to Cart</button>
                        </div>
                    </div>

                    <!-- Recommendation Item -->
                    <div class="tw-flex tw-items-center tw-space-x-4 tw-p-4 tw-bg-gray-50 tw-rounded-lg">
                        <img src="https://via.placeholder.com/60x60?text=🍰" alt="Cake" class="tw-w-15 tw-h-15 tw-rounded-lg tw-object-cover">
                        <div class="tw-flex-1">
                            <h3 class="tw-font-medium tw-text-gray-900">Chocolate Cake</h3>
                            <p class="tw-text-sm tw-text-gray-500">Sweet Dreams • 4.9 ⭐</p>
                            <p class="tw-text-sm tw-text-purple-600 tw-font-medium">Trending dessert</p>
                        </div>
                        <div class="tw-text-right">
                            <p class="tw-font-medium tw-text-gray-900">1,800 XAF</p>
                            <button class="tw-bg-gray-200 hover:tw-bg-gray-300 tw-text-gray-700 tw-px-3 tw-py-1 tw-rounded-md tw-text-sm tw-transition-colors">Add to Cart</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<script>
// Add interactivity for dashboard
document.addEventListener('DOMContentLoaded', function() {
    // Animate stats on load
    const statNumbers = document.querySelectorAll('.tw-text-3xl');
    statNumbers.forEach(stat => {
        const finalValue = parseInt(stat.textContent.replace(/[^\d]/g, ''));
        let currentValue = 0;
        const increment = finalValue / 20;

        const timer = setInterval(() => {
            currentValue += increment;
            if (currentValue >= finalValue) {
                currentValue = finalValue;
                clearInterval(timer);
            }

            if (stat.textContent.includes('XAF')) {
                stat.textContent = Math.floor(currentValue).toLocaleString() + ' XAF';
            } else {
                stat.textContent = Math.floor(currentValue);
            }
        }, 50);
    });
});
</script>

<?php
// Capture the content
$content = ob_get_clean();

// Include the dashboard layout
include __DIR__ . '/../components/dashboard-layout.php';
?>
