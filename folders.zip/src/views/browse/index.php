<?php
/**
 * Browse Restaurants Page - Time2Eat
 * Semantic HTML5 with advanced search, filters, and mobile-first design
 */
?>

<!-- Page Header with Search -->
<section class="tw-bg-gradient-to-br tw-from-primary-600 tw-to-secondary-600 tw-py-16" role="banner">
    <div class="tw-container tw-mx-auto tw-px-4">
        <header class="tw-text-center tw-text-white tw-mb-8">
            <h1 class="tw-text-4xl md:tw-text-5xl tw-font-bold tw-mb-4">Browse Restaurants</h1>
            <p class="tw-text-xl tw-opacity-90">Discover amazing food in Bamenda</p>
        </header>
        
        <!-- Advanced Search Form -->
        <div class="tw-max-w-4xl tw-mx-auto">
            <form method="GET" action="/browse" class="tw-glass-card tw-p-6 tw-rounded-2xl" role="search" aria-label="Search and filter restaurants">
                <div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-12 tw-gap-4">
                    <!-- Search Input -->
                    <div class="md:tw-col-span-5">
                        <label for="search" class="tw-sr-only">Search restaurants or dishes</label>
                        <div class="tw-relative">
                            <i data-feather="search" class="tw-absolute tw-left-4 tw-top-1/2 tw-transform -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400" aria-hidden="true"></i>
                            <input 
                                type="search" 
                                id="search"
                                name="search" 
                                value="<?= e($_GET['search'] ?? '') ?>"
                                placeholder="Search restaurants, dishes, or cuisine..." 
                                class="tw-w-full tw-pl-12 tw-pr-4 tw-py-4 tw-rounded-xl tw-border-0 tw-bg-white/90 tw-backdrop-blur-sm tw-text-gray-800 tw-placeholder-gray-500 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-primary-500 focus:tw-bg-white tw-transition-all tw-duration-200"
                                aria-describedby="search-help"
                            >
                        </div>
                        <div id="search-help" class="tw-sr-only">Search for restaurants by name, cuisine type, or specific dishes</div>
                    </div>
                    
                    <!-- Category Filter -->
                    <div class="md:tw-col-span-3">
                        <label for="category" class="tw-sr-only">Filter by category</label>
                        <select 
                            id="category"
                            name="category" 
                            class="tw-w-full tw-px-4 tw-py-4 tw-rounded-xl tw-border-0 tw-bg-white/90 tw-backdrop-blur-sm tw-text-gray-800 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-primary-500 focus:tw-bg-white tw-transition-all tw-duration-200"
                            aria-label="Filter restaurants by category"
                        >
                            <option value="">All Categories</option>
                            <option value="cameroonian" <?= ($_GET['category'] ?? '') === 'cameroonian' ? 'selected' : '' ?>>Cameroonian</option>
                            <option value="continental" <?= ($_GET['category'] ?? '') === 'continental' ? 'selected' : '' ?>>Continental</option>
                            <option value="fast-food" <?= ($_GET['category'] ?? '') === 'fast-food' ? 'selected' : '' ?>>Fast Food</option>
                            <option value="chinese" <?= ($_GET['category'] ?? '') === 'chinese' ? 'selected' : '' ?>>Chinese</option>
                            <option value="indian" <?= ($_GET['category'] ?? '') === 'indian' ? 'selected' : '' ?>>Indian</option>
                            <option value="pizza" <?= ($_GET['category'] ?? '') === 'pizza' ? 'selected' : '' ?>>Pizza</option>
                        </select>
                    </div>
                    
                    <!-- Sort Filter -->
                    <div class="md:tw-col-span-2">
                        <label for="sort" class="tw-sr-only">Sort restaurants</label>
                        <select 
                            id="sort"
                            name="sort" 
                            class="tw-w-full tw-px-4 tw-py-4 tw-rounded-xl tw-border-0 tw-bg-white/90 tw-backdrop-blur-sm tw-text-gray-800 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-primary-500 focus:tw-bg-white tw-transition-all tw-duration-200"
                            aria-label="Sort restaurants by"
                        >
                            <option value="popular" <?= ($_GET['sort'] ?? '') === 'popular' ? 'selected' : '' ?>>Most Popular</option>
                            <option value="rating" <?= ($_GET['sort'] ?? '') === 'rating' ? 'selected' : '' ?>>Highest Rated</option>
                            <option value="delivery_time" <?= ($_GET['sort'] ?? '') === 'delivery_time' ? 'selected' : '' ?>>Fastest Delivery</option>
                            <option value="delivery_fee" <?= ($_GET['sort'] ?? '') === 'delivery_fee' ? 'selected' : '' ?>>Lowest Delivery Fee</option>
                            <option value="newest" <?= ($_GET['sort'] ?? '') === 'newest' ? 'selected' : '' ?>>Newest</option>
                        </select>
                    </div>
                    
                    <!-- Search Button -->
                    <div class="md:tw-col-span-2">
                        <button 
                            type="submit" 
                            class="tw-btn-primary tw-w-full tw-py-4 tw-rounded-xl tw-font-semibold tw-min-h-[56px] tw-flex tw-items-center tw-justify-center"
                            aria-label="Apply search and filters"
                        >
                            <i data-feather="filter" class="tw-w-5 tw-h-5 tw-mr-2 md:tw-mr-0" aria-hidden="true"></i>
                            <span class="md:tw-hidden">Filter</span>
                        </button>
                    </div>
                </div>
                
                <!-- Quick Filters -->
                <div class="tw-mt-6 tw-flex tw-flex-wrap tw-gap-3">
                    <span class="tw-text-white tw-text-sm tw-font-medium">Quick filters:</span>
                    <a href="/browse?filter=open" class="tw-bg-white/20 tw-backdrop-blur-sm tw-text-white tw-px-4 tw-py-2 tw-rounded-full tw-text-sm tw-font-medium hover:tw-bg-white/30 tw-transition-colors">
                        <i data-feather="clock" class="tw-w-4 tw-h-4 tw-mr-1 tw-inline" aria-hidden="true"></i>
                        Open Now
                    </a>
                    <a href="/browse?filter=free_delivery" class="tw-bg-white/20 tw-backdrop-blur-sm tw-text-white tw-px-4 tw-py-2 tw-rounded-full tw-text-sm tw-font-medium hover:tw-bg-white/30 tw-transition-colors">
                        <i data-feather="truck" class="tw-w-4 tw-h-4 tw-mr-1 tw-inline" aria-hidden="true"></i>
                        Free Delivery
                    </a>
                    <a href="/browse?filter=top_rated" class="tw-bg-white/20 tw-backdrop-blur-sm tw-text-white tw-px-4 tw-py-2 tw-rounded-full tw-text-sm tw-font-medium hover:tw-bg-white/30 tw-transition-colors">
                        <i data-feather="star" class="tw-w-4 tw-h-4 tw-mr-1 tw-inline" aria-hidden="true"></i>
                        Top Rated
                    </a>
                    <a href="/browse?filter=fast_delivery" class="tw-bg-white/20 tw-backdrop-blur-sm tw-text-white tw-px-4 tw-py-2 tw-rounded-full tw-text-sm tw-font-medium hover:tw-bg-white/30 tw-transition-colors">
                        <i data-feather="zap" class="tw-w-4 tw-h-4 tw-mr-1 tw-inline" aria-hidden="true"></i>
                        Fast Delivery
                    </a>
                </div>
            </form>
        </div>
    </div>
</section>

<!-- Results Section -->
<section class="tw-py-12 tw-bg-gray-50" aria-labelledby="results-heading">
    <div class="tw-container tw-mx-auto tw-px-4">
        <!-- Results Header -->
        <header class="tw-flex tw-flex-col md:tw-flex-row tw-justify-between tw-items-start md:tw-items-center tw-mb-8">
            <div>
                <h2 id="results-heading" class="tw-text-2xl tw-font-bold tw-text-gray-800 tw-mb-2">
                    <?php if (!empty($_GET['search'])): ?>
                        Search Results for "<?= e($_GET['search']) ?>"
                    <?php elseif (!empty($_GET['category'])): ?>
                        <?= ucfirst(str_replace('-', ' ', $_GET['category'])) ?> Restaurants
                    <?php else: ?>
                        All Restaurants
                    <?php endif; ?>
                </h2>
                <p class="tw-text-gray-600">
                    <?php 
                    $total_results = count($restaurants ?? []);
                    if ($total_results === 0) {
                        echo "No restaurants found";
                    } else {
                        echo "Showing " . $total_results . " restaurant" . ($total_results !== 1 ? 's' : '') . " in Bamenda";
                    }
                    ?>
                </p>
            </div>
            
            <!-- View Toggle -->
            <div class="tw-flex tw-items-center tw-space-x-2 tw-mt-4 md:tw-mt-0" role="group" aria-label="Change view layout">
                <button 
                    id="grid-view-btn" 
                    class="tw-p-2 tw-rounded-lg tw-bg-primary-600 tw-text-white tw-transition-colors"
                    aria-label="Grid view"
                    aria-pressed="true"
                >
                    <i data-feather="grid" class="tw-w-5 tw-h-5" aria-hidden="true"></i>
                </button>
                <button 
                    id="list-view-btn" 
                    class="tw-p-2 tw-rounded-lg tw-bg-gray-200 tw-text-gray-600 hover:tw-bg-gray-300 tw-transition-colors"
                    aria-label="List view"
                    aria-pressed="false"
                >
                    <i data-feather="list" class="tw-w-5 tw-h-5" aria-hidden="true"></i>
                </button>
            </div>
        </header>
        
        <!-- Restaurant Grid -->
        <div id="restaurants-grid" class="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 lg:tw-grid-cols-3 tw-gap-8" role="list">
            <?php 
            // Default restaurants if none from database
            $default_restaurants = [
                [
                    'id' => 1,
                    'name' => 'Mama\'s Kitchen',
                    'description' => 'Authentic Cameroonian dishes made with love and fresh local ingredients',
                    'rating' => 4.8,
                    'delivery_time' => '25-35',
                    'delivery_fee' => 500,
                    'image' => 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=400&h=300&fit=crop',
                    'cuisine_type' => 'Cameroonian',
                    'is_open' => true,
                    'featured_dishes' => ['Ndolé', 'Eru', 'Jollof Rice']
                ],
                [
                    'id' => 2,
                    'name' => 'Spice Garden',
                    'description' => 'Fresh ingredients, bold flavors, and fast delivery for busy professionals',
                    'rating' => 4.6,
                    'delivery_time' => '20-30',
                    'delivery_fee' => 300,
                    'image' => 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=400&h=300&fit=crop',
                    'cuisine_type' => 'Continental',
                    'is_open' => true,
                    'featured_dishes' => ['Grilled Chicken', 'Pasta', 'Salads']
                ],
                [
                    'id' => 3,
                    'name' => 'Bamenda Bites',
                    'description' => 'Local favorites and international cuisine in the heart of Bamenda',
                    'rating' => 4.7,
                    'delivery_time' => '30-40',
                    'delivery_fee' => 400,
                    'image' => 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=400&h=300&fit=crop',
                    'cuisine_type' => 'Mixed',
                    'is_open' => false,
                    'featured_dishes' => ['Suya', 'Fish & Chips', 'Plantain']
                ],
                [
                    'id' => 4,
                    'name' => 'Pizza Palace',
                    'description' => 'Wood-fired pizzas with authentic Italian flavors and local twists',
                    'rating' => 4.5,
                    'delivery_time' => '35-45',
                    'delivery_fee' => 600,
                    'image' => 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400&h=300&fit=crop',
                    'cuisine_type' => 'Italian',
                    'is_open' => true,
                    'featured_dishes' => ['Margherita Pizza', 'Pepperoni', 'Calzone']
                ],
                [
                    'id' => 5,
                    'name' => 'Golden Dragon',
                    'description' => 'Authentic Chinese cuisine with fresh ingredients and traditional recipes',
                    'rating' => 4.4,
                    'delivery_time' => '40-50',
                    'delivery_fee' => 700,
                    'image' => 'https://images.unsplash.com/photo-1526318896980-cf78c088247c?w=400&h=300&fit=crop',
                    'cuisine_type' => 'Chinese',
                    'is_open' => true,
                    'featured_dishes' => ['Sweet & Sour', 'Fried Rice', 'Spring Rolls']
                ],
                [
                    'id' => 6,
                    'name' => 'Burger Junction',
                    'description' => 'Juicy burgers, crispy fries, and milkshakes made to order',
                    'rating' => 4.3,
                    'delivery_time' => '15-25',
                    'delivery_fee' => 200,
                    'image' => 'https://images.unsplash.com/photo-1571091718767-18b5b1457add?w=400&h=300&fit=crop',
                    'cuisine_type' => 'Fast Food',
                    'is_open' => true,
                    'featured_dishes' => ['Classic Burger', 'Chicken Wings', 'Milkshakes']
                ]
            ];
            $restaurants_to_show = !empty($restaurants) ? $restaurants : $default_restaurants;
            ?>
            
            <?php if (!empty($restaurants_to_show)): ?>
                <?php foreach ($restaurants_to_show as $restaurant): ?>
                    <article class="tw-restaurant-card tw-group" role="listitem">
                        <div class="tw-card tw-overflow-hidden tw-transition-all tw-duration-300 group-hover:tw-scale-105 group-hover:tw-shadow-2xl tw-border-2 tw-border-transparent group-hover:tw-border-primary-200">
                            <!-- Restaurant Image -->
                            <div class="tw-relative tw-h-48 tw-bg-gray-200 tw-overflow-hidden">
                                <img 
                                    src="<?= $restaurant['image'] ?>" 
                                    alt="<?= e($restaurant['name']) ?> restaurant"
                                    class="tw-w-full tw-h-full tw-object-cover lazy-load group-hover:tw-scale-110 tw-transition-transform tw-duration-500"
                                    loading="lazy"
                                >
                                
                                <!-- Status & Rating Badges -->
                                <div class="tw-absolute tw-top-4 tw-left-4 tw-right-4 tw-flex tw-justify-between tw-items-start">
                                    <!-- Status Badge -->
                                    <?php if ($restaurant['is_open']): ?>
                                        <span class="tw-bg-green-500 tw-text-white tw-px-3 tw-py-1 tw-rounded-full tw-text-xs tw-font-semibold tw-shadow-lg">
                                            <i data-feather="clock" class="tw-w-3 tw-h-3 tw-mr-1 tw-inline" aria-hidden="true"></i>
                                            Open
                                        </span>
                                    <?php else: ?>
                                        <span class="tw-bg-red-500 tw-text-white tw-px-3 tw-py-1 tw-rounded-full tw-text-xs tw-font-semibold tw-shadow-lg">
                                            <i data-feather="clock" class="tw-w-3 tw-h-3 tw-mr-1 tw-inline" aria-hidden="true"></i>
                                            Closed
                                        </span>
                                    <?php endif; ?>
                                    
                                    <!-- Rating Badge -->
                                    <div class="tw-bg-white/90 tw-backdrop-blur-sm tw-rounded-full tw-px-3 tw-py-1 tw-flex tw-items-center tw-space-x-1 tw-shadow-lg">
                                        <i data-feather="star" class="tw-w-4 tw-h-4 tw-text-yellow-400 tw-fill-current" aria-hidden="true"></i>
                                        <span class="tw-text-sm tw-font-semibold" aria-label="Rating: <?= number_format($restaurant['rating'], 1) ?> out of 5 stars">
                                            <?= number_format($restaurant['rating'], 1) ?>
                                        </span>
                                    </div>
                                </div>
                                
                                <!-- Delivery Fee Badge -->
                                <?php if ($restaurant['delivery_fee'] == 0): ?>
                                    <div class="tw-absolute tw-bottom-4 tw-left-4">
                                        <span class="tw-bg-green-500 tw-text-white tw-px-3 tw-py-1 tw-rounded-full tw-text-xs tw-font-semibold tw-shadow-lg">
                                            <i data-feather="truck" class="tw-w-3 tw-h-3 tw-mr-1 tw-inline" aria-hidden="true"></i>
                                            Free Delivery
                                        </span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Restaurant Details -->
                            <div class="tw-p-6">
                                <header class="tw-mb-4">
                                    <h3 class="tw-text-xl tw-font-bold tw-text-gray-800 tw-mb-2"><?= e($restaurant['name']) ?></h3>
                                    <p class="tw-text-primary-600 tw-font-medium tw-mb-2"><?= e($restaurant['cuisine_type']) ?></p>
                                    <p class="tw-text-gray-700 tw-text-sm tw-leading-relaxed tw-mb-3"><?= e($restaurant['description']) ?></p>
                                    
                                    <!-- Featured Dishes -->
                                    <div class="tw-flex tw-flex-wrap tw-gap-2 tw-mb-4">
                                        <?php foreach (array_slice($restaurant['featured_dishes'], 0, 3) as $dish): ?>
                                            <span class="tw-bg-gray-100 tw-text-gray-700 tw-px-3 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium">
                                                <?= e($dish) ?>
                                            </span>
                                        <?php endforeach; ?>
                                    </div>
                                </header>
                                
                                <!-- Restaurant Info -->
                                <div class="tw-flex tw-items-center tw-justify-between tw-mb-6 tw-text-sm tw-text-gray-600">
                                    <div class="tw-flex tw-items-center tw-space-x-1" title="Delivery time">
                                        <i data-feather="clock" class="tw-w-4 tw-h-4" aria-hidden="true"></i>
                                        <span><?= $restaurant['delivery_time'] ?> min</span>
                                    </div>
                                    <div class="tw-flex tw-items-center tw-space-x-1" title="Delivery fee">
                                        <i data-feather="truck" class="tw-w-4 tw-h-4" aria-hidden="true"></i>
                                        <span>
                                            <?php if ($restaurant['delivery_fee'] == 0): ?>
                                                Free
                                            <?php else: ?>
                                                XAF <?= number_format($restaurant['delivery_fee']) ?>
                                            <?php endif; ?>
                                        </span>
                                    </div>
                                </div>
                                
                                <!-- Action Button -->
                                <a 
                                    href="/restaurant/<?= $restaurant['id'] ?>" 
                                    class="tw-btn-primary tw-w-full tw-text-center tw-min-h-[48px] tw-flex tw-items-center tw-justify-center tw-font-semibold tw-transition-all tw-duration-200 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-primary-500 focus:tw-ring-offset-2 <?= !$restaurant['is_open'] ? 'tw-opacity-50 tw-cursor-not-allowed' : '' ?>"
                                    aria-label="View menu for <?= e($restaurant['name']) ?>"
                                    <?= !$restaurant['is_open'] ? 'aria-disabled="true"' : '' ?>
                                >
                                    <i data-feather="menu" class="tw-w-4 tw-h-4 tw-mr-2" aria-hidden="true"></i>
                                    <?= $restaurant['is_open'] ? 'View Menu' : 'Currently Closed' ?>
                                </a>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            <?php else: ?>
                <!-- No Results -->
                <div class="tw-col-span-full tw-text-center tw-py-16">
                    <div class="tw-w-24 tw-h-24 tw-mx-auto tw-mb-6 tw-bg-gray-200 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                        <i data-feather="search" class="tw-w-12 tw-h-12 tw-text-gray-400" aria-hidden="true"></i>
                    </div>
                    <h3 class="tw-text-2xl tw-font-bold tw-text-gray-800 tw-mb-4">No restaurants found</h3>
                    <p class="tw-text-gray-600 tw-mb-6">Try adjusting your search criteria or browse all restaurants.</p>
                    <a href="/browse" class="tw-btn-primary tw-px-6 tw-py-3">
                        <i data-feather="utensils" class="tw-w-4 tw-h-4 tw-mr-2" aria-hidden="true"></i>
                        View All Restaurants
                    </a>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Load More Button -->
        <?php if (count($restaurants_to_show) >= 6): ?>
            <div class="tw-text-center tw-mt-12">
                <button 
                    id="load-more-btn" 
                    class="tw-btn-outline tw-px-8 tw-py-4 tw-text-lg"
                    aria-label="Load more restaurants"
                >
                    <i data-feather="plus" class="tw-w-5 tw-h-5 tw-mr-2" aria-hidden="true"></i>
                    Load More Restaurants
                </button>
            </div>
        <?php endif; ?>
    </div>
</section>
