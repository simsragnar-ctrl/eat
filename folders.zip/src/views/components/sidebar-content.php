<?php
$user = $user ?? null;
$currentPage = $currentPage ?? '';
$userRole = $user['role'] ?? 'customer';

// Define sidebar items based on user role
$sidebarItems = [];

switch ($userRole) {
    case 'customer':
        $sidebarItems = [
            ['icon' => 'home', 'label' => 'Dashboard', 'url' => '/customer/dashboard', 'page' => 'dashboard'],
            ['icon' => 'search', 'label' => 'Browse Food', 'url' => '/browse', 'page' => 'browse'],
            ['icon' => 'shopping-bag', 'label' => 'My Orders', 'url' => '/customer/orders', 'page' => 'orders'],
            ['icon' => 'heart', 'label' => 'Favorites', 'url' => '/customer/favorites', 'page' => 'favorites'],
            ['icon' => 'map-pin', 'label' => 'Addresses', 'url' => '/customer/addresses', 'page' => 'addresses'],
            ['icon' => 'credit-card', 'label' => 'Payment Methods', 'url' => '/customer/payments', 'page' => 'payments'],
            ['icon' => 'dollar-sign', 'label' => 'Affiliate Earnings', 'url' => '/customer/affiliates', 'page' => 'affiliates'],
            ['icon' => 'user', 'label' => 'Profile', 'url' => '/customer/profile', 'page' => 'profile'],
            ['icon' => 'message-circle', 'label' => 'Messages', 'url' => '/customer/messages', 'page' => 'messages'],
            ['icon' => 'file-text', 'label' => 'Invoices', 'url' => '/customer/invoices', 'page' => 'invoices']
        ];
        break;
        
    case 'vendor':
        $sidebarItems = [
            ['icon' => 'home', 'label' => 'Dashboard', 'url' => '/vendor/dashboard', 'page' => 'dashboard'],
            ['icon' => 'store', 'label' => 'Restaurant Profile', 'url' => '/vendor/profile', 'page' => 'profile'],
            ['icon' => 'menu', 'label' => 'Menu Management', 'url' => '/vendor/menu', 'page' => 'menu'],
            ['icon' => 'shopping-bag', 'label' => 'Orders', 'url' => '/vendor/orders', 'page' => 'orders'],
            ['icon' => 'package', 'label' => 'Inventory', 'url' => '/vendor/inventory', 'page' => 'inventory'],
            ['icon' => 'bar-chart-2', 'label' => 'Analytics', 'url' => '/vendor/analytics', 'page' => 'analytics'],
            ['icon' => 'dollar-sign', 'label' => 'Earnings', 'url' => '/vendor/earnings', 'page' => 'earnings'],
            ['icon' => 'star', 'label' => 'Reviews', 'url' => '/vendor/reviews', 'page' => 'reviews'],
            ['icon' => 'message-circle', 'label' => 'Messages', 'url' => '/vendor/messages', 'page' => 'messages'],
            ['icon' => 'settings', 'label' => 'Settings', 'url' => '/vendor/settings', 'page' => 'settings']
        ];
        break;
        
    case 'rider':
        $sidebarItems = [
            ['icon' => 'home', 'label' => 'Dashboard', 'url' => '/rider/dashboard', 'page' => 'dashboard'],
            ['icon' => 'truck', 'label' => 'Active Deliveries', 'url' => '/rider/deliveries', 'page' => 'deliveries'],
            ['icon' => 'map', 'label' => 'Available Orders', 'url' => '/rider/available', 'page' => 'available'],
            ['icon' => 'clock', 'label' => 'Schedule', 'url' => '/rider/schedule', 'page' => 'schedule'],
            ['icon' => 'dollar-sign', 'label' => 'Earnings', 'url' => '/rider/earnings', 'page' => 'earnings'],
            ['icon' => 'bar-chart-2', 'label' => 'Performance', 'url' => '/rider/performance', 'page' => 'performance'],
            ['icon' => 'user', 'label' => 'Profile', 'url' => '/rider/profile', 'page' => 'profile'],
            ['icon' => 'message-circle', 'label' => 'Messages', 'url' => '/rider/messages', 'page' => 'messages'],
            ['icon' => 'alert-triangle', 'label' => 'Report Issue', 'url' => '/rider/reports', 'page' => 'reports'],
            ['icon' => 'settings', 'label' => 'Settings', 'url' => '/rider/settings', 'page' => 'settings']
        ];
        break;
        
    case 'admin':
        $sidebarItems = [
            ['icon' => 'home', 'label' => 'Dashboard', 'url' => '/admin/dashboard', 'page' => 'dashboard'],
            ['icon' => 'users', 'label' => 'User Management', 'url' => '/admin/users', 'page' => 'users'],
            ['icon' => 'store', 'label' => 'Restaurants', 'url' => '/admin/restaurants', 'page' => 'restaurants'],
            ['icon' => 'shopping-bag', 'label' => 'Orders', 'url' => '/admin/orders', 'page' => 'orders'],
            ['icon' => 'truck', 'label' => 'Deliveries', 'url' => '/admin/deliveries', 'page' => 'deliveries'],
            ['icon' => 'bar-chart-2', 'label' => 'Analytics', 'url' => '/admin/analytics', 'page' => 'analytics'],
            ['icon' => 'dollar-sign', 'label' => 'Financial', 'url' => '/admin/financial', 'page' => 'financial'],
            ['icon' => 'percent', 'label' => 'Affiliates', 'url' => '/admin/affiliates', 'page' => 'affiliates'],
            ['icon' => 'bell', 'label' => 'Notifications', 'url' => '/admin/notifications', 'page' => 'notifications'],
            ['icon' => 'message-circle', 'label' => 'Disputes', 'url' => '/admin/disputes', 'page' => 'disputes'],
            ['icon' => 'folder', 'label' => 'Categories', 'url' => '/admin/categories', 'page' => 'categories'],
            ['icon' => 'database', 'label' => 'Data Management', 'url' => '/admin/data', 'page' => 'data'],
            ['icon' => 'shield', 'label' => 'Security Logs', 'url' => '/admin/logs', 'page' => 'logs'],
            ['icon' => 'settings', 'label' => 'Settings', 'url' => '/admin/settings', 'page' => 'settings']
        ];
        break;
}
?>

<div class="tw-flex tw-flex-col tw-h-0 tw-flex-1 tw-pt-5 tw-pb-4 tw-overflow-y-auto">
    <!-- Logo -->
    <div class="tw-flex tw-items-center tw-flex-shrink-0 tw-px-4">
        <div class="tw-flex tw-items-center">
            <div class="tw-h-8 tw-w-8 tw-bg-gradient-to-r tw-from-orange-500 tw-to-red-500 tw-rounded-lg tw-flex tw-items-center tw-justify-center">
                <i data-feather="zap" class="tw-h-5 tw-w-5 tw-text-white"></i>
            </div>
            <h1 class="tw-ml-3 tw-text-xl tw-font-bold tw-text-gray-900">Time2Eat</h1>
        </div>
    </div>
    
    <!-- User info -->
    <div class="tw-mt-5 tw-px-4">
        <div class="tw-flex tw-items-center tw-p-3 tw-bg-gray-50 tw-rounded-lg">
            <img class="tw-h-10 tw-w-10 tw-rounded-full" src="https://via.placeholder.com/40x40?text=<?= strtoupper(substr($user['first_name'] ?? 'U', 0, 1)) ?>" alt="Profile">
            <div class="tw-ml-3 tw-flex-1 tw-min-w-0">
                <p class="tw-text-sm tw-font-medium tw-text-gray-900 tw-truncate">
                    <?= e($user['first_name'] ?? 'User') ?> <?= e($user['last_name'] ?? '') ?>
                </p>
                <p class="tw-text-xs tw-text-gray-500 tw-truncate">
                    <?= ucfirst($userRole) ?>
                    <?php if ($userRole === 'customer' && !empty($user['affiliate_code'])): ?>
                        • Affiliate
                    <?php endif; ?>
                </p>
            </div>
            <div class="tw-flex-shrink-0">
                <?php if ($userRole === 'customer'): ?>
                    <span class="tw-inline-flex tw-items-center tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium tw-bg-green-100 tw-text-green-800">
                        <?= number_format($user['balance'] ?? 0) ?> XAF
                    </span>
                <?php elseif ($userRole === 'vendor'): ?>
                    <span class="tw-inline-flex tw-items-center tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium tw-bg-blue-100 tw-text-blue-800">
                        <?= $user['status'] === 'approved' ? 'Approved' : 'Pending' ?>
                    </span>
                <?php elseif ($userRole === 'rider'): ?>
                    <span class="tw-inline-flex tw-items-center tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium tw-bg-yellow-100 tw-text-yellow-800">
                        <?= $user['is_available'] ?? false ? 'Available' : 'Offline' ?>
                    </span>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="tw-mt-5 tw-flex-1 tw-px-2 tw-space-y-1">
        <?php foreach ($sidebarItems as $item): ?>
            <a href="<?= e($item['url']) ?>" 
               class="sidebar-item tw-text-gray-600 <?= $currentPage === $item['page'] ? 'active' : '' ?>"
               data-page="<?= e($item['page']) ?>">
                <i data-feather="<?= e($item['icon']) ?>" class="tw-mr-3 tw-flex-shrink-0 tw-h-5 tw-w-5"></i>
                <?= e($item['label']) ?>
                
                <?php if ($item['page'] === 'orders' && $userRole === 'vendor'): ?>
                    <span class="tw-ml-auto tw-inline-flex tw-items-center tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium tw-bg-red-100 tw-text-red-800">
                        3
                    </span>
                <?php elseif ($item['page'] === 'deliveries' && $userRole === 'rider'): ?>
                    <span class="tw-ml-auto tw-inline-flex tw-items-center tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium tw-bg-green-100 tw-text-green-800">
                        2
                    </span>
                <?php elseif ($item['page'] === 'messages'): ?>
                    <span class="tw-ml-auto tw-inline-flex tw-items-center tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium tw-bg-blue-100 tw-text-blue-800">
                        5
                    </span>
                <?php endif; ?>
            </a>
        <?php endforeach; ?>
    </nav>

    <!-- Quick actions -->
    <div class="tw-flex-shrink-0 tw-px-2 tw-pb-4">
        <div class="tw-space-y-2">
            <?php if ($userRole === 'customer'): ?>
                <a href="/browse" class="tw-flex tw-items-center tw-justify-center tw-w-full tw-px-4 tw-py-2 tw-text-sm tw-font-medium tw-text-white tw-bg-gradient-to-r tw-from-orange-500 tw-to-red-500 tw-rounded-lg hover:tw-from-orange-600 hover:tw-to-red-600 tw-transition-all tw-duration-200">
                    <i data-feather="plus" class="tw-h-4 tw-w-4 tw-mr-2"></i>
                    Order Food
                </a>
            <?php elseif ($userRole === 'vendor'): ?>
                <a href="/vendor/menu/add" class="tw-flex tw-items-center tw-justify-center tw-w-full tw-px-4 tw-py-2 tw-text-sm tw-font-medium tw-text-white tw-bg-gradient-to-r tw-from-orange-500 tw-to-red-500 tw-rounded-lg hover:tw-from-orange-600 hover:tw-to-red-600 tw-transition-all tw-duration-200">
                    <i data-feather="plus" class="tw-h-4 tw-w-4 tw-mr-2"></i>
                    Add Menu Item
                </a>
            <?php elseif ($userRole === 'rider'): ?>
                <button onclick="toggleAvailability()" class="tw-flex tw-items-center tw-justify-center tw-w-full tw-px-4 tw-py-2 tw-text-sm tw-font-medium tw-text-white tw-bg-gradient-to-r tw-from-green-500 tw-to-blue-500 tw-rounded-lg hover:tw-from-green-600 hover:tw-to-blue-600 tw-transition-all tw-duration-200" id="availability-toggle">
                    <i data-feather="power" class="tw-h-4 tw-w-4 tw-mr-2"></i>
                    Go Online
                </button>
            <?php elseif ($userRole === 'admin'): ?>
                <a href="/admin/notifications/create" class="tw-flex tw-items-center tw-justify-center tw-w-full tw-px-4 tw-py-2 tw-text-sm tw-font-medium tw-text-white tw-bg-gradient-to-r tw-from-purple-500 tw-to-pink-500 tw-rounded-lg hover:tw-from-purple-600 hover:tw-to-pink-600 tw-transition-all tw-duration-200">
                    <i data-feather="bell" class="tw-h-4 tw-w-4 tw-mr-2"></i>
                    Send Notification
                </a>
            <?php endif; ?>
            
            <!-- Help/Support -->
            <a href="/support" class="tw-flex tw-items-center tw-justify-center tw-w-full tw-px-4 tw-py-2 tw-text-sm tw-font-medium tw-text-gray-700 tw-bg-gray-100 tw-rounded-lg hover:tw-bg-gray-200 tw-transition-colors tw-duration-200">
                <i data-feather="help-circle" class="tw-h-4 tw-w-4 tw-mr-2"></i>
                Help & Support
            </a>
        </div>
    </div>
</div>

<script>
// Rider availability toggle
function toggleAvailability() {
    const button = document.getElementById('availability-toggle');
    const isOnline = button.textContent.includes('Go Offline');
    
    fetch('/api/rider/toggle-availability', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify({ available: !isOnline })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            if (isOnline) {
                button.innerHTML = '<i data-feather="power" class="tw-h-4 tw-w-4 tw-mr-2"></i>Go Online';
                button.className = button.className.replace('tw-from-red-500 tw-to-orange-500', 'tw-from-green-500 tw-to-blue-500');
            } else {
                button.innerHTML = '<i data-feather="power" class="tw-h-4 tw-w-4 tw-mr-2"></i>Go Offline';
                button.className = button.className.replace('tw-from-green-500 tw-to-blue-500', 'tw-from-red-500 tw-to-orange-500');
            }
            feather.replace();
        }
    })
    .catch(error => {
        console.error('Error toggling availability:', error);
    });
}

// Update notification badges
function updateNotificationBadges() {
    fetch('/api/notifications/counts')
        .then(response => response.json())
        .then(data => {
            // Update sidebar badges
            const badges = document.querySelectorAll('.sidebar-item span');
            badges.forEach(badge => {
                const page = badge.closest('.sidebar-item').dataset.page;
                if (data[page]) {
                    badge.textContent = data[page];
                    badge.style.display = data[page] > 0 ? 'inline-flex' : 'none';
                }
            });
        })
        .catch(error => console.log('Badge update failed:', error));
}

// Update badges every 30 seconds
setInterval(updateNotificationBadges, 30000);
</script>
