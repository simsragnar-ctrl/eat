<?php
/**
 * Modal Components
 * Reusable modals with icons and accessibility
 */

require_once __DIR__ . '/../../traits/UIComponents.php';
require_once __DIR__ . '/../../helpers/IconHelper.php';

class ModalComponents {
    use UIComponents;
    
    /**
     * Render login modal
     */
    public function renderLoginModal(): string
    {
        $content = '
        <form id="login-form" class="tw-space-y-4" onsubmit="handleLogin(event)">
            <div>
                <label for="login-email" class="tw-block tw-text-sm tw-font-medium tw-text-gray-700 tw-mb-2">
                    ' . IconHelper::feather('email', ['size' => 'tw-w-4 tw-h-4', 'class' => 'tw-inline tw-mr-1']) . '
                    Email Address
                </label>
                <input 
                    type="email" 
                    id="login-email" 
                    name="email" 
                    class="tw-input" 
                    placeholder="Enter your email"
                    required
                    autocomplete="email"
                >
            </div>
            
            <div>
                <label for="login-password" class="tw-block tw-text-sm tw-font-medium tw-text-gray-700 tw-mb-2">
                    ' . IconHelper::feather('privacy', ['size' => 'tw-w-4 tw-h-4', 'class' => 'tw-inline tw-mr-1']) . '
                    Password
                </label>
                <div class="tw-relative">
                    <input 
                        type="password" 
                        id="login-password" 
                        name="password" 
                        class="tw-input tw-pr-12" 
                        placeholder="Enter your password"
                        required
                        autocomplete="current-password"
                    >
                    ' . IconHelper::button('view', [
                        'type' => 'button',
                        'class' => 'tw-absolute tw-right-3 tw-top-1/2 tw-transform tw--translate-y-1/2 tw-text-gray-400 hover:tw-text-gray-600',
                        'onclick' => 'togglePasswordVisibility("login-password")',
                        'aria-label' => 'Toggle password visibility'
                    ]) . '
                </div>
            </div>
            
            <div class="tw-flex tw-items-center tw-justify-between">
                <label class="tw-flex tw-items-center">
                    <input type="checkbox" class="tw-checkbox tw-mr-2" name="remember">
                    <span class="tw-text-sm tw-text-gray-600">Remember me</span>
                </label>
                <a href="#" class="tw-text-sm tw-text-primary-600 hover:tw-text-primary-700" onclick="openModal(\'forgot-password-modal\')">
                    Forgot password?
                </a>
            </div>
            
            <div class="tw-space-y-3">
                ' . $this->primaryButton('Sign In', [
                    'type' => 'submit',
                    'icon' => 'login',
                    'class' => 'tw-w-full',
                    'id' => 'login-submit-btn'
                ]) . '
                
                <div class="tw-text-center">
                    <span class="tw-text-sm tw-text-gray-600">Don\'t have an account? </span>
                    <button 
                        type="button" 
                        class="tw-text-sm tw-text-primary-600 hover:tw-text-primary-700 tw-font-medium"
                        onclick="closeModal(\'login-modal\'); openModal(\'register-modal\');"
                    >
                        Sign up
                    </button>
                </div>
            </div>
        </form>';
        
        return $this->modal('login-modal', 'Welcome Back!', $content, ['size' => 'tw-max-w-md']);
    }
    
    /**
     * Render registration modal
     */
    public function renderRegisterModal(): string
    {
        $content = '
        <form id="register-form" class="tw-space-y-4" onsubmit="handleRegister(event)">
            <div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-4">
                <div>
                    <label for="register-first-name" class="tw-block tw-text-sm tw-font-medium tw-text-gray-700 tw-mb-2">
                        ' . IconHelper::feather('user', ['size' => 'tw-w-4 tw-h-4', 'class' => 'tw-inline tw-mr-1']) . '
                        First Name
                    </label>
                    <input 
                        type="text" 
                        id="register-first-name" 
                        name="first_name" 
                        class="tw-input" 
                        placeholder="John"
                        required
                        autocomplete="given-name"
                    >
                </div>
                
                <div>
                    <label for="register-last-name" class="tw-block tw-text-sm tw-font-medium tw-text-gray-700 tw-mb-2">
                        Last Name
                    </label>
                    <input 
                        type="text" 
                        id="register-last-name" 
                        name="last_name" 
                        class="tw-input" 
                        placeholder="Doe"
                        required
                        autocomplete="family-name"
                    >
                </div>
            </div>
            
            <div>
                <label for="register-email" class="tw-block tw-text-sm tw-font-medium tw-text-gray-700 tw-mb-2">
                    ' . IconHelper::feather('email', ['size' => 'tw-w-4 tw-h-4', 'class' => 'tw-inline tw-mr-1']) . '
                    Email Address
                </label>
                <input 
                    type="email" 
                    id="register-email" 
                    name="email" 
                    class="tw-input" 
                    placeholder="john@example.com"
                    required
                    autocomplete="email"
                >
            </div>
            
            <div>
                <label for="register-phone" class="tw-block tw-text-sm tw-font-medium tw-text-gray-700 tw-mb-2">
                    ' . IconHelper::feather('phone', ['size' => 'tw-w-4 tw-h-4', 'class' => 'tw-inline tw-mr-1']) . '
                    Phone Number
                </label>
                <input 
                    type="tel" 
                    id="register-phone" 
                    name="phone" 
                    class="tw-input" 
                    placeholder="+237 6XX XXX XXX"
                    required
                    autocomplete="tel"
                >
            </div>
            
            <div>
                <label for="register-password" class="tw-block tw-text-sm tw-font-medium tw-text-gray-700 tw-mb-2">
                    ' . IconHelper::feather('privacy', ['size' => 'tw-w-4 tw-h-4', 'class' => 'tw-inline tw-mr-1']) . '
                    Password
                </label>
                <div class="tw-relative">
                    <input 
                        type="password" 
                        id="register-password" 
                        name="password" 
                        class="tw-input tw-pr-12" 
                        placeholder="Create a strong password"
                        required
                        autocomplete="new-password"
                        minlength="8"
                    >
                    ' . IconHelper::button('view', [
                        'type' => 'button',
                        'class' => 'tw-absolute tw-right-3 tw-top-1/2 tw-transform tw--translate-y-1/2 tw-text-gray-400 hover:tw-text-gray-600',
                        'onclick' => 'togglePasswordVisibility("register-password")',
                        'aria-label' => 'Toggle password visibility'
                    ]) . '
                </div>
                <p class="tw-text-xs tw-text-gray-500 tw-mt-1">Must be at least 8 characters long</p>
            </div>
            
            <div>
                <label class="tw-flex tw-items-start tw-space-x-2">
                    <input type="checkbox" class="tw-checkbox tw-mt-1" name="terms" required>
                    <span class="tw-text-sm tw-text-gray-600">
                        I agree to the 
                        <a href="/terms" class="tw-text-primary-600 hover:tw-text-primary-700">Terms of Service</a> 
                        and 
                        <a href="/privacy" class="tw-text-primary-600 hover:tw-text-primary-700">Privacy Policy</a>
                    </span>
                </label>
            </div>
            
            <div class="tw-space-y-3">
                ' . $this->primaryButton('Create Account', [
                    'type' => 'submit',
                    'icon' => 'register',
                    'class' => 'tw-w-full',
                    'id' => 'register-submit-btn'
                ]) . '
                
                <div class="tw-text-center">
                    <span class="tw-text-sm tw-text-gray-600">Already have an account? </span>
                    <button 
                        type="button" 
                        class="tw-text-sm tw-text-primary-600 hover:tw-text-primary-700 tw-font-medium"
                        onclick="closeModal(\'register-modal\'); openModal(\'login-modal\');"
                    >
                        Sign in
                    </button>
                </div>
            </div>
        </form>';
        
        return $this->modal('register-modal', 'Join Time2Eat', $content, ['size' => 'tw-max-w-lg']);
    }
    
    /**
     * Render forgot password modal
     */
    public function renderForgotPasswordModal(): string
    {
        $content = '
        <form id="forgot-password-form" class="tw-space-y-4" onsubmit="handleForgotPassword(event)">
            <div class="tw-text-center tw-mb-6">
                ' . IconHelper::feather('email', ['size' => 'tw-w-12 tw-h-12', 'class' => 'tw-mx-auto tw-text-primary-600 tw-mb-4']) . '
                <p class="tw-text-gray-600">Enter your email address and we\'ll send you a link to reset your password.</p>
            </div>
            
            <div>
                <label for="forgot-email" class="tw-block tw-text-sm tw-font-medium tw-text-gray-700 tw-mb-2">
                    Email Address
                </label>
                <input 
                    type="email" 
                    id="forgot-email" 
                    name="email" 
                    class="tw-input" 
                    placeholder="Enter your email"
                    required
                    autocomplete="email"
                >
            </div>
            
            <div class="tw-space-y-3">
                ' . $this->primaryButton('Send Reset Link', [
                    'type' => 'submit',
                    'icon' => 'email',
                    'class' => 'tw-w-full',
                    'id' => 'forgot-submit-btn'
                ]) . '
                
                <div class="tw-text-center">
                    <button 
                        type="button" 
                        class="tw-text-sm tw-text-gray-600 hover:tw-text-gray-800"
                        onclick="closeModal(\'forgot-password-modal\'); openModal(\'login-modal\');"
                    >
                        ' . IconHelper::feather('back', ['size' => 'tw-w-4 tw-h-4', 'class' => 'tw-inline tw-mr-1']) . '
                        Back to Sign In
                    </button>
                </div>
            </div>
        </form>';
        
        return $this->modal('forgot-password-modal', 'Reset Password', $content, ['size' => 'tw-max-w-md']);
    }
    
    /**
     * Render restaurant info modal
     */
    public function renderRestaurantInfoModal(): string
    {
        $content = '
        <div id="restaurant-info-content">
            <!-- Content will be populated by JavaScript -->
            <div class="tw-text-center tw-py-8">
                ' . $this->loadingSpinner(['text' => 'Loading restaurant information...']) . '
            </div>
        </div>';
        
        return $this->modal('restaurant-info-modal', 'Restaurant Information', $content, ['size' => 'tw-max-w-2xl']);
    }
    
    /**
     * Render order tracking modal
     */
    public function renderOrderTrackingModal(): string
    {
        $content = '
        <div id="order-tracking-content" class="tw-space-y-6">
            <!-- Order Status -->
            <div class="tw-text-center">
                <div class="tw-w-16 tw-h-16 tw-bg-primary-100 tw-rounded-full tw-flex tw-items-center tw-justify-center tw-mx-auto tw-mb-4">
                    ' . IconHelper::feather('order', ['size' => 'tw-w-8 tw-h-8', 'class' => 'tw-text-primary-600']) . '
                </div>
                <h3 class="tw-text-lg tw-font-semibold tw-text-gray-800 tw-mb-2">Order #<span id="tracking-order-id">12345</span></h3>
                <div id="tracking-status" class="tw-badge-info">Preparing</div>
            </div>
            
            <!-- Progress Steps -->
            <div class="tw-space-y-4">
                <div class="tw-flex tw-items-center tw-space-x-4 tw-p-3 tw-bg-green-50 tw-rounded-lg">
                    ' . IconHelper::feather('confirm', ['class' => 'tw-text-green-600']) . '
                    <div class="tw-flex-1">
                        <p class="tw-font-medium tw-text-green-800">Order Confirmed</p>
                        <p class="tw-text-sm tw-text-green-600">Your order has been received</p>
                    </div>
                    <span class="tw-text-sm tw-text-green-600">2:30 PM</span>
                </div>
                
                <div class="tw-flex tw-items-center tw-space-x-4 tw-p-3 tw-bg-blue-50 tw-rounded-lg">
                    ' . IconHelper::feather('kitchen', ['class' => 'tw-text-blue-600']) . '
                    <div class="tw-flex-1">
                        <p class="tw-font-medium tw-text-blue-800">Preparing</p>
                        <p class="tw-text-sm tw-text-blue-600">Your food is being prepared</p>
                    </div>
                    <span class="tw-text-sm tw-text-blue-600">2:45 PM</span>
                </div>
                
                <div class="tw-flex tw-items-center tw-space-x-4 tw-p-3 tw-bg-gray-50 tw-rounded-lg tw-opacity-50">
                    ' . IconHelper::feather('delivery', ['class' => 'tw-text-gray-400']) . '
                    <div class="tw-flex-1">
                        <p class="tw-font-medium tw-text-gray-600">Out for Delivery</p>
                        <p class="tw-text-sm tw-text-gray-500">Your order is on the way</p>
                    </div>
                    <span class="tw-text-sm tw-text-gray-500">Est. 3:15 PM</span>
                </div>
                
                <div class="tw-flex tw-items-center tw-space-x-4 tw-p-3 tw-bg-gray-50 tw-rounded-lg tw-opacity-50">
                    ' . IconHelper::feather('success', ['class' => 'tw-text-gray-400']) . '
                    <div class="tw-flex-1">
                        <p class="tw-font-medium tw-text-gray-600">Delivered</p>
                        <p class="tw-text-sm tw-text-gray-500">Order completed</p>
                    </div>
                    <span class="tw-text-sm tw-text-gray-500">Est. 3:30 PM</span>
                </div>
            </div>
            
            <!-- Delivery Info -->
            <div class="tw-border-t tw-border-gray-200 tw-pt-4">
                <h4 class="tw-font-medium tw-text-gray-800 tw-mb-3 tw-flex tw-items-center">
                    ' . IconHelper::feather('location', ['class' => 'tw-mr-2']) . '
                    Delivery Information
                </h4>
                <div class="tw-space-y-2 tw-text-sm tw-text-gray-600">
                    <p><strong>Address:</strong> <span id="tracking-address">123 Main Street, Bamenda</span></p>
                    <p><strong>Phone:</strong> <span id="tracking-phone">+237 6XX XXX XXX</span></p>
                    <p><strong>Estimated Time:</strong> <span id="tracking-eta">25-35 minutes</span></p>
                </div>
            </div>
        </div>';
        
        $footer = '
        <div class="tw-flex tw-space-x-3">
            ' . $this->outlineButton('Contact Restaurant', [
                'icon' => 'phone',
                'onclick' => 'contactRestaurant()',
                'class' => 'tw-flex-1'
            ]) . '
            ' . $this->primaryButton('Track on Map', [
                'icon' => 'map',
                'onclick' => 'openTrackingMap()',
                'class' => 'tw-flex-1'
            ]) . '
        </div>';
        
        return $this->modal('order-tracking-modal', 'Track Your Order', $content, [
            'size' => 'tw-max-w-md',
            'footer' => $footer
        ]);
    }
    
    /**
     * Render confirmation modal
     */
    public function renderConfirmationModal(): string
    {
        $content = '
        <div id="confirmation-content" class="tw-text-center">
            <div class="tw-w-16 tw-h-16 tw-bg-yellow-100 tw-rounded-full tw-flex tw-items-center tw-justify-center tw-mx-auto tw-mb-4">
                ' . IconHelper::feather('warning', ['size' => 'tw-w-8 tw-h-8', 'class' => 'tw-text-yellow-600']) . '
            </div>
            <h3 class="tw-text-lg tw-font-semibold tw-text-gray-800 tw-mb-2" id="confirmation-title">Confirm Action</h3>
            <p class="tw-text-gray-600 tw-mb-6" id="confirmation-message">Are you sure you want to proceed?</p>
        </div>';
        
        $footer = '
        <div class="tw-flex tw-space-x-3">
            ' . $this->outlineButton('Cancel', [
                'onclick' => 'closeModal(\'confirmation-modal\')',
                'class' => 'tw-flex-1'
            ]) . '
            ' . $this->primaryButton('Confirm', [
                'id' => 'confirmation-confirm-btn',
                'class' => 'tw-flex-1 tw-bg-red-600 hover:tw-bg-red-700'
            ]) . '
        </div>';
        
        return $this->modal('confirmation-modal', '', $content, [
            'size' => 'tw-max-w-md',
            'footer' => $footer,
            'closable' => false
        ]);
    }
    
    /**
     * Render all modals
     */
    public function renderAllModals(): string
    {
        return 
            $this->renderLoginModal() .
            $this->renderRegisterModal() .
            $this->renderForgotPasswordModal() .
            $this->renderRestaurantInfoModal() .
            $this->renderOrderTrackingModal() .
            $this->renderConfirmationModal();
    }
    
    /**
     * Render modal JavaScript
     */
    public function renderModalScript(): string
    {
        return '
        <script>
        // Password visibility toggle
        function togglePasswordVisibility(inputId) {
            const input = document.getElementById(inputId);
            const button = input.nextElementSibling;
            const icon = button.querySelector("i");
            
            if (input.type === "password") {
                input.type = "text";
                icon.setAttribute("data-feather", "hide");
            } else {
                input.type = "password";
                icon.setAttribute("data-feather", "view");
            }
            
            feather.replace();
        }
        
        // Form handlers
        function handleLogin(event) {
            event.preventDefault();
            const submitBtn = document.getElementById("login-submit-btn");
            const originalText = submitBtn.innerHTML;
            
            submitBtn.innerHTML = `<i data-feather="loading" class="tw-w-4 tw-h-4 tw-mr-2 tw-animate-spin"></i><span>Signing In...</span>`;
            submitBtn.disabled = true;
            feather.replace();
            
            // Simulate API call
            setTimeout(() => {
                showToast("Login successful!", "success");
                closeModal("login-modal");
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
                feather.replace();
            }, 2000);
        }
        
        function handleRegister(event) {
            event.preventDefault();
            const submitBtn = document.getElementById("register-submit-btn");
            const originalText = submitBtn.innerHTML;
            
            submitBtn.innerHTML = `<i data-feather="loading" class="tw-w-4 tw-h-4 tw-mr-2 tw-animate-spin"></i><span>Creating Account...</span>`;
            submitBtn.disabled = true;
            feather.replace();
            
            // Simulate API call
            setTimeout(() => {
                showToast("Account created successfully!", "success");
                closeModal("register-modal");
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
                feather.replace();
            }, 2000);
        }
        
        function handleForgotPassword(event) {
            event.preventDefault();
            const submitBtn = document.getElementById("forgot-submit-btn");
            const originalText = submitBtn.innerHTML;
            
            submitBtn.innerHTML = `<i data-feather="loading" class="tw-w-4 tw-h-4 tw-mr-2 tw-animate-spin"></i><span>Sending...</span>`;
            submitBtn.disabled = true;
            feather.replace();
            
            // Simulate API call
            setTimeout(() => {
                showToast("Reset link sent to your email!", "success");
                closeModal("forgot-password-modal");
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
                feather.replace();
            }, 2000);
        }
        
        // Confirmation modal
        function showConfirmation(title, message, onConfirm) {
            document.getElementById("confirmation-title").textContent = title;
            document.getElementById("confirmation-message").textContent = message;
            document.getElementById("confirmation-confirm-btn").onclick = function() {
                onConfirm();
                closeModal("confirmation-modal");
            };
            openModal("confirmation-modal");
        }
        
        // Restaurant and tracking functions
        function contactRestaurant() {
            showToast("Calling restaurant...", "info");
        }
        
        function openTrackingMap() {
            showToast("Opening map...", "info");
        }
        </script>';
    }
}
?>
