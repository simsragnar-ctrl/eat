<?php
$user = $user ?? null;
$currentPage = $currentPage ?? '';
$sidebarItems = $sidebarItems ?? [];
$title = $title ?? 'Dashboard - Time2Eat';
?>

<!DOCTYPE html>
<html lang="en" class="tw-h-full tw-bg-gray-50">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title) ?></title>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            prefix: 'tw-',
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#fff7ed',
                            500: '#f97316',
                            600: '#ea580c',
                            700: '#c2410c'
                        }
                    }
                }
            }
        }
    </script>
    
    <!-- Feather Icons -->
    <script src="https://unpkg.com/feather-icons"></script>
    
    <!-- Chart.js for analytics -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <!-- Custom Styles -->
    <style>
        @layer components {
            .sidebar-item {
                @apply tw-flex tw-items-center tw-px-4 tw-py-3 tw-text-sm tw-font-medium tw-rounded-lg tw-transition-colors tw-duration-200;
            }
            .sidebar-item:hover {
                @apply tw-bg-gray-100 tw-text-gray-900;
            }
            .sidebar-item.active {
                @apply tw-bg-primary-500 tw-text-white;
            }
            .sidebar-item.active:hover {
                @apply tw-bg-primary-600;
            }
        }
    </style>
</head>
<body class="tw-h-full tw-font-sans tw-antialiased">
    <div class="tw-min-h-full">
        <!-- Mobile sidebar overlay -->
        <div class="tw-fixed tw-inset-0 tw-flex tw-z-40 lg:tw-hidden" id="mobile-sidebar-overlay" style="display: none;">
            <div class="tw-fixed tw-inset-0 tw-bg-gray-600 tw-bg-opacity-75" onclick="toggleMobileSidebar()"></div>
            <div class="tw-relative tw-flex-1 tw-flex tw-flex-col tw-max-w-xs tw-w-full tw-bg-white">
                <div class="tw-absolute tw-top-0 tw-right-0 tw--mr-12 tw-pt-2">
                    <button type="button" class="tw-ml-1 tw-flex tw-items-center tw-justify-center tw-h-10 tw-w-10 tw-rounded-full focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-inset focus:tw-ring-white" onclick="toggleMobileSidebar()">
                        <i data-feather="x" class="tw-h-6 tw-w-6 tw-text-white"></i>
                    </button>
                </div>
                <?php include 'sidebar-content.php'; ?>
            </div>
        </div>

        <!-- Static sidebar for desktop -->
        <div class="tw-hidden lg:tw-flex lg:tw-w-64 lg:tw-flex-col lg:tw-fixed lg:tw-inset-y-0">
            <div class="tw-flex-1 tw-flex tw-flex-col tw-min-h-0 tw-bg-white tw-border-r tw-border-gray-200">
                <?php include 'sidebar-content.php'; ?>
            </div>
        </div>

        <!-- Main content -->
        <div class="lg:tw-pl-64 tw-flex tw-flex-col tw-flex-1">
            <!-- Top navigation -->
            <div class="tw-sticky tw-top-0 tw-z-10 tw-flex-shrink-0 tw-flex tw-h-16 tw-bg-white tw-shadow">
                <!-- Mobile menu button -->
                <button type="button" class="tw-px-4 tw-border-r tw-border-gray-200 tw-text-gray-500 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-inset focus:tw-ring-primary-500 lg:tw-hidden" onclick="toggleMobileSidebar()">
                    <i data-feather="menu" class="tw-h-6 tw-w-6"></i>
                </button>
                
                <div class="tw-flex-1 tw-px-4 tw-flex tw-justify-between">
                    <div class="tw-flex-1 tw-flex">
                        <!-- Search bar -->
                        <div class="tw-w-full tw-flex tw-md:tw-ml-0">
                            <label for="search-field" class="tw-sr-only">Search</label>
                            <div class="tw-relative tw-w-full tw-text-gray-400 focus-within:tw-text-gray-600">
                                <div class="tw-absolute tw-inset-y-0 tw-left-0 tw-flex tw-items-center tw-pointer-events-none">
                                    <i data-feather="search" class="tw-h-5 tw-w-5"></i>
                                </div>
                                <input id="search-field" class="tw-block tw-w-full tw-h-full tw-pl-8 tw-pr-3 tw-py-2 tw-border-transparent tw-text-gray-900 tw-placeholder-gray-500 focus:tw-outline-none focus:tw-placeholder-gray-400 focus:tw-ring-0 focus:tw-border-transparent" placeholder="Search..." type="search">
                            </div>
                        </div>
                    </div>
                    
                    <div class="tw-ml-4 tw-flex tw-items-center tw-md:tw-ml-6">
                        <!-- Notifications -->
                        <button type="button" class="tw-bg-white tw-p-1 tw-rounded-full tw-text-gray-400 hover:tw-text-gray-500 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-offset-2 focus:tw-ring-primary-500">
                            <span class="tw-sr-only">View notifications</span>
                            <div class="tw-relative">
                                <i data-feather="bell" class="tw-h-6 tw-w-6"></i>
                                <span class="tw-absolute tw-top-0 tw-right-0 tw-block tw-h-2 tw-w-2 tw-rounded-full tw-bg-red-400 tw-ring-2 tw-ring-white"></span>
                            </div>
                        </button>

                        <!-- Profile dropdown -->
                        <div class="tw-ml-3 tw-relative">
                            <div>
                                <button type="button" class="tw-max-w-xs tw-bg-white tw-flex tw-items-center tw-text-sm tw-rounded-full focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-offset-2 focus:tw-ring-primary-500" id="user-menu-button" onclick="toggleUserMenu()">
                                    <span class="tw-sr-only">Open user menu</span>
                                    <img class="tw-h-8 tw-w-8 tw-rounded-full" src="https://via.placeholder.com/32x32?text=<?= strtoupper(substr($user['first_name'] ?? 'U', 0, 1)) ?>" alt="Profile">
                                    <span class="tw-ml-2 tw-text-gray-700 tw-hidden tw-md:tw-block"><?= e($user['first_name'] ?? 'User') ?></span>
                                    <i data-feather="chevron-down" class="tw-ml-1 tw-h-4 tw-w-4 tw-text-gray-400 tw-hidden tw-md:tw-block"></i>
                                </button>
                            </div>
                            
                            <div class="tw-origin-top-right tw-absolute tw-right-0 tw-mt-2 tw-w-48 tw-rounded-md tw-shadow-lg tw-py-1 tw-bg-white tw-ring-1 tw-ring-black tw-ring-opacity-5 focus:tw-outline-none tw-hidden" id="user-menu" role="menu">
                                <a href="/profile" class="tw-block tw-px-4 tw-py-2 tw-text-sm tw-text-gray-700 hover:tw-bg-gray-100" role="menuitem">
                                    <i data-feather="user" class="tw-h-4 tw-w-4 tw-inline tw-mr-2"></i>
                                    Your Profile
                                </a>
                                <a href="/settings" class="tw-block tw-px-4 tw-py-2 tw-text-sm tw-text-gray-700 hover:tw-bg-gray-100" role="menuitem">
                                    <i data-feather="settings" class="tw-h-4 tw-w-4 tw-inline tw-mr-2"></i>
                                    Settings
                                </a>
                                <a href="/logout" class="tw-block tw-px-4 tw-py-2 tw-text-sm tw-text-gray-700 hover:tw-bg-gray-100" role="menuitem">
                                    <i data-feather="log-out" class="tw-h-4 tw-w-4 tw-inline tw-mr-2"></i>
                                    Sign out
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Page content -->
            <main class="tw-flex-1">
                <div class="tw-py-6">
                    <div class="tw-max-w-7xl tw-mx-auto tw-px-4 sm:tw-px-6 md:tw-px-8">
                        <?php if (isset($content)): ?>
                            <?= $content ?>
                        <?php else: ?>
                            <!-- Default content will be inserted here -->
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script>
        // Initialize Feather icons
        feather.replace();

        // Mobile sidebar toggle
        function toggleMobileSidebar() {
            const overlay = document.getElementById('mobile-sidebar-overlay');
            overlay.style.display = overlay.style.display === 'none' ? 'flex' : 'none';
        }

        // User menu toggle
        function toggleUserMenu() {
            const menu = document.getElementById('user-menu');
            menu.classList.toggle('tw-hidden');
        }

        // Close user menu when clicking outside
        document.addEventListener('click', function(event) {
            const menu = document.getElementById('user-menu');
            const button = document.getElementById('user-menu-button');
            
            if (!menu.contains(event.target) && !button.contains(event.target)) {
                menu.classList.add('tw-hidden');
            }
        });

        // Auto-refresh notifications
        function checkNotifications() {
            fetch('/api/notifications/unread')
                .then(response => response.json())
                .then(data => {
                    const badge = document.querySelector('.tw-bg-red-400');
                    if (data.count > 0) {
                        badge.style.display = 'block';
                    } else {
                        badge.style.display = 'none';
                    }
                })
                .catch(error => console.log('Notification check failed:', error));
        }

        // Check notifications every 30 seconds
        setInterval(checkNotifications, 30000);
        checkNotifications(); // Initial check
    </script>
</body>
</html>
