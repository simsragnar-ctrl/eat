<?php
/**
 * Shopping Cart Component
 * Reusable cart with icons and accessibility
 */

require_once __DIR__ . '/../../traits/UIComponents.php';
require_once __DIR__ . '/../../helpers/IconHelper.php';

class CartComponent {
    use UIComponents;
    
    /**
     * Render cart sidebar
     */
    public function renderCartSidebar(): string
    {
        return '
        <div 
            id="cart-sidebar" 
            class="tw-fixed tw-inset-y-0 tw-right-0 tw-z-50 tw-w-full sm:tw-w-96 tw-bg-white tw-shadow-2xl tw-transform tw-translate-x-full tw-transition-transform tw-duration-300"
            role="dialog"
            aria-modal="true"
            aria-labelledby="cart-title"
        >
            <!-- Cart Header -->
            <div class="tw-flex tw-items-center tw-justify-between tw-p-4 tw-border-b tw-border-gray-200">
                <h2 id="cart-title" class="tw-text-lg tw-font-semibold tw-text-gray-800">
                    ' . IconHelper::feather('cart', ['class' => 'tw-mr-2 tw-inline']) . '
                    Your Cart
                </h2>
                ' . IconHelper::button('close', [
                    'class' => 'tw-btn-icon tw-text-gray-400 hover:tw-text-gray-600',
                    'onclick' => 'closeCart()',
                    'aria-label' => 'Close cart'
                ]) . '
            </div>
            
            <!-- Cart Items -->
            <div id="cart-items" class="tw-flex-1 tw-overflow-y-auto tw-p-4">
                <div id="cart-empty" class="tw-text-center tw-py-12">
                    ' . IconHelper::feather('cart', ['size' => 'tw-w-16 tw-h-16', 'class' => 'tw-mx-auto tw-text-gray-300 tw-mb-4']) . '
                    <p class="tw-text-gray-500 tw-mb-4">Your cart is empty</p>
                    ' . $this->primaryButton('Browse Restaurants', [
                        'href' => '/browse',
                        'icon' => 'search',
                        'class' => 'tw-mx-auto'
                    ]) . '
                </div>
                
                <div id="cart-content" class="tw-hidden">
                    <!-- Cart items will be populated by JavaScript -->
                </div>
            </div>
            
            <!-- Cart Footer -->
            <div id="cart-footer" class="tw-hidden tw-border-t tw-border-gray-200 tw-p-4 tw-space-y-4">
                <!-- Subtotal -->
                <div class="tw-flex tw-justify-between tw-items-center tw-text-lg tw-font-semibold">
                    <span>Subtotal:</span>
                    <span id="cart-subtotal" class="tw-text-primary-600">0 FCFA</span>
                </div>
                
                <!-- Delivery Fee -->
                <div class="tw-flex tw-justify-between tw-items-center tw-text-sm tw-text-gray-600">
                    <span class="tw-flex tw-items-center">
                        ' . IconHelper::feather('delivery', ['size' => 'tw-w-4 tw-h-4', 'class' => 'tw-mr-1']) . '
                        Delivery Fee:
                    </span>
                    <span id="cart-delivery">500 FCFA</span>
                </div>
                
                <!-- Total -->
                <div class="tw-flex tw-justify-between tw-items-center tw-text-xl tw-font-bold tw-pt-2 tw-border-t tw-border-gray-200">
                    <span>Total:</span>
                    <span id="cart-total" class="tw-text-primary-600">0 FCFA</span>
                </div>
                
                <!-- Checkout Button -->
                ' . $this->primaryButton('Proceed to Checkout', [
                    'icon' => 'confirm',
                    'class' => 'tw-w-full tw-text-lg tw-py-4',
                    'onclick' => 'proceedToCheckout()',
                    'id' => 'checkout-btn'
                ]) . '
            </div>
        </div>
        
        <!-- Cart Overlay -->
        <div 
            id="cart-overlay" 
            class="tw-fixed tw-inset-0 tw-bg-black tw-bg-opacity-50 tw-z-40 tw-hidden"
            onclick="closeCart()"
        ></div>';
    }
    
    /**
     * Render cart item template
     */
    public function renderCartItemTemplate(): string
    {
        return '
        <template id="cart-item-template">
            <div class="tw-cart-item" data-item-id="">
                <div class="tw-w-16 tw-h-16 tw-bg-gray-200 tw-rounded-lg tw-overflow-hidden tw-flex-shrink-0">
                    <img 
                        src="" 
                        alt="" 
                        class="tw-w-full tw-h-full tw-object-cover"
                        loading="lazy"
                    >
                </div>
                
                <div class="tw-flex-1 tw-min-w-0">
                    <h4 class="tw-font-medium tw-text-gray-800 tw-truncate"></h4>
                    <p class="tw-text-sm tw-text-gray-600 tw-truncate"></p>
                    <p class="tw-text-primary-600 tw-font-semibold"></p>
                </div>
                
                <div class="tw-flex tw-items-center tw-space-x-2">
                    ' . IconHelper::button('remove', [
                        'class' => 'tw-btn-icon tw-btn-icon-danger tw-w-8 tw-h-8',
                        'onclick' => 'updateCartQuantity(this.dataset.itemId, parseInt(this.parentElement.querySelector(\'.quantity-input\').value) - 1)',
                        'aria-label' => 'Decrease quantity'
                    ]) . '
                    
                    <input 
                        type="number" 
                        class="quantity-input tw-w-12 tw-text-center tw-border tw-border-gray-300 tw-rounded tw-py-1" 
                        value="1" 
                        min="0" 
                        max="99"
                        onchange="updateCartQuantity(this.dataset.itemId, parseInt(this.value))"
                    >
                    
                    ' . IconHelper::button('add', [
                        'class' => 'tw-btn-icon tw-btn-icon-primary tw-w-8 tw-h-8',
                        'onclick' => 'updateCartQuantity(this.dataset.itemId, parseInt(this.parentElement.querySelector(\'.quantity-input\').value) + 1)',
                        'aria-label' => 'Increase quantity'
                    ]) . '
                </div>
                
                ' . IconHelper::button('delete', [
                    'class' => 'tw-btn-icon tw-btn-icon-danger tw-ml-2',
                    'onclick' => 'removeFromCart(this.dataset.itemId)',
                    'aria-label' => 'Remove item from cart'
                ]) . '
            </div>
        </template>';
    }
    
    /**
     * Render floating cart button
     */
    public function renderFloatingCartButton(): string
    {
        return '
        <button 
            id="floating-cart-btn"
            class="tw-fixed tw-bottom-6 tw-right-6 tw-bg-primary-600 tw-text-white tw-rounded-full tw-w-14 tw-h-14 tw-flex tw-items-center tw-justify-center tw-shadow-lg hover:tw-bg-primary-700 tw-transition-all tw-duration-200 tw-z-40 tw-hidden"
            onclick="openCart()"
            aria-label="Open shopping cart"
        >
            <div class="tw-relative">
                ' . IconHelper::feather('cart', ['size' => 'tw-w-6 tw-h-6']) . '
                <span 
                    id="floating-cart-badge" 
                    class="tw-cart-badge"
                    data-cart-count
                    style="display: none;"
                >0</span>
            </div>
        </button>';
    }
    
    /**
     * Render cart icon for navigation
     */
    public function renderNavCartIcon(int $itemCount = 0): string
    {
        return '
        <button 
            class="tw-relative tw-p-2 tw-text-gray-700 hover:tw-text-primary-600 tw-transition-colors tw-rounded-lg tw-min-h-[44px] tw-min-w-[44px] tw-flex tw-items-center tw-justify-center"
            onclick="openCart()"
            aria-label="Shopping cart with ' . $itemCount . ' items"
        >
            ' . IconHelper::feather('cart', ['size' => 'tw-w-6 tw-h-6', 'data-cart-icon' => true]) . '
            <span 
                class="tw-cart-badge"
                data-cart-count
                style="display: ' . ($itemCount > 0 ? 'flex' : 'none') . ';"
            >' . ($itemCount > 99 ? '99+' : $itemCount) . '</span>
        </button>';
    }
    
    /**
     * Render add to cart button
     */
    public function renderAddToCartButton(array $item): string
    {
        $itemData = [
            'id' => $item['id'],
            'name' => htmlspecialchars($item['name']),
            'price' => $item['price'],
            'image' => $item['image'] ?? '/public/images/placeholder-food.jpg'
        ];
        
        return $this->primaryButton('Add to Cart', [
            'icon' => 'add',
            'class' => 'tw-w-full',
            'onclick' => "addToCart('{$itemData['id']}', '{$itemData['name']}', {$itemData['price']}, '{$itemData['image']}')",
            'aria-label' => "Add {$itemData['name']} to cart"
        ]);
    }
    
    /**
     * Render quick add button (for restaurant cards)
     */
    public function renderQuickAddButton(array $item): string
    {
        return IconHelper::button('add', [
            'class' => 'tw-btn-icon tw-btn-icon-primary tw-absolute tw-top-2 tw-right-2 tw-bg-white tw-shadow-md',
            'onclick' => "addToCart('{$item['id']}', '" . htmlspecialchars($item['name']) . "', {$item['price']}, '" . ($item['image'] ?? '/public/images/placeholder-food.jpg') . "')",
            'aria-label' => 'Quick add to cart'
        ]);
    }
    
    /**
     * Render cart summary for checkout
     */
    public function renderCartSummary(): string
    {
        return '
        <div class="tw-card tw-p-6">
            <h3 class="tw-text-lg tw-font-semibold tw-text-gray-800 tw-mb-4 tw-flex tw-items-center">
                ' . IconHelper::feather('cart', ['class' => 'tw-mr-2']) . '
                Order Summary
            </h3>
            
            <div id="checkout-items" class="tw-space-y-3 tw-mb-4">
                <!-- Items will be populated by JavaScript -->
            </div>
            
            <div class="tw-space-y-2 tw-pt-4 tw-border-t tw-border-gray-200">
                <div class="tw-flex tw-justify-between tw-text-sm">
                    <span>Subtotal:</span>
                    <span id="checkout-subtotal">0 FCFA</span>
                </div>
                
                <div class="tw-flex tw-justify-between tw-text-sm">
                    <span class="tw-flex tw-items-center">
                        ' . IconHelper::feather('delivery', ['size' => 'tw-w-4 tw-h-4', 'class' => 'tw-mr-1']) . '
                        Delivery:
                    </span>
                    <span id="checkout-delivery">500 FCFA</span>
                </div>
                
                <div class="tw-flex tw-justify-between tw-text-sm">
                    <span>Tax:</span>
                    <span id="checkout-tax">0 FCFA</span>
                </div>
                
                <div class="tw-flex tw-justify-between tw-text-lg tw-font-bold tw-pt-2 tw-border-t tw-border-gray-200">
                    <span>Total:</span>
                    <span id="checkout-total" class="tw-text-primary-600">0 FCFA</span>
                </div>
            </div>
        </div>';
    }
    
    /**
     * Render cart JavaScript
     */
    public function renderCartScript(): string
    {
        return '
        <script>
        // Cart functionality
        function openCart() {
            const sidebar = document.getElementById("cart-sidebar");
            const overlay = document.getElementById("cart-overlay");
            const floatingBtn = document.getElementById("floating-cart-btn");
            
            sidebar.classList.remove("tw-translate-x-full");
            overlay.classList.remove("tw-hidden");
            if (floatingBtn) floatingBtn.classList.add("tw-hidden");
            
            document.body.style.overflow = "hidden";
            updateCartDisplay();
        }
        
        function closeCart() {
            const sidebar = document.getElementById("cart-sidebar");
            const overlay = document.getElementById("cart-overlay");
            const floatingBtn = document.getElementById("floating-cart-btn");
            
            sidebar.classList.add("tw-translate-x-full");
            overlay.classList.add("tw-hidden");
            
            const cartItems = JSON.parse(localStorage.getItem("cart") || "[]");
            if (cartItems.length > 0 && floatingBtn) {
                floatingBtn.classList.remove("tw-hidden");
            }
            
            document.body.style.overflow = "";
        }
        
        function updateCartDisplay() {
            const cartItems = JSON.parse(localStorage.getItem("cart") || "[]");
            const cartEmpty = document.getElementById("cart-empty");
            const cartContent = document.getElementById("cart-content");
            const cartFooter = document.getElementById("cart-footer");
            
            if (cartItems.length === 0) {
                cartEmpty.classList.remove("tw-hidden");
                cartContent.classList.add("tw-hidden");
                cartFooter.classList.add("tw-hidden");
            } else {
                cartEmpty.classList.add("tw-hidden");
                cartContent.classList.remove("tw-hidden");
                cartFooter.classList.remove("tw-hidden");
                
                renderCartItems(cartItems);
                updateCartTotals(cartItems);
            }
        }
        
        function renderCartItems(items) {
            const container = document.getElementById("cart-content");
            const template = document.getElementById("cart-item-template");
            
            container.innerHTML = "";
            
            items.forEach(item => {
                const clone = template.content.cloneNode(true);
                const itemElement = clone.querySelector(".tw-cart-item");
                
                itemElement.dataset.itemId = item.id;
                itemElement.querySelector("img").src = item.image;
                itemElement.querySelector("img").alt = item.name;
                itemElement.querySelector("h4").textContent = item.name;
                itemElement.querySelector("p").textContent = item.restaurant || "Restaurant";
                itemElement.querySelector(".tw-text-primary-600").textContent = `${item.price} FCFA`;
                itemElement.querySelector(".quantity-input").value = item.quantity;
                itemElement.querySelector(".quantity-input").dataset.itemId = item.id;
                
                // Set data attributes for buttons
                itemElement.querySelectorAll("button").forEach(btn => {
                    btn.dataset.itemId = item.id;
                });
                
                container.appendChild(clone);
            });
            
            feather.replace();
        }
        
        function updateCartTotals(items) {
            const subtotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
            const delivery = 500; // Fixed delivery fee
            const total = subtotal + delivery;
            
            document.getElementById("cart-subtotal").textContent = `${subtotal} FCFA`;
            document.getElementById("cart-total").textContent = `${total} FCFA`;
        }
        
        function proceedToCheckout() {
            const cartItems = JSON.parse(localStorage.getItem("cart") || "[]");
            if (cartItems.length === 0) {
                showToast("Your cart is empty", "warning");
                return;
            }
            
            // Redirect to checkout page
            window.location.href = "/checkout";
        }
        
        // Initialize cart on page load
        document.addEventListener("DOMContentLoaded", function() {
            const cartItems = JSON.parse(localStorage.getItem("cart") || "[]");
            const floatingBtn = document.getElementById("floating-cart-btn");
            
            if (cartItems.length > 0 && floatingBtn) {
                floatingBtn.classList.remove("tw-hidden");
            }
        });
        </script>';
    }
}
?>
