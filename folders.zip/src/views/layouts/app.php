<!DOCTYPE html>
<html lang="en" class="tw-h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?= $description ?? 'Time2Eat - Bamenda Food Delivery Platform. Order from local restaurants with real-time tracking.' ?>">
    <meta name="keywords" content="food delivery, Bamenda, Cameroon, restaurants, online ordering">
    <meta name="author" content="Time2Eat">
    
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?= APP_URL ?>">
    <meta property="og:title" content="<?= $title ?? 'Time2Eat - Food Delivery in Bamenda' ?>">
    <meta property="og:description" content="<?= $description ?? 'Order from local restaurants with real-time tracking' ?>">
    <meta property="og:image" content="<?= APP_URL ?>/public/images/og-image.jpg">
    
    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="<?= APP_URL ?>">
    <meta property="twitter:title" content="<?= $title ?? 'Time2Eat - Food Delivery in Bamenda' ?>">
    <meta property="twitter:description" content="<?= $description ?? 'Order from local restaurants with real-time tracking' ?>">
    <meta property="twitter:image" content="<?= APP_URL ?>/public/images/og-image.jpg">
    
    <title><?= $title ?? 'Time2Eat - Food Delivery in Bamenda' ?></title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="/public/images/favicon.ico">
    <link rel="apple-touch-icon" href="/public/images/apple-touch-icon.png">
    
    <!-- PWA Manifest -->
    <link rel="manifest" href="/manifest.json">
    <meta name="theme-color" content="#f97316">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="apple-mobile-web-app-title" content="Time2Eat">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="application-name" content="Time2Eat">
    <meta name="msapplication-TileColor" content="#f97316">
    <meta name="msapplication-config" content="/browserconfig.xml">

    <!-- PWA Icons -->
    <link rel="icon" type="image/png" sizes="192x192" href="/images/icons/icon-192x192.png">
    <link rel="icon" type="image/png" sizes="512x512" href="/images/icons/icon-512x512.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/images/icons/icon-180x180.png">
    
    <!-- Tailwind CSS with tw- prefix -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            prefix: 'tw-',
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#fef2f2',
                            100: '#fee2e2',
                            500: '#ef4444',
                            600: '#dc2626',
                            700: '#b91c1c',
                        },
                        secondary: {
                            50: '#fff7ed',
                            100: '#ffedd5',
                            500: '#f97316',
                            600: '#ea580c',
                        }
                    },
                    fontFamily: {
                        'sans': ['Inter', 'Poppins', 'system-ui', 'sans-serif'],
                    },
                    animation: {
                        'fade-in': 'fadeIn 0.5s ease-in-out',
                        'slide-up': 'slideUp 0.3s ease-out',
                        'pulse-slow': 'pulse 3s infinite',
                    }
                }
            }
        }
    </script>

    <!-- External Resources -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="/public/css/app.css" rel="stylesheet">

    <style>
        @layer components {
            .tw-btn-primary {
                @apply tw-bg-primary-600 tw-text-white tw-px-6 tw-py-3 tw-rounded-lg tw-font-medium tw-transition-all tw-duration-200 hover:tw-bg-primary-700 hover:tw-scale-105 tw-min-h-[44px] tw-flex tw-items-center tw-justify-center;
            }
            .tw-btn-secondary {
                @apply tw-bg-secondary-500 tw-text-white tw-px-6 tw-py-3 tw-rounded-lg tw-font-medium tw-transition-all tw-duration-200 hover:tw-bg-secondary-600 hover:tw-scale-105 tw-min-h-[44px] tw-flex tw-items-center tw-justify-center;
            }
            .tw-btn-outline {
                @apply tw-border-2 tw-border-primary-600 tw-text-primary-600 tw-px-6 tw-py-3 tw-rounded-lg tw-font-medium tw-transition-all tw-duration-200 hover:tw-bg-primary-600 hover:tw-text-white hover:tw-scale-105 tw-min-h-[44px] tw-flex tw-items-center tw-justify-center;
            }
            .tw-card {
                @apply tw-bg-white tw-rounded-xl tw-shadow-lg tw-p-6 tw-transition-all tw-duration-200 hover:tw-shadow-xl;
            }
            .tw-glass {
                @apply tw-backdrop-blur-md tw-bg-white/10 tw-border tw-border-white/20 tw-rounded-xl;
            }
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes slideUp {
            from { transform: translateY(20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        
        /* Loading animation */
        .tw-loading {
            @apply tw-animate-spin tw-rounded-full tw-border-4 tw-border-gray-200 tw-border-t-primary-600;
        }
        
        /* Glassmorphism effects */
        .tw-glass-card {
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
    </style>
    
    <!-- Feather Icons -->
    <script src="https://unpkg.com/feather-icons"></script>
    
    <!-- Google Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>

<body class="tw-bg-gray-50 tw-font-sans tw-min-h-screen tw-flex tw-flex-col">
    <?php
    // Include required components
    require_once __DIR__ . '/../../helpers/IconHelper.php';

    // Helper function for escaping output
    if (!function_exists('e')) {
        function e($value) {
            return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
        }
    }
    ?>

    <!-- Skip to main content link for accessibility -->
    <a href="#main-content" class="tw-sr-only focus:tw-not-sr-only focus:tw-absolute focus:tw-top-4 focus:tw-left-4 tw-bg-primary-600 tw-text-white tw-px-4 tw-py-2 tw-rounded-lg tw-z-50">
        Skip to main content
    </a>

    <!-- Main Navigation -->
    <nav class="tw-bg-white tw-shadow-lg tw-sticky tw-top-0 tw-z-40" role="navigation" aria-label="Main navigation">
        <div class="tw-container tw-mx-auto tw-px-4">
            <div class="tw-flex tw-justify-between tw-items-center tw-h-16">
                <!-- Logo -->
                <div class="tw-flex tw-items-center">
                    <a href="/" class="tw-flex tw-items-center tw-space-x-2 tw-focus-visible:tw-outline-2 tw-focus-visible:tw-outline-primary-500 tw-rounded-lg tw-p-1" aria-label="Time2Eat - Go to homepage">
                        <div class="tw-w-8 tw-h-8 tw-bg-primary-600 tw-rounded-lg tw-flex tw-items-center tw-justify-center">
                            <span class="tw-text-white tw-font-bold tw-text-lg" aria-hidden="true">T</span>
                        </div>
                        <span class="tw-text-xl tw-font-bold tw-text-gray-800">Time2Eat</span>
                    </a>
                </div>

                <!-- Desktop Navigation -->
                <div class="tw-hidden md:tw-flex tw-items-center tw-space-x-8" role="menubar">
                    <a
                        href="/"
                        class="tw-text-gray-700 hover:tw-text-primary-600 tw-transition-colors tw-px-3 tw-py-2 tw-rounded-lg tw-focus-visible:tw-outline-2 tw-focus-visible:tw-outline-primary-500 tw-min-h-[44px] tw-flex tw-items-center"
                        role="menuitem"
                        aria-current="<?= $_SERVER['REQUEST_URI'] === '/' ? 'page' : 'false' ?>"
                    >
                        Home
                    </a>
                    <a
                        href="/browse"
                        class="tw-flex tw-items-center tw-space-x-1 tw-text-gray-700 hover:tw-text-primary-600 tw-transition-colors tw-px-3 tw-py-2 tw-rounded-lg tw-focus-visible:tw-outline-2 tw-focus-visible:tw-outline-primary-500 tw-min-h-[44px]"
                        role="menuitem"
                        aria-current="<?= strpos($_SERVER['REQUEST_URI'], '/browse') === 0 ? 'page' : 'false' ?>"
                        aria-label="Browse restaurants and food"
                    >
                        <i data-feather="search" class="tw-w-4 tw-h-4" aria-hidden="true"></i>
                        <span>Browse</span>
                    </a>
                    <a
                        href="/about"
                        class="tw-text-gray-700 hover:tw-text-primary-600 tw-transition-colors tw-px-3 tw-py-2 tw-rounded-lg tw-focus-visible:tw-outline-2 tw-focus-visible:tw-outline-primary-500 tw-min-h-[44px] tw-flex tw-items-center"
                        role="menuitem"
                        aria-current="<?= $_SERVER['REQUEST_URI'] === '/about' ? 'page' : 'false' ?>"
                    >
                        About
                    </a>

                    <!-- Cart Icon -->
                    <?php
                    $cartComponent = new CartComponent();
                    echo $cartComponent->renderNavCartIcon(0); // Will be updated by JavaScript
                    ?>

                    <?php if (isset($user) && $user): ?>
                        <!-- User Menu -->
                        <div class="tw-relative tw-group" role="menuitem">
                            <button
                                class="tw-flex tw-items-center tw-space-x-2 tw-text-gray-700 hover:tw-text-primary-600 tw-transition-colors tw-px-3 tw-py-2 tw-rounded-lg tw-focus-visible:tw-outline-2 tw-focus-visible:tw-outline-primary-500 tw-min-h-[44px]"
                                aria-expanded="false"
                                aria-haspopup="true"
                                aria-label="User menu for <?= htmlspecialchars($user['username']) ?>"
                            >
                                <div class="tw-w-8 tw-h-8 tw-bg-primary-100 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                                    <span class="tw-text-primary-600 tw-font-semibold tw-text-sm">
                                        <?= strtoupper(substr($user['username'], 0, 1)) ?>
                                    </span>
                                </div>
                                <span><?= htmlspecialchars($user['username']) ?></span>
                                <i data-feather="chevron-down" class="tw-w-4 tw-h-4" aria-hidden="true"></i>
                            </button>
                            <div
                                class="tw-absolute tw-right-0 tw-mt-2 tw-w-48 tw-bg-white tw-rounded-lg tw-shadow-lg tw-opacity-0 tw-invisible group-hover:tw-opacity-100 group-hover:tw-visible tw-transition-all tw-duration-200 tw-border tw-border-gray-200"
                                role="menu"
                                aria-label="User account menu"
                            >
                                <a
                                    href="/dashboard"
                                    class="tw-block tw-px-4 tw-py-3 tw-text-gray-700 hover:tw-bg-gray-100 tw-transition-colors tw-first:tw-rounded-t-lg"
                                    role="menuitem"
                                >
                                    <i data-feather="grid" class="tw-w-4 tw-h-4 tw-mr-2 tw-inline" aria-hidden="true"></i>
                                    Dashboard
                                </a>
                                <a
                                    href="/profile"
                                    class="tw-block tw-px-4 tw-py-3 tw-text-gray-700 hover:tw-bg-gray-100 tw-transition-colors"
                                    role="menuitem"
                                >
                                    <i data-feather="user" class="tw-w-4 tw-h-4 tw-mr-2 tw-inline" aria-hidden="true"></i>
                                    Profile
                                </a>
                                <a
                                    href="/orders"
                                    class="tw-block tw-px-4 tw-py-3 tw-text-gray-700 hover:tw-bg-gray-100 tw-transition-colors"
                                    role="menuitem"
                                >
                                    <i data-feather="shopping-bag" class="tw-w-4 tw-h-4 tw-mr-2 tw-inline" aria-hidden="true"></i>
                                    My Orders
                                </a>
                                <hr class="tw-border-gray-200">
                                <a
                                    href="/logout"
                                    class="tw-block tw-px-4 tw-py-3 tw-text-red-600 hover:tw-bg-red-50 tw-transition-colors tw-last:tw-rounded-b-lg"
                                    role="menuitem"
                                >
                                    <i data-feather="log-out" class="tw-w-4 tw-h-4 tw-mr-2 tw-inline" aria-hidden="true"></i>
                                    Logout
                                </a>
                            </div>
                        </div>
                    <?php else: ?>
                        <!-- Guest Menu -->
                        <button
                            class="tw-text-gray-700 hover:tw-text-primary-600 tw-transition-colors tw-px-3 tw-py-2 tw-rounded-lg tw-focus-visible:tw-outline-2 tw-focus-visible:tw-outline-primary-500 tw-min-h-[44px] tw-flex tw-items-center"
                            role="menuitem"
                            onclick="openModal('login-modal')"
                        >
                            <?= IconHelper::feather('login', ['size' => 'tw-w-4 tw-h-4', 'class' => 'tw-mr-2']) ?>
                            Login
                        </button>
                        <button
                            class="tw-btn-primary tw-focus-visible:tw-outline-2 tw-focus-visible:tw-outline-primary-500 tw-focus-visible:tw-outline-offset-2"
                            role="menuitem"
                            aria-label="Create a new account"
                            onclick="openModal('register-modal')"
                        >
                            <?= IconHelper::feather('register', ['size' => 'tw-w-4 tw-h-4', 'class' => 'tw-mr-2']) ?>
                            Sign Up
                        </button>
                    <?php endif; ?>
                </div>

                <!-- Mobile menu button -->
                <div class="md:tw-hidden">
                    <button
                        id="mobile-menu-btn"
                        class="tw-text-gray-700 hover:tw-text-primary-600 tw-p-2 tw-rounded-lg tw-focus-visible:tw-outline-2 tw-focus-visible:tw-outline-primary-500 tw-min-h-[44px] tw-min-w-[44px] tw-flex tw-items-center tw-justify-center"
                        aria-expanded="false"
                        aria-controls="mobile-menu"
                        aria-label="Toggle mobile menu"
                    >
                        <i data-feather="menu" class="tw-w-6 tw-h-6" aria-hidden="true"></i>
                    </button>
                </div>
            </div>
        </div>

        <!-- Mobile Navigation -->
        <div
            id="mobile-menu"
            class="md:tw-hidden tw-hidden tw-bg-white tw-border-t tw-border-gray-200"
            role="menu"
            aria-label="Mobile navigation menu"
        >
            <div class="tw-px-4 tw-py-2 tw-space-y-1">
                <a
                    href="/"
                    class="tw-block tw-px-3 tw-py-3 tw-text-gray-700 hover:tw-text-primary-600 hover:tw-bg-gray-50 tw-rounded-lg tw-transition-colors tw-min-h-[44px] tw-flex tw-items-center"
                    role="menuitem"
                    aria-current="<?= $_SERVER['REQUEST_URI'] === '/' ? 'page' : 'false' ?>"
                >
                    <i data-feather="home" class="tw-w-5 tw-h-5 tw-mr-3" aria-hidden="true"></i>
                    Home
                </a>
                <a
                    href="/browse"
                    class="tw-block tw-px-3 tw-py-3 tw-text-gray-700 hover:tw-text-primary-600 hover:tw-bg-gray-50 tw-rounded-lg tw-transition-colors tw-min-h-[44px] tw-flex tw-items-center"
                    role="menuitem"
                    aria-current="<?= strpos($_SERVER['REQUEST_URI'], '/browse') === 0 ? 'page' : 'false' ?>"
                >
                    <i data-feather="search" class="tw-w-5 tw-h-5 tw-mr-3" aria-hidden="true"></i>
                    Browse Restaurants
                </a>
                <a
                    href="/about"
                    class="tw-block tw-px-3 tw-py-3 tw-text-gray-700 hover:tw-text-primary-600 hover:tw-bg-gray-50 tw-rounded-lg tw-transition-colors tw-min-h-[44px] tw-flex tw-items-center"
                    role="menuitem"
                    aria-current="<?= $_SERVER['REQUEST_URI'] === '/about' ? 'page' : 'false' ?>"
                >
                    <i data-feather="info" class="tw-w-5 tw-h-5 tw-mr-3" aria-hidden="true"></i>
                    About
                </a>

                <?php if (isset($user) && $user): ?>
                    <hr class="tw-border-gray-200 tw-my-2">
                    <div class="tw-px-3 tw-py-2">
                        <div class="tw-flex tw-items-center tw-space-x-3 tw-mb-3">
                            <div class="tw-w-10 tw-h-10 tw-bg-primary-100 tw-rounded-full tw-flex tw-items-center tw-justify-center">
                                <span class="tw-text-primary-600 tw-font-semibold">
                                    <?= strtoupper(substr($user['username'], 0, 1)) ?>
                                </span>
                            </div>
                            <div>
                                <p class="tw-font-semibold tw-text-gray-800"><?= htmlspecialchars($user['username']) ?></p>
                                <p class="tw-text-sm tw-text-gray-600"><?= ucfirst($user['role'] ?? 'Customer') ?></p>
                            </div>
                        </div>
                    </div>
                    <a
                        href="/dashboard"
                        class="tw-block tw-px-3 tw-py-3 tw-text-gray-700 hover:tw-text-primary-600 hover:tw-bg-gray-50 tw-rounded-lg tw-transition-colors tw-min-h-[44px] tw-flex tw-items-center"
                        role="menuitem"
                    >
                        <i data-feather="grid" class="tw-w-5 tw-h-5 tw-mr-3" aria-hidden="true"></i>
                        Dashboard
                    </a>
                    <a
                        href="/orders"
                        class="tw-block tw-px-3 tw-py-3 tw-text-gray-700 hover:tw-text-primary-600 hover:tw-bg-gray-50 tw-rounded-lg tw-transition-colors tw-min-h-[44px] tw-flex tw-items-center"
                        role="menuitem"
                    >
                        <i data-feather="shopping-bag" class="tw-w-5 tw-h-5 tw-mr-3" aria-hidden="true"></i>
                        My Orders
                    </a>
                    <a
                        href="/logout"
                        class="tw-block tw-px-3 tw-py-3 tw-text-red-600 hover:tw-text-red-700 hover:tw-bg-red-50 tw-rounded-lg tw-transition-colors tw-min-h-[44px] tw-flex tw-items-center"
                        role="menuitem"
                    >
                        <i data-feather="log-out" class="tw-w-5 tw-h-5 tw-mr-3" aria-hidden="true"></i>
                        Logout
                    </a>
                <?php else: ?>
                    <hr class="tw-border-gray-200 tw-my-2">
                    <a
                        href="/login"
                        class="tw-block tw-px-3 tw-py-3 tw-text-gray-700 hover:tw-text-primary-600 hover:tw-bg-gray-50 tw-rounded-lg tw-transition-colors tw-min-h-[44px] tw-flex tw-items-center"
                        role="menuitem"
                    >
                        <i data-feather="log-in" class="tw-w-5 tw-h-5 tw-mr-3" aria-hidden="true"></i>
                        Login
                    </a>
                    <a
                        href="/register"
                        class="tw-block tw-mx-3 tw-my-2 tw-btn-primary tw-text-center tw-min-h-[44px] tw-flex tw-items-center tw-justify-center"
                        role="menuitem"
                    >
                        <i data-feather="user-plus" class="tw-w-5 tw-h-5 tw-mr-2" aria-hidden="true"></i>
                        Sign Up
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Flash Messages -->
    <?php
    $flash = $_SESSION['flash'] ?? [];
    foreach ($flash as $type => $message):
        $bgColor = $type === 'success' ? 'tw-bg-green-100 tw-border-green-500 tw-text-green-700' : 
                  ($type === 'error' ? 'tw-bg-red-100 tw-border-red-500 tw-text-red-700' : 
                   'tw-bg-blue-100 tw-border-blue-500 tw-text-blue-700');
    ?>
        <div class="tw-border-l-4 <?= $bgColor ?> tw-p-4 tw-mx-4 tw-mt-4 tw-rounded">
            <p><?= htmlspecialchars($message) ?></p>
        </div>
    <?php endforeach; ?>
    <?php unset($_SESSION['flash']); ?>

    <!-- Main Content -->
    <main id="main-content" class="tw-flex-1" role="main">
        <?= $content ?>
    </main>

    <!-- Footer -->
    <footer class="tw-bg-gray-800 tw-text-white tw-py-12" role="contentinfo">
        <div class="tw-container tw-mx-auto tw-px-4">
            <div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-4 tw-gap-8">
                <!-- Company Info -->
                <section class="tw-space-y-4">
                    <div class="tw-flex tw-items-center tw-space-x-2 tw-mb-4">
                        <div class="tw-w-8 tw-h-8 tw-bg-primary-600 tw-rounded-lg tw-flex tw-items-center tw-justify-center">
                            <span class="tw-text-white tw-font-bold tw-text-lg" aria-hidden="true">T</span>
                        </div>
                        <span class="tw-text-xl tw-font-bold">Time2Eat</span>
                    </div>
                    <p class="tw-text-gray-400 tw-leading-relaxed">
                        Connecting you with the best local restaurants in Bamenda. Fast delivery, authentic flavors, exceptional service.
                    </p>

                    <!-- Social Media Links -->
                    <div class="tw-flex tw-space-x-4 tw-pt-4">
                        <a
                            href="#"
                            class="tw-w-10 tw-h-10 tw-bg-gray-700 tw-rounded-full tw-flex tw-items-center tw-justify-center tw-text-gray-400 hover:tw-bg-primary-600 hover:tw-text-white tw-transition-all tw-duration-200"
                            aria-label="Follow us on Facebook"
                        >
                            <i data-feather="facebook" class="tw-w-5 tw-h-5" aria-hidden="true"></i>
                        </a>
                        <a
                            href="#"
                            class="tw-w-10 tw-h-10 tw-bg-gray-700 tw-rounded-full tw-flex tw-items-center tw-justify-center tw-text-gray-400 hover:tw-bg-primary-600 hover:tw-text-white tw-transition-all tw-duration-200"
                            aria-label="Follow us on Twitter"
                        >
                            <i data-feather="twitter" class="tw-w-5 tw-h-5" aria-hidden="true"></i>
                        </a>
                        <a
                            href="#"
                            class="tw-w-10 tw-h-10 tw-bg-gray-700 tw-rounded-full tw-flex tw-items-center tw-justify-center tw-text-gray-400 hover:tw-bg-primary-600 hover:tw-text-white tw-transition-all tw-duration-200"
                            aria-label="Follow us on Instagram"
                        >
                            <i data-feather="instagram" class="tw-w-5 tw-h-5" aria-hidden="true"></i>
                        </a>
                        <a
                            href="#"
                            class="tw-w-10 tw-h-10 tw-bg-gray-700 tw-rounded-full tw-flex tw-items-center tw-justify-center tw-text-gray-400 hover:tw-bg-primary-600 hover:tw-text-white tw-transition-all tw-duration-200"
                            aria-label="Contact us on WhatsApp"
                        >
                            <i data-feather="message-circle" class="tw-w-5 tw-h-5" aria-hidden="true"></i>
                        </a>
                    </div>
                </section>

                <!-- Quick Links -->
                <section>
                    <h3 class="tw-font-semibold tw-mb-4 tw-text-lg">Quick Links</h3>
                    <nav aria-label="Footer navigation">
                        <ul class="tw-space-y-3">
                            <li>
                                <a
                                    href="/"
                                    class="tw-text-gray-400 hover:tw-text-white tw-transition-colors tw-flex tw-items-center tw-space-x-2 tw-py-1"
                                >
                                    <i data-feather="home" class="tw-w-4 tw-h-4" aria-hidden="true"></i>
                                    <span>Home</span>
                                </a>
                            </li>
                            <li>
                                <a
                                    href="/browse"
                                    class="tw-text-gray-400 hover:tw-text-white tw-transition-colors tw-flex tw-items-center tw-space-x-2 tw-py-1"
                                >
                                    <i data-feather="search" class="tw-w-4 tw-h-4" aria-hidden="true"></i>
                                    <span>Browse Restaurants</span>
                                </a>
                            </li>
                            <li>
                                <a
                                    href="/about"
                                    class="tw-text-gray-400 hover:tw-text-white tw-transition-colors tw-flex tw-items-center tw-space-x-2 tw-py-1"
                                >
                                    <i data-feather="info" class="tw-w-4 tw-h-4" aria-hidden="true"></i>
                                    <span>About Us</span>
                                </a>
                            </li>
                            <?php if (!isset($user) || !$user): ?>
                                <li>
                                    <a
                                        href="/register"
                                        class="tw-text-gray-400 hover:tw-text-white tw-transition-colors tw-flex tw-items-center tw-space-x-2 tw-py-1"
                                    >
                                        <i data-feather="user-plus" class="tw-w-4 tw-h-4" aria-hidden="true"></i>
                                        <span>Sign Up</span>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </section>

                <!-- Support -->
                <section>
                    <h3 class="tw-font-semibold tw-mb-4 tw-text-lg">Support</h3>
                    <nav aria-label="Support links">
                        <ul class="tw-space-y-3">
                            <li>
                                <a
                                    href="/help"
                                    class="tw-text-gray-400 hover:tw-text-white tw-transition-colors tw-flex tw-items-center tw-space-x-2 tw-py-1"
                                >
                                    <i data-feather="help-circle" class="tw-w-4 tw-h-4" aria-hidden="true"></i>
                                    <span>Help Center</span>
                                </a>
                            </li>
                            <li>
                                <a
                                    href="/contact"
                                    class="tw-text-gray-400 hover:tw-text-white tw-transition-colors tw-flex tw-items-center tw-space-x-2 tw-py-1"
                                >
                                    <i data-feather="mail" class="tw-w-4 tw-h-4" aria-hidden="true"></i>
                                    <span>Contact Us</span>
                                </a>
                            </li>
                            <li>
                                <a
                                    href="/privacy"
                                    class="tw-text-gray-400 hover:tw-text-white tw-transition-colors tw-flex tw-items-center tw-space-x-2 tw-py-1"
                                >
                                    <i data-feather="shield" class="tw-w-4 tw-h-4" aria-hidden="true"></i>
                                    <span>Privacy Policy</span>
                                </a>
                            </li>
                            <li>
                                <a
                                    href="/terms"
                                    class="tw-text-gray-400 hover:tw-text-white tw-transition-colors tw-flex tw-items-center tw-space-x-2 tw-py-1"
                                >
                                    <i data-feather="file-text" class="tw-w-4 tw-h-4" aria-hidden="true"></i>
                                    <span>Terms of Service</span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </section>

                <!-- Contact Info -->
                <section>
                    <h3 class="tw-font-semibold tw-mb-4 tw-text-lg">Contact Info</h3>
                    <address class="tw-space-y-3 tw-text-gray-400 tw-not-italic">
                        <div class="tw-flex tw-items-start tw-space-x-3">
                            <i data-feather="mail" class="tw-w-4 tw-h-4 tw-mt-1 tw-flex-shrink-0" aria-hidden="true"></i>
                            <div>
                                <p class="tw-text-sm tw-text-gray-500 tw-mb-1">Email</p>
                                <a
                                    href="mailto:<?= e($site_settings['email'] ?? 'hello@time2eat.cm') ?>"
                                    class="tw-text-gray-400 hover:tw-text-white tw-transition-colors"
                                >
                                    <?= e($site_settings['email'] ?? 'hello@time2eat.cm') ?>
                                </a>
                            </div>
                        </div>

                        <div class="tw-flex tw-items-start tw-space-x-3">
                            <i data-feather="phone" class="tw-w-4 tw-h-4 tw-mt-1 tw-flex-shrink-0" aria-hidden="true"></i>
                            <div>
                                <p class="tw-text-sm tw-text-gray-500 tw-mb-1">Phone</p>
                                <a
                                    href="tel:<?= e($site_settings['phone'] ?? '+237 6XX XXX XXX') ?>"
                                    class="tw-text-gray-400 hover:tw-text-white tw-transition-colors"
                                >
                                    <?= e($site_settings['phone'] ?? '+237 6XX XXX XXX') ?>
                                </a>
                            </div>
                        </div>

                        <div class="tw-flex tw-items-start tw-space-x-3">
                            <i data-feather="map-pin" class="tw-w-4 tw-h-4 tw-mt-1 tw-flex-shrink-0" aria-hidden="true"></i>
                            <div>
                                <p class="tw-text-sm tw-text-gray-500 tw-mb-1">Address</p>
                                <p class="tw-text-gray-400">
                                    <?= e($site_settings['address'] ?? 'Commercial Avenue, Bamenda, Northwest Region, Cameroon') ?>
                                </p>
                            </div>
                        </div>

                        <div class="tw-flex tw-items-start tw-space-x-3">
                            <i data-feather="clock" class="tw-w-4 tw-h-4 tw-mt-1 tw-flex-shrink-0" aria-hidden="true"></i>
                            <div>
                                <p class="tw-text-sm tw-text-gray-500 tw-mb-1">Hours</p>
                                <p class="tw-text-gray-400">24/7 Service</p>
                            </div>
                        </div>
                    </address>
                </section>
            </div>

            <!-- Bottom Footer -->
            <div class="tw-border-t tw-border-gray-700 tw-mt-8 tw-pt-8">
                <div class="tw-flex tw-flex-col md:tw-flex-row tw-justify-between tw-items-center tw-space-y-4 md:tw-space-y-0">
                    <div class="tw-text-center md:tw-text-left tw-text-gray-400">
                        <p>&copy; <?= date('Y') ?> Time2Eat. All rights reserved.</p>
                        <p class="tw-text-sm tw-mt-1">Made with ❤️ in Bamenda, Cameroon</p>
                    </div>

                    <!-- App Download Links -->
                    <div class="tw-flex tw-items-center tw-space-x-4">
                        <button
                            id="footer-install-btn"
                            class="tw-hidden tw-bg-primary-600 tw-text-white tw-px-4 tw-py-2 tw-rounded-lg tw-text-sm tw-font-medium hover:tw-bg-primary-700 tw-transition-colors tw-flex tw-items-center tw-space-x-2"
                            aria-label="Install Time2Eat app"
                        >
                            <i data-feather="download" class="tw-w-4 tw-h-4" aria-hidden="true"></i>
                            <span>Install App</span>
                        </button>

                        <div class="tw-flex tw-items-center tw-space-x-2 tw-text-gray-400 tw-text-sm">
                            <i data-feather="smartphone" class="tw-w-4 tw-h-4" aria-hidden="true"></i>
                            <span>PWA Ready</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script>
        // Initialize application
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize Feather icons
            feather.replace();

            // Mobile menu functionality
            initializeMobileMenu();

            // PWA functionality
            initializePWA();

            // Lazy loading for images
            initializeLazyLoading();

            // Accessibility enhancements
            initializeAccessibility();
        });

        /**
         * Initialize mobile menu functionality
         */
        function initializeMobileMenu() {
            const mobileMenuBtn = document.getElementById('mobile-menu-btn');
            const mobileMenu = document.getElementById('mobile-menu');

            if (mobileMenuBtn && mobileMenu) {
                mobileMenuBtn.addEventListener('click', function() {
                    const isExpanded = mobileMenuBtn.getAttribute('aria-expanded') === 'true';

                    // Toggle menu visibility
                    mobileMenu.classList.toggle('tw-hidden');

                    // Update ARIA attributes
                    mobileMenuBtn.setAttribute('aria-expanded', !isExpanded);

                    // Update icon
                    const icon = mobileMenuBtn.querySelector('i');
                    if (icon) {
                        icon.setAttribute('data-feather', isExpanded ? 'menu' : 'x');
                        feather.replace();
                    }
                });

                // Close menu when clicking outside
                document.addEventListener('click', function(event) {
                    if (!mobileMenuBtn.contains(event.target) && !mobileMenu.contains(event.target)) {
                        mobileMenu.classList.add('tw-hidden');
                        mobileMenuBtn.setAttribute('aria-expanded', 'false');
                        const icon = mobileMenuBtn.querySelector('i');
                        if (icon) {
                            icon.setAttribute('data-feather', 'menu');
                            feather.replace();
                        }
                    }
                });

                // Close menu on escape key
                document.addEventListener('keydown', function(event) {
                    if (event.key === 'Escape' && !mobileMenu.classList.contains('tw-hidden')) {
                        mobileMenu.classList.add('tw-hidden');
                        mobileMenuBtn.setAttribute('aria-expanded', 'false');
                        mobileMenuBtn.focus();
                    }
                });
            }
        }

        /**
         * Initialize PWA functionality
         */
        function initializePWA() {
            let deferredPrompt;
            const installBtns = document.querySelectorAll('#install-app-btn, #footer-install-btn, #install-pwa-btn');
            const pwaBanner = document.getElementById('pwa-install-banner');
            const dismissBannerBtn = document.getElementById('dismiss-pwa-banner');

            // Handle beforeinstallprompt event
            window.addEventListener('beforeinstallprompt', (e) => {
                e.preventDefault();
                deferredPrompt = e;

                // Show install buttons
                installBtns.forEach(btn => {
                    if (btn) {
                        btn.classList.remove('tw-hidden');
                        btn.style.display = 'flex';
                    }
                });

                // Show PWA banner
                if (pwaBanner && !localStorage.getItem('pwa-banner-dismissed')) {
                    pwaBanner.classList.remove('tw-hidden');
                }
            });

            // Handle install button clicks
            installBtns.forEach(btn => {
                if (btn) {
                    btn.addEventListener('click', async () => {
                        if (deferredPrompt) {
                            deferredPrompt.prompt();
                            const { outcome } = await deferredPrompt.userChoice;

                            if (outcome === 'accepted') {
                                console.log('PWA installed');
                                // Hide install buttons
                                installBtns.forEach(b => {
                                    if (b) b.style.display = 'none';
                                });
                                if (pwaBanner) pwaBanner.classList.add('tw-hidden');
                            }

                            deferredPrompt = null;
                        }
                    });
                }
            });

            // Handle banner dismiss
            if (dismissBannerBtn) {
                dismissBannerBtn.addEventListener('click', () => {
                    if (pwaBanner) {
                        pwaBanner.classList.add('tw-hidden');
                        localStorage.setItem('pwa-banner-dismissed', 'true');
                    }
                });
            }

            // Handle app installed event
            window.addEventListener('appinstalled', () => {
                console.log('PWA was installed');
                installBtns.forEach(btn => {
                    if (btn) btn.style.display = 'none';
                });
                if (pwaBanner) pwaBanner.classList.add('tw-hidden');
            });
        }

        /**
         * Initialize lazy loading for images
         */
        function initializeLazyLoading() {
            if ('IntersectionObserver' in window) {
                const imageObserver = new IntersectionObserver((entries, observer) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            const img = entry.target;
                            if (img.dataset.src) {
                                img.src = img.dataset.src;
                                img.classList.remove('lazy-load');
                                observer.unobserve(img);
                            }
                        }
                    });
                });

                document.querySelectorAll('img.lazy-load').forEach(img => {
                    imageObserver.observe(img);
                });
            } else {
                // Fallback for browsers without IntersectionObserver
                document.querySelectorAll('img.lazy-load').forEach(img => {
                    if (img.dataset.src) {
                        img.src = img.dataset.src;
                    }
                });
            }
        }

        /**
         * Initialize accessibility enhancements
         */
        function initializeAccessibility() {
            // Add focus management for dropdowns
            const dropdowns = document.querySelectorAll('.tw-group');
            dropdowns.forEach(dropdown => {
                const button = dropdown.querySelector('button');
                const menu = dropdown.querySelector('[role="menu"]');

                if (button && menu) {
                    button.addEventListener('keydown', (e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault();
                            menu.classList.toggle('tw-opacity-0');
                            menu.classList.toggle('tw-invisible');
                        }
                    });
                }
            });

            // Announce page changes for screen readers
            const pageTitle = document.title;
            if (pageTitle) {
                const announcement = document.createElement('div');
                announcement.setAttribute('aria-live', 'polite');
                announcement.setAttribute('aria-atomic', 'true');
                announcement.className = 'tw-sr-only';
                announcement.textContent = `Page loaded: ${pageTitle}`;
                document.body.appendChild(announcement);

                // Remove announcement after screen reader has time to read it
                setTimeout(() => {
                    document.body.removeChild(announcement);
                }, 1000);
            }
        }

        /**
         * Show notification to user
         */
        function showNotification(title, message, type = 'info') {
            if ('Notification' in window && Notification.permission === 'granted') {
                new Notification(title, {
                    body: message,
                    icon: '/public/images/icon-192x192.png',
                    badge: '/public/images/icon-72x72.png'
                });
            }

            // Also show in-app notification
            const notification = document.createElement('div');
            notification.className = `tw-fixed tw-top-4 tw-right-4 tw-z-50 tw-max-w-sm tw-p-4 tw-rounded-lg tw-shadow-lg tw-transition-all tw-duration-300 tw-transform tw-translate-x-full`;

            const bgColor = type === 'success' ? 'tw-bg-green-500' :
                           type === 'error' ? 'tw-bg-red-500' :
                           type === 'warning' ? 'tw-bg-yellow-500' : 'tw-bg-blue-500';

            notification.classList.add(bgColor, 'tw-text-white');
            notification.innerHTML = `
                <div class="tw-flex tw-items-start tw-space-x-3">
                    <div class="tw-flex-1">
                        <h4 class="tw-font-semibold">${title}</h4>
                        <p class="tw-text-sm tw-opacity-90">${message}</p>
                    </div>
                    <button class="tw-text-white hover:tw-text-gray-200" onclick="this.parentElement.parentElement.remove()">
                        <i data-feather="x" class="tw-w-4 tw-h-4"></i>
                    </button>
                </div>
            `;

            document.body.appendChild(notification);
            feather.replace();

            // Animate in
            setTimeout(() => {
                notification.classList.remove('tw-translate-x-full');
            }, 100);

            // Auto remove after 5 seconds
            setTimeout(() => {
                notification.classList.add('tw-translate-x-full');
                setTimeout(() => {
                    if (notification.parentElement) {
                        notification.parentElement.removeChild(notification);
                    }
                }, 300);
            }, 5000);
        }

        // Make showNotification globally available
        window.showNotification = showNotification;
    </script>

    <!-- Service Worker Registration -->
    <script>
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', function() {
                navigator.serviceWorker.register('/sw.js')
                    .then(function(registration) {
                        console.log('ServiceWorker registration successful with scope: ', registration.scope);

                        // Check for updates
                        registration.addEventListener('updatefound', () => {
                            const newWorker = registration.installing;
                            newWorker.addEventListener('statechange', () => {
                                if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                                    // New content is available
                                    if (window.showNotification) {
                                        showNotification(
                                            'Update Available',
                                            'A new version of Time2Eat is available. Refresh to update.',
                                            'info'
                                        );
                                    }
                                }
                            });
                        });
                    })
                    .catch(function(err) {
                        console.log('ServiceWorker registration failed: ', err);
                    });
            });
        }

        // Request notification permission
        if ('Notification' in window && Notification.permission === 'default') {
            Notification.requestPermission().then(permission => {
                console.log('Notification permission:', permission);
            });
        }
    </script>

    <!-- External Scripts -->
    <script src="https://unpkg.com/feather-icons"></script>
    <script src="/public/js/app.js"></script>

    <?php
    // Include UI Components
    require_once __DIR__ . '/../components/cart.php';
    require_once __DIR__ . '/../components/modals.php';

    $cartComponent = new CartComponent();
    $modalComponents = new ModalComponents();

    // Render Cart Components
    echo $cartComponent->renderCartSidebar();
    echo $cartComponent->renderCartItemTemplate();
    echo $cartComponent->renderFloatingCartButton();

    // Render Modal Components
    echo $modalComponents->renderAllModals();

    // Render Scripts
    echo $cartComponent->renderCartScript();
    echo $modalComponents->renderModalScript();
    ?>

    <!-- QR Code Library -->
    <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js"></script>

    <!-- PWA Manager -->
    <script src="/js/pwa.js"></script>

    <!-- PWA Initialization Script -->
    <script>
        // Generate QR Code for current URL
        document.addEventListener('DOMContentLoaded', function() {
            const qrCodeElement = document.getElementById('qr-code');
            if (qrCodeElement && typeof QRCode !== 'undefined') {
                QRCode.toCanvas(qrCodeElement, window.location.origin, {
                    width: 150,
                    height: 150,
                    colorDark: '#1f2937',
                    colorLight: '#ffffff',
                    margin: 2,
                    errorCorrectionLevel: 'M'
                }, function (error) {
                    if (error) {
                        console.error('QR Code generation failed:', error);
                        qrCodeElement.innerHTML = '<div class="tw-text-gray-500 tw-text-sm">QR Code unavailable</div>';
                    }
                });
            }
        });

        // Share App Function
        function shareApp() {
            if (navigator.share) {
                navigator.share({
                    title: 'Time2Eat - Food Delivery',
                    text: 'Order food from your favorite restaurants in Bamenda',
                    url: window.location.origin
                }).catch(console.error);
            } else {
                // Fallback: Copy to clipboard
                navigator.clipboard.writeText(window.location.origin).then(() => {
                    if (window.pwaManager) {
                        window.pwaManager.showNotification('Link copied to clipboard!', 'success');
                    } else {
                        alert('Link copied to clipboard!');
                    }
                }).catch(() => {
                    // Fallback: Show URL
                    prompt('Copy this link:', window.location.origin);
                });
            }
        }

        // Connection Status Monitoring
        function updateConnectionStatus() {
            const statusElements = document.querySelectorAll('.connection-status');
            const isOnline = navigator.onLine;

            statusElements.forEach(element => {
                if (isOnline) {
                    element.textContent = 'Online';
                    element.className = 'connection-status tw-text-green-600 tw-font-medium';
                } else {
                    element.textContent = 'Offline';
                    element.className = 'connection-status tw-text-red-600 tw-font-medium';
                }
            });
        }

        // Initialize connection monitoring
        window.addEventListener('online', updateConnectionStatus);
        window.addEventListener('offline', updateConnectionStatus);
        document.addEventListener('DOMContentLoaded', updateConnectionStatus);

        // Notification Permission Prompt
        function requestNotificationPermission() {
            if ('Notification' in window && Notification.permission === 'default') {
                Notification.requestPermission().then(permission => {
                    if (permission === 'granted') {
                        if (window.pwaManager) {
                            window.pwaManager.showNotification('Notifications enabled!', 'success');
                        }
                    }
                });
            }
        }

        // Add notification prompt to page if needed
        document.addEventListener('DOMContentLoaded', function() {
            if ('Notification' in window && Notification.permission === 'default') {
                // Show notification prompt after 5 seconds
                setTimeout(() => {
                    const notificationBanner = document.createElement('div');
                    notificationBanner.className = 'notification-prompt tw-fixed tw-bottom-4 tw-right-4 tw-bg-blue-500 tw-text-white tw-p-4 tw-rounded-lg tw-shadow-lg tw-z-50 tw-max-w-sm';
                    notificationBanner.innerHTML = `
                        <div class="tw-flex tw-items-center tw-justify-between">
                            <div class="tw-mr-3">
                                <p class="tw-font-medium tw-mb-1">Enable Notifications</p>
                                <p class="tw-text-sm tw-opacity-90">Get updates on your orders</p>
                            </div>
                            <div class="tw-flex tw-space-x-2">
                                <button onclick="requestNotificationPermission(); this.closest('.notification-prompt').remove();" class="enable-notifications tw-bg-white tw-text-blue-500 tw-px-3 tw-py-1 tw-rounded tw-text-sm tw-font-medium">
                                    Enable
                                </button>
                                <button onclick="this.closest('.notification-prompt').remove();" class="tw-text-white tw-opacity-75 tw-hover:tw-opacity-100">
                                    <i data-feather="x" class="tw-w-4 tw-h-4"></i>
                                </button>
                            </div>
                        </div>
                    `;
                    document.body.appendChild(notificationBanner);

                    // Initialize feather icons for the new elements
                    if (typeof feather !== 'undefined') {
                        feather.replace();
                    }
                }, 5000);
            }
        });

        // Performance monitoring
        if ('performance' in window) {
            window.addEventListener('load', () => {
                setTimeout(() => {
                    const perfData = performance.getEntriesByType('navigation')[0];
                    if (perfData) {
                        console.log('[PWA] Page load time:', perfData.loadEventEnd - perfData.fetchStart, 'ms');

                        // Track slow loads
                        if (perfData.loadEventEnd - perfData.fetchStart > 3000) {
                            console.warn('[PWA] Slow page load detected');
                        }
                    }
                }, 0);
            });
        }
    </script>
</body>
</html>
