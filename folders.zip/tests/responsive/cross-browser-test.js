/**
 * Time2Eat Cross-Browser Testing Suite
 * Comprehensive browser compatibility testing
 */

class CrossBrowserTestSuite {
    constructor() {
        this.browserFeatures = this.initializeBrowserFeatures();
        this.testResults = {};
        this.init();
    }

    /**
     * Initialize browser feature detection
     */
    initializeBrowserFeatures() {
        return {
            // CSS Features
            css: {
                flexbox: this.supportsCSS('display', 'flex'),
                grid: this.supportsCSS('display', 'grid'),
                customProperties: this.supportsCSS('--test', 'test'),
                transforms: this.supportsCSS('transform', 'translateX(1px)'),
                transitions: this.supportsCSS('transition', 'all 1s'),
                animations: this.supportsCSS('animation', 'test 1s'),
                calc: this.supportsCSS('width', 'calc(100% - 10px)'),
                viewport: this.supportsCSS('width', '100vw'),
                objectFit: this.supportsCSS('object-fit', 'cover'),
                backdropFilter: this.supportsCSS('backdrop-filter', 'blur(10px)')
            },
            
            // JavaScript Features
            javascript: {
                es6: this.supportsES6(),
                promises: typeof Promise !== 'undefined',
                fetch: typeof fetch !== 'undefined',
                intersectionObserver: 'IntersectionObserver' in window,
                serviceWorker: 'serviceWorker' in navigator,
                webWorkers: typeof Worker !== 'undefined',
                localStorage: this.supportsLocalStorage(),
                sessionStorage: this.supportsSessionStorage(),
                geolocation: 'geolocation' in navigator,
                notifications: 'Notification' in window
            },
            
            // Media Features
            media: {
                webp: this.supportsWebP(),
                avif: this.supportsAVIF(),
                webm: this.supportsWebM(),
                mp4: this.supportsMP4()
            },
            
            // Touch and Input
            input: {
                touch: 'ontouchstart' in window,
                pointer: 'onpointerdown' in window,
                deviceMotion: 'DeviceMotionEvent' in window,
                deviceOrientation: 'DeviceOrientationEvent' in window
            },
            
            // PWA Features
            pwa: {
                manifest: 'onbeforeinstallprompt' in window,
                serviceWorker: 'serviceWorker' in navigator,
                pushManager: 'PushManager' in window,
                backgroundSync: 'serviceWorker' in navigator && 'sync' in window.ServiceWorkerRegistration.prototype
            }
        };
    }

    /**
     * Initialize testing suite
     */
    init() {
        this.detectBrowser();
        this.runCompatibilityTests();
        this.setupPolyfills();
    }

    /**
     * Detect current browser
     */
    detectBrowser() {
        const userAgent = navigator.userAgent;
        const vendor = navigator.vendor;
        
        this.browser = {
            name: 'Unknown',
            version: 'Unknown',
            engine: 'Unknown'
        };

        // Chrome
        if (/Chrome/.test(userAgent) && /Google Inc/.test(vendor)) {
            this.browser.name = 'Chrome';
            this.browser.version = userAgent.match(/Chrome\/(\d+)/)?.[1] || 'Unknown';
            this.browser.engine = 'Blink';
        }
        // Firefox
        else if (/Firefox/.test(userAgent)) {
            this.browser.name = 'Firefox';
            this.browser.version = userAgent.match(/Firefox\/(\d+)/)?.[1] || 'Unknown';
            this.browser.engine = 'Gecko';
        }
        // Safari
        else if (/Safari/.test(userAgent) && /Apple Computer/.test(vendor)) {
            this.browser.name = 'Safari';
            this.browser.version = userAgent.match(/Version\/(\d+)/)?.[1] || 'Unknown';
            this.browser.engine = 'WebKit';
        }
        // Edge
        else if (/Edg/.test(userAgent)) {
            this.browser.name = 'Edge';
            this.browser.version = userAgent.match(/Edg\/(\d+)/)?.[1] || 'Unknown';
            this.browser.engine = 'Blink';
        }
        // Internet Explorer
        else if (/Trident/.test(userAgent)) {
            this.browser.name = 'Internet Explorer';
            this.browser.version = userAgent.match(/rv:(\d+)/)?.[1] || 'Unknown';
            this.browser.engine = 'Trident';
        }

        console.log('Detected browser:', this.browser);
    }

    /**
     * Run comprehensive compatibility tests
     */
    runCompatibilityTests() {
        this.testResults = {
            browser: this.browser,
            features: this.browserFeatures,
            tests: {
                css: this.testCSSCompatibility(),
                javascript: this.testJavaScriptCompatibility(),
                responsive: this.testResponsiveFeatures(),
                pwa: this.testPWACompatibility(),
                performance: this.testPerformanceFeatures(),
                accessibility: this.testAccessibilityFeatures()
            },
            recommendations: this.generateRecommendations()
        };

        this.displayResults();
    }

    /**
     * Test CSS compatibility
     */
    testCSSCompatibility() {
        const results = { status: 'pass', issues: [], warnings: [] };
        
        // Critical CSS features
        const criticalFeatures = ['flexbox', 'grid', 'transforms', 'transitions'];
        criticalFeatures.forEach(feature => {
            if (!this.browserFeatures.css[feature]) {
                results.status = 'fail';
                results.issues.push(`Critical CSS feature not supported: ${feature}`);
            }
        });

        // Nice-to-have features
        const enhancementFeatures = ['customProperties', 'calc', 'objectFit', 'backdropFilter'];
        enhancementFeatures.forEach(feature => {
            if (!this.browserFeatures.css[feature]) {
                results.warnings.push(`Enhancement CSS feature not supported: ${feature}`);
            }
        });

        // Test Tailwind CSS compatibility
        if (!this.testTailwindCompatibility()) {
            results.status = 'fail';
            results.issues.push('Tailwind CSS not fully compatible');
        }

        return results;
    }

    /**
     * Test JavaScript compatibility
     */
    testJavaScriptCompatibility() {
        const results = { status: 'pass', issues: [], warnings: [] };
        
        // Critical JavaScript features
        const criticalFeatures = ['es6', 'promises', 'fetch'];
        criticalFeatures.forEach(feature => {
            if (!this.browserFeatures.javascript[feature]) {
                results.status = 'fail';
                results.issues.push(`Critical JavaScript feature not supported: ${feature}`);
            }
        });

        // Enhancement features
        const enhancementFeatures = ['intersectionObserver', 'serviceWorker', 'localStorage'];
        enhancementFeatures.forEach(feature => {
            if (!this.browserFeatures.javascript[feature]) {
                results.warnings.push(`Enhancement JavaScript feature not supported: ${feature}`);
            }
        });

        return results;
    }

    /**
     * Test responsive design features
     */
    testResponsiveFeatures() {
        const results = { status: 'pass', issues: [], warnings: [] };
        
        // Test viewport meta tag
        const viewportMeta = document.querySelector('meta[name="viewport"]');
        if (!viewportMeta) {
            results.status = 'fail';
            results.issues.push('Viewport meta tag missing');
        }

        // Test media queries
        if (!window.matchMedia) {
            results.status = 'fail';
            results.issues.push('Media queries not supported');
        }

        // Test touch support
        if (this.browserFeatures.input.touch) {
            if (!this.testTouchInteractions()) {
                results.warnings.push('Touch interactions may not work properly');
            }
        }

        return results;
    }

    /**
     * Test PWA compatibility
     */
    testPWACompatibility() {
        const results = { status: 'pass', issues: [], warnings: [] };
        
        // Test service worker support
        if (!this.browserFeatures.pwa.serviceWorker) {
            results.status = 'fail';
            results.issues.push('Service Worker not supported - PWA features unavailable');
        }

        // Test manifest support
        if (!this.browserFeatures.pwa.manifest) {
            results.warnings.push('Web App Manifest may not be fully supported');
        }

        // Test push notifications
        if (!this.browserFeatures.pwa.pushManager) {
            results.warnings.push('Push notifications not supported');
        }

        return results;
    }

    /**
     * Test performance features
     */
    testPerformanceFeatures() {
        const results = { status: 'pass', issues: [], warnings: [] };
        
        // Test Intersection Observer for lazy loading
        if (!this.browserFeatures.javascript.intersectionObserver) {
            results.warnings.push('Intersection Observer not supported - lazy loading fallback required');
        }

        // Test WebP support
        if (!this.browserFeatures.media.webp) {
            results.warnings.push('WebP images not supported - using fallback formats');
        }

        // Test Web Workers
        if (!this.browserFeatures.javascript.webWorkers) {
            results.warnings.push('Web Workers not supported - background processing limited');
        }

        return results;
    }

    /**
     * Test accessibility features
     */
    testAccessibilityFeatures() {
        const results = { status: 'pass', issues: [], warnings: [] };
        
        // Test ARIA support
        const testElement = document.createElement('div');
        testElement.setAttribute('aria-label', 'test');
        if (!testElement.getAttribute('aria-label')) {
            results.status = 'fail';
            results.issues.push('ARIA attributes not supported');
        }

        // Test focus management
        if (!document.activeElement) {
            results.warnings.push('Focus management may be limited');
        }

        // Test screen reader compatibility
        if (!this.testScreenReaderCompatibility()) {
            results.warnings.push('Screen reader compatibility may be limited');
        }

        return results;
    }

    /**
     * Generate recommendations based on test results
     */
    generateRecommendations() {
        const recommendations = [];
        
        // Browser-specific recommendations
        switch (this.browser.name) {
            case 'Internet Explorer':
                recommendations.push('Consider upgrading to a modern browser for better performance and security');
                recommendations.push('Enable polyfills for ES6 features');
                recommendations.push('Use CSS prefixes for better compatibility');
                break;
                
            case 'Safari':
                recommendations.push('Test PWA features thoroughly - Safari has limited support');
                recommendations.push('Use -webkit- prefixes for CSS features');
                break;
                
            case 'Firefox':
                recommendations.push('Test backdrop-filter effects - may require fallbacks');
                break;
        }

        // Feature-based recommendations
        if (!this.browserFeatures.css.grid) {
            recommendations.push('Use Flexbox fallbacks for CSS Grid layouts');
        }
        
        if (!this.browserFeatures.javascript.fetch) {
            recommendations.push('Include fetch polyfill for AJAX requests');
        }
        
        if (!this.browserFeatures.media.webp) {
            recommendations.push('Provide JPEG/PNG fallbacks for WebP images');
        }

        return recommendations;
    }

    /**
     * Display test results
     */
    displayResults() {
        console.group('Cross-Browser Compatibility Test Results');
        console.log('Browser:', this.browser);
        console.log('Test Results:', this.testResults);
        console.groupEnd();

        // Create visual results if in development mode
        if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
            this.createResultsUI();
        }
    }

    /**
     * Create visual results UI
     */
    createResultsUI() {
        const resultsContainer = document.createElement('div');
        resultsContainer.id = 'browser-test-results';
        resultsContainer.innerHTML = `
            <div class="test-results-header">
                <h3>Browser Compatibility Results</h3>
                <button id="close-results">×</button>
            </div>
            <div class="test-results-content">
                <div class="browser-info">
                    <strong>${this.browser.name} ${this.browser.version}</strong> (${this.browser.engine})
                </div>
                ${this.renderTestResults()}
            </div>
        `;

        // Add styles
        const styles = `
            <style>
                #browser-test-results {
                    position: fixed;
                    top: 20px;
                    left: 20px;
                    width: 400px;
                    max-height: 80vh;
                    background: white;
                    border: 1px solid #ddd;
                    border-radius: 8px;
                    box-shadow: 0 4px 20px rgba(0,0,0,0.1);
                    z-index: 10000;
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    font-size: 14px;
                    overflow: hidden;
                }
                
                .test-results-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 15px;
                    background: #f8f9fa;
                    border-bottom: 1px solid #ddd;
                }
                
                .test-results-header h3 {
                    margin: 0;
                    font-size: 16px;
                }
                
                #close-results {
                    background: none;
                    border: none;
                    font-size: 20px;
                    cursor: pointer;
                    padding: 0;
                    width: 24px;
                    height: 24px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }
                
                .test-results-content {
                    padding: 15px;
                    max-height: calc(80vh - 60px);
                    overflow-y: auto;
                }
                
                .browser-info {
                    margin-bottom: 15px;
                    padding: 10px;
                    background: #e3f2fd;
                    border-radius: 4px;
                }
                
                .test-category {
                    margin-bottom: 15px;
                }
                
                .test-category h4 {
                    margin: 0 0 8px 0;
                    font-size: 14px;
                    font-weight: 600;
                }
                
                .test-status {
                    display: inline-block;
                    padding: 2px 8px;
                    border-radius: 12px;
                    font-size: 12px;
                    font-weight: 500;
                    margin-left: 8px;
                }
                
                .test-status.pass {
                    background: #d4edda;
                    color: #155724;
                }
                
                .test-status.fail {
                    background: #f8d7da;
                    color: #721c24;
                }
                
                .test-status.warning {
                    background: #fff3cd;
                    color: #856404;
                }
                
                .test-issues {
                    margin-top: 8px;
                    font-size: 12px;
                }
                
                .test-issues ul {
                    margin: 4px 0;
                    padding-left: 20px;
                }
                
                .test-issues li {
                    margin-bottom: 2px;
                }
                
                .recommendations {
                    margin-top: 15px;
                    padding: 10px;
                    background: #fff3cd;
                    border-radius: 4px;
                }
                
                .recommendations h4 {
                    margin: 0 0 8px 0;
                    font-size: 14px;
                }
                
                .recommendations ul {
                    margin: 0;
                    padding-left: 20px;
                }
            </style>
        `;

        document.head.insertAdjacentHTML('beforeend', styles);
        document.body.appendChild(resultsContainer);

        // Bind close button
        document.getElementById('close-results').addEventListener('click', () => {
            resultsContainer.remove();
        });
    }

    /**
     * Render test results HTML
     */
    renderTestResults() {
        let html = '';
        
        for (const [category, result] of Object.entries(this.testResults.tests)) {
            html += `
                <div class="test-category">
                    <h4>
                        ${category.charAt(0).toUpperCase() + category.slice(1)}
                        <span class="test-status ${result.status}">${result.status.toUpperCase()}</span>
                    </h4>
                    ${result.issues && result.issues.length > 0 ? `
                        <div class="test-issues">
                            <strong>Issues:</strong>
                            <ul>${result.issues.map(issue => `<li>${issue}</li>`).join('')}</ul>
                        </div>
                    ` : ''}
                    ${result.warnings && result.warnings.length > 0 ? `
                        <div class="test-issues">
                            <strong>Warnings:</strong>
                            <ul>${result.warnings.map(warning => `<li>${warning}</li>`).join('')}</ul>
                        </div>
                    ` : ''}
                </div>
            `;
        }

        if (this.testResults.recommendations.length > 0) {
            html += `
                <div class="recommendations">
                    <h4>Recommendations</h4>
                    <ul>${this.testResults.recommendations.map(rec => `<li>${rec}</li>`).join('')}</ul>
                </div>
            `;
        }

        return html;
    }

    /**
     * Setup polyfills for unsupported features
     */
    setupPolyfills() {
        // Fetch polyfill
        if (!this.browserFeatures.javascript.fetch) {
            this.loadPolyfill('https://cdn.jsdelivr.net/npm/whatwg-fetch@3.6.2/dist/fetch.umd.js');
        }

        // Intersection Observer polyfill
        if (!this.browserFeatures.javascript.intersectionObserver) {
            this.loadPolyfill('https://cdn.jsdelivr.net/npm/intersection-observer@0.12.0/intersection-observer.js');
        }

        // CSS Custom Properties polyfill for IE
        if (!this.browserFeatures.css.customProperties && this.browser.name === 'Internet Explorer') {
            this.loadPolyfill('https://cdn.jsdelivr.net/npm/css-vars-ponyfill@2.4.7/dist/css-vars-ponyfill.min.js');
        }
    }

    /**
     * Load polyfill script
     */
    loadPolyfill(url) {
        const script = document.createElement('script');
        script.src = url;
        script.async = true;
        document.head.appendChild(script);
    }

    // Helper methods for feature detection
    supportsCSS(property, value) {
        const element = document.createElement('div');
        element.style[property] = value;
        return element.style[property] === value;
    }

    supportsES6() {
        try {
            return typeof Symbol !== 'undefined' && 
                   eval('class Test {}; true');
        } catch (e) {
            return false;
        }
    }

    supportsLocalStorage() {
        try {
            localStorage.setItem('test', 'test');
            localStorage.removeItem('test');
            return true;
        } catch (e) {
            return false;
        }
    }

    supportsSessionStorage() {
        try {
            sessionStorage.setItem('test', 'test');
            sessionStorage.removeItem('test');
            return true;
        } catch (e) {
            return false;
        }
    }

    supportsWebP() {
        const canvas = document.createElement('canvas');
        canvas.width = 1;
        canvas.height = 1;
        return canvas.toDataURL('image/webp').indexOf('data:image/webp') === 0;
    }

    supportsAVIF() {
        const canvas = document.createElement('canvas');
        canvas.width = 1;
        canvas.height = 1;
        return canvas.toDataURL('image/avif').indexOf('data:image/avif') === 0;
    }

    supportsWebM() {
        const video = document.createElement('video');
        return video.canPlayType('video/webm') !== '';
    }

    supportsMP4() {
        const video = document.createElement('video');
        return video.canPlayType('video/mp4') !== '';
    }

    testTailwindCompatibility() {
        // Test if Tailwind classes are working
        const testElement = document.createElement('div');
        testElement.className = 'tw-flex tw-items-center';
        document.body.appendChild(testElement);
        
        const styles = window.getComputedStyle(testElement);
        const isWorking = styles.display === 'flex' && styles.alignItems === 'center';
        
        document.body.removeChild(testElement);
        return isWorking;
    }

    testTouchInteractions() {
        return 'ontouchstart' in window && 'ontouchmove' in window && 'ontouchend' in window;
    }

    testScreenReaderCompatibility() {
        // Basic test for screen reader support
        const testElement = document.createElement('div');
        testElement.setAttribute('role', 'button');
        testElement.setAttribute('aria-label', 'test');
        
        return testElement.getAttribute('role') === 'button' && 
               testElement.getAttribute('aria-label') === 'test';
    }
}

// Initialize cross-browser testing
document.addEventListener('DOMContentLoaded', () => {
    window.crossBrowserTest = new CrossBrowserTestSuite();
});
