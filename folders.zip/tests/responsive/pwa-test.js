/**
 * Time2Eat PWA Testing Suite
 * Comprehensive testing for Progressive Web App functionality
 */

class PWATestSuite {
    constructor() {
        this.testResults = {};
        this.serviceWorkerRegistration = null;
        this.init();
    }

    /**
     * Initialize PWA testing
     */
    async init() {
        console.log('🚀 Starting PWA Test Suite...');
        
        await this.runAllTests();
        this.displayResults();
    }

    /**
     * Run all PWA tests
     */
    async runAllTests() {
        this.testResults = {
            serviceWorker: await this.testServiceWorker(),
            manifest: await this.testManifest(),
            offline: await this.testOfflineCapability(),
            installability: await this.testInstallability(),
            pushNotifications: await this.testPushNotifications(),
            backgroundSync: await this.testBackgroundSync(),
            caching: await this.testCaching(),
            performance: await this.testPerformance()
        };
    }

    /**
     * Test Service Worker functionality
     */
    async testServiceWorker() {
        const results = { status: 'pass', tests: [], issues: [] };

        try {
            // Check Service Worker support
            if (!('serviceWorker' in navigator)) {
                results.status = 'fail';
                results.issues.push('Service Worker not supported in this browser');
                return results;
            }

            results.tests.push({ name: 'Service Worker Support', status: 'pass' });

            // Check if Service Worker is registered
            const registration = await navigator.serviceWorker.getRegistration();
            if (!registration) {
                results.status = 'fail';
                results.issues.push('Service Worker not registered');
                return results;
            }

            this.serviceWorkerRegistration = registration;
            results.tests.push({ name: 'Service Worker Registration', status: 'pass' });

            // Check Service Worker state
            const sw = registration.active || registration.waiting || registration.installing;
            if (!sw) {
                results.status = 'fail';
                results.issues.push('No active Service Worker found');
                return results;
            }

            results.tests.push({ 
                name: 'Service Worker State', 
                status: 'pass',
                details: `State: ${sw.state}`
            });

            // Test Service Worker communication
            const communicationTest = await this.testServiceWorkerCommunication(sw);
            results.tests.push(communicationTest);

            if (communicationTest.status === 'fail') {
                results.status = 'warning';
            }

        } catch (error) {
            results.status = 'fail';
            results.issues.push(`Service Worker test failed: ${error.message}`);
        }

        return results;
    }

    /**
     * Test Service Worker communication
     */
    async testServiceWorkerCommunication(serviceWorker) {
        return new Promise((resolve) => {
            const messageChannel = new MessageChannel();
            
            messageChannel.port1.onmessage = (event) => {
                if (event.data && event.data.type === 'pong') {
                    resolve({ name: 'Service Worker Communication', status: 'pass' });
                } else {
                    resolve({ name: 'Service Worker Communication', status: 'fail' });
                }
            };

            // Send ping message
            serviceWorker.postMessage({ type: 'ping' }, [messageChannel.port2]);

            // Timeout after 5 seconds
            setTimeout(() => {
                resolve({ name: 'Service Worker Communication', status: 'fail' });
            }, 5000);
        });
    }

    /**
     * Test Web App Manifest
     */
    async testManifest() {
        const results = { status: 'pass', tests: [], issues: [] };

        try {
            // Check if manifest link exists
            const manifestLink = document.querySelector('link[rel="manifest"]');
            if (!manifestLink) {
                results.status = 'fail';
                results.issues.push('Manifest link not found in HTML');
                return results;
            }

            results.tests.push({ name: 'Manifest Link', status: 'pass' });

            // Fetch and validate manifest
            const manifestUrl = manifestLink.href;
            const response = await fetch(manifestUrl);
            
            if (!response.ok) {
                results.status = 'fail';
                results.issues.push(`Manifest fetch failed: ${response.status}`);
                return results;
            }

            const manifest = await response.json();
            results.tests.push({ name: 'Manifest Fetch', status: 'pass' });

            // Validate required manifest fields
            const requiredFields = ['name', 'short_name', 'start_url', 'display', 'icons'];
            const manifestValidation = this.validateManifestFields(manifest, requiredFields);
            
            results.tests.push(...manifestValidation.tests);
            if (manifestValidation.issues.length > 0) {
                results.status = 'warning';
                results.issues.push(...manifestValidation.issues);
            }

            // Test theme color
            const themeColorMeta = document.querySelector('meta[name="theme-color"]');
            if (!themeColorMeta) {
                results.issues.push('Theme color meta tag missing');
                results.status = 'warning';
            } else {
                results.tests.push({ name: 'Theme Color', status: 'pass' });
            }

        } catch (error) {
            results.status = 'fail';
            results.issues.push(`Manifest test failed: ${error.message}`);
        }

        return results;
    }

    /**
     * Validate manifest fields
     */
    validateManifestFields(manifest, requiredFields) {
        const tests = [];
        const issues = [];

        requiredFields.forEach(field => {
            if (manifest[field]) {
                tests.push({ name: `Manifest ${field}`, status: 'pass' });
            } else {
                tests.push({ name: `Manifest ${field}`, status: 'fail' });
                issues.push(`Required manifest field missing: ${field}`);
            }
        });

        // Validate icons
        if (manifest.icons && Array.isArray(manifest.icons)) {
            const hasRequiredSizes = manifest.icons.some(icon => 
                icon.sizes && (icon.sizes.includes('192x192') || icon.sizes.includes('512x512'))
            );
            
            if (hasRequiredSizes) {
                tests.push({ name: 'Manifest Icons Sizes', status: 'pass' });
            } else {
                tests.push({ name: 'Manifest Icons Sizes', status: 'warning' });
                issues.push('Manifest should include 192x192 and 512x512 icon sizes');
            }
        }

        return { tests, issues };
    }

    /**
     * Test offline capability
     */
    async testOfflineCapability() {
        const results = { status: 'pass', tests: [], issues: [] };

        try {
            // Test if offline page exists
            const offlineTest = await this.testOfflinePage();
            results.tests.push(offlineTest);

            // Test cache strategies
            const cacheTest = await this.testCacheStrategies();
            results.tests.push(cacheTest);

            // Simulate offline condition
            if ('onLine' in navigator) {
                results.tests.push({ 
                    name: 'Online Status Detection', 
                    status: 'pass',
                    details: `Currently: ${navigator.onLine ? 'Online' : 'Offline'}`
                });
            }

        } catch (error) {
            results.status = 'fail';
            results.issues.push(`Offline test failed: ${error.message}`);
        }

        return results;
    }

    /**
     * Test offline page
     */
    async testOfflinePage() {
        try {
            const response = await fetch('/offline.html', { cache: 'no-cache' });
            if (response.ok) {
                return { name: 'Offline Page', status: 'pass' };
            } else {
                return { name: 'Offline Page', status: 'warning' };
            }
        } catch (error) {
            return { name: 'Offline Page', status: 'fail' };
        }
    }

    /**
     * Test cache strategies
     */
    async testCacheStrategies() {
        try {
            const cacheNames = await caches.keys();
            if (cacheNames.length > 0) {
                return { 
                    name: 'Cache Strategy', 
                    status: 'pass',
                    details: `${cacheNames.length} cache(s) found`
                };
            } else {
                return { name: 'Cache Strategy', status: 'warning' };
            }
        } catch (error) {
            return { name: 'Cache Strategy', status: 'fail' };
        }
    }

    /**
     * Test PWA installability
     */
    async testInstallability() {
        const results = { status: 'pass', tests: [], issues: [] };

        try {
            // Check for beforeinstallprompt event
            let installPromptAvailable = false;
            
            window.addEventListener('beforeinstallprompt', (e) => {
                installPromptAvailable = true;
                e.preventDefault(); // Prevent automatic prompt
            });

            // Wait a bit to see if event fires
            await new Promise(resolve => setTimeout(resolve, 1000));

            if (installPromptAvailable) {
                results.tests.push({ name: 'Install Prompt Available', status: 'pass' });
            } else {
                results.tests.push({ name: 'Install Prompt Available', status: 'warning' });
                results.issues.push('Install prompt not available (may already be installed)');
            }

            // Check if already installed
            if (window.matchMedia('(display-mode: standalone)').matches) {
                results.tests.push({ name: 'PWA Installation Status', status: 'pass', details: 'Already installed' });
            } else {
                results.tests.push({ name: 'PWA Installation Status', status: 'pass', details: 'Not installed' });
            }

        } catch (error) {
            results.status = 'fail';
            results.issues.push(`Installability test failed: ${error.message}`);
        }

        return results;
    }

    /**
     * Test push notifications
     */
    async testPushNotifications() {
        const results = { status: 'pass', tests: [], issues: [] };

        try {
            // Check Push API support
            if (!('PushManager' in window)) {
                results.status = 'warning';
                results.issues.push('Push notifications not supported');
                return results;
            }

            results.tests.push({ name: 'Push API Support', status: 'pass' });

            // Check notification permission
            const permission = Notification.permission;
            results.tests.push({ 
                name: 'Notification Permission', 
                status: permission === 'granted' ? 'pass' : 'warning',
                details: `Permission: ${permission}`
            });

            // Check if push subscription exists
            if (this.serviceWorkerRegistration) {
                const subscription = await this.serviceWorkerRegistration.pushManager.getSubscription();
                if (subscription) {
                    results.tests.push({ name: 'Push Subscription', status: 'pass' });
                } else {
                    results.tests.push({ name: 'Push Subscription', status: 'warning' });
                }
            }

        } catch (error) {
            results.status = 'fail';
            results.issues.push(`Push notification test failed: ${error.message}`);
        }

        return results;
    }

    /**
     * Test background sync
     */
    async testBackgroundSync() {
        const results = { status: 'pass', tests: [], issues: [] };

        try {
            // Check Background Sync support
            if (this.serviceWorkerRegistration && 'sync' in this.serviceWorkerRegistration) {
                results.tests.push({ name: 'Background Sync Support', status: 'pass' });
            } else {
                results.status = 'warning';
                results.issues.push('Background Sync not supported');
            }

        } catch (error) {
            results.status = 'fail';
            results.issues.push(`Background sync test failed: ${error.message}`);
        }

        return results;
    }

    /**
     * Test caching functionality
     */
    async testCaching() {
        const results = { status: 'pass', tests: [], issues: [] };

        try {
            // Check Cache API support
            if (!('caches' in window)) {
                results.status = 'fail';
                results.issues.push('Cache API not supported');
                return results;
            }

            results.tests.push({ name: 'Cache API Support', status: 'pass' });

            // List available caches
            const cacheNames = await caches.keys();
            results.tests.push({ 
                name: 'Available Caches', 
                status: cacheNames.length > 0 ? 'pass' : 'warning',
                details: `${cacheNames.length} cache(s): ${cacheNames.join(', ')}`
            });

            // Test cache functionality
            if (cacheNames.length > 0) {
                const cache = await caches.open(cacheNames[0]);
                const cachedRequests = await cache.keys();
                results.tests.push({ 
                    name: 'Cached Resources', 
                    status: cachedRequests.length > 0 ? 'pass' : 'warning',
                    details: `${cachedRequests.length} cached resources`
                });
            }

        } catch (error) {
            results.status = 'fail';
            results.issues.push(`Caching test failed: ${error.message}`);
        }

        return results;
    }

    /**
     * Test PWA performance
     */
    async testPerformance() {
        const results = { status: 'pass', tests: [], issues: [] };

        try {
            // Test load time
            if ('performance' in window && performance.timing) {
                const loadTime = performance.timing.loadEventEnd - performance.timing.navigationStart;
                results.tests.push({ 
                    name: 'Page Load Time', 
                    status: loadTime < 3000 ? 'pass' : 'warning',
                    details: `${loadTime}ms`
                });
            }

            // Test First Contentful Paint
            if ('performance' in window && performance.getEntriesByType) {
                const paintEntries = performance.getEntriesByType('paint');
                const fcp = paintEntries.find(entry => entry.name === 'first-contentful-paint');
                
                if (fcp) {
                    results.tests.push({ 
                        name: 'First Contentful Paint', 
                        status: fcp.startTime < 2000 ? 'pass' : 'warning',
                        details: `${Math.round(fcp.startTime)}ms`
                    });
                }
            }

        } catch (error) {
            results.status = 'warning';
            results.issues.push(`Performance test failed: ${error.message}`);
        }

        return results;
    }

    /**
     * Display test results
     */
    displayResults() {
        console.group('🔍 PWA Test Results');
        
        for (const [category, result] of Object.entries(this.testResults)) {
            console.group(`${this.getStatusIcon(result.status)} ${category.toUpperCase()}`);
            
            if (result.tests) {
                result.tests.forEach(test => {
                    console.log(`${this.getStatusIcon(test.status)} ${test.name}${test.details ? ` - ${test.details}` : ''}`);
                });
            }
            
            if (result.issues && result.issues.length > 0) {
                console.warn('Issues:', result.issues);
            }
            
            console.groupEnd();
        }
        
        console.groupEnd();

        // Create visual results in development
        if (this.isDevelopment()) {
            this.createResultsUI();
        }
    }

    /**
     * Get status icon for console output
     */
    getStatusIcon(status) {
        const icons = {
            pass: '✅',
            fail: '❌',
            warning: '⚠️'
        };
        return icons[status] || '❓';
    }

    /**
     * Check if in development environment
     */
    isDevelopment() {
        return window.location.hostname === 'localhost' || 
               window.location.hostname === '127.0.0.1' ||
               window.location.hostname.includes('dev');
    }

    /**
     * Create visual results UI
     */
    createResultsUI() {
        const existingResults = document.getElementById('pwa-test-results');
        if (existingResults) {
            existingResults.remove();
        }

        const resultsContainer = document.createElement('div');
        resultsContainer.id = 'pwa-test-results';
        resultsContainer.innerHTML = `
            <div class="pwa-results-header">
                <h3>🚀 PWA Test Results</h3>
                <button id="close-pwa-results">×</button>
            </div>
            <div class="pwa-results-content">
                ${this.renderResultsHTML()}
            </div>
        `;

        // Add styles
        this.addResultsStyles();
        
        document.body.appendChild(resultsContainer);

        // Bind close button
        document.getElementById('close-pwa-results').addEventListener('click', () => {
            resultsContainer.remove();
        });
    }

    /**
     * Render results as HTML
     */
    renderResultsHTML() {
        let html = '';
        
        for (const [category, result] of Object.entries(this.testResults)) {
            html += `
                <div class="pwa-test-category">
                    <h4>
                        ${this.getStatusIcon(result.status)} ${category.charAt(0).toUpperCase() + category.slice(1)}
                        <span class="pwa-status ${result.status}">${result.status.toUpperCase()}</span>
                    </h4>
                    ${result.tests ? result.tests.map(test => `
                        <div class="pwa-test-item">
                            ${this.getStatusIcon(test.status)} ${test.name}
                            ${test.details ? `<span class="pwa-test-details">${test.details}</span>` : ''}
                        </div>
                    `).join('') : ''}
                    ${result.issues && result.issues.length > 0 ? `
                        <div class="pwa-test-issues">
                            <strong>Issues:</strong>
                            <ul>${result.issues.map(issue => `<li>${issue}</li>`).join('')}</ul>
                        </div>
                    ` : ''}
                </div>
            `;
        }

        return html;
    }

    /**
     * Add CSS styles for results UI
     */
    addResultsStyles() {
        if (document.getElementById('pwa-test-styles')) return;

        const styles = document.createElement('style');
        styles.id = 'pwa-test-styles';
        styles.textContent = `
            #pwa-test-results {
                position: fixed;
                top: 20px;
                right: 20px;
                width: 400px;
                max-height: 80vh;
                background: white;
                border: 1px solid #ddd;
                border-radius: 8px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.1);
                z-index: 10001;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                font-size: 14px;
                overflow: hidden;
            }
            
            .pwa-results-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 15px;
                background: #f8f9fa;
                border-bottom: 1px solid #ddd;
            }
            
            .pwa-results-header h3 {
                margin: 0;
                font-size: 16px;
            }
            
            #close-pwa-results {
                background: none;
                border: none;
                font-size: 20px;
                cursor: pointer;
                padding: 0;
                width: 24px;
                height: 24px;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            
            .pwa-results-content {
                padding: 15px;
                max-height: calc(80vh - 60px);
                overflow-y: auto;
            }
            
            .pwa-test-category {
                margin-bottom: 20px;
            }
            
            .pwa-test-category h4 {
                margin: 0 0 10px 0;
                font-size: 14px;
                font-weight: 600;
                display: flex;
                align-items: center;
                justify-content: space-between;
            }
            
            .pwa-status {
                font-size: 12px;
                padding: 2px 8px;
                border-radius: 12px;
                font-weight: 500;
            }
            
            .pwa-status.pass {
                background: #d4edda;
                color: #155724;
            }
            
            .pwa-status.fail {
                background: #f8d7da;
                color: #721c24;
            }
            
            .pwa-status.warning {
                background: #fff3cd;
                color: #856404;
            }
            
            .pwa-test-item {
                margin-bottom: 8px;
                font-size: 13px;
                display: flex;
                align-items: center;
                justify-content: space-between;
            }
            
            .pwa-test-details {
                font-size: 11px;
                color: #666;
                font-style: italic;
            }
            
            .pwa-test-issues {
                margin-top: 10px;
                padding: 8px;
                background: #fff3cd;
                border-radius: 4px;
                font-size: 12px;
            }
            
            .pwa-test-issues ul {
                margin: 4px 0 0 0;
                padding-left: 16px;
            }
            
            .pwa-test-issues li {
                margin-bottom: 2px;
            }
        `;
        
        document.head.appendChild(styles);
    }
}

// Initialize PWA testing when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    // Only run in development or when explicitly requested
    if (window.location.search.includes('pwa-test') || 
        window.location.hostname === 'localhost' || 
        window.location.hostname === '127.0.0.1') {
        
        setTimeout(() => {
            window.pwaTestSuite = new PWATestSuite();
        }, 2000); // Wait for app to initialize
    }
});
