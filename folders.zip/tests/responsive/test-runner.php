<?php
/**
 * Time2Eat Responsive Testing Runner
 * Main entry point for running all responsive and cross-browser tests
 */

declare(strict_types=1);

require_once __DIR__ . '/ResponsiveTestSuite.php';

class TestRunner
{
    private ResponsiveTestSuite $testSuite;
    private array $testResults = [];
    private string $outputFormat = 'html';
    
    public function __construct(string $outputFormat = 'html')
    {
        $this->testSuite = new ResponsiveTestSuite();
        $this->outputFormat = $outputFormat;
    }
    
    /**
     * Run all tests and generate report
     */
    public function runAllTests(): array
    {
        echo $this->outputFormat === 'html' ? "<h1>🧪 Time2Eat Responsive Testing Suite</h1>\n" : "Time2Eat Responsive Testing Suite\n";
        echo $this->outputFormat === 'html' ? "<p>Running comprehensive responsive and cross-browser tests...</p>\n" : "Running comprehensive tests...\n";
        
        // Run PHP-based tests
        $this->testResults = $this->testSuite->runAllTests();
        
        // Generate comprehensive report
        $this->generateReport();
        
        return $this->testResults;
    }
    
    /**
     * Generate comprehensive test report
     */
    private function generateReport(): void
    {
        if ($this->outputFormat === 'html') {
            $this->generateHTMLReport();
        } else {
            $this->generateTextReport();
        }
    }
    
    /**
     * Generate HTML report
     */
    private function generateHTMLReport(): void
    {
        echo $this->getHTMLStyles();
        echo "<div class='test-report'>\n";
        
        // Summary
        $this->generateSummary();
        
        // Device test results
        echo "<h2>📱 Device Testing Results</h2>\n";
        foreach ($this->testResults as $deviceKey => $result) {
            if ($deviceKey === 'cross_browser' || $deviceKey === 'pwa' || $deviceKey === 'accessibility') {
                continue;
            }
            
            $this->renderDeviceResults($deviceKey, $result);
        }
        
        // Cross-browser results
        if (isset($this->testResults['cross_browser'])) {
            echo "<h2>🌐 Cross-Browser Testing Results</h2>\n";
            $this->renderCrossBrowserResults($this->testResults['cross_browser']);
        }
        
        // PWA results
        if (isset($this->testResults['pwa'])) {
            echo "<h2>🚀 PWA Testing Results</h2>\n";
            $this->renderPWAResults($this->testResults['pwa']);
        }
        
        // Accessibility results
        if (isset($this->testResults['accessibility'])) {
            echo "<h2>♿ Accessibility Testing Results</h2>\n";
            $this->renderAccessibilityResults($this->testResults['accessibility']);
        }
        
        // Recommendations
        $this->generateRecommendations();
        
        echo "</div>\n";
        
        // Add JavaScript for interactive features
        echo $this->getJavaScriptEnhancements();
    }
    
    /**
     * Generate test summary
     */
    private function generateSummary(): void
    {
        $totalTests = 0;
        $passedTests = 0;
        $failedTests = 0;
        $warningTests = 0;
        
        foreach ($this->testResults as $result) {
            if (isset($result['tests'])) {
                foreach ($result['tests'] as $test) {
                    $totalTests++;
                    switch ($test['status']) {
                        case 'pass':
                            $passedTests++;
                            break;
                        case 'fail':
                            $failedTests++;
                            break;
                        case 'warning':
                            $warningTests++;
                            break;
                    }
                }
            }
        }
        
        $passRate = $totalTests > 0 ? round(($passedTests / $totalTests) * 100, 1) : 0;
        
        echo "<div class='summary-card'>\n";
        echo "<h2>📊 Test Summary</h2>\n";
        echo "<div class='summary-stats'>\n";
        echo "<div class='stat-item'><span class='stat-number'>{$totalTests}</span><span class='stat-label'>Total Tests</span></div>\n";
        echo "<div class='stat-item pass'><span class='stat-number'>{$passedTests}</span><span class='stat-label'>Passed</span></div>\n";
        echo "<div class='stat-item fail'><span class='stat-number'>{$failedTests}</span><span class='stat-label'>Failed</span></div>\n";
        echo "<div class='stat-item warning'><span class='stat-number'>{$warningTests}</span><span class='stat-label'>Warnings</span></div>\n";
        echo "<div class='stat-item'><span class='stat-number'>{$passRate}%</span><span class='stat-label'>Pass Rate</span></div>\n";
        echo "</div>\n";
        echo "</div>\n";
    }
    
    /**
     * Render device test results
     */
    private function renderDeviceResults(string $deviceKey, array $result): void
    {
        $device = $result['device'] ?? $deviceKey;
        $viewport = $result['viewport'] ?? 'Unknown';
        
        echo "<div class='device-result'>\n";
        echo "<h3>📱 {$device} ({$viewport})</h3>\n";
        
        if (isset($result['tests'])) {
            foreach ($result['tests'] as $testType => $testResult) {
                $this->renderTestResult($testType, $testResult);
            }
        }
        
        echo "</div>\n";
    }
    
    /**
     * Render individual test result
     */
    private function renderTestResult(string $testName, array $testResult): void
    {
        $status = $testResult['status'] ?? 'unknown';
        $statusClass = strtolower($status);
        $statusIcon = $this->getStatusIcon($status);
        
        echo "<div class='test-result {$statusClass}'>\n";
        echo "<div class='test-header'>\n";
        echo "<span class='test-icon'>{$statusIcon}</span>\n";
        echo "<span class='test-name'>" . ucfirst(str_replace('_', ' ', $testName)) . "</span>\n";
        echo "<span class='test-status'>{$status}</span>\n";
        echo "</div>\n";
        
        if (!empty($testResult['issues'])) {
            echo "<div class='test-issues'>\n";
            echo "<strong>Issues:</strong>\n";
            echo "<ul>\n";
            foreach ($testResult['issues'] as $issue) {
                echo "<li>" . htmlspecialchars($issue) . "</li>\n";
            }
            echo "</ul>\n";
            echo "</div>\n";
        }
        
        echo "</div>\n";
    }
    
    /**
     * Render cross-browser results
     */
    private function renderCrossBrowserResults(array $results): void
    {
        if (isset($results['browsers'])) {
            foreach ($results['browsers'] as $browserKey => $browserResult) {
                $this->renderBrowserResult($browserKey, $browserResult);
            }
        }
    }
    
    /**
     * Render browser test result
     */
    private function renderBrowserResult(string $browserKey, array $result): void
    {
        $browserName = $result['name'] ?? ucfirst($browserKey);
        $status = $result['status'] ?? 'unknown';
        $statusIcon = $this->getStatusIcon($status);
        
        echo "<div class='browser-result {$status}'>\n";
        echo "<h4>{$statusIcon} {$browserName}</h4>\n";
        
        if (!empty($result['issues'])) {
            echo "<div class='browser-issues'>\n";
            echo "<ul>\n";
            foreach ($result['issues'] as $issue) {
                echo "<li>" . htmlspecialchars($issue) . "</li>\n";
            }
            echo "</ul>\n";
            echo "</div>\n";
        }
        
        echo "</div>\n";
    }
    
    /**
     * Render PWA results
     */
    private function renderPWAResults(array $results): void
    {
        if (isset($results['tests'])) {
            foreach ($results['tests'] as $testName => $testResult) {
                $this->renderTestResult($testName, $testResult);
            }
        }
    }
    
    /**
     * Render accessibility results
     */
    private function renderAccessibilityResults(array $results): void
    {
        if (isset($results['tests'])) {
            foreach ($results['tests'] as $testName => $testResult) {
                $this->renderTestResult($testName, $testResult);
            }
        }
    }
    
    /**
     * Generate recommendations
     */
    private function generateRecommendations(): void
    {
        echo "<div class='recommendations'>\n";
        echo "<h2>💡 Recommendations</h2>\n";
        
        $recommendations = $this->analyzeResultsForRecommendations();
        
        if (empty($recommendations)) {
            echo "<p class='no-recommendations'>✅ Great job! No major issues found.</p>\n";
        } else {
            echo "<ul class='recommendation-list'>\n";
            foreach ($recommendations as $recommendation) {
                echo "<li>" . htmlspecialchars($recommendation) . "</li>\n";
            }
            echo "</ul>\n";
        }
        
        echo "</div>\n";
    }
    
    /**
     * Analyze results and generate recommendations
     */
    private function analyzeResultsForRecommendations(): array
    {
        $recommendations = [];
        
        // Analyze device test results
        foreach ($this->testResults as $deviceKey => $result) {
            if (in_array($deviceKey, ['cross_browser', 'pwa', 'accessibility'])) {
                continue;
            }
            
            if (isset($result['tests'])) {
                foreach ($result['tests'] as $testType => $testResult) {
                    if ($testResult['status'] === 'fail') {
                        switch ($testType) {
                            case 'layout':
                                $recommendations[] = "Fix layout issues on {$result['device']} - check Tailwind breakpoints";
                                break;
                            case 'touch':
                                $recommendations[] = "Improve touch interactions on {$result['device']} - ensure 44px minimum touch targets";
                                break;
                            case 'typography':
                                $recommendations[] = "Optimize typography for {$result['device']} - increase font sizes for mobile";
                                break;
                            case 'images':
                                $recommendations[] = "Optimize images for {$result['device']} - implement responsive images and lazy loading";
                                break;
                            case 'navigation':
                                $recommendations[] = "Fix navigation issues on {$result['device']} - ensure mobile menu works properly";
                                break;
                        }
                    }
                }
            }
        }
        
        // Remove duplicates
        return array_unique($recommendations);
    }
    
    /**
     * Get status icon
     */
    private function getStatusIcon(string $status): string
    {
        $icons = [
            'pass' => '✅',
            'fail' => '❌',
            'warning' => '⚠️',
            'unknown' => '❓'
        ];
        
        return $icons[$status] ?? $icons['unknown'];
    }
    
    /**
     * Generate text report
     */
    private function generateTextReport(): void
    {
        echo "\n" . str_repeat('=', 60) . "\n";
        echo "RESPONSIVE TESTING REPORT\n";
        echo str_repeat('=', 60) . "\n\n";
        
        foreach ($this->testResults as $deviceKey => $result) {
            echo "Device: " . ($result['device'] ?? $deviceKey) . "\n";
            echo "Viewport: " . ($result['viewport'] ?? 'Unknown') . "\n";
            echo str_repeat('-', 40) . "\n";
            
            if (isset($result['tests'])) {
                foreach ($result['tests'] as $testType => $testResult) {
                    $status = strtoupper($testResult['status'] ?? 'UNKNOWN');
                    echo sprintf("%-20s: %s\n", ucfirst($testType), $status);
                    
                    if (!empty($testResult['issues'])) {
                        foreach ($testResult['issues'] as $issue) {
                            echo "  - " . $issue . "\n";
                        }
                    }
                }
            }
            
            echo "\n";
        }
    }
    
    /**
     * Get HTML styles
     */
    private function getHTMLStyles(): string
    {
        return "
        <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 20px; background: #f5f5f5; }
            .test-report { max-width: 1200px; margin: 0 auto; }
            h1 { color: #333; text-align: center; margin-bottom: 30px; }
            h2 { color: #444; border-bottom: 2px solid #007bff; padding-bottom: 10px; }
            .summary-card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin-bottom: 30px; }
            .summary-stats { display: flex; justify-content: space-around; flex-wrap: wrap; }
            .stat-item { text-align: center; margin: 10px; }
            .stat-number { display: block; font-size: 2em; font-weight: bold; }
            .stat-label { display: block; font-size: 0.9em; color: #666; }
            .stat-item.pass .stat-number { color: #28a745; }
            .stat-item.fail .stat-number { color: #dc3545; }
            .stat-item.warning .stat-number { color: #ffc107; }
            .device-result, .browser-result { background: white; margin: 20px 0; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .test-result { margin: 10px 0; padding: 15px; border-radius: 6px; border-left: 4px solid #ddd; }
            .test-result.pass { background: #d4edda; border-left-color: #28a745; }
            .test-result.fail { background: #f8d7da; border-left-color: #dc3545; }
            .test-result.warning { background: #fff3cd; border-left-color: #ffc107; }
            .test-header { display: flex; align-items: center; justify-content: space-between; }
            .test-name { font-weight: 600; }
            .test-status { font-size: 0.8em; padding: 2px 8px; border-radius: 12px; background: rgba(0,0,0,0.1); }
            .test-issues { margin-top: 10px; font-size: 0.9em; }
            .test-issues ul { margin: 5px 0; padding-left: 20px; }
            .recommendations { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin-top: 30px; }
            .recommendation-list li { margin: 8px 0; }
            .no-recommendations { color: #28a745; font-weight: 500; }
            @media (max-width: 768px) {
                .summary-stats { flex-direction: column; }
                .test-header { flex-direction: column; align-items: flex-start; }
            }
        </style>
        ";
    }
    
    /**
     * Get JavaScript enhancements
     */
    private function getJavaScriptEnhancements(): string
    {
        return "
        <script>
            // Add interactive features
            document.addEventListener('DOMContentLoaded', function() {
                // Add expand/collapse functionality
                const testResults = document.querySelectorAll('.test-result');
                testResults.forEach(result => {
                    const header = result.querySelector('.test-header');
                    const issues = result.querySelector('.test-issues');
                    
                    if (issues) {
                        header.style.cursor = 'pointer';
                        header.addEventListener('click', () => {
                            issues.style.display = issues.style.display === 'none' ? 'block' : 'none';
                        });
                    }
                });
                
                // Add filter functionality
                const filterButtons = document.createElement('div');
                filterButtons.className = 'filter-buttons';
                filterButtons.innerHTML = `
                    <button onclick='filterResults(\"all\")'>All</button>
                    <button onclick='filterResults(\"pass\")'>Passed</button>
                    <button onclick='filterResults(\"fail\")'>Failed</button>
                    <button onclick='filterResults(\"warning\")'>Warnings</button>
                `;
                
                const report = document.querySelector('.test-report');
                if (report) {
                    report.insertBefore(filterButtons, report.firstChild);
                }
            });
            
            function filterResults(status) {
                const results = document.querySelectorAll('.test-result');
                results.forEach(result => {
                    if (status === 'all' || result.classList.contains(status)) {
                        result.style.display = 'block';
                    } else {
                        result.style.display = 'none';
                    }
                });
            }
        </script>
        ";
    }
}

// Run tests if called directly
if (basename(__FILE__) === basename($_SERVER['SCRIPT_NAME'])) {
    $outputFormat = $_GET['format'] ?? 'html';
    $runner = new TestRunner($outputFormat);
    
    if ($outputFormat === 'html') {
        header('Content-Type: text/html; charset=utf-8');
        echo "<!DOCTYPE html><html><head><title>Time2Eat Responsive Test Results</title></head><body>";
    } else {
        header('Content-Type: text/plain; charset=utf-8');
    }
    
    $results = $runner->runAllTests();
    
    if ($outputFormat === 'html') {
        echo "</body></html>";
    }
    
    // Save results to file
    $timestamp = date('Y-m-d_H-i-s');
    $filename = __DIR__ . "/test-results-{$timestamp}.json";
    file_put_contents($filename, json_encode($results, JSON_PRETTY_PRINT));
    
    if ($outputFormat === 'html') {
        echo "<script>console.log('Test results saved to: {$filename}');</script>";
    } else {
        echo "\nTest results saved to: {$filename}\n";
    }
}
