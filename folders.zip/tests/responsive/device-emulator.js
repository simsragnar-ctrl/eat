/**
 * Time2Eat Device Emulator
 * JavaScript tool for testing responsive design across different devices
 */

class DeviceEmulator {
    constructor() {
        this.currentDevice = null;
        this.testResults = [];
        this.deviceProfiles = this.initializeDeviceProfiles();
        this.testSuite = new ResponsiveTestRunner();
        this.init();
    }

    /**
     * Initialize device profiles
     */
    initializeDeviceProfiles() {
        return {
            // Mobile Devices
            'iphone_se': {
                name: 'iPhone SE',
                width: 375,
                height: 667,
                pixelRatio: 2,
                userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1',
                touch: true,
                category: 'mobile'
            },
            'iphone_12': {
                name: 'iPhone 12',
                width: 390,
                height: 844,
                pixelRatio: 3,
                userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1',
                touch: true,
                category: 'mobile'
            },
            'samsung_galaxy_s21': {
                name: 'Samsung Galaxy S21',
                width: 384,
                height: 854,
                pixelRatio: 2.75,
                userAgent: 'Mozilla/5.0 (Linux; Android 11; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36',
                touch: true,
                category: 'mobile'
            },
            'pixel_5': {
                name: 'Google Pixel 5',
                width: 393,
                height: 851,
                pixelRatio: 2.75,
                userAgent: 'Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36',
                touch: true,
                category: 'mobile'
            },
            
            // Tablets
            'ipad': {
                name: 'iPad',
                width: 768,
                height: 1024,
                pixelRatio: 2,
                userAgent: 'Mozilla/5.0 (iPad; CPU OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1',
                touch: true,
                category: 'tablet'
            },
            'ipad_pro': {
                name: 'iPad Pro',
                width: 1024,
                height: 1366,
                pixelRatio: 2,
                userAgent: 'Mozilla/5.0 (iPad; CPU OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1',
                touch: true,
                category: 'tablet'
            },
            
            // Desktop
            'desktop_small': {
                name: 'Small Desktop',
                width: 1024,
                height: 768,
                pixelRatio: 1,
                userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Safari/537.36',
                touch: false,
                category: 'desktop'
            },
            'desktop_large': {
                name: 'Large Desktop',
                width: 1920,
                height: 1080,
                pixelRatio: 1,
                userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Safari/537.36',
                touch: false,
                category: 'desktop'
            },
            
            // Edge Cases
            'very_small': {
                name: 'Very Small Screen (320px)',
                width: 320,
                height: 568,
                pixelRatio: 2,
                userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1',
                touch: true,
                category: 'mobile'
            }
        };
    }

    /**
     * Initialize the emulator
     */
    init() {
        this.createEmulatorUI();
        this.bindEvents();
        this.loadDefaultDevice();
    }

    /**
     * Create emulator UI
     */
    createEmulatorUI() {
        // Create emulator container
        const emulatorContainer = document.createElement('div');
        emulatorContainer.id = 'device-emulator';
        emulatorContainer.innerHTML = `
            <div class="emulator-controls">
                <div class="device-selector">
                    <label for="device-select">Device:</label>
                    <select id="device-select">
                        ${Object.entries(this.deviceProfiles).map(([key, device]) => 
                            `<option value="${key}">${device.name} (${device.width}x${device.height})</option>`
                        ).join('')}
                    </select>
                </div>
                <div class="emulator-actions">
                    <button id="rotate-device" title="Rotate Device">🔄</button>
                    <button id="test-device" title="Run Tests">🧪</button>
                    <button id="screenshot" title="Take Screenshot">📷</button>
                    <button id="toggle-touch" title="Toggle Touch Mode">👆</button>
                </div>
                <div class="viewport-info">
                    <span id="viewport-size">-</span>
                    <span id="pixel-ratio">-</span>
                </div>
            </div>
            <div class="emulator-frame">
                <div id="device-frame" class="device-frame">
                    <iframe id="device-viewport" src="${window.location.href}" frameborder="0"></iframe>
                </div>
            </div>
            <div class="test-results" id="test-results" style="display: none;">
                <h3>Test Results</h3>
                <div id="results-content"></div>
            </div>
        `;

        // Add styles
        const styles = `
            <style>
                #device-emulator {
                    position: fixed;
                    top: 0;
                    right: 0;
                    width: 400px;
                    height: 100vh;
                    background: #f5f5f5;
                    border-left: 1px solid #ddd;
                    z-index: 10000;
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    font-size: 14px;
                }
                
                .emulator-controls {
                    padding: 15px;
                    background: white;
                    border-bottom: 1px solid #ddd;
                }
                
                .device-selector {
                    margin-bottom: 10px;
                }
                
                .device-selector label {
                    display: block;
                    margin-bottom: 5px;
                    font-weight: 500;
                }
                
                .device-selector select {
                    width: 100%;
                    padding: 8px;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                }
                
                .emulator-actions {
                    display: flex;
                    gap: 10px;
                    margin-bottom: 10px;
                }
                
                .emulator-actions button {
                    padding: 8px 12px;
                    border: 1px solid #ddd;
                    background: white;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 16px;
                }
                
                .emulator-actions button:hover {
                    background: #f0f0f0;
                }
                
                .viewport-info {
                    display: flex;
                    justify-content: space-between;
                    font-size: 12px;
                    color: #666;
                }
                
                .emulator-frame {
                    flex: 1;
                    padding: 20px;
                    display: flex;
                    justify-content: center;
                    align-items: flex-start;
                    overflow: auto;
                }
                
                .device-frame {
                    border: 8px solid #333;
                    border-radius: 20px;
                    background: #333;
                    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
                    transition: all 0.3s ease;
                }
                
                .device-frame.mobile {
                    border-radius: 25px;
                }
                
                .device-frame.tablet {
                    border-radius: 15px;
                }
                
                .device-frame.desktop {
                    border-radius: 8px;
                    border-width: 4px;
                }
                
                #device-viewport {
                    width: 100%;
                    height: 100%;
                    border-radius: 12px;
                    background: white;
                }
                
                .test-results {
                    max-height: 300px;
                    overflow-y: auto;
                    padding: 15px;
                    background: white;
                    border-top: 1px solid #ddd;
                }
                
                .test-result {
                    margin-bottom: 10px;
                    padding: 8px;
                    border-radius: 4px;
                }
                
                .test-result.pass {
                    background: #d4edda;
                    color: #155724;
                }
                
                .test-result.fail {
                    background: #f8d7da;
                    color: #721c24;
                }
                
                .test-result.warning {
                    background: #fff3cd;
                    color: #856404;
                }
            </style>
        `;

        document.head.insertAdjacentHTML('beforeend', styles);
        document.body.appendChild(emulatorContainer);
    }

    /**
     * Bind event listeners
     */
    bindEvents() {
        const deviceSelect = document.getElementById('device-select');
        const rotateBtn = document.getElementById('rotate-device');
        const testBtn = document.getElementById('test-device');
        const screenshotBtn = document.getElementById('screenshot');
        const touchBtn = document.getElementById('toggle-touch');

        deviceSelect.addEventListener('change', (e) => {
            this.switchDevice(e.target.value);
        });

        rotateBtn.addEventListener('click', () => {
            this.rotateDevice();
        });

        testBtn.addEventListener('click', () => {
            this.runTests();
        });

        screenshotBtn.addEventListener('click', () => {
            this.takeScreenshot();
        });

        touchBtn.addEventListener('click', () => {
            this.toggleTouchMode();
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey || e.metaKey) {
                switch (e.key) {
                    case 'r':
                        e.preventDefault();
                        this.rotateDevice();
                        break;
                    case 't':
                        e.preventDefault();
                        this.runTests();
                        break;
                }
            }
        });
    }

    /**
     * Load default device
     */
    loadDefaultDevice() {
        this.switchDevice('iphone_12');
    }

    /**
     * Switch to different device
     */
    switchDevice(deviceKey) {
        const device = this.deviceProfiles[deviceKey];
        if (!device) return;

        this.currentDevice = device;
        
        const frame = document.getElementById('device-frame');
        const viewport = document.getElementById('device-viewport');
        const viewportSize = document.getElementById('viewport-size');
        const pixelRatio = document.getElementById('pixel-ratio');

        // Update frame appearance
        frame.className = `device-frame ${device.category}`;
        
        // Update viewport size
        viewport.style.width = `${device.width}px`;
        viewport.style.height = `${device.height}px`;
        
        // Update frame size (add padding for device chrome)
        frame.style.width = `${device.width}px`;
        frame.style.height = `${device.height}px`;

        // Update info display
        viewportSize.textContent = `${device.width}×${device.height}`;
        pixelRatio.textContent = `${device.pixelRatio}x`;

        // Simulate device characteristics
        this.simulateDevice(device);
    }

    /**
     * Simulate device characteristics
     */
    simulateDevice(device) {
        const viewport = document.getElementById('device-viewport');
        
        // Update user agent (limited in iframe)
        try {
            viewport.contentWindow.navigator.__defineGetter__('userAgent', () => device.userAgent);
        } catch (e) {
            console.warn('Cannot override user agent in iframe');
        }

        // Simulate pixel ratio
        try {
            viewport.contentWindow.devicePixelRatio = device.pixelRatio;
        } catch (e) {
            console.warn('Cannot override device pixel ratio');
        }

        // Add touch simulation for touch devices
        if (device.touch) {
            this.enableTouchSimulation(viewport);
        }
    }

    /**
     * Enable touch simulation
     */
    enableTouchSimulation(viewport) {
        try {
            const doc = viewport.contentDocument;
            if (!doc) return;

            // Add touch event simulation
            doc.addEventListener('mousedown', (e) => {
                const touchEvent = new TouchEvent('touchstart', {
                    touches: [{
                        clientX: e.clientX,
                        clientY: e.clientY,
                        target: e.target
                    }]
                });
                e.target.dispatchEvent(touchEvent);
            });

            doc.addEventListener('mousemove', (e) => {
                if (e.buttons === 1) {
                    const touchEvent = new TouchEvent('touchmove', {
                        touches: [{
                            clientX: e.clientX,
                            clientY: e.clientY,
                            target: e.target
                        }]
                    });
                    e.target.dispatchEvent(touchEvent);
                }
            });

            doc.addEventListener('mouseup', (e) => {
                const touchEvent = new TouchEvent('touchend', {
                    touches: []
                });
                e.target.dispatchEvent(touchEvent);
            });
        } catch (e) {
            console.warn('Cannot enable touch simulation:', e);
        }
    }

    /**
     * Rotate device
     */
    rotateDevice() {
        if (!this.currentDevice) return;

        const temp = this.currentDevice.width;
        this.currentDevice.width = this.currentDevice.height;
        this.currentDevice.height = temp;

        this.switchDevice(Object.keys(this.deviceProfiles).find(key => 
            this.deviceProfiles[key] === this.currentDevice
        ));
    }

    /**
     * Run responsive tests
     */
    async runTests() {
        if (!this.currentDevice) return;

        const testResults = document.getElementById('test-results');
        const resultsContent = document.getElementById('results-content');
        
        testResults.style.display = 'block';
        resultsContent.innerHTML = '<div class="loading">Running tests...</div>';

        try {
            const results = await this.testSuite.runDeviceTests(this.currentDevice);
            this.displayTestResults(results);
        } catch (error) {
            resultsContent.innerHTML = `<div class="test-result fail">Error running tests: ${error.message}</div>`;
        }
    }

    /**
     * Display test results
     */
    displayTestResults(results) {
        const resultsContent = document.getElementById('results-content');
        let html = '';

        for (const [testName, result] of Object.entries(results)) {
            const status = result.status || 'unknown';
            html += `
                <div class="test-result ${status}">
                    <strong>${testName}</strong>: ${status.toUpperCase()}
                    ${result.issues && result.issues.length > 0 ? 
                        `<ul>${result.issues.map(issue => `<li>${issue}</li>`).join('')}</ul>` : 
                        ''
                    }
                </div>
            `;
        }

        resultsContent.innerHTML = html;
    }

    /**
     * Take screenshot
     */
    takeScreenshot() {
        const viewport = document.getElementById('device-viewport');
        
        // Use html2canvas if available
        if (window.html2canvas) {
            html2canvas(viewport).then(canvas => {
                const link = document.createElement('a');
                link.download = `screenshot-${this.currentDevice.name.replace(/\s+/g, '-')}-${Date.now()}.png`;
                link.href = canvas.toDataURL();
                link.click();
            });
        } else {
            alert('Screenshot functionality requires html2canvas library');
        }
    }

    /**
     * Toggle touch mode
     */
    toggleTouchMode() {
        const touchBtn = document.getElementById('toggle-touch');
        const frame = document.getElementById('device-frame');
        
        if (frame.classList.contains('touch-mode')) {
            frame.classList.remove('touch-mode');
            touchBtn.style.background = 'white';
        } else {
            frame.classList.add('touch-mode');
            touchBtn.style.background = '#007bff';
            touchBtn.style.color = 'white';
        }
    }
}

/**
 * Responsive Test Runner
 */
class ResponsiveTestRunner {
    constructor() {
        this.tests = [];
    }

    /**
     * Run tests for specific device
     */
    async runDeviceTests(device) {
        const results = {};

        // Test layout breakpoints
        results.layout = await this.testLayoutBreakpoints(device);
        
        // Test touch interactions (if touch device)
        if (device.touch) {
            results.touch = await this.testTouchInteractions(device);
        }

        // Test typography
        results.typography = await this.testTypography(device);

        // Test images
        results.images = await this.testImages(device);

        // Test navigation
        results.navigation = await this.testNavigation(device);

        return results;
    }

    /**
     * Test layout breakpoints
     */
    async testLayoutBreakpoints(device) {
        const issues = [];
        
        // Check if container is responsive
        const containers = document.querySelectorAll('.tw-container, .container');
        containers.forEach(container => {
            const styles = window.getComputedStyle(container);
            const maxWidth = parseInt(styles.maxWidth);
            
            if (device.width < 640 && maxWidth > device.width) {
                issues.push(`Container too wide for mobile: ${maxWidth}px > ${device.width}px`);
            }
        });

        // Check grid layouts
        const grids = document.querySelectorAll('[class*="tw-grid-cols"], [class*="grid-cols"]');
        grids.forEach(grid => {
            const styles = window.getComputedStyle(grid);
            const columns = styles.gridTemplateColumns.split(' ').length;
            
            if (device.width < 640 && columns > 1) {
                issues.push('Grid should be single column on mobile');
            }
        });

        return {
            status: issues.length === 0 ? 'pass' : 'fail',
            issues: issues
        };
    }

    /**
     * Test touch interactions
     */
    async testTouchInteractions(device) {
        const issues = [];
        
        // Check touch target sizes
        const touchTargets = document.querySelectorAll('button, a, input, [role="button"]');
        touchTargets.forEach(target => {
            const rect = target.getBoundingClientRect();
            if (rect.width < 44 || rect.height < 44) {
                issues.push(`Touch target too small: ${Math.round(rect.width)}x${Math.round(rect.height)}px`);
            }
        });

        return {
            status: issues.length === 0 ? 'pass' : 'fail',
            issues: issues
        };
    }

    /**
     * Test typography
     */
    async testTypography(device) {
        const issues = [];
        
        // Check font sizes
        const textElements = document.querySelectorAll('p, span, div, h1, h2, h3, h4, h5, h6');
        textElements.forEach(element => {
            const styles = window.getComputedStyle(element);
            const fontSize = parseInt(styles.fontSize);
            
            if (device.category === 'mobile' && fontSize < 14) {
                issues.push(`Font too small on mobile: ${fontSize}px`);
            }
        });

        return {
            status: issues.length === 0 ? 'pass' : 'fail',
            issues: issues
        };
    }

    /**
     * Test images
     */
    async testImages(device) {
        const issues = [];
        
        // Check image loading
        const images = document.querySelectorAll('img');
        images.forEach(img => {
            if (!img.complete || img.naturalHeight === 0) {
                issues.push(`Image failed to load: ${img.src}`);
            }
            
            // Check if image has alt text
            if (!img.alt) {
                issues.push(`Image missing alt text: ${img.src}`);
            }
        });

        return {
            status: issues.length === 0 ? 'pass' : 'fail',
            issues: issues
        };
    }

    /**
     * Test navigation
     */
    async testNavigation(device) {
        const issues = [];
        
        // Check mobile menu
        if (device.category === 'mobile') {
            const mobileMenu = document.querySelector('#mobile-menu, .mobile-menu');
            if (!mobileMenu) {
                issues.push('Mobile menu not found');
            }
        }

        // Check navigation accessibility
        const navLinks = document.querySelectorAll('nav a');
        navLinks.forEach(link => {
            if (!link.getAttribute('aria-label') && !link.textContent.trim()) {
                issues.push('Navigation link missing accessible text');
            }
        });

        return {
            status: issues.length === 0 ? 'pass' : 'fail',
            issues: issues
        };
    }
}

// Initialize device emulator when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    // Only initialize if not in iframe (to avoid recursive emulators)
    if (window.self === window.top) {
        window.deviceEmulator = new DeviceEmulator();
    }
});
