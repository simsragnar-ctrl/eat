<?php
/**
 * Real-time Tracking System Test
 * 
 * This script tests the real-time tracking functionality
 */

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../config/database.php';

use Time2Eat\Models\Delivery;
use Time2Eat\Models\Order;
use Time2Eat\Models\User;

class TrackingTest
{
    private Delivery $deliveryModel;
    private Order $orderModel;
    private User $userModel;

    public function __construct()
    {
        $this->deliveryModel = new Delivery();
        $this->orderModel = new Order();
        $this->userModel = new User();
    }

    public function runTests(): void
    {
        echo "===========================================\n";
        echo "Time2Eat Real-time Tracking System Test\n";
        echo "===========================================\n\n";

        $this->testDeliveryCreation();
        $this->testTrackingCodeGeneration();
        $this->testLocationUpdates();
        $this->testStatusUpdates();
        $this->testTrackingRetrieval();

        echo "\n===========================================\n";
        echo "All tests completed!\n";
        echo "===========================================\n";
    }

    private function testDeliveryCreation(): void
    {
        echo "Testing delivery creation...\n";

        $deliveryData = [
            'order_id' => 1,
            'rider_id' => 1,
            'pickup_location' => json_encode([
                'latitude' => 5.9631,
                'longitude' => 10.1591,
                'address' => 'Test Restaurant, Bamenda'
            ]),
            'delivery_location' => json_encode([
                'latitude' => 5.9700,
                'longitude' => 10.1500,
                'address' => 'Test Customer Address, Bamenda'
            ]),
            'delivery_fee' => 1000
        ];

        $deliveryId = $this->deliveryModel->createDelivery($deliveryData);

        if ($deliveryId) {
            echo "✓ Delivery created successfully (ID: {$deliveryId})\n";
            $this->testDeliveryId = $deliveryId;
        } else {
            echo "✗ Failed to create delivery\n";
        }
    }

    private function testTrackingCodeGeneration(): void
    {
        echo "Testing tracking code generation...\n";

        $trackingCode = $this->deliveryModel->generateTrackingCode();

        if (preg_match('/^TRK\d{8}\d{3}$/', $trackingCode)) {
            echo "✓ Tracking code generated successfully: {$trackingCode}\n";
        } else {
            echo "✗ Invalid tracking code format: {$trackingCode}\n";
        }

        // Test uniqueness
        $trackingCode2 = $this->deliveryModel->generateTrackingCode();
        if ($trackingCode !== $trackingCode2) {
            echo "✓ Tracking codes are unique\n";
        } else {
            echo "✗ Tracking codes are not unique\n";
        }
    }

    private function testLocationUpdates(): void
    {
        echo "Testing location updates...\n";

        if (!isset($this->testDeliveryId)) {
            echo "✗ No test delivery ID available\n";
            return;
        }

        $latitude = 5.9650;
        $longitude = 10.1550;

        $updated = $this->deliveryModel->updateRiderLocation($this->testDeliveryId, $latitude, $longitude);

        if ($updated) {
            echo "✓ Rider location updated successfully\n";

            // Verify location was saved
            $location = $this->deliveryModel->getRiderLocation($this->testDeliveryId);
            if ($location && $location['latitude'] == $latitude && $location['longitude'] == $longitude) {
                echo "✓ Location retrieved successfully\n";
            } else {
                echo "✗ Location retrieval failed\n";
            }
        } else {
            echo "✗ Failed to update rider location\n";
        }
    }

    private function testStatusUpdates(): void
    {
        echo "Testing status updates...\n";

        if (!isset($this->testDeliveryId)) {
            echo "✗ No test delivery ID available\n";
            return;
        }

        $statuses = ['picked_up', 'out_for_delivery', 'delivered'];

        foreach ($statuses as $status) {
            $updated = $this->deliveryModel->updateDeliveryStatus($this->testDeliveryId, $status);
            
            if ($updated) {
                echo "✓ Status updated to: {$status}\n";
            } else {
                echo "✗ Failed to update status to: {$status}\n";
            }

            // Small delay to ensure timestamps are different
            sleep(1);
        }
    }

    private function testTrackingRetrieval(): void
    {
        echo "Testing tracking data retrieval...\n";

        if (!isset($this->testDeliveryId)) {
            echo "✗ No test delivery ID available\n";
            return;
        }

        // Get delivery by ID
        $delivery = $this->deliveryModel->getById($this->testDeliveryId);

        if ($delivery) {
            echo "✓ Delivery retrieved by ID\n";

            // Test tracking by code
            if (!empty($delivery['tracking_code'])) {
                $deliveryByCode = $this->deliveryModel->getDeliveryByTrackingCode($delivery['tracking_code']);
                
                if ($deliveryByCode && $deliveryByCode['id'] == $this->testDeliveryId) {
                    echo "✓ Delivery retrieved by tracking code\n";
                } else {
                    echo "✗ Failed to retrieve delivery by tracking code\n";
                }
            } else {
                echo "✗ No tracking code found\n";
            }
        } else {
            echo "✗ Failed to retrieve delivery by ID\n";
        }
    }

    public function testWebSocketConnection(): void
    {
        echo "Testing WebSocket connection...\n";

        $host = 'localhost';
        $port = 8080;

        $socket = @fsockopen($host, $port, $errno, $errstr, 5);

        if ($socket) {
            echo "✓ WebSocket server is running on {$host}:{$port}\n";
            fclose($socket);
        } else {
            echo "✗ WebSocket server is not running on {$host}:{$port}\n";
            echo "   Error: {$errstr} ({$errno})\n";
            echo "   Start the server with: php scripts/websocket-server.php {$port}\n";
        }
    }

    public function testAPIEndpoints(): void
    {
        echo "Testing API endpoints...\n";

        $baseUrl = 'http://localhost';
        
        // Test public tracking endpoint
        $trackingCode = 'TRK24011200123'; // Example tracking code
        $url = "{$baseUrl}/api/tracking/code/{$trackingCode}";
        
        $response = @file_get_contents($url);
        
        if ($response !== false) {
            $data = json_decode($response, true);
            if (isset($data['success'])) {
                echo "✓ API endpoint accessible\n";
            } else {
                echo "✗ Invalid API response format\n";
            }
        } else {
            echo "✗ API endpoint not accessible\n";
            echo "   Make sure the web server is running\n";
        }
    }

    public function cleanup(): void
    {
        echo "Cleaning up test data...\n";

        if (isset($this->testDeliveryId)) {
            // In a real scenario, you might want to delete test data
            // For now, we'll just mark it as a test
            echo "✓ Test delivery ID: {$this->testDeliveryId}\n";
        }
    }
}

// Run the tests
$test = new TrackingTest();

try {
    $test->runTests();
    $test->testWebSocketConnection();
    $test->testAPIEndpoints();
    $test->cleanup();
} catch (Exception $e) {
    echo "Test failed with error: " . $e->getMessage() . "\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n";
}
