<?php

declare(strict_types=1);

/**
 * Application Bootstrap
 * Initialize the Time2Eat application with enhanced routing and error handling
 */

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Set error reporting
error_reporting(E_ALL);
ini_set('display_errors', '1');

// Set timezone
date_default_timezone_set('Africa/Douala');

// Define constants
define('ROOT_PATH', dirname(__DIR__));
define('APP_PATH', ROOT_PATH . '/src');
define('CONFIG_PATH', ROOT_PATH . '/config');
define('STORAGE_PATH', ROOT_PATH . '/storage');
define('PUBLIC_PATH', ROOT_PATH . '/public');

// Autoloader for classes
spl_autoload_register(function ($class) {
    // Convert namespace to file path
    $file = str_replace('\\', '/', $class) . '.php';
    
    // Try different base paths
    $paths = [
        APP_PATH . '/' . $file,
        ROOT_PATH . '/src/' . $file,
        ROOT_PATH . '/' . $file
    ];
    
    foreach ($paths as $path) {
        if (file_exists($path)) {
            require_once $path;
            return;
        }
    }
});

// Load configuration
$config = [];
if (file_exists(CONFIG_PATH . '/app.php')) {
    $config = require CONFIG_PATH . '/app.php';
}

// Set application environment
$environment = $config['environment'] ?? 'development';
define('APP_ENV', $environment);

// Error handling based on environment
if ($environment === 'production') {
    error_reporting(0);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
    ini_set('error_log', STORAGE_PATH . '/logs/error.log');
}

// Custom error handler
set_error_handler(function($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) {
        return false;
    }
    
    $errorMessage = "Error: {$message} in {$file} on line {$line}";
    error_log($errorMessage);
    
    if (APP_ENV === 'development') {
        echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; margin: 10px; border: 1px solid #f5c6cb; border-radius: 4px;'>";
        echo "<strong>Error:</strong> {$message}<br>";
        echo "<strong>File:</strong> {$file}<br>";
        echo "<strong>Line:</strong> {$line}";
        echo "</div>";
    }
    
    return true;
});

// Custom exception handler
set_exception_handler(function($exception) {
    $errorMessage = "Uncaught Exception: " . $exception->getMessage() . " in " . $exception->getFile() . " on line " . $exception->getLine();
    error_log($errorMessage);
    
    if (APP_ENV === 'development') {
        echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; margin: 10px; border: 1px solid #f5c6cb; border-radius: 4px;'>";
        echo "<h3>Uncaught Exception</h3>";
        echo "<strong>Message:</strong> " . $exception->getMessage() . "<br>";
        echo "<strong>File:</strong> " . $exception->getFile() . "<br>";
        echo "<strong>Line:</strong> " . $exception->getLine() . "<br>";
        echo "<strong>Stack Trace:</strong><pre>" . $exception->getTraceAsString() . "</pre>";
        echo "</div>";
    } else {
        http_response_code(500);
        echo "<h1>500 - Internal Server Error</h1>";
        echo "<p>Something went wrong. Please try again later.</p>";
    }
});

/**
 * Application Class
 * Main application container and router
 */
class Application
{
    private $router;
    private $config;
    private static $instance;
    
    public function __construct(array $config = [])
    {
        $this->config = $config;
        $this->initializeRouter();
        self::$instance = $this;
    }
    
    /**
     * Get application instance
     */
    public static function getInstance(): ?self
    {
        return self::$instance;
    }
    
    /**
     * Initialize router
     */
    private function initializeRouter(): void
    {
        // Use enhanced router if available, fallback to simple router
        if (class_exists('core\EnhancedRouter')) {
            $this->router = new core\EnhancedRouter($this->config('app.url', ''));
        } else {
            $this->router = new core\Router();
        }
    }
    
    /**
     * Load routes
     */
    public function loadRoutes(): void
    {
        $routeFiles = [
            ROOT_PATH . '/routes/web.php',
            ROOT_PATH . '/routes/api.php'
        ];
        
        foreach ($routeFiles as $routeFile) {
            if (file_exists($routeFile)) {
                $router = require $routeFile;
                if ($router instanceof core\EnhancedRouter) {
                    $this->router = $router;
                }
            }
        }
    }
    
    /**
     * Run the application
     */
    public function run(): void
    {
        try {
            $this->loadRoutes();
            
            $method = $_SERVER['REQUEST_METHOD'];
            $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
            
            // Remove trailing slash except for root
            if ($uri !== '/' && substr($uri, -1) === '/') {
                $uri = rtrim($uri, '/');
            }
            
            // Dispatch request
            if (method_exists($this->router, 'dispatch')) {
                $this->router->dispatch($method, $uri);
            } else {
                // Fallback for simple router
                $this->router->dispatch();
            }
            
        } catch (Exception $e) {
            $this->handleException($e);
        }
    }
    
    /**
     * Handle application exceptions
     */
    private function handleException(Exception $e): void
    {
        error_log("Application Exception: " . $e->getMessage());
        
        if (APP_ENV === 'development') {
            throw $e;
        }
        
        // Check if it's an API request
        $isApi = strpos($_SERVER['REQUEST_URI'] ?? '', '/api/') === 0 ||
                 (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false);
        
        if ($isApi) {
            header('Content-Type: application/json');
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'Internal server error',
                'code' => 500
            ]);
        } else {
            http_response_code(500);
            $this->renderErrorPage(500, 'Internal Server Error');
        }
    }
    
    /**
     * Render error page
     */
    private function renderErrorPage(int $code, string $message): void
    {
        $errorFile = APP_PATH . "/views/errors/{$code}.php";
        
        if (file_exists($errorFile)) {
            $title = "{$code} - {$message}";
            $error_code = $code;
            $error_message = $message;
            
            include $errorFile;
        } else {
            echo "<h1>{$code} - {$message}</h1>";
        }
    }
    
    /**
     * Get configuration value
     */
    public function config(string $key, $default = null)
    {
        $keys = explode('.', $key);
        $value = $this->config;
        
        foreach ($keys as $k) {
            if (!isset($value[$k])) {
                return $default;
            }
            $value = $value[$k];
        }
        
        return $value;
    }
    
    /**
     * Get router instance
     */
    public function getRouter()
    {
        return $this->router;
    }
}

/**
 * Helper Functions
 */

/**
 * Get application instance
 */
function app(): Application
{
    return Application::getInstance();
}

/**
 * Get configuration value
 */
function config(string $key, $default = null)
{
    return app()->config($key, $default);
}

/**
 * Generate URL for named route
 */
function route(string $name, array $parameters = []): string
{
    $router = app()->getRouter();
    
    if (method_exists($router, 'url')) {
        return $router->url($name, $parameters);
    }
    
    // Fallback for simple routing
    return '/' . ltrim($name, '/');
}

/**
 * Get asset URL
 */
function asset(string $path): string
{
    $baseUrl = config('app.url', '');
    return $baseUrl . '/' . ltrim($path, '/');
}

/**
 * Escape HTML
 */
function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

/**
 * Get old input value
 */
function old(string $key, $default = ''): string
{
    $oldInput = $_SESSION['old_input'] ?? [];
    return $oldInput[$key] ?? $default;
}

/**
 * Check if there are validation errors
 */
function hasErrors(): bool
{
    return !empty($_SESSION['errors']);
}

/**
 * Get validation errors
 */
function errors(): array
{
    $errors = $_SESSION['errors'] ?? [];
    unset($_SESSION['errors']);
    return $errors;
}

/**
 * Get flash messages
 */
function flash(): array
{
    $flash = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $flash;
}

/**
 * Generate CSRF token
 */
function csrf_token(): string
{
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Generate CSRF field
 */
function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . csrf_token() . '">';
}

// Create and return application instance
return new Application($config);
