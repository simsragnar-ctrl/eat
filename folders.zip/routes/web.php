<?php

declare(strict_types=1);

use core\EnhancedRouter;

/**
 * Web Routes for Time2Eat Application
 * Define all web routes with middleware and authentication
 */

$router = new EnhancedRouter();

// ============================================================================
// PUBLIC ROUTES (No Authentication Required)
// ============================================================================

// Home and Public Pages
$router->get('/', 'HomeController@index')->name('home');
$router->get('/about', 'HomeController@about')->name('about');
$router->get('/contact', 'HomeController@contact')->name('contact');
$router->post('/contact', 'HomeController@submitContact')->name('contact.submit');

// Browse and Search
$router->get('/browse', 'BrowseController@index')->name('browse');
$router->get('/browse/search', 'BrowseController@search')->name('browse.search');
$router->get('/browse/category/{slug}', 'BrowseController@category')->name('browse.category');
$router->get('/browse/restaurant/{id}', 'BrowseController@restaurant')->name('browse.restaurant');

// Search Routes
$router->get('/search', 'SearchController@index')->name('search.index');
$router->get('/search/suggestions', 'SearchController@suggestions')->name('search.suggestions');
$router->get('/search/live', 'SearchController@liveSearch')->name('search.live');

// Public Reviews
$router->get('/reviews', 'ReviewController@index')->name('reviews.index');

// Food Items
$router->get('/food/{id}', 'FoodController@show')->name('food.show');
$router->get('/menu/{restaurant_id}', 'FoodController@menu')->name('food.menu');

// Authentication Routes
$router->get('/login', 'AuthController@showLogin')->name('login');
$router->post('/login', 'AuthController@login')->name('login.submit');
$router->get('/register', 'AuthController@showRegister')->name('register');
$router->post('/register', 'AuthController@register')->name('register.submit');
$router->get('/forgot-password', 'AuthController@showForgotPassword')->name('password.request');
$router->post('/forgot-password', 'AuthController@forgotPassword')->name('password.email');
$router->get('/reset-password/{token}', 'AuthController@showResetPassword')->name('password.reset');
$router->post('/reset-password', 'AuthController@resetPassword')->name('password.update');

// Security Routes
$router->get('/captcha/generate', 'CaptchaController@generate')->name('captcha.generate');
$router->post('/captcha/validate', 'CaptchaController@validate')->name('captcha.validate');
$router->get('/captcha/image', 'CaptchaController@image')->name('captcha.image');
$router->get('/captcha/refresh', 'CaptchaController@refresh')->name('captcha.refresh');

// Email Verification
$router->get('/email/verify/{token}', 'AuthController@verifyEmail')->name('verification.verify');
$router->post('/email/resend', 'AuthController@resendVerification')->name('verification.resend');

// ============================================================================
// AUTHENTICATED ROUTES (Require Login)
// ============================================================================

$router->group(['middleware' => ['AuthMiddleware']], function($router) {
    
    // Logout
    $router->post('/logout', 'AuthController@logout')->name('logout');
    
    // User Profile
    $router->get('/profile', 'ProfileController@show')->name('profile');
    $router->get('/profile/edit', 'ProfileController@edit')->name('profile.edit');
    $router->put('/profile', 'ProfileController@update')->name('profile.update');
    $router->delete('/profile', 'ProfileController@destroy')->name('profile.delete');
    
    // Password Management
    $router->get('/profile/password', 'ProfileController@showChangePassword')->name('profile.password');
    $router->put('/profile/password', 'ProfileController@changePassword')->name('profile.password.update');
    
    // Cart and Checkout
    $router->get('/cart', 'CartController@index')->name('cart');
    $router->post('/cart/add', 'CartController@add')->name('cart.add');
    $router->put('/cart/update/{id}', 'CartController@update')->name('cart.update');
    $router->delete('/cart/remove/{id}', 'CartController@remove')->name('cart.remove');
    $router->delete('/cart/clear', 'CartController@clear')->name('cart.clear');
    
    // Checkout Process
    $router->get('/checkout', 'CheckoutController@index')->name('checkout');
    $router->post('/checkout/address', 'CheckoutController@setAddress')->name('checkout.address');
    $router->post('/checkout/payment', 'CheckoutController@setPayment')->name('checkout.payment');
    $router->post('/checkout/place-order', 'CheckoutController@placeOrder')->name('checkout.place');
    
    // Orders
    $router->get('/orders', 'OrderController@index')->name('orders');
    $router->get('/orders/{id}', 'OrderController@show')->name('orders.show');
    $router->post('/orders/{id}/cancel', 'OrderController@cancel')->name('orders.cancel');
    $router->post('/orders/{id}/rate', 'OrderController@rate')->name('orders.rate');

    // Reviews and Ratings
    $router->get('/reviews/create', 'ReviewController@create')->name('reviews.create');
    $router->post('/reviews/store', 'ReviewController@store')->name('reviews.store');
    $router->get('/reviews/edit/{id}', 'ReviewController@edit')->name('reviews.edit');
    $router->put('/reviews/update/{id}', 'ReviewController@update')->name('reviews.update');
    $router->delete('/reviews/delete/{id}', 'ReviewController@delete')->name('reviews.delete');
    $router->post('/reviews/{id}/helpful', 'ReviewController@markHelpful')->name('reviews.helpful');
    $router->post('/reviews/{id}/report', 'ReviewController@report')->name('reviews.report');

    // Order Cancellations and Refunds
    $router->get('/cancellations/create/{orderId}', 'CancellationController@create')->name('cancellations.create');
    $router->post('/cancellations/store', 'CancellationController@store')->name('cancellations.store');
    
    // Favorites
    $router->get('/favorites', 'FavoriteController@index')->name('favorites');
    $router->post('/favorites/add', 'FavoriteController@add')->name('favorites.add');
    $router->delete('/favorites/remove/{id}', 'FavoriteController@remove')->name('favorites.remove');
    
    // Addresses
    $router->get('/addresses', 'AddressController@index')->name('addresses');
    $router->get('/addresses/create', 'AddressController@create')->name('addresses.create');
    $router->post('/addresses', 'AddressController@store')->name('addresses.store');
    $router->get('/addresses/{id}/edit', 'AddressController@edit')->name('addresses.edit');
    $router->put('/addresses/{id}', 'AddressController@update')->name('addresses.update');
    $router->delete('/addresses/{id}', 'AddressController@destroy')->name('addresses.delete');
    
    // Notifications
    $router->get('/notifications', 'NotificationController@index')->name('notifications');
    $router->post('/notifications/{id}/read', 'NotificationController@markAsRead')->name('notifications.read');
    $router->post('/notifications/read-all', 'NotificationController@markAllAsRead')->name('notifications.read-all');
});

// ============================================================================
// CUSTOMER DASHBOARD ROUTES
// ============================================================================

$router->group(['prefix' => '/customer', 'middleware' => ['AuthMiddleware', 'RoleMiddleware:customer']], function($router) {

    // Customer Dashboard
    $router->get('/dashboard', 'CustomerDashboardController@index')->name('customer.dashboard');

    // Orders
    $router->get('/orders', 'CustomerDashboardController@orders')->name('customer.orders');

    // Favorites
    $router->get('/favorites', 'CustomerDashboardController@favorites')->name('customer.favorites');

    // Addresses
    $router->get('/addresses', 'CustomerDashboardController@addresses')->name('customer.addresses');
    $router->post('/addresses', 'CustomerDashboardController@addresses')->name('customer.addresses.action');

    // Payment Methods
    $router->get('/payments', 'CustomerDashboardController@payments')->name('customer.payments');
    $router->post('/payments', 'CustomerDashboardController@payments')->name('customer.payments.action');

    // Affiliate Program
    $router->get('/affiliates', 'CustomerDashboardController@affiliates')->name('customer.affiliates');

    // Profile
    $router->get('/profile', 'CustomerDashboardController@profile')->name('customer.profile');
    $router->post('/profile', 'CustomerDashboardController@profile')->name('customer.profile.update');
});

// ============================================================================
// VENDOR ROUTES (Restaurant Owners)
// ============================================================================

$router->group(['prefix' => '/vendor', 'middleware' => ['AuthMiddleware', 'RoleMiddleware:vendor']], function($router) {
    
    // Vendor Dashboard
    $router->get('/dashboard', 'VendorDashboardController@index')->name('vendor.dashboard');
    
    // Restaurant Management
    $router->get('/restaurant', 'Vendor\RestaurantController@show')->name('vendor.restaurant');
    $router->get('/restaurant/edit', 'Vendor\RestaurantController@edit')->name('vendor.restaurant.edit');
    $router->put('/restaurant', 'Vendor\RestaurantController@update')->name('vendor.restaurant.update');
    
    // Menu Management
    $router->resource('menu', 'Vendor\MenuController')->name('vendor.menu');
    $router->post('/menu/{id}/toggle-status', 'Vendor\MenuController@toggleStatus')->name('vendor.menu.toggle');
    
    // Categories
    $router->resource('categories', 'Vendor\CategoryController')->name('vendor.categories');
    
    // Orders Management
    $router->get('/orders', 'VendorDashboardController@orders')->name('vendor.orders');
    $router->post('/orders/status', 'VendorDashboardController@updateOrderStatus')->name('vendor.orders.status');
    $router->get('/orders/{id}', 'Vendor\OrderController@show')->name('vendor.orders.show');
    $router->post('/orders/{id}/accept', 'Vendor\OrderController@accept')->name('vendor.orders.accept');
    $router->post('/orders/{id}/reject', 'Vendor\OrderController@reject')->name('vendor.orders.reject');
    $router->post('/orders/{id}/ready', 'Vendor\OrderController@ready')->name('vendor.orders.ready');

    // Restaurant Management
    $router->get('/profile', 'VendorDashboardController@profile')->name('vendor.profile');
    $router->post('/profile', 'VendorDashboardController@profile')->name('vendor.profile.update');
    $router->post('/toggle-availability', 'VendorDashboardController@toggleAvailability')->name('vendor.toggle-availability');

    // Menu Management
    $router->get('/menu', 'VendorDashboardController@menu')->name('vendor.menu');

    // Analytics and Earnings
    $router->get('/analytics', 'VendorDashboardController@analytics')->name('vendor.analytics');
    $router->get('/earnings', 'VendorDashboardController@earnings')->name('vendor.earnings');
    
    // Analytics
    $router->get('/analytics', 'Vendor\AnalyticsController@index')->name('vendor.analytics');
    $router->get('/analytics/sales', 'Vendor\AnalyticsController@sales')->name('vendor.analytics.sales');
    $router->get('/analytics/export', 'Vendor\AnalyticsController@export')->name('vendor.analytics.export');
    
    // Reviews
    $router->get('/reviews', 'Vendor\ReviewController@index')->name('vendor.reviews');
    $router->post('/reviews/{id}/reply', 'Vendor\ReviewController@reply')->name('vendor.reviews.reply');
});

// ============================================================================
// RIDER ROUTES (Delivery Personnel)
// ============================================================================

$router->group(['prefix' => '/rider', 'middleware' => ['AuthMiddleware', 'RoleMiddleware:rider']], function($router) {
    
    // Rider Dashboard
    $router->get('/dashboard', 'RiderDashboardController@index')->name('rider.dashboard');
    
    // Delivery Management
    $router->get('/deliveries', 'RiderDashboardController@deliveries')->name('rider.deliveries');
    $router->get('/available', 'RiderDashboardController@available')->name('rider.available');
    $router->post('/accept-order', 'RiderDashboardController@acceptOrder')->name('rider.accept-order');
    $router->post('/delivery-status', 'RiderDashboardController@updateDeliveryStatus')->name('rider.delivery-status');
    $router->get('/deliveries/available', 'Rider\DeliveryController@available')->name('rider.deliveries.available');
    $router->post('/deliveries/{id}/accept', 'Rider\DeliveryController@accept')->name('rider.deliveries.accept');
    $router->post('/deliveries/{id}/pickup', 'Rider\DeliveryController@pickup')->name('rider.deliveries.pickup');
    $router->post('/deliveries/{id}/deliver', 'Rider\DeliveryController@deliver')->name('rider.deliveries.deliver');

    // Rider Management
    $router->get('/schedule', 'RiderDashboardController@schedule')->name('rider.schedule');
    $router->post('/schedule', 'RiderDashboardController@schedule')->name('rider.schedule.update');
    $router->get('/performance', 'RiderDashboardController@performance')->name('rider.performance');
    $router->post('/toggle-availability', 'RiderDashboardController@toggleAvailability')->name('rider.toggle-availability');

    // Location Updates
    $router->post('/location/update', 'Rider\LocationController@update')->name('rider.location.update');
    $router->post('/status/toggle', 'Rider\StatusController@toggle')->name('rider.status.toggle');

    // Earnings
    $router->get('/earnings', 'RiderDashboardController@earnings')->name('rider.earnings');
    $router->get('/earnings/export', 'Rider\EarningsController@export')->name('rider.earnings.export');
});

// ============================================================================
// ADMIN ROUTES (System Administration)
// ============================================================================

$router->group(['prefix' => '/admin', 'middleware' => ['AuthMiddleware', 'RoleMiddleware:admin']], function($router) {
    
    // Admin Dashboard
    $router->get('/dashboard', 'AdminDashboardController@index')->name('admin.dashboard');
    
    // User Management
    $router->get('/users', 'AdminDashboardController@users')->name('admin.users');
    $router->post('/users/status', 'AdminDashboardController@updateUserStatus')->name('admin.users.status');
    $router->resource('users', 'Admin\UserController')->name('admin.users.resource');
    $router->post('/users/{id}/toggle-status', 'Admin\UserController@toggleStatus')->name('admin.users.toggle');
    $router->post('/users/{id}/reset-password', 'Admin\UserController@resetPassword')->name('admin.users.reset-password');

    // Restaurant Management
    $router->get('/restaurants', 'AdminDashboardController@restaurants')->name('admin.restaurants');
    $router->post('/restaurants/approve', 'AdminDashboardController@approveRestaurant')->name('admin.restaurants.approve');
    $router->resource('restaurants', 'Admin\RestaurantController')->name('admin.restaurants.resource');
    $router->post('/restaurants/{id}/reject', 'Admin\RestaurantController@reject')->name('admin.restaurants.reject');

    // Order Management
    $router->get('/orders', 'AdminDashboardController@orders')->name('admin.orders');
    $router->get('/orders/{id}', 'Admin\OrderController@show')->name('admin.orders.show');
    $router->post('/orders/{id}/refund', 'Admin\OrderController@refund')->name('admin.orders.refund');

    // Analytics and Financial
    $router->get('/analytics', 'AdminDashboardController@analytics')->name('admin.analytics');
    $router->get('/financial', 'AdminDashboardController@financial')->name('admin.financial');
    $router->get('/system-status', 'AdminDashboardController@systemStatus')->name('admin.system-status');
    
    // Categories Management
    $router->resource('categories', 'Admin\CategoryController')->name('admin.categories');
    
    // System Settings
    $router->get('/settings', 'Admin\SettingsController@index')->name('admin.settings');
    $router->put('/settings', 'Admin\SettingsController@update')->name('admin.settings.update');
    
    // Analytics and Reports
    $router->get('/analytics', 'Admin\AnalyticsController@index')->name('admin.analytics');
    $router->get('/reports/sales', 'Admin\ReportController@sales')->name('admin.reports.sales');
    $router->get('/reports/users', 'Admin\ReportController@users')->name('admin.reports.users');
    $router->get('/reports/restaurants', 'Admin\ReportController@restaurants')->name('admin.reports.restaurants');
    
    // System Logs
    $router->get('/logs', 'Admin\LogController@index')->name('admin.logs');
    $router->delete('/logs/clear', 'Admin\LogController@clear')->name('admin.logs.clear');

    // Admin Tools
    $router->get('/tools/analytics', 'AdminToolsController@analytics')->name('admin.tools.analytics');
    $router->get('/tools/approvals', 'AdminToolsController@approvals')->name('admin.tools.approvals');
    $router->post('/tools/approvals', 'AdminToolsController@approvals')->name('admin.tools.approvals.post');
    $router->get('/tools/backups', 'AdminToolsController@backups')->name('admin.tools.backups');
    $router->post('/tools/backups', 'AdminToolsController@backups')->name('admin.tools.backups.post');
    $router->get('/tools/notifications', 'AdminToolsController@notifications')->name('admin.tools.notifications');
    $router->post('/tools/notifications', 'AdminToolsController@notifications')->name('admin.tools.notifications.post');
    $router->get('/tools/settings', 'AdminToolsController@settings')->name('admin.tools.settings');
    $router->post('/tools/settings', 'AdminToolsController@settings')->name('admin.tools.settings.post');

    // Cancellation Management
    $router->get('/cancellations', 'CancellationController@index')->name('admin.cancellations.index');
    $router->get('/cancellations/{id}', 'CancellationController@show')->name('admin.cancellations.show');
    $router->post('/cancellations/{id}/approve', 'CancellationController@approve')->name('admin.cancellations.approve');
    $router->post('/cancellations/{id}/reject', 'CancellationController@reject')->name('admin.cancellations.reject');

    // Review Management
    $router->get('/reviews/pending', 'Admin\ReviewController@pending')->name('admin.reviews.pending');
    $router->post('/reviews/{id}/approve', 'Admin\ReviewController@approve')->name('admin.reviews.approve');
    $router->post('/reviews/{id}/reject', 'Admin\ReviewController@reject')->name('admin.reviews.reject');
    $router->post('/reviews/{id}/feature', 'Admin\ReviewController@feature')->name('admin.reviews.feature');

    // Performance Management
    $router->get('/performance', 'PerformanceController@dashboard')->name('admin.performance.dashboard');
    $router->post('/performance/optimize', 'PerformanceController@optimize')->name('admin.performance.optimize');
    $router->post('/performance/optimize-images', 'PerformanceController@optimizeImages')->name('admin.performance.optimize-images');
    $router->post('/performance/clear-cache', 'PerformanceController@clearCache')->name('admin.performance.clear-cache');
    $router->get('/performance/metrics', 'PerformanceController@metrics')->name('admin.performance.metrics');
    $router->get('/performance/test', 'PerformanceController@test')->name('admin.performance.test');
});

// ============================================================================
// PERFORMANCE ROUTES (Public)
// ============================================================================

// Optimized image serving
$router->get('/images/optimized', 'PerformanceController@serveImage')->name('images.optimized');

// ============================================================================
// API ROUTES (JSON Responses)
// ============================================================================

$router->group(['prefix' => '/api/v1'], function($router) {
    
    // Public API
    $router->get('/restaurants', 'Api\RestaurantController@index');
    $router->get('/restaurants/{id}', 'Api\RestaurantController@show');
    $router->get('/restaurants/{id}/menu', 'Api\MenuController@index');
    $router->get('/categories', 'Api\CategoryController@index');
    $router->get('/search', 'Api\SearchController@index');
    
    // Authentication API
    $router->post('/auth/login', 'Api\AuthController@login');
    $router->post('/auth/register', 'Api\AuthController@register');
    $router->post('/auth/refresh', 'Api\AuthController@refresh');
    
    // Authenticated API
    $router->group(['middleware' => ['ApiAuthMiddleware']], function($router) {
        $router->post('/auth/logout', 'Api\AuthController@logout');
        $router->get('/profile', 'Api\ProfileController@show');
        $router->put('/profile', 'Api\ProfileController@update');
        
        // Cart API
        $router->get('/cart', 'Api\CartController@index');
        $router->post('/cart', 'Api\CartController@add');
        $router->put('/cart/{id}', 'Api\CartController@update');
        $router->delete('/cart/{id}', 'Api\CartController@remove');
        
        // Orders API
        $router->get('/orders', 'Api\OrderController@index');
        $router->post('/orders', 'Api\OrderController@store');
        $router->get('/orders/{id}', 'Api\OrderController@show');
        $router->post('/orders/{id}/cancel', 'Api\OrderController@cancel');

        // Payment API
        $router->post('/payments/process', 'PaymentController@processPayment');
        $router->get('/payments/status', 'PaymentController@getPaymentStatus');
        $router->post('/payments/refund', 'PaymentController@processRefund');

        // Reviews API
        $router->get('/reviews', 'ReviewController@apiGetReviews');
    });

    // Payment Webhooks (no authentication required)
    $router->post('/payments/webhook/{provider}', 'PaymentController@webhook');
});

// ============================================================================
// WEBHOOK ROUTES (External Services)
// ============================================================================

$router->group(['prefix' => '/webhooks'], function($router) {
    $router->post('/stripe', 'Webhook\StripeController@handle');
    $router->post('/paypal', 'Webhook\PayPalController@handle');
    $router->post('/orange-money', 'Webhook\OrangeMoneyController@handle');
    $router->post('/mtn-momo', 'Webhook\MTNMoMoController@handle');
});

// ============================================================================
// CART AND CHECKOUT ROUTES
// ============================================================================

// Cart Routes
$router->group(['prefix' => '/cart', 'middleware' => ['AuthMiddleware']], function($router) {
    $router->get('/', 'CartController@index')->name('cart.index');
    $router->post('/add', 'CartController@add')->name('cart.add');
    $router->post('/update', 'CartController@update')->name('cart.update');
    $router->post('/remove', 'CartController@remove')->name('cart.remove');
    $router->post('/clear', 'CartController@clear')->name('cart.clear');
    $router->get('/count', 'CartController@getCartCount')->name('cart.count');
    $router->get('/totals', 'CartController@getCartTotals')->name('cart.totals');
    $router->post('/apply-promo', 'CartController@applyPromoCode')->name('cart.promo.apply');
    $router->post('/remove-promo', 'CartController@removePromoCode')->name('cart.promo.remove');
    $router->post('/quick-add', 'CartController@quickAdd')->name('cart.quick-add');
});

// Checkout Routes
$router->group(['prefix' => '/checkout', 'middleware' => ['AuthMiddleware']], function($router) {
    $router->get('/', 'CheckoutController@index')->name('checkout.index');
    $router->post('/place-order', 'CheckoutController@placeOrder')->name('checkout.place-order');
    $router->post('/validate-affiliate', 'CheckoutController@validateAffiliateCode')->name('checkout.validate-affiliate');
});

// Real-time Tracking Routes
$router->get('/track', 'TrackingController@getTrackingPage')->name('tracking.search');
$router->get('/track/{code}', 'TrackingController@getTrackingPage')->name('tracking.live');

// Tracking API Routes
$router->group(['prefix' => '/api/tracking'], function($router) {
    // Public tracking (no auth required)
    $router->get('/code/{tracking_code}', 'TrackingController@trackByCode')->name('api.tracking.code');

    // Authenticated tracking routes
    $router->group(['middleware' => ['AuthMiddleware']], function($router) {
        $router->post('/order', 'TrackingController@trackOrder')->name('api.tracking.order');
        $router->get('/order/{order_id}', 'TrackingController@trackOrder')->name('api.tracking.order.get');
        $router->post('/location/update', 'TrackingController@updateRiderLocation')->name('api.tracking.location.update');
        $router->post('/status/update', 'TrackingController@updateDeliveryStatus')->name('api.tracking.status.update');
        $router->get('/updates/{delivery_id}', 'TrackingController@getDeliveryUpdates')->name('api.tracking.updates');
    });
});

// Affiliate Routes
$router->group(['prefix' => '/affiliate', 'middleware' => ['AuthMiddleware']], function($router) {
    $router->get('/dashboard', 'AffiliateController@dashboard')->name('affiliate.dashboard');
    $router->get('/earnings', 'AffiliateController@earnings')->name('affiliate.earnings');
    $router->get('/withdrawals', 'AffiliateController@withdrawals')->name('affiliate.withdrawals');
    $router->get('/referrals', 'AffiliateController@referrals')->name('affiliate.referrals');
    $router->get('/request-withdrawal', 'AffiliateController@requestWithdrawal')->name('affiliate.request-withdrawal');
    $router->post('/request-withdrawal', 'AffiliateController@processWithdrawalRequest')->name('affiliate.process-withdrawal');
    $router->get('/stats', 'AffiliateController@getAffiliateStats')->name('affiliate.stats');
});

// Public Affiliate API Routes
$router->get('/api/affiliate/validate-code', 'AffiliateController@validateReferralCode')->name('api.affiliate.validate-code');

// Push Notification API Routes
$router->group(['prefix' => '/api/push', 'middleware' => ['AuthMiddleware']], function($router) {
    $router->post('/subscribe', 'PushNotificationController@subscribe')->name('api.push.subscribe');
    $router->post('/unsubscribe', 'PushNotificationController@unsubscribe')->name('api.push.unsubscribe');
    $router->get('/subscriptions', 'PushNotificationController@getSubscriptions')->name('api.push.subscriptions');
    $router->post('/send', 'PushNotificationController@sendNotification')->name('api.push.send');
});

// Performance API Routes
$router->group(['prefix' => '/api/performance'], function($router) {
    $router->post('/metrics', 'PerformanceController@recordMetrics')->name('api.performance.metrics');
    $router->get('/status', 'PerformanceController@getStatus')->name('api.performance.status');
});

// Admin Affiliate Routes
$router->group(['prefix' => '/admin/affiliate', 'middleware' => ['AuthMiddleware']], function($router) {
    $router->get('/dashboard', 'AdminAffiliateController@dashboard')->name('admin.affiliate.dashboard');
    $router->get('/affiliates', 'AdminAffiliateController@affiliates')->name('admin.affiliate.affiliates');
    $router->get('/withdrawals', 'AdminAffiliateController@withdrawals')->name('admin.affiliate.withdrawals');
    $router->get('/payouts', 'AdminAffiliateController@payouts')->name('admin.affiliate.payouts');
    $router->get('/details', 'AdminAffiliateController@affiliateDetails')->name('admin.affiliate.details');
    $router->post('/approve-withdrawal', 'AdminAffiliateController@approveWithdrawal')->name('admin.affiliate.approve-withdrawal');
    $router->post('/reject-withdrawal', 'AdminAffiliateController@rejectWithdrawal')->name('admin.affiliate.reject-withdrawal');
    $router->post('/update-commission', 'AdminAffiliateController@updateCommissionRate')->name('admin.affiliate.update-commission');
    $router->post('/update-status', 'AdminAffiliateController@updateAffiliateStatus')->name('admin.affiliate.update-status');
    $router->post('/process-payouts', 'AdminAffiliateController@processPayouts')->name('admin.affiliate.process-payouts');
});

// ============================================================================
// UTILITY ROUTES
// ============================================================================

// File Uploads
$router->post('/upload/image', 'UploadController@image')->middleware(['AuthMiddleware']);
$router->post('/upload/document', 'UploadController@document')->middleware(['AuthMiddleware']);

// Real-time Features
$router->get('/sse/orders/{id}', 'SSEController@orderUpdates')->middleware(['AuthMiddleware']);
$router->get('/sse/notifications', 'SSEController@notifications')->middleware(['AuthMiddleware']);

// Vendor Menu Management Routes
$router->get('/vendor/menu/dashboard', 'VendorMenuController@dashboard')->middleware(['AuthMiddleware', 'RoleMiddleware:vendor']);
$router->get('/vendor/menu', 'VendorMenuController@index')->middleware(['AuthMiddleware', 'RoleMiddleware:vendor']);
$router->get('/vendor/menu/create', 'VendorMenuController@create')->middleware(['AuthMiddleware', 'RoleMiddleware:vendor']);
$router->post('/vendor/menu/create', 'VendorMenuController@store')->middleware(['AuthMiddleware', 'RoleMiddleware:vendor']);
$router->get('/vendor/menu/edit/{id}', 'VendorMenuController@edit')->middleware(['AuthMiddleware', 'RoleMiddleware:vendor']);
$router->post('/vendor/menu/edit/{id}', 'VendorMenuController@update')->middleware(['AuthMiddleware', 'RoleMiddleware:vendor']);
$router->delete('/vendor/menu/delete/{id}', 'VendorMenuController@delete')->middleware(['AuthMiddleware', 'RoleMiddleware:vendor']);
$router->post('/vendor/menu/toggle/{id}', 'VendorMenuController@toggleAvailability')->middleware(['AuthMiddleware', 'RoleMiddleware:vendor']);
$router->post('/vendor/menu/stock/{id}', 'VendorMenuController@updateStock')->middleware(['AuthMiddleware', 'RoleMiddleware:vendor']);
$router->get('/vendor/menu/import', 'VendorMenuController@showImport')->middleware(['AuthMiddleware', 'RoleMiddleware:vendor']);
$router->post('/vendor/menu/import', 'VendorMenuController@importCsv')->middleware(['AuthMiddleware', 'RoleMiddleware:vendor']);
$router->get('/vendor/menu/template', 'VendorMenuController@downloadTemplate')->middleware(['AuthMiddleware', 'RoleMiddleware:vendor']);

// ============================================================================
// RIDER DELIVERY MANAGEMENT ROUTES
// ============================================================================

// Rider Delivery Views
$router->get('/rider/delivery-dashboard', function() {
    require_once __DIR__ . '/../src/views/rider/delivery-dashboard.php';
})->middleware(['AuthMiddleware', 'RoleMiddleware:rider']);

$router->get('/rider/navigation', function() {
    require_once __DIR__ . '/../src/views/rider/navigation.php';
})->middleware(['AuthMiddleware', 'RoleMiddleware:rider']);

$router->get('/rider/earnings', function() {
    require_once __DIR__ . '/../src/views/rider/earnings.php';
})->middleware(['AuthMiddleware', 'RoleMiddleware:rider']);

// Rider Delivery API Routes
$router->group(['prefix' => '/api/rider', 'middleware' => ['AuthMiddleware', 'RoleMiddleware:rider']], function($router) {
    $router->get('/available-deliveries', 'RiderDeliveryController@getAvailableDeliveries');
    $router->post('/accept-delivery', 'RiderDeliveryController@acceptDelivery');
    $router->post('/reject-delivery', 'RiderDeliveryController@rejectDelivery');
    $router->post('/update-delivery-status', 'RiderDeliveryController@updateDeliveryStatus');
    $router->post('/update-location', 'RiderDeliveryController@updateLocation');
    $router->get('/navigation-route', 'RiderDeliveryController@getNavigationRoute');
    $router->get('/earnings', 'RiderDeliveryController@getEarnings');
});

// Health Check
$router->get('/health', function() {
    return json_encode(['status' => 'ok', 'timestamp' => time()]);
});

return $router;
