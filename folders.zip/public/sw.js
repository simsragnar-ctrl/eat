// Time2Eat Service Worker
// Version 1.0.0

const CACHE_NAME = 'time2eat-v1.0.0';
const OFFLINE_URL = '/offline.html';
const FALLBACK_IMAGE = '/images/fallback-food.jpg';

// Resources to cache immediately
const STATIC_CACHE_URLS = [
  '/',
  '/offline.html',
  '/browse',
  '/about',
  '/contact',
  '/manifest.json',
  '/images/logo.png',
  '/images/fallback-food.jpg',
  '/images/icons/icon-192x192.png',
  '/images/icons/icon-512x512.png',
  // CSS and JS files
  'https://cdn.tailwindcss.com',
  'https://unpkg.com/feather-icons',
  // Fonts
  'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap'
];

// Resources to cache on first visit
const DYNAMIC_CACHE_PATTERNS = [
  /^https:\/\/.*\.(?:png|jpg|jpeg|svg|gif|webp)$/,
  /^\/api\/restaurants/,
  /^\/api\/menu/,
  /^\/images\//,
  /^\/css\//,
  /^\/js\//
];

// Network-first patterns (always try network first)
const NETWORK_FIRST_PATTERNS = [
  /^\/api\/orders/,
  /^\/api\/cart/,
  /^\/api\/checkout/,
  /^\/api\/tracking/,
  /^\/api\/auth/,
  /^\/api\/payments/
];

// Cache-first patterns (serve from cache if available)
const CACHE_FIRST_PATTERNS = [
  /^\/images\//,
  /^https:\/\/.*\.(?:png|jpg|jpeg|svg|gif|webp)$/,
  /^https:\/\/fonts\./,
  /^https:\/\/cdn\./
];

// Install event - cache static resources
self.addEventListener('install', event => {
  console.log('[SW] Installing service worker...');
  
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('[SW] Caching static resources');
        return cache.addAll(STATIC_CACHE_URLS);
      })
      .then(() => {
        console.log('[SW] Static resources cached successfully');
        return self.skipWaiting();
      })
      .catch(error => {
        console.error('[SW] Failed to cache static resources:', error);
      })
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', event => {
  console.log('[SW] Activating service worker...');
  
  event.waitUntil(
    caches.keys()
      .then(cacheNames => {
        return Promise.all(
          cacheNames.map(cacheName => {
            if (cacheName !== CACHE_NAME) {
              console.log('[SW] Deleting old cache:', cacheName);
              return caches.delete(cacheName);
            }
          })
        );
      })
      .then(() => {
        console.log('[SW] Service worker activated');
        return self.clients.claim();
      })
  );
});

// Fetch event - handle network requests
self.addEventListener('fetch', event => {
  const { request } = event;
  const url = new URL(request.url);
  
  // Skip non-GET requests
  if (request.method !== 'GET') {
    return;
  }
  
  // Skip chrome-extension and other non-http requests
  if (!url.protocol.startsWith('http')) {
    return;
  }
  
  event.respondWith(handleFetch(request));
});

// Handle fetch requests with different strategies
async function handleFetch(request) {
  const url = new URL(request.url);
  
  try {
    // Network-first strategy for critical API calls
    if (NETWORK_FIRST_PATTERNS.some(pattern => pattern.test(request.url))) {
      return await networkFirst(request);
    }
    
    // Cache-first strategy for static assets
    if (CACHE_FIRST_PATTERNS.some(pattern => pattern.test(request.url))) {
      return await cacheFirst(request);
    }
    
    // Stale-while-revalidate for dynamic content
    if (DYNAMIC_CACHE_PATTERNS.some(pattern => pattern.test(request.url))) {
      return await staleWhileRevalidate(request);
    }
    
    // Default: Network-first with offline fallback
    return await networkFirstWithFallback(request);
    
  } catch (error) {
    console.error('[SW] Fetch error:', error);
    return await getOfflineFallback(request);
  }
}

// Network-first strategy
async function networkFirst(request) {
  try {
    const networkResponse = await fetch(request);
    
    if (networkResponse.ok) {
      const cache = await caches.open(CACHE_NAME);
      cache.put(request, networkResponse.clone());
    }
    
    return networkResponse;
  } catch (error) {
    const cachedResponse = await caches.match(request);
    if (cachedResponse) {
      return cachedResponse;
    }
    throw error;
  }
}

// Cache-first strategy
async function cacheFirst(request) {
  const cachedResponse = await caches.match(request);
  
  if (cachedResponse) {
    return cachedResponse;
  }
  
  try {
    const networkResponse = await fetch(request);
    
    if (networkResponse.ok) {
      const cache = await caches.open(CACHE_NAME);
      cache.put(request, networkResponse.clone());
    }
    
    return networkResponse;
  } catch (error) {
    return await getOfflineFallback(request);
  }
}

// Stale-while-revalidate strategy
async function staleWhileRevalidate(request) {
  const cachedResponse = await caches.match(request);
  
  const networkResponsePromise = fetch(request)
    .then(networkResponse => {
      if (networkResponse.ok) {
        const cache = caches.open(CACHE_NAME);
        cache.then(c => c.put(request, networkResponse.clone()));
      }
      return networkResponse;
    })
    .catch(() => null);
  
  return cachedResponse || await networkResponsePromise || await getOfflineFallback(request);
}

// Network-first with offline fallback
async function networkFirstWithFallback(request) {
  try {
    const networkResponse = await fetch(request);
    
    if (networkResponse.ok) {
      const cache = await caches.open(CACHE_NAME);
      cache.put(request, networkResponse.clone());
    }
    
    return networkResponse;
  } catch (error) {
    const cachedResponse = await caches.match(request);
    return cachedResponse || await getOfflineFallback(request);
  }
}

// Get appropriate offline fallback
async function getOfflineFallback(request) {
  const url = new URL(request.url);
  
  // HTML pages - return offline page
  if (request.headers.get('accept')?.includes('text/html')) {
    return await caches.match(OFFLINE_URL) || new Response('Offline', { status: 503 });
  }
  
  // Images - return fallback image
  if (request.headers.get('accept')?.includes('image/')) {
    return await caches.match(FALLBACK_IMAGE) || new Response('', { status: 503 });
  }
  
  // API calls - return offline JSON response
  if (url.pathname.startsWith('/api/')) {
    return new Response(JSON.stringify({
      success: false,
      message: 'You are currently offline. Please check your internet connection.',
      offline: true
    }), {
      status: 503,
      headers: { 'Content-Type': 'application/json' }
    });
  }
  
  // Default fallback
  return new Response('Resource not available offline', { status: 503 });
}

// Push notification event
self.addEventListener('push', event => {
  console.log('[SW] Push notification received');
  
  const options = {
    body: 'Your order status has been updated!',
    icon: '/images/icons/icon-192x192.png',
    badge: '/images/icons/badge-72x72.png',
    vibrate: [200, 100, 200],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1
    },
    actions: [
      {
        action: 'explore',
        title: 'View Order',
        icon: '/images/icons/action-view.png'
      },
      {
        action: 'close',
        title: 'Close',
        icon: '/images/icons/action-close.png'
      }
    ],
    requireInteraction: true,
    silent: false
  };
  
  if (event.data) {
    try {
      const data = event.data.json();
      options.title = data.title || 'Time2Eat';
      options.body = data.body || options.body;
      options.icon = data.icon || options.icon;
      options.data = { ...options.data, ...data.data };
      
      if (data.url) {
        options.data.url = data.url;
      }
    } catch (error) {
      console.error('[SW] Error parsing push data:', error);
      options.title = 'Time2Eat';
    }
  } else {
    options.title = 'Time2Eat';
  }
  
  event.waitUntil(
    self.registration.showNotification(options.title, options)
  );
});

// Notification click event
self.addEventListener('notificationclick', event => {
  console.log('[SW] Notification clicked');
  
  event.notification.close();
  
  const urlToOpen = event.notification.data?.url || '/orders';
  
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true })
      .then(clientList => {
        // Check if there's already a window/tab open with the target URL
        for (const client of clientList) {
          if (client.url === urlToOpen && 'focus' in client) {
            return client.focus();
          }
        }
        
        // If no existing window/tab, open a new one
        if (self.clients.openWindow) {
          return self.clients.openWindow(urlToOpen);
        }
      })
  );
});

// Background sync event
self.addEventListener('sync', event => {
  console.log('[SW] Background sync triggered:', event.tag);
  
  if (event.tag === 'background-sync-orders') {
    event.waitUntil(syncOrders());
  }
  
  if (event.tag === 'background-sync-cart') {
    event.waitUntil(syncCart());
  }
});

// Sync pending orders when back online
async function syncOrders() {
  try {
    // Get pending orders from IndexedDB or localStorage
    const pendingOrders = await getPendingOrders();
    
    for (const order of pendingOrders) {
      try {
        const response = await fetch('/api/orders', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(order)
        });
        
        if (response.ok) {
          await removePendingOrder(order.id);
          console.log('[SW] Order synced successfully:', order.id);
        }
      } catch (error) {
        console.error('[SW] Failed to sync order:', error);
      }
    }
  } catch (error) {
    console.error('[SW] Background sync failed:', error);
  }
}

// Sync cart when back online
async function syncCart() {
  try {
    const cartData = await getOfflineCart();
    
    if (cartData) {
      const response = await fetch('/api/cart/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(cartData)
      });
      
      if (response.ok) {
        await clearOfflineCart();
        console.log('[SW] Cart synced successfully');
      }
    }
  } catch (error) {
    console.error('[SW] Cart sync failed:', error);
  }
}

// Helper functions for offline data management
async function getPendingOrders() {
  // Implementation would use IndexedDB or localStorage
  return [];
}

async function removePendingOrder(orderId) {
  // Implementation would remove from IndexedDB or localStorage
}

async function getOfflineCart() {
  // Implementation would get cart from IndexedDB or localStorage
  return null;
}

async function clearOfflineCart() {
  // Implementation would clear cart from IndexedDB or localStorage
}

// Message event for communication with main thread
self.addEventListener('message', event => {
  console.log('[SW] Message received:', event.data);
  
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  
  if (event.data && event.data.type === 'GET_VERSION') {
    event.ports[0].postMessage({ version: CACHE_NAME });
  }
});
