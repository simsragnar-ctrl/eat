<?php
/**
 * Time2Eat Configuration File
 * Loads environment variables and sets application constants
 */

// Load environment variables from .env file
function loadEnv($path) {
    if (!file_exists($path)) {
        return;
    }
    
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) {
            continue; // Skip comments
        }
        
        list($name, $value) = explode('=', $line, 2);
        $name = trim($name);
        $value = trim($value);
        
        // Remove quotes if present
        if (preg_match('/^"(.*)"$/', $value, $matches)) {
            $value = $matches[1];
        } elseif (preg_match("/^'(.*)'$/", $value, $matches)) {
            $value = $matches[1];
        }
        
        if (!array_key_exists($name, $_ENV)) {
            $_ENV[$name] = $value;
        }
    }
}

// Load .env file
loadEnv(ROOT_PATH . '/.env');

// Helper function to get environment variables with default values
function env($key, $default = null) {
    return $_ENV[$key] ?? $default;
}

// Database Configuration
define('DB_HOST', env('DB_HOST', 'localhost'));
define('DB_NAME', env('DB_NAME', 'time2eat'));
define('DB_USER', env('DB_USER', 'root'));
define('DB_PASS', env('DB_PASS', ''));
define('DB_CHARSET', env('DB_CHARSET', 'utf8mb4'));

// Application Settings
define('APP_NAME', env('APP_NAME', 'Time2Eat'));
define('APP_URL', env('APP_URL', 'http://localhost'));
define('APP_ENV', env('APP_ENV', 'development'));
define('APP_DEBUG', env('APP_DEBUG', 'true') === 'true');
define('APP_KEY', env('APP_KEY', 'default-secret-key'));

// Security
define('JWT_SECRET', env('JWT_SECRET', 'default-jwt-secret'));

// Map Configuration
define('MAP_API_KEY', env('MAP_API_KEY', ''));
define('MAP_PROVIDER', env('MAP_PROVIDER', 'google'));

// Payment Configuration
define('STRIPE_PUBLIC_KEY', env('STRIPE_PUBLIC_KEY', ''));
define('STRIPE_SECRET_KEY', env('STRIPE_SECRET_KEY', ''));
define('PAYPAL_CLIENT_ID', env('PAYPAL_CLIENT_ID', ''));
define('PAYPAL_CLIENT_SECRET', env('PAYPAL_CLIENT_SECRET', ''));

// Mobile Money Configuration
define('MTN_MOMO_API_KEY', env('MTN_MOMO_API_KEY', ''));
define('ORANGE_MONEY_API_KEY', env('ORANGE_MONEY_API_KEY', ''));

// Email Configuration
define('MAIL_HOST', env('MAIL_HOST', 'smtp.gmail.com'));
define('MAIL_PORT', env('MAIL_PORT', 587));
define('MAIL_USERNAME', env('MAIL_USERNAME', ''));
define('MAIL_PASSWORD', env('MAIL_PASSWORD', ''));
define('MAIL_ENCRYPTION', env('MAIL_ENCRYPTION', 'tls'));
define('MAIL_FROM_ADDRESS', env('MAIL_FROM_ADDRESS', 'noreply@time2eat.com'));
define('MAIL_FROM_NAME', env('MAIL_FROM_NAME', 'Time2Eat'));

// SMS Configuration
define('TWILIO_SID', env('TWILIO_SID', ''));
define('TWILIO_TOKEN', env('TWILIO_TOKEN', ''));
define('TWILIO_FROM', env('TWILIO_FROM', ''));

// Push Notifications
define('ONESIGNAL_APP_ID', env('ONESIGNAL_APP_ID', ''));
define('ONESIGNAL_REST_API_KEY', env('ONESIGNAL_REST_API_KEY', ''));

// File Upload Settings
define('MAX_FILE_SIZE', (int)env('MAX_FILE_SIZE', 5242880)); // 5MB
define('ALLOWED_IMAGE_TYPES', explode(',', env('ALLOWED_IMAGE_TYPES', 'jpg,jpeg,png,webp,gif')));

// Affiliate Settings
define('DEFAULT_AFFILIATE_RATE', (float)env('DEFAULT_AFFILIATE_RATE', 0.05));
define('WITHDRAWAL_THRESHOLD', (int)env('WITHDRAWAL_THRESHOLD', 10000));

// Delivery Settings
define('BASE_DELIVERY_FEE', (int)env('BASE_DELIVERY_FEE', 500));
define('DELIVERY_FEE_PER_KM', (int)env('DELIVERY_FEE_PER_KM', 100));

// Cache Settings
define('CACHE_ENABLED', env('CACHE_ENABLED', 'true') === 'true');
define('CACHE_DURATION', (int)env('CACHE_DURATION', 3600));

// Session Settings
define('SESSION_LIFETIME', (int)env('SESSION_LIFETIME', 7200));
define('SESSION_SECURE', env('SESSION_SECURE', 'false') === 'true');

// Rate Limiting
define('RATE_LIMIT_ENABLED', env('RATE_LIMIT_ENABLED', 'true') === 'true');
define('MAX_LOGIN_ATTEMPTS', (int)env('MAX_LOGIN_ATTEMPTS', 5));
define('RATE_LIMIT_WINDOW', (int)env('RATE_LIMIT_WINDOW', 900));

// Set timezone
date_default_timezone_set('Africa/Douala');

// Configure session
ini_set('session.gc_maxlifetime', SESSION_LIFETIME);
session_set_cookie_params([
    'lifetime' => SESSION_LIFETIME,
    'path' => '/',
    'domain' => '',
    'secure' => SESSION_SECURE,
    'httponly' => true,
    'samesite' => 'Lax'
]);

// Error handling for production
if (!APP_DEBUG) {
    error_reporting(0);
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);
    ini_set('error_log', ROOT_PATH . '/logs/error.log');
}
