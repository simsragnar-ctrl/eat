<?php
/**
 * Database Configuration and Connection Handler
 * Provides PDO connection with error handling and connection pooling
 */

class Database {
    private static $instance = null;
    private $connection = null;
    private $host;
    private $dbname;
    private $username;
    private $password;
    private $charset;
    
    private function __construct() {
        $this->host = DB_HOST;
        $this->dbname = DB_NAME;
        $this->username = DB_USER;
        $this->password = DB_PASS;
        $this->charset = DB_CHARSET;
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        if ($this->connection === null) {
            try {
                $dsn = "mysql:host={$this->host};dbname={$this->dbname};charset={$this->charset}";
                $options = [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES {$this->charset}",
                    PDO::ATTR_PERSISTENT => true, // Connection pooling
                ];
                
                $this->connection = new PDO($dsn, $this->username, $this->password, $options);
                
                // Set timezone to match PHP
                $this->connection->exec("SET time_zone = '+01:00'"); // WAT (West Africa Time)
                
            } catch (PDOException $e) {
                error_log("Database Connection Error: " . $e->getMessage());
                throw new Exception("Database connection failed. Please check your configuration.");
            }
        }
        
        return $this->connection;
    }
    
    public function beginTransaction() {
        return $this->getConnection()->beginTransaction();
    }
    
    public function commit() {
        return $this->getConnection()->commit();
    }
    
    public function rollback() {
        return $this->getConnection()->rollback();
    }
    
    public function lastInsertId() {
        return $this->getConnection()->lastInsertId();
    }
    
    public function prepare($sql) {
        return $this->getConnection()->prepare($sql);
    }
    
    public function query($sql) {
        return $this->getConnection()->query($sql);
    }
    
    public function exec($sql) {
        return $this->getConnection()->exec($sql);
    }
    
    // Prevent cloning
    private function __clone() {}
    
    // Prevent unserialization
    public function __wakeup() {
        throw new Exception("Cannot unserialize singleton");
    }
}

// Database helper functions
function db() {
    return Database::getInstance();
}

function dbConnection() {
    return Database::getInstance()->getConnection();
}

// Test database connection on first load
try {
    $testConnection = Database::getInstance()->getConnection();
    if (APP_DEBUG) {
        error_log("Database connection successful");
    }
} catch (Exception $e) {
    if (APP_DEBUG) {
        error_log("Database connection failed: " . $e->getMessage());
    }
    // Don't throw exception here to allow installer to run
}
