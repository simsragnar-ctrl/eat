-- ============================================================================
-- Time2Eat Database Schema
-- Comprehensive MySQL schema for Bamenda Food Delivery Platform
-- Version: 1.0.0
-- ============================================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

-- ============================================================================
-- CORE TABLES
-- ============================================================================

-- Users table with multi-role support and affiliate system
CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL UNIQUE,
  `email` varchar(100) NOT NULL UNIQUE,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `role` enum('customer','vendor','rider','admin') NOT NULL DEFAULT 'customer',
  `status` enum('active','inactive','suspended','pending') NOT NULL DEFAULT 'active',
  `affiliate_code` varchar(20) UNIQUE DEFAULT NULL,
  `affiliate_rate` decimal(5,4) DEFAULT 0.0500 COMMENT 'Commission rate for affiliates (5%)',
  `balance` decimal(10,2) DEFAULT 0.00 COMMENT 'User wallet balance in XAF',
  `total_earnings` decimal(12,2) DEFAULT 0.00 COMMENT 'Total affiliate earnings',
  `referral_count` int(11) DEFAULT 0,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `last_login_ip` varchar(45) DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expires` timestamp NULL DEFAULT NULL,
  `two_factor_secret` varchar(255) DEFAULT NULL,
  `two_factor_enabled` boolean DEFAULT FALSE,
  `notification_preferences` json DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_affiliate_code_unique` (`affiliate_code`),
  KEY `users_role_index` (`role`),
  KEY `users_status_index` (`status`),
  KEY `users_created_at_index` (`created_at`),
  KEY `users_deleted_at_index` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- User profiles for additional information
CREATE TABLE `user_profiles` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` enum('male','female','other') DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `country` varchar(100) DEFAULT 'Cameroon',
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `preferences` json DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_profiles_user_id_unique` (`user_id`),
  CONSTRAINT `user_profiles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Categories for restaurants and menu items
CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL UNIQUE,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `icon` varchar(100) DEFAULT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `is_active` boolean DEFAULT TRUE,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_unique` (`slug`),
  KEY `categories_parent_id_index` (`parent_id`),
  KEY `categories_is_active_index` (`is_active`),
  KEY `categories_sort_order_index` (`sort_order`),
  KEY `categories_deleted_at_index` (`deleted_at`),
  CONSTRAINT `categories_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Restaurants table with comprehensive business information
CREATE TABLE `restaurants` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL COMMENT 'Owner/Vendor ID',
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL UNIQUE,
  `description` text DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `cover_image` varchar(255) DEFAULT NULL,
  `category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `cuisine_type` varchar(100) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `address` text NOT NULL,
  `city` varchar(100) NOT NULL DEFAULT 'Bamenda',
  `state` varchar(100) DEFAULT 'North West',
  `postal_code` varchar(20) DEFAULT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `delivery_radius` decimal(5,2) DEFAULT 10.00 COMMENT 'Delivery radius in KM',
  `minimum_order` decimal(8,2) DEFAULT 0.00 COMMENT 'Minimum order amount in XAF',
  `delivery_fee` decimal(6,2) DEFAULT 500.00 COMMENT 'Delivery fee in XAF',
  `delivery_time` varchar(50) DEFAULT '30-45 mins',
  `commission_rate` decimal(5,4) DEFAULT 0.1500 COMMENT 'Platform commission rate (15%)',
  `rating` decimal(3,2) DEFAULT 0.00,
  `total_reviews` int(11) DEFAULT 0,
  `total_orders` int(11) DEFAULT 0,
  `status` enum('pending','approved','active','inactive','suspended','rejected') NOT NULL DEFAULT 'pending',
  `is_featured` boolean DEFAULT FALSE,
  `is_open` boolean DEFAULT TRUE,
  `opening_hours` json DEFAULT NULL,
  `special_hours` json DEFAULT NULL COMMENT 'Holiday/special day hours',
  `payment_methods` json DEFAULT NULL,
  `tags` json DEFAULT NULL,
  `social_media` json DEFAULT NULL,
  `business_license` varchar(255) DEFAULT NULL,
  `tax_id` varchar(100) DEFAULT NULL,
  `bank_details` json DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `restaurants_slug_unique` (`slug`),
  KEY `restaurants_user_id_index` (`user_id`),
  KEY `restaurants_category_id_index` (`category_id`),
  KEY `restaurants_status_index` (`status`),
  KEY `restaurants_is_featured_index` (`is_featured`),
  KEY `restaurants_is_open_index` (`is_open`),
  KEY `restaurants_rating_index` (`rating`),
  KEY `restaurants_city_index` (`city`),
  KEY `restaurants_location_index` (`latitude`, `longitude`),
  KEY `restaurants_deleted_at_index` (`deleted_at`),
  CONSTRAINT `restaurants_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `restaurants_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Menu items with comprehensive product information
CREATE TABLE `menu_items` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `restaurant_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `images` json DEFAULT NULL COMMENT 'Multiple images array',
  `price` decimal(8,2) NOT NULL COMMENT 'Price in XAF',
  `original_price` decimal(8,2) DEFAULT NULL COMMENT 'Original price before discount',
  `cost_price` decimal(8,2) DEFAULT NULL COMMENT 'Cost price for profit calculation',
  `sku` varchar(100) DEFAULT NULL,
  `barcode` varchar(100) DEFAULT NULL,
  `ingredients` text DEFAULT NULL,
  `allergens` json DEFAULT NULL,
  `nutritional_info` json DEFAULT NULL,
  `preparation_time` int(11) DEFAULT 15 COMMENT 'Prep time in minutes',
  `calories` int(11) DEFAULT NULL,
  `serving_size` varchar(50) DEFAULT NULL,
  `spice_level` enum('none','mild','medium','hot','very_hot') DEFAULT 'none',
  `dietary_tags` json DEFAULT NULL COMMENT 'vegetarian, vegan, gluten-free, etc.',
  `is_available` boolean DEFAULT TRUE,
  `is_featured` boolean DEFAULT FALSE,
  `is_popular` boolean DEFAULT FALSE,
  `stock_quantity` int(11) DEFAULT NULL COMMENT 'NULL = unlimited',
  `sold_count` int(11) DEFAULT 0,
  `rating` decimal(3,2) DEFAULT 0.00,
  `total_reviews` int(11) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `menu_items_restaurant_slug_unique` (`restaurant_id`, `slug`),
  KEY `menu_items_restaurant_id_index` (`restaurant_id`),
  KEY `menu_items_category_id_index` (`category_id`),
  KEY `menu_items_is_available_index` (`is_available`),
  KEY `menu_items_is_featured_index` (`is_featured`),
  KEY `menu_items_is_popular_index` (`is_popular`),
  KEY `menu_items_price_index` (`price`),
  KEY `menu_items_rating_index` (`rating`),
  KEY `menu_items_sold_count_index` (`sold_count`),
  KEY `menu_items_deleted_at_index` (`deleted_at`),
  CONSTRAINT `menu_items_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `menu_items_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Menu item variants (size, extras, customizations)
CREATE TABLE `menu_item_variants` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `menu_item_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL COMMENT 'Small, Medium, Large, Extra Cheese, etc.',
  `type` enum('size','addon','customization') NOT NULL DEFAULT 'addon',
  `price_adjustment` decimal(6,2) DEFAULT 0.00 COMMENT 'Price difference from base price',
  `is_required` boolean DEFAULT FALSE,
  `max_selections` int(11) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `is_active` boolean DEFAULT TRUE,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `menu_item_variants_menu_item_id_index` (`menu_item_id`),
  KEY `menu_item_variants_type_index` (`type`),
  KEY `menu_item_variants_is_active_index` (`is_active`),
  CONSTRAINT `menu_item_variants_menu_item_id_foreign` FOREIGN KEY (`menu_item_id`) REFERENCES `menu_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- ORDER MANAGEMENT TABLES
-- ============================================================================

-- Orders table with comprehensive order tracking
CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_number` varchar(50) NOT NULL UNIQUE,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `restaurant_id` bigint(20) UNSIGNED NOT NULL,
  `rider_id` bigint(20) UNSIGNED DEFAULT NULL,
  `affiliate_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Referral affiliate user',
  `status` enum('pending','confirmed','preparing','ready','picked_up','on_the_way','delivered','cancelled','refunded') NOT NULL DEFAULT 'pending',
  `payment_status` enum('pending','paid','failed','refunded','partially_refunded') NOT NULL DEFAULT 'pending',
  `payment_method` enum('cash','card','mobile_money','orange_money','mtn_momo','paypal','stripe') NOT NULL DEFAULT 'cash',
  `subtotal` decimal(10,2) NOT NULL COMMENT 'Items total in XAF',
  `tax_amount` decimal(8,2) DEFAULT 0.00 COMMENT 'Tax amount in XAF',
  `delivery_fee` decimal(6,2) DEFAULT 0.00 COMMENT 'Delivery fee in XAF',
  `service_fee` decimal(6,2) DEFAULT 0.00 COMMENT 'Platform service fee in XAF',
  `discount_amount` decimal(8,2) DEFAULT 0.00 COMMENT 'Discount amount in XAF',
  `affiliate_commission` decimal(8,2) DEFAULT 0.00 COMMENT 'Affiliate commission in XAF',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'Final total in XAF',
  `currency` varchar(3) DEFAULT 'XAF',
  `delivery_address` json NOT NULL COMMENT 'Full delivery address with coordinates',
  `delivery_instructions` text DEFAULT NULL,
  `estimated_delivery_time` timestamp NULL DEFAULT NULL,
  `actual_delivery_time` timestamp NULL DEFAULT NULL,
  `preparation_time` int(11) DEFAULT NULL COMMENT 'Estimated prep time in minutes',
  `delivery_distance` decimal(5,2) DEFAULT NULL COMMENT 'Distance in KM',
  `coupon_code` varchar(50) DEFAULT NULL,
  `special_instructions` text DEFAULT NULL,
  `rating` tinyint(1) DEFAULT NULL COMMENT '1-5 star rating',
  `review` text DEFAULT NULL,
  `cancellation_reason` text DEFAULT NULL,
  `refund_amount` decimal(10,2) DEFAULT 0.00,
  `refund_reason` text DEFAULT NULL,
  `tracking_data` json DEFAULT NULL COMMENT 'Real-time tracking information',
  `metadata` json DEFAULT NULL COMMENT 'Additional order metadata',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orders_order_number_unique` (`order_number`),
  KEY `orders_customer_id_index` (`customer_id`),
  KEY `orders_restaurant_id_index` (`restaurant_id`),
  KEY `orders_rider_id_index` (`rider_id`),
  KEY `orders_affiliate_id_index` (`affiliate_id`),
  KEY `orders_status_index` (`status`),
  KEY `orders_payment_status_index` (`payment_status`),
  KEY `orders_payment_method_index` (`payment_method`),
  KEY `orders_created_at_index` (`created_at`),
  KEY `orders_total_amount_index` (`total_amount`),
  KEY `orders_deleted_at_index` (`deleted_at`),
  CONSTRAINT `orders_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `orders_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `orders_rider_id_foreign` FOREIGN KEY (`rider_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_affiliate_id_foreign` FOREIGN KEY (`affiliate_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Order items with detailed item information
CREATE TABLE `order_items` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `menu_item_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `unit_price` decimal(8,2) NOT NULL COMMENT 'Price per unit in XAF',
  `total_price` decimal(8,2) NOT NULL COMMENT 'Total price for this item in XAF',
  `special_instructions` text DEFAULT NULL,
  `variants` json DEFAULT NULL COMMENT 'Selected variants/customizations',
  `item_snapshot` json NOT NULL COMMENT 'Menu item details at time of order',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `order_items_order_id_index` (`order_id`),
  KEY `order_items_menu_item_id_index` (`menu_item_id`),
  CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_menu_item_id_foreign` FOREIGN KEY (`menu_item_id`) REFERENCES `menu_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Order status history for tracking
CREATE TABLE `order_status_history` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `status` varchar(50) NOT NULL,
  `notes` text DEFAULT NULL,
  `changed_by` bigint(20) UNSIGNED DEFAULT NULL,
  `location` json DEFAULT NULL COMMENT 'GPS coordinates when status changed',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `order_status_history_order_id_index` (`order_id`),
  KEY `order_status_history_status_index` (`status`),
  KEY `order_status_history_changed_by_index` (`changed_by`),
  KEY `order_status_history_created_at_index` (`created_at`),
  CONSTRAINT `order_status_history_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_status_history_changed_by_foreign` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- DELIVERY SYSTEM TABLES
-- ============================================================================

-- Deliveries table for detailed delivery tracking
CREATE TABLE `deliveries` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `rider_id` bigint(20) UNSIGNED NOT NULL,
  `pickup_address` json NOT NULL COMMENT 'Restaurant address with coordinates',
  `delivery_address` json NOT NULL COMMENT 'Customer address with coordinates',
  `distance` decimal(5,2) NOT NULL COMMENT 'Delivery distance in KM',
  `estimated_duration` int(11) NOT NULL COMMENT 'Estimated delivery time in minutes',
  `actual_duration` int(11) DEFAULT NULL COMMENT 'Actual delivery time in minutes',
  `pickup_time` timestamp NULL DEFAULT NULL,
  `delivery_time` timestamp NULL DEFAULT NULL,
  `delivery_fee` decimal(6,2) NOT NULL COMMENT 'Delivery fee in XAF',
  `rider_earnings` decimal(6,2) NOT NULL COMMENT 'Rider earnings in XAF',
  `platform_commission` decimal(6,2) NOT NULL COMMENT 'Platform commission in XAF',
  `status` enum('assigned','accepted','picked_up','on_the_way','delivered','cancelled') NOT NULL DEFAULT 'assigned',
  `cancellation_reason` text DEFAULT NULL,
  `delivery_proof` varchar(255) DEFAULT NULL COMMENT 'Photo proof of delivery',
  `customer_signature` text DEFAULT NULL COMMENT 'Digital signature',
  `rating` tinyint(1) DEFAULT NULL COMMENT '1-5 star rating from customer',
  `review` text DEFAULT NULL,
  `rider_notes` text DEFAULT NULL,
  `tracking_data` json DEFAULT NULL COMMENT 'Real-time GPS tracking data',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `deliveries_order_id_unique` (`order_id`),
  KEY `deliveries_rider_id_index` (`rider_id`),
  KEY `deliveries_status_index` (`status`),
  KEY `deliveries_pickup_time_index` (`pickup_time`),
  KEY `deliveries_delivery_time_index` (`delivery_time`),
  KEY `deliveries_created_at_index` (`created_at`),
  CONSTRAINT `deliveries_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `deliveries_rider_id_foreign` FOREIGN KEY (`rider_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Rider schedules and availability
CREATE TABLE `rider_schedules` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `rider_id` bigint(20) UNSIGNED NOT NULL,
  `day_of_week` tinyint(1) NOT NULL COMMENT '0=Sunday, 1=Monday, ..., 6=Saturday',
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `is_available` boolean DEFAULT TRUE,
  `max_orders` int(11) DEFAULT 10 COMMENT 'Maximum concurrent orders',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rider_schedules_rider_day_unique` (`rider_id`, `day_of_week`),
  KEY `rider_schedules_rider_id_index` (`rider_id`),
  KEY `rider_schedules_day_of_week_index` (`day_of_week`),
  KEY `rider_schedules_is_available_index` (`is_available`),
  CONSTRAINT `rider_schedules_rider_id_foreign` FOREIGN KEY (`rider_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Rider locations for real-time tracking
CREATE TABLE `rider_locations` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `rider_id` bigint(20) UNSIGNED NOT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `accuracy` decimal(5,2) DEFAULT NULL COMMENT 'GPS accuracy in meters',
  `speed` decimal(5,2) DEFAULT NULL COMMENT 'Speed in km/h',
  `heading` decimal(5,2) DEFAULT NULL COMMENT 'Direction in degrees',
  `is_online` boolean DEFAULT TRUE,
  `battery_level` tinyint(3) DEFAULT NULL COMMENT 'Device battery percentage',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `rider_locations_rider_id_index` (`rider_id`),
  KEY `rider_locations_is_online_index` (`is_online`),
  KEY `rider_locations_created_at_index` (`created_at`),
  KEY `rider_locations_location_index` (`latitude`, `longitude`),
  CONSTRAINT `rider_locations_rider_id_foreign` FOREIGN KEY (`rider_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- AFFILIATE SYSTEM TABLES
-- ============================================================================

-- Affiliates tracking and management
CREATE TABLE `affiliates` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `referrer_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Who referred this affiliate',
  `affiliate_code` varchar(20) NOT NULL UNIQUE,
  `commission_rate` decimal(5,4) NOT NULL DEFAULT 0.0500 COMMENT 'Commission rate (5%)',
  `total_referrals` int(11) DEFAULT 0,
  `total_orders` int(11) DEFAULT 0,
  `total_earnings` decimal(12,2) DEFAULT 0.00 COMMENT 'Total earnings in XAF',
  `paid_earnings` decimal(12,2) DEFAULT 0.00 COMMENT 'Already paid earnings in XAF',
  `pending_earnings` decimal(12,2) DEFAULT 0.00 COMMENT 'Pending earnings in XAF',
  `status` enum('active','inactive','suspended') NOT NULL DEFAULT 'active',
  `payment_method` enum('bank_transfer','mobile_money','cash') DEFAULT 'mobile_money',
  `payment_details` json DEFAULT NULL COMMENT 'Payment account details',
  `last_payout_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `affiliates_user_id_unique` (`user_id`),
  UNIQUE KEY `affiliates_affiliate_code_unique` (`affiliate_code`),
  KEY `affiliates_referrer_id_index` (`referrer_id`),
  KEY `affiliates_status_index` (`status`),
  KEY `affiliates_total_earnings_index` (`total_earnings`),
  KEY `affiliates_deleted_at_index` (`deleted_at`),
  CONSTRAINT `affiliates_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `affiliates_referrer_id_foreign` FOREIGN KEY (`referrer_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Affiliate referrals tracking
CREATE TABLE `affiliate_referrals` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `affiliate_id` bigint(20) UNSIGNED NOT NULL,
  `referred_user_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'First order that generated commission',
  `commission_amount` decimal(8,2) DEFAULT 0.00 COMMENT 'Commission earned in XAF',
  `commission_rate` decimal(5,4) NOT NULL COMMENT 'Rate used for this referral',
  `status` enum('pending','confirmed','paid','cancelled') NOT NULL DEFAULT 'pending',
  `confirmed_at` timestamp NULL DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `affiliate_referrals_affiliate_user_unique` (`affiliate_id`, `referred_user_id`),
  KEY `affiliate_referrals_affiliate_id_index` (`affiliate_id`),
  KEY `affiliate_referrals_referred_user_id_index` (`referred_user_id`),
  KEY `affiliate_referrals_order_id_index` (`order_id`),
  KEY `affiliate_referrals_status_index` (`status`),
  KEY `affiliate_referrals_created_at_index` (`created_at`),
  CONSTRAINT `affiliate_referrals_affiliate_id_foreign` FOREIGN KEY (`affiliate_id`) REFERENCES `affiliates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `affiliate_referrals_referred_user_id_foreign` FOREIGN KEY (`referred_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `affiliate_referrals_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Affiliate payouts
CREATE TABLE `affiliate_payouts` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `affiliate_id` bigint(20) UNSIGNED NOT NULL,
  `amount` decimal(10,2) NOT NULL COMMENT 'Payout amount in XAF',
  `method` enum('bank_transfer','mobile_money','cash') NOT NULL,
  `reference_number` varchar(100) DEFAULT NULL,
  `status` enum('pending','processing','completed','failed','cancelled') NOT NULL DEFAULT 'pending',
  `processed_at` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `affiliate_payouts_affiliate_id_index` (`affiliate_id`),
  KEY `affiliate_payouts_status_index` (`status`),
  KEY `affiliate_payouts_created_at_index` (`created_at`),
  CONSTRAINT `affiliate_payouts_affiliate_id_foreign` FOREIGN KEY (`affiliate_id`) REFERENCES `affiliates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- PAYMENT SYSTEM TABLES
-- ============================================================================

-- Payment methods for users
CREATE TABLE `payment_methods` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `type` enum('card','mobile_money','bank_account','paypal') NOT NULL,
  `provider` varchar(50) NOT NULL COMMENT 'stripe, orange_money, mtn_momo, paypal, etc.',
  `name` varchar(100) NOT NULL COMMENT 'User-friendly name',
  `details` json NOT NULL COMMENT 'Encrypted payment details',
  `is_default` boolean DEFAULT FALSE,
  `is_verified` boolean DEFAULT FALSE,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_methods_user_id_index` (`user_id`),
  KEY `payment_methods_type_index` (`type`),
  KEY `payment_methods_provider_index` (`provider`),
  KEY `payment_methods_is_default_index` (`is_default`),
  KEY `payment_methods_deleted_at_index` (`deleted_at`),
  CONSTRAINT `payment_methods_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Payments and transactions
CREATE TABLE `payments` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) UNSIGNED DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `payment_method_id` bigint(20) UNSIGNED DEFAULT NULL,
  `transaction_id` varchar(255) NOT NULL UNIQUE COMMENT 'External transaction ID',
  `reference_number` varchar(100) NOT NULL UNIQUE COMMENT 'Internal reference',
  `type` enum('payment','refund','payout','commission','affiliate_payout') NOT NULL DEFAULT 'payment',
  `method` enum('cash','card','mobile_money','orange_money','mtn_momo','paypal','stripe','bank_transfer') NOT NULL,
  `provider` varchar(50) DEFAULT NULL COMMENT 'Payment gateway provider',
  `amount` decimal(10,2) NOT NULL COMMENT 'Amount in XAF',
  `currency` varchar(3) DEFAULT 'XAF',
  `fee` decimal(8,2) DEFAULT 0.00 COMMENT 'Transaction fee in XAF',
  `net_amount` decimal(10,2) NOT NULL COMMENT 'Amount after fees in XAF',
  `status` enum('pending','processing','completed','failed','cancelled','refunded') NOT NULL DEFAULT 'pending',
  `gateway_response` json DEFAULT NULL COMMENT 'Payment gateway response',
  `failure_reason` text DEFAULT NULL,
  `processed_at` timestamp NULL DEFAULT NULL,
  `refunded_at` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payments_transaction_id_unique` (`transaction_id`),
  UNIQUE KEY `payments_reference_number_unique` (`reference_number`),
  KEY `payments_order_id_index` (`order_id`),
  KEY `payments_user_id_index` (`user_id`),
  KEY `payments_payment_method_id_index` (`payment_method_id`),
  KEY `payments_type_index` (`type`),
  KEY `payments_method_index` (`method`),
  KEY `payments_status_index` (`status`),
  KEY `payments_created_at_index` (`created_at`),
  CONSTRAINT `payments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `payments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payments_payment_method_id_foreign` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- REVIEW AND RATING SYSTEM
-- ============================================================================

-- Reviews for restaurants and menu items
CREATE TABLE `reviews` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED DEFAULT NULL,
  `reviewable_type` enum('restaurant','menu_item','rider') NOT NULL,
  `reviewable_id` bigint(20) UNSIGNED NOT NULL,
  `rating` tinyint(1) NOT NULL COMMENT '1-5 star rating',
  `title` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `images` json DEFAULT NULL COMMENT 'Review images',
  `is_verified` boolean DEFAULT FALSE COMMENT 'Verified purchase review',
  `is_featured` boolean DEFAULT FALSE,
  `helpful_count` int(11) DEFAULT 0,
  `unhelpful_count` int(11) DEFAULT 0,
  `status` enum('pending','approved','rejected','hidden') NOT NULL DEFAULT 'pending',
  `moderated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `moderated_at` timestamp NULL DEFAULT NULL,
  `moderation_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reviews_user_id_index` (`user_id`),
  KEY `reviews_order_id_index` (`order_id`),
  KEY `reviews_reviewable_index` (`reviewable_type`, `reviewable_id`),
  KEY `reviews_rating_index` (`rating`),
  KEY `reviews_status_index` (`status`),
  KEY `reviews_is_verified_index` (`is_verified`),
  KEY `reviews_is_featured_index` (`is_featured`),
  KEY `reviews_created_at_index` (`created_at`),
  KEY `reviews_deleted_at_index` (`deleted_at`),
  CONSTRAINT `reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviews_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `reviews_moderated_by_foreign` FOREIGN KEY (`moderated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Review helpfulness votes
CREATE TABLE `review_votes` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `review_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `vote` enum('helpful','unhelpful') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `review_votes_review_user_unique` (`review_id`, `user_id`),
  KEY `review_votes_review_id_index` (`review_id`),
  KEY `review_votes_user_id_index` (`user_id`),
  KEY `review_votes_vote_index` (`vote`),
  CONSTRAINT `review_votes_review_id_foreign` FOREIGN KEY (`review_id`) REFERENCES `reviews` (`id`) ON DELETE CASCADE,
  CONSTRAINT `review_votes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- NOTIFICATION AND MESSAGING SYSTEM
-- ============================================================================

-- Popup notifications for users
CREATE TABLE `popup_notifications` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'NULL for global notifications',
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','success','warning','error','promotion') NOT NULL DEFAULT 'info',
  `action_url` varchar(500) DEFAULT NULL,
  `action_text` varchar(100) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `priority` enum('low','normal','high','urgent') NOT NULL DEFAULT 'normal',
  `is_read` boolean DEFAULT FALSE,
  `is_dismissed` boolean DEFAULT FALSE,
  `expires_at` timestamp NULL DEFAULT NULL,
  `conditions` json DEFAULT NULL COMMENT 'Display conditions (user role, location, etc.)',
  `metadata` json DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `popup_notifications_user_id_index` (`user_id`),
  KEY `popup_notifications_type_index` (`type`),
  KEY `popup_notifications_priority_index` (`priority`),
  KEY `popup_notifications_is_read_index` (`is_read`),
  KEY `popup_notifications_expires_at_index` (`expires_at`),
  KEY `popup_notifications_created_at_index` (`created_at`),
  KEY `popup_notifications_deleted_at_index` (`deleted_at`),
  CONSTRAINT `popup_notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Messages between users (customer support, rider communication)
CREATE TABLE `messages` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `conversation_id` varchar(100) NOT NULL COMMENT 'Unique conversation identifier',
  `sender_id` bigint(20) UNSIGNED NOT NULL,
  `recipient_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Related order if applicable',
  `message` text NOT NULL,
  `message_type` enum('text','image','file','location','system') NOT NULL DEFAULT 'text',
  `attachments` json DEFAULT NULL,
  `is_read` boolean DEFAULT FALSE,
  `read_at` timestamp NULL DEFAULT NULL,
  `is_system_message` boolean DEFAULT FALSE,
  `metadata` json DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `messages_conversation_id_index` (`conversation_id`),
  KEY `messages_sender_id_index` (`sender_id`),
  KEY `messages_recipient_id_index` (`recipient_id`),
  KEY `messages_order_id_index` (`order_id`),
  KEY `messages_is_read_index` (`is_read`),
  KEY `messages_created_at_index` (`created_at`),
  KEY `messages_deleted_at_index` (`deleted_at`),
  CONSTRAINT `messages_sender_id_foreign` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `messages_recipient_id_foreign` FOREIGN KEY (`recipient_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `messages_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- USER INTERACTION TABLES
-- ============================================================================

-- Wishlists/Favorites
CREATE TABLE `wishlists` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `wishlistable_type` enum('restaurant','menu_item') NOT NULL,
  `wishlistable_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wishlists_user_wishlistable_unique` (`user_id`, `wishlistable_type`, `wishlistable_id`),
  KEY `wishlists_user_id_index` (`user_id`),
  KEY `wishlists_wishlistable_index` (`wishlistable_type`, `wishlistable_id`),
  KEY `wishlists_created_at_index` (`created_at`),
  CONSTRAINT `wishlists_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Shopping cart (persistent cart)
CREATE TABLE `cart_items` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `menu_item_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `variants` json DEFAULT NULL COMMENT 'Selected variants/customizations',
  `special_instructions` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cart_items_user_menu_item_unique` (`user_id`, `menu_item_id`),
  KEY `cart_items_user_id_index` (`user_id`),
  KEY `cart_items_menu_item_id_index` (`menu_item_id`),
  CONSTRAINT `cart_items_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_items_menu_item_id_foreign` FOREIGN KEY (`menu_item_id`) REFERENCES `menu_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- DISPUTE AND SUPPORT SYSTEM
-- ============================================================================

-- Disputes for orders and deliveries
CREATE TABLE `disputes` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `restaurant_id` bigint(20) UNSIGNED DEFAULT NULL,
  `rider_id` bigint(20) UNSIGNED DEFAULT NULL,
  `assigned_to` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Admin handling the dispute',
  `type` enum('order_issue','delivery_issue','payment_issue','quality_issue','missing_items','wrong_order','late_delivery','damaged_food','refund_request','other') NOT NULL,
  `subject` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `evidence` json DEFAULT NULL COMMENT 'Photos, documents, etc.',
  `status` enum('open','investigating','resolved','closed','escalated') NOT NULL DEFAULT 'open',
  `priority` enum('low','normal','high','urgent') NOT NULL DEFAULT 'normal',
  `resolution` text DEFAULT NULL,
  `refund_amount` decimal(10,2) DEFAULT 0.00,
  `compensation` json DEFAULT NULL COMMENT 'Credits, vouchers, etc.',
  `resolved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `disputes_order_id_index` (`order_id`),
  KEY `disputes_customer_id_index` (`customer_id`),
  KEY `disputes_restaurant_id_index` (`restaurant_id`),
  KEY `disputes_rider_id_index` (`rider_id`),
  KEY `disputes_assigned_to_index` (`assigned_to`),
  KEY `disputes_type_index` (`type`),
  KEY `disputes_status_index` (`status`),
  KEY `disputes_priority_index` (`priority`),
  KEY `disputes_created_at_index` (`created_at`),
  CONSTRAINT `disputes_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `disputes_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `disputes_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE SET NULL,
  CONSTRAINT `disputes_rider_id_foreign` FOREIGN KEY (`rider_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `disputes_assigned_to_foreign` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- SYSTEM CONFIGURATION TABLES
-- ============================================================================

-- Site settings and configuration
CREATE TABLE `site_settings` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `key` varchar(100) NOT NULL UNIQUE,
  `value` longtext DEFAULT NULL,
  `type` enum('string','integer','float','boolean','json','text') NOT NULL DEFAULT 'string',
  `group` varchar(50) DEFAULT 'general',
  `description` text DEFAULT NULL,
  `is_public` boolean DEFAULT FALSE COMMENT 'Can be accessed by frontend',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `site_settings_key_unique` (`key`),
  KEY `site_settings_group_index` (`group`),
  KEY `site_settings_is_public_index` (`is_public`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- System logs for debugging and monitoring
CREATE TABLE `logs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `level` enum('emergency','alert','critical','error','warning','notice','info','debug') NOT NULL,
  `message` text NOT NULL,
  `context` json DEFAULT NULL,
  `channel` varchar(50) DEFAULT 'app',
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `url` varchar(500) DEFAULT NULL,
  `method` varchar(10) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `logs_level_index` (`level`),
  KEY `logs_channel_index` (`channel`),
  KEY `logs_user_id_index` (`user_id`),
  KEY `logs_created_at_index` (`created_at`),
  CONSTRAINT `logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Coupons and promotions
CREATE TABLE `coupons` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL UNIQUE,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('fixed','percentage','free_delivery') NOT NULL,
  `value` decimal(8,2) NOT NULL COMMENT 'Discount amount or percentage',
  `minimum_order` decimal(8,2) DEFAULT 0.00 COMMENT 'Minimum order amount in XAF',
  `maximum_discount` decimal(8,2) DEFAULT NULL COMMENT 'Maximum discount amount in XAF',
  `usage_limit` int(11) DEFAULT NULL COMMENT 'Total usage limit',
  `usage_limit_per_user` int(11) DEFAULT 1,
  `used_count` int(11) DEFAULT 0,
  `applicable_to` enum('all','restaurants','menu_items','users') NOT NULL DEFAULT 'all',
  `applicable_ids` json DEFAULT NULL COMMENT 'Specific restaurant/item/user IDs',
  `starts_at` timestamp NOT NULL,
  `expires_at` timestamp NOT NULL,
  `is_active` boolean DEFAULT TRUE,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `coupons_code_unique` (`code`),
  KEY `coupons_type_index` (`type`),
  KEY `coupons_is_active_index` (`is_active`),
  KEY `coupons_starts_at_index` (`starts_at`),
  KEY `coupons_expires_at_index` (`expires_at`),
  KEY `coupons_created_by_index` (`created_by`),
  KEY `coupons_deleted_at_index` (`deleted_at`),
  CONSTRAINT `coupons_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Coupon usage tracking
CREATE TABLE `coupon_usages` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `coupon_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `discount_amount` decimal(8,2) NOT NULL COMMENT 'Actual discount applied in XAF',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `coupon_usages_coupon_id_index` (`coupon_id`),
  KEY `coupon_usages_user_id_index` (`user_id`),
  KEY `coupon_usages_order_id_index` (`order_id`),
  KEY `coupon_usages_created_at_index` (`created_at`),
  CONSTRAINT `coupon_usages_coupon_id_foreign` FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `coupon_usages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `coupon_usages_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- ANALYTICS AND REPORTING TABLES
-- ============================================================================

-- Analytics data for dynamic queries and reporting
CREATE TABLE `analytics` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `metric_name` varchar(100) NOT NULL,
  `metric_value` decimal(15,4) NOT NULL,
  `dimensions` json DEFAULT NULL COMMENT 'Breakdown dimensions (user_id, restaurant_id, date, etc.)',
  `date` date NOT NULL,
  `hour` tinyint(2) DEFAULT NULL COMMENT '0-23 for hourly metrics',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `analytics_metric_name_index` (`metric_name`),
  KEY `analytics_date_index` (`date`),
  KEY `analytics_hour_index` (`hour`),
  KEY `analytics_metric_date_index` (`metric_name`, `date`),
  KEY `analytics_created_at_index` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Daily aggregated statistics for performance
CREATE TABLE `daily_stats` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `restaurant_id` bigint(20) UNSIGNED DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `total_orders` int(11) DEFAULT 0,
  `total_revenue` decimal(12,2) DEFAULT 0.00,
  `total_commission` decimal(10,2) DEFAULT 0.00,
  `total_deliveries` int(11) DEFAULT 0,
  `average_order_value` decimal(8,2) DEFAULT 0.00,
  `average_delivery_time` int(11) DEFAULT 0 COMMENT 'Average delivery time in minutes',
  `customer_satisfaction` decimal(3,2) DEFAULT 0.00 COMMENT 'Average rating',
  `new_customers` int(11) DEFAULT 0,
  `returning_customers` int(11) DEFAULT 0,
  `cancelled_orders` int(11) DEFAULT 0,
  `refunded_orders` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `daily_stats_date_restaurant_user_unique` (`date`, `restaurant_id`, `user_id`),
  KEY `daily_stats_date_index` (`date`),
  KEY `daily_stats_restaurant_id_index` (`restaurant_id`),
  KEY `daily_stats_user_id_index` (`user_id`),
  CONSTRAINT `daily_stats_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `daily_stats_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- PERFORMANCE INDEXES AND OPTIMIZATIONS
-- ============================================================================

-- Additional composite indexes for common queries
CREATE INDEX idx_orders_customer_status_date ON orders (customer_id, status, created_at);
CREATE INDEX idx_orders_restaurant_status_date ON orders (restaurant_id, status, created_at);
CREATE INDEX idx_orders_rider_status_date ON orders (rider_id, status, created_at);
CREATE INDEX idx_menu_items_restaurant_available ON menu_items (restaurant_id, is_available, sort_order);
CREATE INDEX idx_reviews_reviewable_rating ON reviews (reviewable_type, reviewable_id, rating, status);
CREATE INDEX idx_payments_user_status_date ON payments (user_id, status, created_at);
CREATE INDEX idx_deliveries_rider_status_date ON deliveries (rider_id, status, created_at);
CREATE INDEX idx_affiliate_referrals_affiliate_status ON affiliate_referrals (affiliate_id, status, created_at);

-- Full-text search indexes
ALTER TABLE restaurants ADD FULLTEXT(name, description, cuisine_type, tags);
ALTER TABLE menu_items ADD FULLTEXT(name, description, ingredients);
ALTER TABLE categories ADD FULLTEXT(name, description);

-- ============================================================================
-- AUTO-INCREMENT STARTING VALUES
-- ============================================================================

ALTER TABLE users AUTO_INCREMENT = 1000;
ALTER TABLE restaurants AUTO_INCREMENT = 100;
ALTER TABLE menu_items AUTO_INCREMENT = 1000;
ALTER TABLE orders AUTO_INCREMENT = 10000;
ALTER TABLE categories AUTO_INCREMENT = 10;

-- ============================================================================
-- TRIGGERS FOR AUTOMATIC CALCULATIONS
-- ============================================================================

DELIMITER $$

-- Update restaurant rating when review is added/updated
CREATE TRIGGER update_restaurant_rating_after_review_insert
AFTER INSERT ON reviews
FOR EACH ROW
BEGIN
    IF NEW.reviewable_type = 'restaurant' AND NEW.status = 'approved' THEN
        UPDATE restaurants
        SET rating = (
            SELECT AVG(rating)
            FROM reviews
            WHERE reviewable_type = 'restaurant'
            AND reviewable_id = NEW.reviewable_id
            AND status = 'approved'
        ),
        total_reviews = (
            SELECT COUNT(*)
            FROM reviews
            WHERE reviewable_type = 'restaurant'
            AND reviewable_id = NEW.reviewable_id
            AND status = 'approved'
        )
        WHERE id = NEW.reviewable_id;
    END IF;
END$$

-- Update menu item rating when review is added/updated
CREATE TRIGGER update_menu_item_rating_after_review_insert
AFTER INSERT ON reviews
FOR EACH ROW
BEGIN
    IF NEW.reviewable_type = 'menu_item' AND NEW.status = 'approved' THEN
        UPDATE menu_items
        SET rating = (
            SELECT AVG(rating)
            FROM reviews
            WHERE reviewable_type = 'menu_item'
            AND reviewable_id = NEW.reviewable_id
            AND status = 'approved'
        ),
        total_reviews = (
            SELECT COUNT(*)
            FROM reviews
            WHERE reviewable_type = 'menu_item'
            AND reviewable_id = NEW.reviewable_id
            AND status = 'approved'
        )
        WHERE id = NEW.reviewable_id;
    END IF;
END$$

-- Update order total when order items change
CREATE TRIGGER update_order_total_after_item_insert
AFTER INSERT ON order_items
FOR EACH ROW
BEGIN
    UPDATE orders
    SET subtotal = (
        SELECT SUM(total_price)
        FROM order_items
        WHERE order_id = NEW.order_id
    )
    WHERE id = NEW.order_id;

    UPDATE orders
    SET total_amount = subtotal + delivery_fee + service_fee + tax_amount - discount_amount
    WHERE id = NEW.order_id;
END$$

-- Update affiliate earnings when order is completed
CREATE TRIGGER update_affiliate_earnings_after_order_complete
AFTER UPDATE ON orders
FOR EACH ROW
BEGIN
    IF NEW.status = 'delivered' AND OLD.status != 'delivered' AND NEW.affiliate_id IS NOT NULL THEN
        UPDATE users
        SET total_earnings = total_earnings + NEW.affiliate_commission,
            balance = balance + NEW.affiliate_commission
        WHERE id = NEW.affiliate_id;

        UPDATE affiliates
        SET total_earnings = total_earnings + NEW.affiliate_commission,
            pending_earnings = pending_earnings + NEW.affiliate_commission,
            total_orders = total_orders + 1
        WHERE user_id = NEW.affiliate_id;
    END IF;
END$$

-- Update restaurant total orders when order is completed
CREATE TRIGGER update_restaurant_stats_after_order_complete
AFTER UPDATE ON orders
FOR EACH ROW
BEGIN
    IF NEW.status = 'delivered' AND OLD.status != 'delivered' THEN
        UPDATE restaurants
        SET total_orders = total_orders + 1
        WHERE id = NEW.restaurant_id;
    END IF;
END$$

DELIMITER ;

-- ============================================================================
-- SAMPLE DATA FOR DEVELOPMENT
-- ============================================================================

-- Insert default categories
INSERT INTO categories (name, slug, description, icon, sort_order, is_active) VALUES
('Fast Food', 'fast-food', 'Quick and delicious fast food options', 'fast-food', 1, TRUE),
('African Cuisine', 'african-cuisine', 'Traditional African dishes', 'restaurant', 2, TRUE),
('Chinese', 'chinese', 'Authentic Chinese cuisine', 'rice-bowl', 3, TRUE),
('Pizza', 'pizza', 'Fresh pizzas with various toppings', 'pizza', 4, TRUE),
('Beverages', 'beverages', 'Refreshing drinks and beverages', 'coffee', 5, TRUE),
('Desserts', 'desserts', 'Sweet treats and desserts', 'cake', 6, TRUE),
('Healthy', 'healthy', 'Nutritious and healthy meal options', 'leaf', 7, TRUE),
('Breakfast', 'breakfast', 'Morning breakfast options', 'sunrise', 8, TRUE);

-- Insert default site settings
INSERT INTO site_settings (`key`, `value`, `type`, `group`, `description`, `is_public`) VALUES
('site_name', 'Time2Eat', 'string', 'general', 'Website name', TRUE),
('site_description', 'Bamenda Food Delivery Platform', 'string', 'general', 'Website description', TRUE),
('contact_email', 'info@time2eat.cm', 'string', 'contact', 'Contact email address', TRUE),
('contact_phone', '+237 6XX XXX XXX', 'string', 'contact', 'Contact phone number', TRUE),
('contact_address', 'Bamenda, North West Region, Cameroon', 'string', 'contact', 'Physical address', TRUE),
('delivery_fee', '500', 'integer', 'business', 'Default delivery fee in XAF', FALSE),
('free_delivery_threshold', '5000', 'integer', 'business', 'Free delivery threshold in XAF', FALSE),
('commission_rate', '0.15', 'float', 'business', 'Platform commission rate (15%)', FALSE),
('tax_rate', '0.1925', 'float', 'business', 'Tax rate (19.25% VAT)', FALSE),
('currency', 'XAF', 'string', 'business', 'Default currency', TRUE),
('timezone', 'Africa/Douala', 'string', 'general', 'Application timezone', FALSE),
('maintenance_mode', 'false', 'boolean', 'system', 'Maintenance mode status', FALSE),
('allow_registration', 'true', 'boolean', 'auth', 'Allow new user registration', FALSE),
('email_verification_required', 'true', 'boolean', 'auth', 'Require email verification', FALSE),
('max_delivery_distance', '15', 'integer', 'business', 'Maximum delivery distance in KM', FALSE);

-- Enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
